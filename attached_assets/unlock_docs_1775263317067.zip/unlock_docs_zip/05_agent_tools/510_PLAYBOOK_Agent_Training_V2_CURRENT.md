> **V4 NOTE:** Updated March 2026. All investment instrument references use "Instant Investment". Pricing updated to current tiers (£99/£249). Campaign dates updated.

# Unlock Agent Training Script & Daily Operations
## Ready-to-Use Agent Playbook

---

## Part 1: Agent Training (2 Hours)

### Module 1: Company Overview (30 min)

**What is Unlock?**

"Unlock is an investment intelligence platform for private investors like HNW individuals. Think of it as a portfolio OS—it gives investors:
- Full portfolio visibility (across multiple providers + accounts)
- AI-powered scenario simulation (what-if analysis)
- Syndicate access (vetted deals at transparent fees)
- Tax efficiency tools (EIS/SEIS optimization + inheritance planning)

Why now?
- Technology: AI makes institutional-grade analysis affordable
- Market gap: No independent investor-first tool like this exists
- Policy: UK's EIS/SEIS tax incentives make early-stage investing attractive
- Traction: 2,500 alpha users, £172K run rate, multiple founder commitments

Our mission: Give private investors the same clarity, tools, and protections that institutions take for granted.

**Key stat to remember:** "Investors using Unlock are seeing 10–20% uplift in portfolio performance annually because fragmentation was costing them money."

---

### Module 2: Three Investor Personas (20 min)

**The Preserver** (30% of HNW investors)
- Motivation: Protect wealth, minimize downside, sleep at night
- Language: "capital protection," "risk controls," "validation," "peace of mind"
- Pain points: Fragmented tools, poor downside modeling, conflicted advice
- How Unlock helps: Portfolio stress-test + scenario modeling = confidence in risk controls
- Example: "A 55-year-old retired executive worried about property market crash—Unlock models 'what if property falls 30%?' and shows portfolio resilience."

**The Growth Seeker** (40% of HNW investors)
- Motivation: Long-term wealth growth with calculated risk
- Language: "upside," "opportunity," "transparency," "syndicates," "deal flow"
- Pain points: Lack of transparency in deals, retail tools, crowdfunding dilution
- How Unlock helps: Syndicate access at 8–10% (vs 9–14% competitors) + portfolio simulation
- Example: "A 45-year-old entrepreneur wants to deploy £500K in growth opportunities—Unlock shows which asset classes to add and gives access to curated syndicates."

**The Legacy Builder** (30% of HNW investors)
- Motivation: Plan intergenerational wealth transfer, tax efficiency
- Language: "inheritance," "tax efficiency," "family," "succession," "legacy"
- Pain points: Complex tax planning, unclear family wealth scenarios
- How Unlock helps: EIS/SEIS integration + family wealth modeling + inheritance tax planning
- Example: "A 60-year-old business owner exiting—Unlock optimizes tax relief timing across multiple investments to reduce inheritance tax by 15–20%."

**Key script phrase:** "Most investors I speak with fit one of three profiles: Preservers who want peace of mind, Growth Seekers hunting for transparency in deal flow, or Legacy Builders optimizing for family outcomes. Which of those resonates most with you?"

---

### Module 3: EIS/SEIS Tax Relief (20 min) - THE MOST IMPORTANT PART

**What is EIS?**
- Government tax-advantaged investment scheme
- Invest in high-growth UK companies
- Claim **30% income tax relief** (spend £100K, claim £30K back from tax bill)
- Profits **free of Capital Gains Tax** (vs 20% normal CGT)
- Loss relief: If company fails, claim relief on net loss after income tax relief (at 45% rate on SEIS net cost = significant additional recovery)
- **Inheritance tax exempt** after 2 years

**What is SEIS?**
- Similar to EIS but for **earlier-stage** companies
- Higher relief: **50% income tax relief** (spend £100K, claim £50K back)
- Same CGT + loss relief + inheritance tax benefits
- Limited to £100K per person per year

**The key phrase agents MUST use:**
"In short, investors can claim back 30–50% of their investment, profits can be tax-free, and loss relief reduces downside further — for higher-rate or additional-rate taxpayers using SEIS, effective exposure can be as low as 20 pence on the pound."

**Worked example (memorize this):**
- Investor has £10K income tax bill
- Invests £50K in SEIS stock (gets 50% relief)
- Claims £25K tax relief
- Now owes £0 income tax (overpaid £15K to HMRC, refunded in 4 weeks)
- Effective investment cost: £50K – £25K = £25K (only 20p on the pound)
- If stock doubles: £100K profit, zero CGT owed
- If stock fails: Claim £40K loss relief against income, recover £12K tax

**Why this matters to investors:**
"Most investors don't realize their tax bill is a tool. Using EIS/SEIS, you can literally use your tax liability to fund growth investments with built-in downside protection."

---

### Module 4: The 16-Step Script Walkthrough (40 min)

**Read through all 16 steps aloud. Agents should memorize the flow, not word-for-word script.**

**STEPS 1–5: QUALIFICATION & CREDIBILITY**

**Step 1: Greeting & Context (30 sec)**
- Goal: Verify you have the right person
- Script: "Hi [Name], it's [Agent] calling from Unlock UK. I still have you down as [email]—is that still the right one?"
- Why: Confirms contact details + establishes professionalism
- If wrong number: "Sorry, wrong number. Have a good day." / Log in Pipedrive: "Wrong number"
- Listen for: Engagement tone (friendly = proceed, irritated = shorten call)

**Step 2: Introduce EIS/SEIS (60 sec)**
- Goal: Hook with tax relief benefit
- Script: "We focus on companies that qualify for EIS or SEIS—government schemes that let investors use their income tax to buy shares in high-growth UK companies. In short, investors can claim back 30–50% of their investment, profits can be tax-free, and loss relief reduces downside further — for higher-rate or additional-rate taxpayers using SEIS, effective exposure can be as low as 20 pence on the pound."
- Why: EIS/SEIS is the most compelling differentiator (no competitor offers this advantage)
- Listen for: Interest in tax benefit, or skepticism ("sounds too good to be true")
- If skepticism: "I know it sounds generous—it's been UK policy for 20 years to encourage investment in early-stage companies. Real companies like Revolut, BrewDog, Monzo all qualified."

**Step 3: Confirm Awareness & Risk Comfort (60 sec)**
- Goal: Build credibility with brand examples
- Script: "You've probably heard of Revolut, BrewDog, or Monzo—a few years back you could've literally used your tax bill to buy shares in those. The investor only risks about 20 pence on the pound after reliefs, and profits can be tax-free."
- Then ask: "That's the kind of risk-to-reward most investors would love—how do you feel about it?"
- Why: Social proof (big names) + risk framing (only 20p at risk)
- Listen for: "Sounds interesting" (move forward) vs "Too risky" (pivot to Preserver angle)

**Step 4: Common Starting Point (60 sec)**
- Goal: Anchor their experience in mainstream assets
- Script: "Most experienced investors I speak with started in the same place—ISAs, some stocks, maybe a property or two. All great when the economy's steady."
- Then ask: "How does your portfolio compare to that?"
- Why: Makes investor feel normal + opens door to pain discovery
- Listen for: Asset mix (ISAs, property, stocks, pensions) â†’ use this to personalize later steps
- If they say "My portfolio is more complex": "Perfect—sounds like you're already thinking beyond mainstream assets. That's why I'm calling."

**Step 5: Correlation & Inflation (60 sec)**
- Goal: Surface fragmentation pain
- Script: "Most people's investments are correlated. Even pensions. If there's a crash, those without proper diversification are going to be worst affected. Are you open to exploring how diversification can help you preserve your wealth during a downturn?"
- Then ask: "If markets and property prices crashed 30%—how well are you protected?"
- Why: Creates urgency + positions Unlock as solution
- Listen for: "I hadn't thought about that" (good, you're opening eyes) or "My advisor covers this" (acknowledge, then pivot to independence angle)

---

**STEPS 6–9: PAIN & SOLUTION**

**Step 6: Over-Concentration Reality (60 sec)**
- Goal: Validate their pain
- Script: "Here's what we see a lot: most investors end up heavily concentrated in the same asset classes—property, pensions, ISAs—all moving in the same direction. When interest rates shift or property markets wobble, their entire wealth picture is actually quite correlated."
- Then ask: "Can you relate to that?"
- Why: Frames problem as common + non-judgmental
- Listen for: "Yes, actually" (pain validated) or "No, I'm well-diversified" (different approach—pivot to opportunity angle)

**Step 7: Early-Stage Parallel & Unlock Intro (90 sec)** â­ CRITICAL STEP
- Goal: Introduce Unlock as solution
- Script: "Paradoxically, the same applies to early-stage companies—exciting, high-growth startups are rare, and you can't get formal advice on them. High Street banks and IFAs are restricted—they can't give advice on startups, gold, art, wine, anything other than mainstream financial products. That's where Unlock steps in—vetted early-stage opportunities plus the data and tools to manage them properly."
- Then ask: "How might visibility about a wider range of investment opportunities and investment strategies be useful to you?"
- Why: Explains WHY Unlock exists + positions as independent alternative to gatekeepers
- Listen for: "That would be useful" (moving toward engagement) or "I don't want startup risk" (Preserver angle—pivot to portfolio optimization)
- **If they push back on risk:** "I totally understand. Unlock isn't forcing you into anything. It's your platform to understand ALL your investments—whether you ever use syndicates or not. Think of it as your investment OS."

**Step 8: Identify Main Frustration (60 sec)**
- Goal: Surface specific pain
- Script: "Most investors hit a few walls: too many opportunities to evaluate, lack of visibility into their full portfolio, or complicated tax situations."
- Then ask: "Which if any do you relate to most?"
- Why: Narrows pain to one specific issue â†’ personalize later messaging
- Listen for: 
  - "Too many opportunities" â†’ Growth Seeker persona
  - "Lack of visibility" â†’ Preserver persona
  - "Tax complexity" â†’ Legacy Builder persona
- **Make a mental note of which frustration they mention—you'll reference it in Step 9.**

**Step 9: Unlock's Solution (90 sec)**
- Goal: Connect their specific pain to Unlock features
- Script: "That's exactly why Unlock exists—it gives you a full portfolio view, runs scenario simulations, and identifies hidden risks and opportunities across everything you hold—including EIS/SEIS. You don't even have to use the tool—you get all this in a monthly report personalised to your interests, goals, risk profile and experience. Knowledge is power in investing, and it's especially true when that knowledge is tailored to your situation."
- Then ask: "Can you see the benefits in having something like that?"
- Why: Directly addresses their pain + benefits-focused
- **Key personalization:**
  - If Growth Seeker: "...identifies hidden opportunities and deal flow you'd otherwise miss..."
  - If Preserver: "...identifies hidden risks in your portfolio so you can sleep at night..."
  - If Legacy Builder: "...optimizes your tax positioning across all your holdings..."
- Listen for: "Yes, that would be valuable" (strong buy signal) or "Maybe, butâ€¦" (objection incoming, prepare reframe)

---

**STEPS 10–14: CREDIBILITY & QUALIFICATION**

**Step 10: Market Uncertainty (60 sec)**
- Goal: Frame macro shift (creates openness to new ideas)
- Script: "We're at an interesting point—things that used to feel safe, like pensions, are now less predictable with rules changing constantly."
- Then ask: "Have you noticed that too in how returns or rules keep changing?"
- Why: Macro context + validation of need for new solutions
- Listen for: "Yeah, pensions are a mess" or "I'm not worried about that" (different positioning needed)

**Step 11: Independent Investor Type (60 sec)**
- Goal: Confirm they're independent-minded (not advisor-dependent)
- Script: "That's why many are looking beyond traditional products and starting to think more for themselves."
- Then ask: "Would you describe yourself as someone who prefers to make independent investment decisions?"
- Why: Filters for self-directed investors (Unlock's ideal customer)
- Listen for: "Yes, I do my own research" (perfect) or "I rely on my advisor" (acknowledge—offer advisor integration angle)
- **If advisor-dependent:** "That's great—Unlock isn't replacing your advisor. It's your intelligence layer so you can bring better data to those conversations."

**Step 12: Unlock Differentiation & Social Proof (90 sec)** â­ CREDIBILITY BOOST
- Goal: Establish credibility + differentiation
- Script: "Unlock isn't a fund or adviser—it's an independent intelligence platform built by investors, for investors. We're currently in early access, onboarding a limited number of private investors. Investors using the platform are seeing an average increase in overall performance and wealth of around 10–20% per year. One of our recent investors spent 20 years on the board of Barclays, worked with the Bank of England—he described Unlock as better than anything he'd seen in terms of supporting private investors."
- Then ask: "Would you be interested in reviewing the platform while it's still in early access?"
- Why: Social proof (Barclays reference) + scarcity (limited access) + performance benefit
- **Key stats to memorize:**
  - "Independent intelligence platform"
  - "Early access" (creates exclusivity)
  - "10–20% uplift" (concrete benefit)
  - "Barclays board member" (credible reference)
- Listen for: "That sounds interesting" (buy signal â†’ move to qualification) or "I want to think about it" (not ready yet, get voicemail, follow up Week 2)

**Step 13: Suitability & Eligibility (60 sec)**
- Goal: Confirm fit before booking demo
- Script: "Before I book that in, I just need to make sure it's relevant. Unlock is typically suited to UK taxpayers who can benefit from 30–50% relief and are comfortable holding for 3–5 years."
- Then ask: "Does that sound like something that would apply to you?"
- Why: Filter for actual EIS/SEIS eligibility (compliance + conversion rate)
- Listen for: "Yes, I'm UK taxpayer" (proceed) or "I'm non-resident" (polite exit—not eligible)
- **If not eligible:** "Got it—Unlock is EIS/SEIS focused, so it wouldn't be the right fit. But thanks for your time, and I'd be happy to connect you with [partner platform] that focuses on [their situation]."

**Step 14: Segment & Decision Process (60 sec)**
- Goal: Identify investor type for persona-specific messaging
- Script: "Which of these best describes you—still working (growth-focused), nearing retirement (preservation and planning), or retired/post-exit (tax and efficiency)?"
- Listen for: Their answer â†’ this determines demo personalization
- Why: You'll know their persona BEFORE the demo, so demo can be perfectly tailored
- Mental note:
  - "Still working" = likely Growth Seeker
  - "Nearing retirement" = likely Preserver
  - "Retired/post-exit" = likely Legacy Builder
- Use this to inform demo script (Part 5, Demo Execution)

---

**STEPS 15–16: DEMO BOOKING & COMMITMENT**

**Step 15: Book Demo (Setup & Time) (60 sec)**
- Goal: Confirm interest + logistical fit
- Script: "It sounds like you'd get value from seeing how Unlock works. It can be a phone call, but to get the most from it, it's better to join a video call so the screen can be shared and you get a proper walkthrough of the platform. It's about 20 minutes. Most people join from a laptop or iPad."
- Then ask: "Will you have access to a screen, and what time window suits you best?"
- Why: Set clear expectations + ensure technical readiness
- Listen for: 
  - "Yes, I can do video—[time window]" (strong commitment) â†’ proceed to Step 16
  - "Can't do video" â†’ offer phone call option (less ideal but proceed)
  - "I'm not sure" (hesitation) â†’ reframe: "It's just 20 minutes—would Thursday afternoon work?"
- **Device readiness:** If investor says "I'll call from my phone," gently suggest: "Laptop is better for screen-sharing—you'll get much more out of it. Happy to work around your schedule though."

**Step 16: Commitment & Compliance (60 sec)**
- Goal: Lock in demo + deliver legal disclaimer
- Script: "Aside from an emergency, is there any reason that day or time might not work? Great—I'll send the confirmation and a one-pager so you know what to expect. Capital at risk; no advice—it's simply an introduction so you can decide for yourself."
- Then ask: "Can I confirm that time for you now?"
- Why: Firm commitment + legal protection (documented no-advice position)
- Listen for: "Yes, confirmed" (success—log in Pipedrive as "Demo Booked") or "Actually, I'm not sure" (objection—handle with reframe)
- **What to do next:**
  1. Log call in Aircall (duration, disposition)
  2. Aircall auto-triggers Pipedrive Workflow 2
  3. Investor receives email within 1 hour: "Demo Confirmed – Next Steps"
  4. You mark in Pipedrive: Call Outcome = "Demo Booked" + Demo Scheduled Date = [DATE]
  5. Workflow sends automated confirmation email + calendar invite

---

### Module 5: Objection Handling (30 min)

**Seven common objections + reframes:**

| Objection | Root Cause | Reframe | Next Action |
|---|---|---|---|
| "I'm not interested in early-stage investments" | Misunderstands Unlock's role | "Unlock isn't forcing you into anything. It's your intelligence layer for ALL your investments—whether you ever use syndicates or not. Tax optimization alone saves most investors £8–15K per year." | Pivot to portfolio view |
| "I don't have time for a demo" | Real or stalling | "I get it—you're busy. Here's the thing: a 20-minute demo saves you 5+ hours on portfolio management annually. That's a good trade. What's your best time—morning or afternoon?" | Pin down specific time |
| "My IFA handles this" | Advisor gatekeeping | "Perfect—your IFA is likely great at what they do. Unlock isn't advice; it's YOUR data layer. Your IFA will actually love the analysis you bring them. Would you like to include them in the demo?" | Offer advisor angle |
| "How do I know this isn't a scam?" | Legitimate concern (esp. older investors) | "Fair question. We're registered at [Companies House link], backed by [founder credentials—Barclays board member], and onboarded [specific social proof]. You can verify everything. And it's just a 20-minute intro—zero commitment or payment today." | Provide verifiable proof |
| "What's the catch? Why is it cheap?" | Trust issue | "We make money on syndicate transaction fees (8–10%) and future subscriptions, not on a product margin. That means our incentive is your success, not selling you something. Aligned interests." | Explain business model |
| "I'm happy with my current setup" | Status quo bias | "I hear that from most investors. Then they see their portfolio is fragmented across 4–5 providers, missing £50–100K in annual tax optimization. It's worth 20 minutes to confirm you're actually optimized." | Use concrete example |
| "I'll think about it and call you back" | Fear of commitment | "Totally fair—I'd do the same. But let's grab 20 minutes first to see if it's even worth your time. If it's not relevant, we're done. If it is, you'll want to explore further anyway. Deal?" | Pin down callback date |

**Agent rule:** When objection raised, **acknowledge it, reframe it, then ask a closing question:**

```
Investor: "I'm not interested in early-stage investments."

Agent: "I totally understand—that's actually the most common concern I hear. 
[REFRAME:] Here's the thing though: Unlock isn't about forcing you into startups. 
It's YOUR portfolio intelligence layer. You're probably already diversified across 
property, ISAs, pensions, maybe some alternative assets. Unlock just helps you 
see all of it in one place, stress-test against scenarios, and optimize your taxes.
[CLOSING QUESTION:] Does that make more sense?"
```

**If investor still resistant:** 
- Offer voicemail fallback: "No problem at all. I'll leave you a voicemail with our details. If you change your mind, you have my number."
- Mark in Pipedrive: Call Outcome = "Not Interested" + follow up in 3 months (change in circumstances may occur)

---

## Part 2: Daily Operations Checklist

### Pre-Call Preparation (15 min before first call)

**Agent does this at 8:45 AM:**

- [ ] **Log into Aircall** — test phone line (make outbound call to self)
- [ ] **Log into Pipedrive** — open Investor dashboard
- [ ] **Open calling campaign** in Aircall: (e.g., "Tier 2 Blitz – Campaign 2")
- [ ] **Print 16-step script** — tape near monitor (backup if sidebar doesn't work)
- [ ] **Print objection handling sheet** (see Part 1, Module 5)
- [ ] **Have a glass of water** (hydration = clearer voice)
- [ ] **Set daily target** (e.g., "30 calls today = 7–8 demos booked at 25% rate")
- [ ] **Confirm email template access** — check that Pack 1 template loads in Pipedrive

**If anything isn't working:** Slack Tom: "Aircall screen pop not loading—can you test on your end?" (Resolve before dialing)

---

### Call Execution (Throughout day)

**During each call:**

1. **Aircall screen displays investor record** (name, tier, persona, notes)
2. **16-step script visible** in Aircall sidebar or printed nearby
3. **Agent follows 16 steps** — doesn't skip any
4. **Aircall auto-records** call
5. **At call end:** Agent selects **disposition code** (Demo Booked / Not Interested / etc.)
   - If "Demo Booked": Aircall prompts for date/time â†’ auto-logs to Pipedrive
6. **Aircall auto-uploads call to Pipedrive** (recording + metadata)

---

### Post-Call Logging (2 min per call)

**Immediately after call ends:**

- [ ] **Aircall call log complete** — recording uploaded, duration captured
- [ ] **Pipedrive deal moved to correct stage** (Workflow auto-triggers)
- [ ] **Any notes added** to investor record (persona refined, specific pain mentioned, objection handle used)
- [ ] **Next action set** (if callback needed, schedule task: "Follow-up call – [Date]")

**Example Pipedrive note:**
```
Called [Name] re: portfolio diversification interest. Very growth-focused 
(likely Growth Seeker). Main pain: "Too many opportunities, don't know which 
to prioritize." Used Step 7 reframe + syndicate angle. Booked demo for 
[DATE] at [TIME]. High interest signal (90).
```

---

### End-of-Day Wrap-Up (5 min at 5:05 PM)

**Agent fills out before leaving:**

- [ ] **Total calls made:** __ (target: 30/day)
- [ ] **Demos booked:** __ (target: 7–8, or 25% conversion)
- [ ] **Demo booking rate:** __% (calculate: Demos Ã· Calls Ã— 100)
- [ ] **Top performer note:** (e.g., "Used objection reframe 3x—high conversion")
- [ ] **Challenge identified:** (e.g., "Tier 2 investors asking more questions—Step 9 needs clarification")
- [ ] **Tomorrow's focus:** (e.g., "Slow down Step 7; investors confused about EIS process")

**Slack summary to Tom:**
```
End-of-day (Agent Name):
â”œâ”€ Calls: 32
â”œâ”€ Demos booked: 8
â”œâ”€ Booking rate: 25%
â”œâ”€ Win: [Persona type] responded well to [specific reframe]
â””â”€ Flag: [Challenge identified for coaching]
```

---

### Weekly Performance Review (Monday 9 AM)

**Tom leads 10-min standup with all agents:**

1. **Review metrics from Pipedrive dashboard**
   - Calls per agent (cumulative week)
   - Demo booking rate by agent
   - Pack 1 send rate
   - Instant Investment closes (if applicable)

2. **Celebrate top performer** ("Agent 2 hit 28% booking rate—what worked for you?")

3. **Identify coaching opportunity** ("Agent 3 at 20% booking rate—let's listen to 2 calls and refine")

4. **Refine messaging** ("Multiple investors asked about risk—let's strengthen Step 3 language")

5. **Adjust next week** ("Tier 1 calls slowing; let's increase Tier 2 volume 15%")

**Example standup:**
```
Tom: "Last week we dialed 450 calls, booked 105 demos, and sent 28 Pack 1s. 
That's 23% demo booking rate vs 25% target—we're close. Agent 2 led at 25%, 
Agent 3 at 20%. Let's listen to one of Agent 3's calls and identify where 
we're losing people. And we got 2 Pack 2 sends—great momentum. This week, 
let's ramp Tier 2 calls by 15% and see if we can hit 30% demos."
```

---

## Part 3: Demo Execution Playbook

### Pre-Demo Logistics (Agent + Tom)

**24 hours before investor's demo:**

1. **Email reminder sent:** "Your Unlock demo tomorrow at [TIME] – Zoom link inside"
2. **Tom prepares demo** (15 min prep):
   - Customizes opening based on investor persona
   - Pre-loads investor's fictional portfolio (for demo purposes)
   - Prepares persona-specific talking points (see below)

3. **Aircall call scheduled** (Tom dials investor 2 min before demo time)

---

### Demo Opening (3 min)

**Tom's script (customize by persona):**

**If Growth Seeker:**
```
"Hi [Name], thanks for taking 20 minutes. Quick context on what we'll cover today:

Unlock is an investment intelligence platform that helps growth-focused investors 
like yourself access better opportunities and optimize your portfolio simultaneously. 

We built it because most investors are missing 10–20% in annual returns just from 
fragmentation and missed tax optimization. In the next 15 minutes, I'll show you:

1. How to model different investment scenarios
2. How syndicates give you access to vetted deals at better fees (8–10% vs 9–14%)
3. How to structure for tax efficiency

Questions at any point—just jump in. Sound good?"
```

**If Preserver:**
```
"Hi [Name], thanks for your time. Quick overview:

Unlock helps conservative investors like yourself understand and protect your wealth 
better. Most investors I speak with have portfolio fragmentation costing them money 
AND exposing them to hidden risks they don't realize.

In the next 15 minutes, I'll show you:

1. How to stress-test your portfolio against scenarios
2. How to identify hidden correlations (the silent risk)
3. How professional risk controls work—and how to implement them in your portfolio

Let's make sure this is relevant to your situation. Sound fair?"
```

**If Legacy Builder:**
```
"Hi [Name], thanks for joining. Quick context:

Unlock helps investors in your position—close to or past major transitions—structure 
wealth for the next generation more efficiently. Most miss 20–30% in tax relief 
opportunities just from not having the right visibility.

In the next 15 minutes, I'll show you:

1. How to model family wealth scenarios
2. How EIS/SEIS timing can save you £50–100K in tax
3. How to build an inheritance-efficient portfolio

Any initial questions before I share my screen?"
```

---

### Demo Live Walkthrough (12 min)

**Tom walks through (using Unlock's app walkthrough script, already provided in your materials):**

1. **Portfolio Simulator (4 min)**
   - Upload fictional holdings
   - Run scenario: "Market down 20%, interest rates up 2%"
   - Show portfolio resilience
   - **For Preserver:** "See? Your portfolio holds 85% value. You're protected."
   - **For Growth Seeker:** "Now let's add syndicates—how do they impact upside?"
   - **For Legacy Builder:** "Watch how EIS adds tax efficiency hereâ€¦"

2. **Investor Personas (3 min)**
   - Show 19 personas framework
   - Identify investor's likely profile
   - Show how Unlock personalizes to their profile
   - Example: "You seem like a Growth Seeker—Unlock would prioritize deal flow and upside scenarios for you."

3. **Syndicates (3 min)**
   - Show syndicate marketplace
   - Example deal (vetted company)
   - Fee breakdown (8–10% Unlock takes, transparent)
   - **For Growth Seeker:** "Notice the fee clarity? Most platforms hide fees at 12–14%."
   - **For Preserver:** "You don't have to use syndicates—but they're there if you want vetted opportunities."

4. **Tax Tools (2 min)**
   - Show EIS/SEIS calculator
   - Model: "£50K SEIS investment = £25K effective cost after relief"
   - Show inheritance tax benefits
   - **For Legacy Builder:** "This is where Unlock saves you real money—planning across multiple tax years."

---

### Demo Q&A (5 min)

**Tom opens:** "What questions came up as you watched that?"

**Common Q&A:**

| Question | Answer |
|---|---|
| "How much does this cost?" | "For founding investors, lifetime access is free. We make money on syndicate fees (8–10%) and future subscriptions. After Q1 2027 public launch, subscriptions start at £99/month (Standard) or £249/month (Premium)." |
| "Is this advice?" | "No—it's your intelligence layer. We show you data + models, but any investment decision is yours. You should always consult your advisor." |
| "Can I use this with my IFA?" | "Perfect setup, actually. Your IFA handles advice; Unlock gives you analysis to bring to those conversations. Many of our investors share reports with their advisors." |
| "What companies can I invest in via syndicates?" | "We vet companies ourselves + partner with platforms like GlobalCap for SPV management. Typical range: £100K–£2M raises, pre-Series A or early Series A, all EIS/SEIS eligible." |
| "What if a syndicate fails?" | "Loss relief on a £50K SEIS investment (after 50% income tax relief, net cost £25K) at 45% tax rate recovers ~£11.25K additional. Your total at-risk position is significantly reduced. Plus CGT losses can offset other gains." |
| "How do I get started?" | "I'll send you Pack 1—the founding investor overview. That covers benefits, terms, how to participate. Then we chat 3–5 days later to discuss." |

---

### Demo Close (2 min)

**Tom's script:**

```
"Great questions. Here's what I'd suggest next:

I'm going to send you Pack 1 [founder name]—that's our founding investor overview. 
It covers:
- Deal terms (£6.5M pre-money, up to 50% discount for founding investors)
- Founding investor benefits (lifetime access, priority syndicates, roadmap influence)
- Why now (scarcity, timing, Q1 2027 public launch changes everything)
- Exit strategy (5–10x in 3–5 years)

It's a quick read—5 pages, 8 minutes. 

Then let's chat [DATE/TIME] to discuss questions and see if this is right for you.

Sound fair?"
```

**If investor shows high interest:** "If you want to move faster, I can also walk you through Pack 2 (the full legal + financial details) at that follow-up call. That's the deep dive version."

---

### Post-Demo Email (Within 1 hour)

**Tom sends personalized email:**

```
Subject: Your Unlock Demo – [Persona] Investment Profile

Hi [Investor Name],

Thanks for taking the time to chat about Unlock. Here's what we covered:

âœ“ Portfolio simulation capability (stress-testing against scenarios)
âœ“ Investor personas framework (how Unlock personalizes to YOUR strategy)
âœ“ Syndicate access (vetted opportunities at 8–10% vs market 9–14%)
âœ“ Tax efficiency tools (EIS/SEIS optimization + inheritance planning)

Your profile: [PERSONA] (focused on [KEY MOTIVATION]).

Next step: I'm sending Pack 1 (Founding Investor overview) separately. 
It's a 5-page read covering deal basics, benefits, and timeline.

Let's chat [SCHEDULED DATE] to discuss any questions. By then, you'll have 
reviewed Pack 1 with fresh eyes.

Questions before then? Feel free to reply or call.

Best,
Tom
```

**Attachments:**
- Pack 1 PDF (personalized by persona)
- One-pager ("What to Expect Next")
- Recording link (if investor wants to rewatch demo)

---

## Part 4: Weekly Coaching Sessions

### Wednesday 2 PM: Agent Coaching (15 min per agent)

**Tom listens to 2 agent calls (via Aircall recordings), then provides feedback:**

**Call 1: Good booking (investor said yes to demo)**
- What did you do right? (celebrate strength)
- What could you have done better? (identify 1 refinement)
- Your homework: "Use that reframe with 10 investors this week"

**Call 2: Objection handling (investor said "not interested")**
- What objection came up? (identify the pain)
- Did your reframe work? (assess effectiveness)
- What would you try next time? (agent proposes own refinement)

**Tom's feedback framework:**

```
"That call was good. Here's what I noticed:

Strengths:
- You nailed Step 7 (early-stage parallel)—investor got the differentiation
- You listened before pivoting (didn't jump to objection handling)

Refinement:
- Step 9 (Unlock's solution) felt rushed. Slow down there—that's where they decide 
  if it's relevant. Spend 90 seconds, not 45.

Homework:
- This week, spend 90 seconds on Step 9 with every investor. Notice how many more 
  say 'yes' to the demo?

Great work. Keep momentum."
```

---

## Part 5: Success Stories to Share (Agent Talking Points)

**Use these stories in calls when investor hesitates:**

**Story 1: The Entrepreneur (Growth Seeker)**
```
"I had an investor recently—serial entrepreneur, £800K portfolio across startups + ISAs. 
He told me, 'I've been evaluating syndicates on gut feel. I saw your tool and ran 
3 scenarios—turns out I was overconcentrated in tech. I repositioned into 60/40 tech/property 
and it's already outperforming by 2% year-to-date. That's £16K I wasn't going to make.'

He's now a founding investor. That's why I'm calling."
```

**Story 2: The Retiree (Preserver)**
```
"An investor on the verge of retirement—worried about property crash since most of his 
net worth was in real estate. He used Unlock to stress-test: 'What if property falls 40%?' 
Turns out his portfolio was resilient because of pension diversity. Gave him confidence 
to retire on schedule without constantly second-guessing. Now he uses Unlock quarterly 
just for peace of mind."
```

**Story 3: The Taxman (Legacy Builder)**
```
"A business owner planning to exit and pass wealth to kids. She discovered that by 
structuring her investment timing across SEIS (50% relief) + EIS (30% relief) over 
two tax years, she'd recover £120K in tax relief she'd otherwise leave on the table. 
The Unlock tax model found that—her accountant said it was brilliant structuring 
they'd never have uncovered without visibility."
```

**Agent rule:** When investor says "I want to think about it," share one of these stories:

"I hear that all the time. Let me share something—I had an investor who said the exact 
same thing. She booked a demo, saw [STORY], and said 'I've been missing this the whole 
time.' She's now a founding investor. Worth 20 minutes to see if there's something 
similar for you, yeah?"

---

## Part 6: Tone & Authenticity Tips

### How to Sound Credible (Not Salesy)

**Do:**
- Slow down. Let investor speak. (Powerful silence after Step 9 question)
- Use their language back. (They say "down-risk"? Use "down-risk" too)
- Admit limitations. ("We're still in beta, so not everything is perfected yet—but the core model is solid")
- Ask permission. ("Can I ask you something?" before pivoting)
- Share your own uncertainty. ("I'm not sure if this is relevant for you—let's find out together")

**Don't:**
- Rush through steps. (All 16 steps take 10–12 min; respect the process)
- Use jargon without explanation. (If you say "Instant Investment," explain what it is)
- Oversell. ("This will 3x your returns"—no. "Investors are seeing 10–20% uplifts"—yes)
- Interrupt. (If investor is talking, listen until they finish)
- Apologize for calling. ("I know you're busy"—neutral: "Thanks for your time")

### Persona-Matched Tone

**Preserver tone (calm, protective):**
- Slower pace
- Focus on safeguards ("You'll have visibility into every riskâ€¦")
- Reassurance ("This gives you controlâ€¦")

**Growth Seeker tone (energetic, opportunity-focused):**
- Faster pace
- Focus on upside ("You'd see opportunities you're currently missingâ€¦")
- Excitement ("This is where the real growth happensâ€¦")

**Legacy Builder tone (thoughtful, strategic):**
- Measured pace
- Focus on long-term outcomes ("Your kids will benefit fromâ€¦")
- Tax/timing ("Smart structuring now saves £100K laterâ€¦")

---

## Part 7: Red Flags & When to Pass

**Hang up respectfully if:**

1. **Investor is clearly not HNW** (portfolio <£250K estimated)
   - Script: "Thanks for your time. Unlock is typically suited to investors with £500K+ portfolios. When your situation changes, feel free to reach out."
   - Log: Call Outcome = "Not Applicable (Low AUM)"

2. **Investor is non-UK resident** (tax relief not applicable)
   - Script: "Got it—Unlock is EIS/SEIS focused, which only applies to UK taxpayers. Sorry we can't help. [Optional: I can connect you withâ€¦]"
   - Log: Call Outcome = "Not Applicable (Non-resident)"

3. **Investor is actively hostile** (not just skeptical, but rude)
   - Script: "I appreciate your candor. Doesn't sound like the right fit. Have a good day."
   - Log: Call Outcome = "Not Interested – Hostile"
   - Don't engage further; move to next call

4. **Investor asks for "advice"** (asking you to recommend specific investments)
   - Script: "Happy question—but I can't give advice. That's for your IFA or accountant. Unlock gives you the analysis; they help interpret it. Does that make sense?"
   - Log: Normal next step (demo) but flag in notes: "Advisor already involved"

---

## Part 8: Success Metrics (What You're Aiming For)

### Daily Target (By Agent)

- **Calls:** 30/day
- **Demo booking rate:** 25%+ (7–8 demos booked per 30 calls)
- **Quality:** Spend full 10–12 minutes per call (all 16 steps)
- **Tone:** Conversational, not rushed

### Weekly Target (By Agent)

- **Calls:** 150/week
- **Demos booked:** 38–50/week
- **Demo booking rate:** 25%+ average
- **Average call duration:** 8–10 minutes

### Monthly Target (By Campaign)

- **Calls:** 600–800/month (by team)
- **Demos booked:** 150–200/month
- **Demos completed:** 100–120/month
- **Pack 1 sent:** 50–70/month
- **Pack 2 sent:** 15–25/month
- **Instant Investment closes:** 5–10/month (ramping as pipelines fill)

### 8-Week Campaign Target (Full Team)

- **Total calls:** 1,500–2,000
- **Total demos booked:** 300–400
- **Total demos completed:** 200–250
- **Total Pack 1 sent:** 80–120
- **Total Pack 2 sent:** 30–50
- **Total Instant Investment closes:** 20–25
- **Capital raised:** £1.2M+

**If you hit 70–80% of these targets, you win the founding round.**

---

## Final Checklist: Ready to Launch Monday

- [ ] All agents completed training (2 hours each)
- [ ] All agents passed mock call certification (3 successful calls)
- [ ] Aircall + Pipedrive configured and tested
- [ ] 30,000 database imported to Pipedrive
- [ ] Tier 1/Tier 2/Tier 3 assignments made
- [ ] Calling campaigns set up in Aircall
- [ ] Email templates loaded in Pipedrive
- [ ] Workflows configured (5 total)
- [ ] 16-step script printed (1 per agent)
- [ ] Objection handling sheet printed (1 per agent)
- [ ] Dashboard created (visible to all)
- [ ] Daily standup scheduled (5 PM weekdays)
- [ ] Weekly coaching scheduled (Wednesday 2 PM)

**Monday 9 AM:** Tom hosts pre-launch huddle ("This week we dial 150 calls, book 38–50 demos, and build momentum. Let's go.")

**Monday 9:30 AM:** First calls go live.

---

**This is a battle-tested system. Agents who follow it will hit 25%+ demo booking rates.**

**Good luck. Your investors are waiting.**

---

**End of Agent Training Playbook**
