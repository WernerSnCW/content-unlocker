+-----------------------------------------------------------------------+
| **UNLOCK**                                                            |
|                                                                       |
| **Cold Call Script --- Founding Investor Programme**                  |
|                                                                       |
| *For use with known HNW prospects. Tom King. Confidential.*           |
+-----------------------------------------------------------------------+

**Quick reference**

  ----------------------- -----------------------------------------------
  **EIS income tax        30% --- can wipe entire annual bill if sized
  relief**                correctly

  **SEIS income tax       50% --- for smaller earlier-stage companies
  relief**                

  **CGT on exit**         Exempt after 3-year minimum hold

  **IHT relief (until 6   100% unlimited --- capped at £2.5M from 6 April
  Apr 2026)**             2026

  **UK unicorns backed by 46.5% of all active UK unicorns (Beauhurst,
  EIS**                   2024)

  **Portfolio return      Up to 7x on well-constructed, diversified
  (curated)**             portfolio

  **Typical prospect      £500K+ investable assets, annual tax bill \>
  profile**               £30K

  **Call objective**      Qualify fit → send one-pager → book 30-min
                          video call
  ----------------------- -----------------------------------------------

  -----------------------------------------------------------------------
  **01 Opening**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  \[Name\] --- this is Tom King from Unlock. The reason I'm calling you
  in particular --- we work with high-net-worth individuals who have
  significant income tax and capital gains liabilities, and I've been
  looking at people who I think would genuinely benefit from what we do.
  Do you have sixty seconds?

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Wait for the yes before continuing. Don't barrel through.
  The pause does work.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **02 The Hook --- EIS Introduction**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  We specialise in EIS --- the Enterprise Investment Scheme --- which is
  approved and run by HMRC. In plain terms: EIS allows people who know
  how to use it to invest in a way that can wipe out their entire income
  tax bill for the year. If your tax bill is 00a350,000 and you invest
  00a3100,000 into SEIS, HMRC hands back 00a350,000 --- that\'s 50%
  straight off your tax bill. Your tax bill for that year is zero. You've
  heard of Revolut and Monzo? Both were initially funded through the
  scheme. In fact, nearly half of every active UK unicorn --- companies
  valued over £1 billion --- benefitted from EIS-backed funding. On a
  well-constructed, diversified portfolio, the average return has been up
  to 7x. Profits are tax-free. There's a structural reason why not
  everyone gets access to quality EIS opportunities --- which I can
  explain to you. But before I do --- I just want to confirm something.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Pause after 'confirm something'. Let them lean in. Don't
  rush the next line.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **03 The Confirmation Question**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  Because as far as I can tell, \[Name\], you're someone who isn't
  currently using your annual EIS allowance. Is that right?

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Either answer works. If YES --- they're not using it,
  proceed. If NO --- they are using it, find out who they're using and
  what their experience has been. That's still a productive
  conversation.*

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If YES →**   Perfect. Continue to Section 04.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If NO →**    "Really --- tell me about that. Who are you working
                 with?" Then listen. Position around quality of deal flow
                 and portfolio intelligence vs. whatever they're
                 currently doing.

  -------------- --------------------------------------------------------

  -----------------------------------------------------------------------
  **04 Normalise the Gap**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  999 times out of 1,000 --- the reason a successful person isn't using
  EIS is one of two things: either they haven't heard of it properly, or
  they don't fully understand it. And neither do they know anyone who
  does. The interesting thing is --- the more you earn, the more tax you
  pay, and the more tax you pay, the more you can deploy via EIS. So it
  gets more advantageous the larger your tax bill. But honestly, it
  doesn't matter where you start. Used correctly, EIS is one of the few
  legitimate ways to substantially reduce your tax bill while building a
  high-growth asset at the same time.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *This section does two things: removes embarrassment (it's
  normal not to know) and amplifies relevance (the bigger their tax bill,
  the more they need this). Don't rush it.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **05 What Unlock Does Differently**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  What we do that's different from anyone else in this space --- we don't
  just give you access to EIS deal flow. We give you the portfolio
  intelligence alongside it. So you can see exactly how each investment
  interacts with your overall tax position, your estate, your existing
  holdings. You're not investing blind --- you're investing with a
  complete picture of what it means for your specific situation. Most
  people who come to us have never had that. Not from their IFA, not from
  their accountant, not from anyone.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *This is the Unlock differentiator. It separates Tom from any
  other EIS introducer. Keep it concise --- one short paragraph, then
  move to qualification.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **06 Qualification --- Three Gates**

  -----------------------------------------------------------------------

**Gate 1: Tax bill vs investable assets**

  -----------------------------------------------------------------------
  Before I suggest we take this any further --- a couple of quick
  questions to make sure it actually makes sense for you. Do you have
  significant income tax or capital gains liabilities each year? I
  typically work with people who have between £5M and £20M in liquid
  assets --- but in truth the number that matters most isn't your total
  wealth. It's the ratio of your annual tax bill to what you can
  comfortably invest. If your tax bill is £50,000 and you can access
  £100,000 --- that's worth our time. It means EIS can work hard for you
  immediately.

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If yes →**   Good. Continue to Gate 2.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If no / not  "That's useful to know. It might still be worth a
  sure →**       conversation --- can I ask roughly what your situation
                 looks like?"

  -------------- --------------------------------------------------------

**Gate 2: Self-directed element**

  -----------------------------------------------------------------------
  The other thing I'd want to understand --- do you manage any of your
  own money directly? It doesn't need to be everything. A lot of the
  people I work with use an IFA or wealth manager for pensions, ISAs,
  their share portfolio. But alongside that, they make their own
  investment decisions. The reason I ask is practical: advisers who
  charge a percentage of assets under management have a structural reason
  not to recommend strategies that reduce those assets --- it's not
  personal, it's how they're paid. EIS reduces the pool they manage. So
  it very rarely comes from that channel. Is that something that
  describes you --- you make at least some of your own financial
  decisions?

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If yes →**   Good. Continue to Gate 3.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If no →**    "Understood --- is there an area where you do make your
                 own calls? Or is everything managed?" If everything is
                 fully managed with no self-directed element, this
                 prospect isn't the right fit right now.

  -------------- --------------------------------------------------------

**Gate 3: Time and inclination**

  -----------------------------------------------------------------------
  And the last thing --- this isn't something you can assess in five
  minutes. To do it properly, you'd need to look at some information,
  have a meaningful conversation, and make a considered decision. Do you
  have the time and inclination to look at something properly if it
  stacks up for you?

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If yes →**   All three gates passed. Move to Section 07 --- the
                 close.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If hesitant  "Completely understand --- what would work better for
  →**            you in terms of timing?"

  -------------- --------------------------------------------------------

  -----------------------------------------------------------------------
  **07 The Close --- Low-Friction Next Step**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  In that case --- here's what I'd suggest. I'll send you something short
  --- takes about four minutes to read. It explains what Unlock does, how
  the EIS structure works, and what founding investors in our current
  round are getting. If it resonates, we book a 30-minute call and I'll
  walk you through it properly. What's the best email address to send
  that to?

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Do not jump straight to a 40-minute video call. The
  one-pager is the bridge. Get the email, send the doc, book the call as
  a second step. Lower friction converts better with this audience.*

  -----------------------------------------------------------------------

**If they want more before giving the email:**

  -----------------------------------------------------------------------
  Of course. The short version: we're raising a founding round at a £6.5M
  valuation. We're limiting it to around 25 investors --- not for
  scarcity, but because the people we work with need to be genuinely
  engaged. It's EIS eligible, so depending on your tax position, the
  effective entry cost is significantly lower than the face value. Shares
  issue on 6 April 2026 --- which also happens to be the last date to
  qualify for unlimited EIS Inheritance Tax relief before a rule change
  caps it. After that date, the relief is capped at £2.5M per estate.
  So there's a real reason to look at it now rather than later.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **08 Objection Handling**

  -----------------------------------------------------------------------

+-----------------------------------------------------------------------+
| **Objection: "I already invest in EIS."**                             |
|                                                                       |
| That's great --- most of my best conversations are with people who    |
| already understand the scheme. What I'd be curious about is whether   |
| you're getting the portfolio intelligence alongside it --- being able |
| to see exactly how each holding interacts with your tax picture.      |
| That's the piece that's usually missing. Worth a quick conversation?  |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "I'm not interested in investing in startups."**         |
|                                                                       |
| Completely fair --- the investment risk is real and it's not for      |
| everyone. The question I'd ask is whether the tax relief changes the  |
| calculation for you. If you can wipe a £50,000 tax bill and put the   |
| money into a diversified portfolio of 10 companies, your effective    |
| exposure on the downside is much lower than it looks. But if the risk |
| profile still doesn't work for you, I completely understand.          |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "Send me something and I'll have a look."**              |
|                                                                       |
| Of course --- what's the best email? \[Get email.\] And just so I     |
| know when to follow up --- are you someone who tends to look at       |
| things quickly, or would a week be more realistic? \[Agree a          |
| follow-up date before hanging up.\]                                   |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "How did you get my number?"**                           |
|                                                                       |
| We work from a curated list of investors who we believe would benefit |
| from what we do --- your name came up through \[network / research /  |
| referral\]. I apologise if the timing is inconvenient. Would it be    |
| better if I called at a different time?                               |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "I'm happy with my current advisers."**                  |
|                                                                       |
| That's good to hear. This isn't really an adviser conversation though |
| --- EIS is something you do directly, alongside whatever else you     |
| have in place. It doesn't replace your existing arrangements, it sits |
| outside them. Is there a reason you'd want to keep this kind of       |
| decision within the advisory relationship?                            |
+-----------------------------------------------------------------------+

  -----------------------------------------------------------------------
  **09 After the Call**

  -----------------------------------------------------------------------

**Within 2 hours of hanging up:**

  -----------------------------------------------------------------------
  Send the one-page founding investor document with a personal two-line
  note: "Great to speak, \[Name\]. As promised --- four minutes,
  everything you need to know. If it makes sense, reply and we'll find a
  time." Do not send Pack 1 or Pack 2 at this stage. The one-pager is the
  filter. If they engage with that, Pack 1 follows. Pack 2 only when
  they're seriously considering committing.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Document sequence: One-pager → Pack 1 (Founding Investor
  Brief) → Pack 2 (IIM). Each step qualifies for the next. Never skip
  ahead.*

  -----------------------------------------------------------------------

**Follow-up timing:**

  --------------- -------------------------------------------------------
  **Same day**    Send one-pager with personal note

  **Day 3--4**    Brief follow-up: "Just checking this landed --- happy
                  to answer any questions."

  **Day 7**       If no response: "I'll leave this with you --- the April
                  6 date is worth being aware of. Reply whenever suits."

  **Day 14**      Final touch if warm: reference a specific detail from
                  the call
  --------------- -------------------------------------------------------

*For internal use only. This script is a guide, not a regulated
financial promotion. All investment conversations must be conducted in
accordance with applicable FCA rules. EIS tax relief figures are
illustrative; individual outcomes depend on personal tax position and
HMRC approval. Capital is at risk. Tom King, Unlock Services Limited.*
