**UNLOCK**

**Investor Information Memorandum**

Founding Round --- 2025 / 2026

Prepared for: \[Investor Name\]

Prepared by: Tom King, Founder & CEO, Unlock

Date: March 2026

*This document is private and confidential. It is intended solely for
the named recipient. It supplements the Founding Investor Brief (Pack 1)
with full financial, legal, and operational detail to support investment
due diligence. It does not constitute financial advice. Recipients
should seek independent financial and tax advice before making any
investment decision.*

**Document Contents**

  ----------------------- -----------------------------------------------
  **Section**             **Contents**

  **1. Investment Terms & Instant Investment mechanics, founding investor
  Structure**             terms, worked example, SeedLegals process,
                          timeline

  **2. Valuation &        Valuation rationale, comparables, sensitivity
  Returns Framework**     analysis, exit scenarios

  **3. Financial          5-year revenue, user growth, unit economics,
  Projections**           break-even analysis

  **4. The Platform &     Full product description with build status for
  Product**               each service

  **5. Go-to-Market       Acquisition channels, sales funnel, partner
  Strategy**              strategy

  **6. Risk Factors**     Full risk disclosure with mitigations

  **7. Regulatory &       EIS/SEIS mechanics, IFA advice gap, April 2026
  Compliance**            IHT changes

  **Appendix A**          Team & Governance

  **Appendix B**          Competitive Analysis

  **Appendix C**          Glossary of Key Terms
  ----------------------- -----------------------------------------------

**1. Investment Terms & Structure**

**1.1 The Investment Instrument: Instant Investment via SeedLegals**

Unlock uses Instant Investment via SeedLegals --- the UK's leading
EIS/SEIS investment platform. Instant Investment is the instrument used
in this founding round. It enables immediate EIS compliance processing
and provides structural anti-dilution protection until Series A.

SeedLegals is the UK\'s leading EIS/SEIS investment platform, used in
approximately 33% of UK funding rounds. The use of SeedLegals ensures
full HMRC compliance, professional share issuance documentation, and a
standardised process familiar to UK advisers and solicitors.

**Key features of the Instant Investment structure:**

-   EIS compliance processed at point of investment --- not after round
    close.

-   Anti-dilution protection: founding investor ownership percentage is
    protected until Series A.

-   Shares issued on a fixed date: April 6, 2026.

-   Legally standardised: SeedLegals template, familiar to advisers and
    solicitors.

**1.2 Founding Investor Terms**

Founding investors invest at £6.5M pre-money valuation via the Instant
Investment structure described above. The round target is £1.2M across
approximately 25 investors.

Founding investor discounts are negotiated individually based on the
strategic value the investor brings beyond capital. Discount tiers are
not published. Tickets range from £40,000 to £500,000.

  -------------------------- --------------------------------------------
  **Term**                   **Founding Investors**

  **Pre-money valuation**    £6.5M

  **Round target**           £1.2M

  **Number of investors**    ∼25

  **Instrument**             Instant Investment via SeedLegals

  **Platform**               SeedLegals (HMRC-compliant)

  **Share issuance date**    April 6, 2026 (fixed)

  **Ticket range**           £40,000 -- £500,000

  **Founding investor        Negotiated individually
  discount**                 

  **Anti-dilution**          Ownership % protected until Series A
  -------------------------- --------------------------------------------

**1.3 Worked Example: £50,000 Investment Under SEIS**

  ----------------------- -----------------------------------------------
  **Step**                **Detail**

  **Investment made**     £50,000 via Instant Investment (SeedLegals)

  **SEIS income tax       HMRC returns £25,000 to investor via Self
  relief (50%)**          Assessment

  **Effective cost after  £25,000
  relief**                

  **Share issuance**      April 6, 2026: shares issued in investor\'s
                          name

  **If investment         Profits are tax-free on exit after 3-year
  succeeds**              qualifying hold

  **If company fails**    Additional loss relief reduces net loss further
                          (amount depends on tax bracket)

  **IHT exemption**       Qualifying EIS/SEIS shares are IHT-exempt after
                          2 years (subject to April 2026 cap)
  ----------------------- -----------------------------------------------

*Note: EIS and SEIS tax treatment depends on individual circumstances.
This example is illustrative. Investors should confirm eligibility and
relief with a qualified tax adviser.*

**1.4 Investment Process & Timeline**

  ------------------ ----------------------------------------------------
  **Stage**          **Action**

  **Day 1**          Investor confirms soft commitment. Tom King confirms
                     founding investor terms.

  **Days 2--3**      SeedLegals prepares Instant Investment agreement.
                     Investor reviews (solicitor optional, typically
                     £500).

  **Day 4**          Instant Investment agreement signed electronically.
                     Capital transferred to Unlock's designated account.

  **Days 5--7**      SeedLegals issues shares. Investor receives share
                     certificate. HMRC application submitted.

  **Weeks 2--4**     HMRC processes EIS/SEIS application. Tax relief
                     confirmed for Self Assessment claim.

  **April 6, 2026**  Shares formally issued on this date across all
                     founding investors.

  **Ongoing**        Quarterly investor updates. Direct founder access.
                     Platform access --- lifetime, premium.
  ------------------ ----------------------------------------------------

**2. Valuation & Returns Framework**

**2.1 Valuation Rationale**

The £6.5M pre-money valuation is set at the founding round to reflect
the stage of development, validated demand, and the regulatory moat
being built. It is benchmarked against comparable early-stage B2B SaaS
and fintech platforms at seed stage in the UK.

The valuation represents a discount to projected forward milestones.
Founding investors enter at the lowest valuation this business will ever
be offered at, ahead of public launch, Growth Capital round, and the
full platform build funded by this raise.

**2.2 Projected Returns: Base Case**

  ------------- ------------------- ------------------- ------------------
  **Horizon**   **Scenario**        **Projected         **Multiple on
                                    Valuation**         Entry (£6.5M)**

  **Year 2--3** Strategic M&A       £20--£30M           3--5×
                (early)                                 

  **Year 3--4** Strategic M&A       £50--£70M           8--11×
                (primary)                               

  **Year 4--5** PE buyout / IPO     £100M+              15×+
                pathway                                 
  ------------- ------------------- ------------------- ------------------

*Projected returns are not guaranteed. These figures represent
management estimates based on comparable transactions and the financial
model. Actual outcomes may differ materially.*

**2.3 Strategic Exit Considerations**

Named strategic acquirers operating in adjacent markets: Bloomberg,
Morningstar, Refinitiv, Crowdcube, S&P Global. Each has a rationale:
Unlock's proprietary lot-level data asset, UK tax intelligence
capability, and the HNW investor base are all acquirable assets in the
context of a larger wealth intelligence platform.

IPO pathway: at £20M+ ARR with 10,000+ subscribers. Fintech PE buyout:
at 7--10× ARR multiples for profitable SaaS with demonstrable moat.

Base case: 5--10× returns within 3--5 years. Projections are management
estimates; actual outcomes depend on execution and market conditions.

**3. Financial Projections**

**3.1 Revenue Projections (2026--2029)**

  ---------- ---------------- ------------------- --------------------------
  **Year**   **Revenue**      **Stage**           **Notes**

  **2026**   ∼£1.4M           Beta + early        Growth Capital round.
                              syndicates          Platform in limited
                                                  access.

  **2027**   ∼£3.0M           Public launch       Q1 2027 public launch.
                                                  Subscription growth
                                                  accelerating.

  **2028**   ∼£5.0M           Subscription +      Established product.
                              syndicate growth    Multiple revenue streams
                                                  active.

  **2029**   £8.25M--£9.25M   Mature ARR          Institutional channels
                                                  opening. Year 5 EBITDA
                                                  positive.
  ---------- ---------------- ------------------- --------------------------

*These are forward-looking projections based on management assumptions.
They are not guaranteed and should not be relied upon as forecasts.*

**3.2 User Growth**

  -------------- ------------------ ------------------ --------------------
  **Year**       **Free Users**     **Paid Users**     **Notes**

  **2026**       10,000             500                Beta cohort.
                                                       Founding investor
                                                       onboarding.

  **2027**       28,000             1,200              Public launch.
                                                       Content-led growth.

  **2028**       50,000+            3,600              Adviser referral
                                                       channel activating.
  -------------- ------------------ ------------------ --------------------

**3.3 Unit Economics**

  ------------------------ ------------------- --------------------------
  **Metric**               **Figure**          **Notes**

  **Customer Acquisition   £200                Warm introductions,
  Cost (CAC)**                                 referrals, content. Does
                                               not include paid
                                               acquisition.

  **Lifetime Value (LTV)** £3,000--£3,250      3--5 year average lifetime
                                               on current churn
                                               assumptions.

  **LTV:CAC ratio**        10:1 to 15:1        Strong structural
                                               economics. Referral
                                               flywheel improves this
                                               over time.

  **Payback period**       ∼3 months (steady   At mature conversion
                           state)              rates. Longer in early
                                               build phase.

  **Gross margin           High margin SaaS    Infrastructure cost per
  (subscription)**                             user is minimal at scale.

  **Gross margin           90%+                Minimal cost per syndicate
  (syndicates)**                               at current volumes.
  ------------------------ ------------------- --------------------------

**3.4 Use of Founding Round Funds (£1.2M)**

  ---------------- ---------------- -------------- ----------------------------
  **Category**     **Allocation**   **Amount**     **Priority**

  **Product & AI   35%              ∼£420,000      Tax intelligence engine,
  Development**                                    portfolio simulator, asset
                                                   register automation.

  **Go-to-Market & 32%              ∼£384,000      Growth Capital round
  Sales**                                          outreach, content, adviser
                                                   partnerships.

  **Team &         21%              ∼£252,000      Engineering, compliance,
  Operations**                                     service delivery hires.

  **Working        12%              ∼£144,000      18--24 month operational
  Capital**                                        runway to Year 3
                                                   profitability.
  ---------------- ---------------- -------------- ----------------------------

**4. The Platform & Product**

Unlock is a founding-stage platform. The following table describes each
service, its current build status, and the investor benefit. Build
status is stated honestly. Claims are not made for capabilities not yet
live.

**Asset Register**

The single source of financial truth. A permanent, accurate record of
everything an investor owns across all accounts, platforms, wrappers,
and family members.

Core features: Lot-level tracking (date, units, price paid per
purchase). Cost basis evolution to current value. Income tracking
(dividends, interest, coupons) with routing visibility. Document linkage
(statements, contract notes, valuations). Household view across people,
wrappers, and entities. Date-freeze for IHT/probate valuations. Plain
language queries.

*Build status: Operational for founding investor onboarding. Automated
multi-platform connections on roadmap.*

**Portfolio Simulator**

Scenario testing and stress modelling grounded in the investor's actual
positions. Models what happens to a real portfolio under defined
conditions --- not a hypothetical model portfolio.

Core features: 30+ downside scenario models (markets crash 30%, interest
rates spike, property falls, stagflation). Macro belief integration.
Upside vs downside comparison. All insights traceable to actual
positions.

*Build status: Decided capability. In active development. Full build
funded by this raise.*

**Tax Intelligence Engine**

Real-time, forward-looking modelling of all UK tax interactions across
EIS, SEIS, CGT, IHT, pension drawdown, and AIM BPR. Continuous HMRC
rule-tracking. This is Unlock's core defensive moat.

Core features: EIS/SEIS relief tracking and optimisation. CGT
crystallisation timing and deferral modelling. IHT planning and
inheritance scenario modelling. Pension drawdown sequencing. AIM BPR
eligibility tracking.

*Build status: Decided capability. Core moat. 18--24 months minimum for
any competitor to replicate correctly. Full build funded by this raise.*

**Syndicate Access**

Curated access to vetted collective investment opportunities at 8--10%
fees versus the 9--14% charged by Crowdcube, Seedrs, and comparable
platforms. Founding investors receive priority allocation on all
deal-flow.

*Build status: Operational. Founding investors have priority access
now.*

**Unlock Access --- EIS Deal-Flow Service**

A curated EIS deal-flow and portfolio service. Direct portfolio building
--- not a fund. Investors build their own EIS portfolio from Unlock's
curated pipeline, with full visibility at every stage. Four pillars:
Guidance, Tools, Access, Administration.

Transparency note: Unlock Access raises for its own pipeline companies.
This is stated openly. The positioning is full transparency and
disclosure --- not claims of independence from deal-flow.

*Build status: Operational. EIS compliance processed via SeedLegals.
Instant Investment process live.*

**Decumulation Planner**

A planning tool that answers: given my assets, how long will my money
last if I spend £X per year --- and what is the optimal sequence to draw
assets to minimise tax and maximise the estate passed to heirs? Asset
classes covered: Cash, ISA (including flexible ISA), pension
(DC/SIPP/workplace), investment property, VCT, EIS, AIM shares.

Four drawdown strategies: Tax-optimised (minimise income tax and CGT
drag), IHT-optimised (maximise estate), Income-first, Growth-first. Each
produces a different asset draw priority order. User selects strategy;
platform models all four for comparison.

*Build status: Technical specification v1.2 complete (March 2026).
Prototype build commencing. This capability is funded by the founding
round.*

**5. Go-to-Market Strategy**

**5.1 Customer Acquisition Channels**

  -------------------- --------------------------------------- -------------
  **Channel**          **Description**                         **Stage**

  **Proprietary HNW    30,000+ UK HNW investor profiles.       Active now
  database**           Direct outreach channel. Founding round 
                       being closed through this database.     

  **Warm introductions Network-driven introductions from       Active now
  & referrals**        founding investors, advisers, and       
                       existing relationships.                 

  **Content & thought  Long-form content on EIS/SEIS, IHT      In build
  leadership**         planning, portfolio intelligence.       
                       Establishes authority in target         
                       segment.                                

  **Media & PR         Specialist financial press and          In build
  partnerships**       HNW-facing media. Thought leadership    
                       positioning for Tom King.               

  **Founder-hosted     Private events for qualified HNW        In build
  investor events**    prospects. High-trust, low-friction     
                       conversion environment.                 

  **Syndicate-driven   Founding investors and syndicate        Active now
  referrals**          participants refer their networks.      
                       Network effect with high trust signals. 
  -------------------- --------------------------------------- -------------

**5.2 IFA & Adviser Partner Channel**

IFAs are not competitors. They are potential distribution partners. IFAs
are legally prohibited from advising on individual EIS company
investments --- they can only advise on EIS funds and VCTs. Unlock fills
exactly this gap with intelligence tools and due diligence support.

KYS (Know Your Situation) packs, formatted for adviser meetings, make
Unlock a complement to professional advice rather than a threat to it.
IFA referrals to Unlock are low-CAC and high-trust when the channel is
activated at scale.

**5.3 Founding Round vs Growth Capital Round**

Founding round (current): quality-controlled, founder-led, closed
through the proprietary database and network. Approximately 25
investors. Not a volume exercise.

Growth Capital round (Q2 2026 target): volume playbook. Outreach
infrastructure (Pipedrive CRM, Aircall), agent training, content-led
inbound, and adviser partnerships all active. This is what the
go-to-market allocation in the founding round budget is building toward.

**6. Risk Factors**

The following risks are disclosed without softening. Each is real. Each
has a mitigation. Investors should read this section carefully and seek
independent advice.

  ---------------- ----------------------------- ------------------------
  **Risk**         **Detail**                    **Mitigation**

  **Pre-launch,    Public launch targeted Q1     Working product in use.
  pre-revenue at   2027. Revenue at founding     Complete technical
  scale**          stage is pre-scale. Current   specifications. Credible
                   build is founding-stage       milestone roadmap.
                   desktop application.          Break-even projected at
                                                 Year 2 ARR.

  **Founder-led    Tom King conducts all demos   By design for founding
  trust            at this stage. Credibility    round (25 slots). Growth
  dependency**     cannot yet be delegated.      Capital round requires
                                                 delegation --- agent
                                                 playbook and training
                                                 infrastructure being
                                                 built.

  **Automated data Multi-asset integration (ISA  White-glove onboarding
  connections not  platforms, broker accounts,   operational now.
  yet live**       pension providers) is on the  Automated connections
                   roadmap. Manual onboarding    funded by this raise.
                   operational for founding      
                   investors.                    

  **No user        Pre-launch. Social proof from 40+ market interviews.
  testimonials     live platform users does not  70% would pay. Founding
  yet**            yet exist.                    investor commitments and
                                                 senior-level backing
                                                 provide partial
                                                 compensation.

  **Series A       Full platform build and       Break-even projected
  dependency**     Growth Capital ambitions      without Series A at Year
                   require follow-on funding.    2 ARR (£3M). Strong unit
                                                 economics (LTV:CAC
                                                 10--15:1). Realistic
                                                 profitability pathway.

  **Incumbent      Large platforms could attempt Product conflict makes
  competitive      to add portfolio intelligence genuine independence
  response**       features.                     impossible for
                                                 incumbents. UK tax
                                                 complexity takes 18--24
                                                 months minimum to build
                                                 correctly. Data flywheel
                                                 advantages early movers.

  **EIS/SEIS rule  HMRC or FCA changes to        Platform designed for
  changes**        EIS/SEIS rules could affect   continuous HMRC
                   tax relief availability.      rule-tracking.
                                                 Regulatory change is a
                                                 risk for investors in
                                                 any EIS/SEIS vehicle.
  ---------------- ----------------------------- ------------------------

**7. Regulatory & Compliance**

**7.1 EIS & SEIS Overview**

  ------------ ---------------- ------------------ ------------------- ----------
  **Scheme**   **Income Tax     **Annual Limit**   **CGT**             **IHT**
               Relief**                                                

  **SEIS**     50%              £200,000 per year  Tax-free after 3    Exempt
                                                   years; loss relief  after 2
                                                   if company fails    years
                                                                       (April
                                                                       2026 cap
                                                                       applies)

  **EIS**      30%              £1,000,000 per     Tax-free after 3    Exempt
                                year (standard     years; CGT deferral after 2
                                EIS)               available; loss     years
                                                   relief if company   (April
                                                   fails               2026 cap
                                                                       applies)
  ------------ ---------------- ------------------ ------------------- ----------

*Note: Tax treatment depends on individual circumstances and is subject
to HMRC rules which may change.*

**7.2 The April 6, 2026 IHT Change**

From April 6, 2026, IHT relief on EIS/SEIS investments is subject to a
new cap: 100% relief applies up to £2.5M per estate; relief on amounts
above that threshold reduces to 50%. This is a significant structural
change for HNW investors who have been using EIS/SEIS for IHT
mitigation.

Investors planning to use EIS/SEIS for IHT mitigation purposes should
structure their investments before April 6, 2026 to maximise relief
under current rules. Founding investors who close before this date
benefit from full BPR treatment on their qualifying shares.

+-----------------------------------------------------------------------+
| **Important:**                                                        |
|                                                                       |
| This is not manufactured urgency. The April 6, 2026 change is         |
| confirmed HMRC policy. Investors with existing EIS/SEIS positions or  |
| planning new ones should review their position with a qualified tax   |
| adviser before this date.                                             |
+-----------------------------------------------------------------------+

**7.3 The IFA Advice Gap**

IFAs are not permitted to advise on individual EIS company investments
under current FCA regulations. They can only advise on EIS funds and
VCTs. This is a structural feature of UK financial regulation, not a
limitation of Unlock.

It means that sophisticated investors evaluating direct EIS
opportunities have no regulated adviser to turn to for guidance on
individual company investments. Unlock fills exactly this gap:
intelligence tools, due diligence support, and portfolio-level modelling
that IFAs cannot legally provide.

IFAs are therefore potential distribution partners --- not competitors.
They refer clients who need tools and information the IFA cannot legally
provide.

**Appendix A. Team & Governance**

  -------------- ------------------- ------------------------------------
                 **Role**            **Background**

  **Thomas       Founder & Chief     12+ years building
  King**         Executive Officer   investor-introduction and
                                     capital-facilitation technology.
                                     Founder of Cloudworkz (AI operating
                                     intelligence platform for SMBs).
                                     £250M+ capital facilitated across
                                     investment platforms. Leads product
                                     vision, investor relations, and the
                                     founding round. Dual-founder role
                                     across Unlock and Cloudworkz is a
                                     structural advantage: the Cloudworkz
                                     platform directly supports Unlock's
                                     content and outreach infrastructure.

  **Werner       Head of Product     19 years in senior product
  Snyman**                           leadership roles at Nedbank. Deep
                                     expertise in wealth management
                                     platform architecture, user
                                     experience design for sophisticated
                                     investors, and financial product
                                     build.

  **William      Head of Service     Track record delivering
  Corke**        Delivery &          multi-million-pound projects for
                 Compliance          FTSE 500 clients. Oversees investor
                                     onboarding quality, service delivery
                                     standards, and regulatory compliance
                                     across all investor-facing
                                     processes.

  **Claudia      Co-Founder &        Fintech partnerships and commercial
  Chavez**       Commercial Director development. Leads strategic partner
                                     relationships, commercial channel
                                     development, and growth initiatives.
                                     Co-founder with responsibility for
                                     commercial scaling.
  -------------- ------------------- ------------------------------------

**Advisory**

Founding investor backing from: former Chairman of Barclays and former
Director General of TISA. These are not nominal advisers. They are
investors who have assessed the opportunity and committed capital ---
which is a materially stronger signal than advisory board membership.

**Appendix B. Competitive Analysis**

Unlock competes in a market where every incumbent has a product conflict
it cannot resolve without dismantling its own business model. The
competitive analysis reflects this structural reality.

  ------------------ ---------------------- -------------- ------------------------- ---------------------
  **Competitor       **What They Offer**    **Fees**       **What They Lack**        **Why Unlock Wins**
  Type**                                                                             

  **IFAs & Wealth    Holistic financial     1--2% AUM +    Cannot advise on          Unlock fills the
  Managers**         advice.                fees           individual EIS company    EIS/SEIS direct
                     Relationship-driven.                  investments. Earn from    investment gap IFAs
                                                           product recommendations.  cannot touch.
                                                           Relationship-dependent,   Complement, not
                                                           not tool-dependent.       competitor.

  **DIY              Full control. Low      Near-zero      No modelling, no tax      Unlock replaces
  (Spreadsheets)**   cost. Manual.          direct cost    intelligence, no scenario reconstruction with
                                                           simulation. Manual        intelligence. Upgrade
                                                           reconstruction is fragile path for the
                                                           and time-consuming.       sophisticated
                                                                                     self-directed
                                                                                     investor.

  **Portfolio        Data aggregation       Freemium / low Limited tax intelligence. Unlock delivers
  Aggregators (e.g.  across accounts.       subscription   No scenario simulation.   institutional-grade
  Moneyhub)**                                              No EIS/SEIS deal-flow.    modelling on top of
                                                           Not built for HNW         aggregated data.
                                                           complexity.               Entirely different
                                                                                     capability level.

  **Crowdfunding     EIS deal access.       9--14% of      High fees.                Unlock offers better
  Platforms          Community of           funds raised   Retail-focused. No        economics (8--10%),
  (Crowdcube,        investors.                            portfolio intelligence.   better structure
  Seedrs)**                                                No tax optimisation       (Instant Investment
                                                           tools. No anti-dilution   anti-dilution), and
                                                           protection standard.      portfolio
                                                                                     integration.

  **Private Banks &  Comprehensive wealth   1--2% AUM +    Only accessible above     Unlock democratises
  Family Offices**   management.            performance    £20--50M.                 the capability layer:
                                            fees; entry    Relationship-driven, not  same intelligence,
                                            £20--50M+      tool-driven. Not          without the AUM
                                                           scalable.                 threshold or the
                                                                                     conflicts.
  ------------------ ---------------------- -------------- ------------------------- ---------------------

**Appendix C. Glossary of Key Terms**

  ------------------- ---------------------------------------------------
  **Term**            **Definition**

  **Instant           The investment instrument used in this founding
  Investment**        round. Processed via SeedLegals. Provides immediate
                      EIS compliance processing and anti-dilution
                      protection until Series A.

  **EIS (Enterprise   UK government programme providing 30% income tax
  Investment          relief on investments in qualifying early-stage
  Scheme)**           companies, plus CGT exemption and IHT benefits.

  **SEIS (Seed        UK government programme providing 50% income tax
  Enterprise          relief on investments in qualifying seed-stage
  Investment          companies. Higher relief rate; lower annual limit
  Scheme)**           than EIS.

  **IHT (Inheritance  UK tax on the estate of a deceased person above the
  Tax)**              nil-rate band. EIS/SEIS investments qualify for
                      Business Property Relief (IHT exemption) after 2
                      years, subject to the April 2026 cap.

  **BPR (Business     HMRC provision making qualifying business assets
  Property Relief)**  (including EIS/SEIS shares) exempt from IHT after 2
                      years of qualifying ownership.

  **CGT (Capital      UK tax on gains from the disposal of assets.
  Gains Tax)**        EIS/SEIS qualifying investments are CGT-exempt on
                      profits after a 3-year qualifying hold.

  **LTV (Lifetime     Total revenue expected from a single customer over
  Value)**            the duration of their relationship with the
                      platform. Unlock LTV: £3,000--£3,250.

  **CAC (Customer     Total cost to acquire a single new paying customer.
  Acquisition Cost)** Unlock CAC: £200.

  **ARR (Annual       Annualised value of recurring subscription
  Recurring           contracts. The primary revenue metric for SaaS
  Revenue)**          businesses.

  **SeedLegals**      UK\'s leading EIS/SEIS investment platform used in
                      ∼33% of UK funding rounds. Handles Instant
                      Investment processing, share issuance, and HMRC
                      compliance documentation.

  **Instant           The investment instrument used across Unlock Access
  Investment**        and this founding round. Processed via SeedLegals.
                      Enables immediate EIS compliance and anti-dilution
                      protection.

  **Decumulation**    The phase of an investor's wealth journey in which
                      they draw down assets to fund expenditure, rather
                      than accumulating new assets. Distinct from
                      accumulation in risk profile, tax implications, and
                      planning priorities.
  ------------------- ---------------------------------------------------

*This document is private and confidential. It is intended solely for
the named recipient and must not be reproduced or distributed without
the prior written consent of Unlock. This document does not constitute
financial advice. Investment in early-stage companies carries
significant risk, including the possible loss of capital. EIS/SEIS
eligibility and tax treatment depend on individual circumstances and are
subject to HMRC rules which may change. Recipients should seek
independent financial and tax advice before making any investment
decision. Unlock does not guarantee returns. All financial projections
are management estimates and should not be relied upon as forecasts.*
