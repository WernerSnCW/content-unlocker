# UNLOCK — Portfolio Intelligence Platform
# EIS & Inheritance Tax
### A Strategy for Moving Capital Outside the Taxable Estate

*Private & Confidential — March 2026*

---

> **The core principle**
>
> EIS-qualifying investments are classified as business assets under UK tax law. Under Business Property Relief (BPR), qualifying assets held for two or more years are fully exempt from Inheritance Tax at death — removing them from the taxable estate entirely.
>
> *Managed as a rolling programme — reinvesting exit proceeds into new EIS qualifying companies — the IHT exemption can be maintained indefinitely, while capital continues working and growing.*

---

## 1. The Inheritance Tax Picture on a £5 Million Estate

Before considering any planning, a £5 million estate carries a substantial IHT liability. The calculation below assumes a single individual with full nil-rate band and residence nil-rate band available.

| | Amount |
|---|---|
| Total estate value | £5,000,000 |
| Nil-rate band | £325,000 |
| Residence nil-rate band | £175,000 |
| Total threshold | £500,000 |
| Taxable estate | £4,500,000 |
| **IHT liability at 40%** | **£1,800,000** |
| Estate received by beneficiaries | £3,200,000 |

*If the nil-rate bands from a deceased spouse are transferable, the combined threshold rises to £1,000,000, reducing the IHT liability to £1,600,000. The figures above use the single-person baseline.*

---

## 2. The April 6, 2026 Planning Window

From 6 April 2026, Business Property Relief and Agricultural Property Relief will be subject to a combined £2.5 million allowance per taxpayer at 100% relief — above that threshold, relief falls to 50%, leaving an effective IHT rate of 20% on the excess.

| Invested Before 6 April 2026 | Invested From 6 April 2026 Onwards |
|---|---|
| 100% IHT exemption on the full amount after 2 years | 100% relief on combined BPR/APR up to £2.5M per taxpayer |
| No cap — any amount invested qualifies in full | 50% relief above £2.5M — effective 20% IHT rate on excess |
| This tax year's investments lock in full relief under current rules | Larger portfolios face partial IHT exposure on new tranches above the allowance |

A £250,000 EIS investment made before 6 April 2026 qualifies for full BPR under current rules — and is unaffected by the new £2.5 million allowance, which applies to investments made from 6 April 2026 onwards.

---

## 3. How Value Passes to the Next Generation

There are two paths for an EIS investment: shares passed at death, or proceeds reinvested on exit.

| | Passing Shares at Death | Exit Proceeds — Reinvested |
|---|---|---|
| IHT position | **Zero — BPR applies, full value exempt** | **Proceeds immediately reinvested into new EIS; two-year clock restarts** |
| CGT position | **Wiped at death — no CGT on any gain** | No CGT if EIS holding period complete |
| What the family receives | **Full share value — no deductions** | Continuous IHT-exempt pot maintained; capital keeps working |
| Planning note | Ideal outcome — pass shares not cash | Reinvest promptly; gap between exit and reinvestment creates brief estate exposure |

*Unlock tracks exit events across the portfolio so reinvestment timing is visible — preventing unintentional gaps in BPR coverage.*

---

## 4. Illustrative Scenarios: £250,000 Invested on a £5M Estate

### Scenario A — Capital Returned Flat (No Growth, No Loss)

| Item | Amount |
|---|---|
| Amount invested | £250,000 |
| Income tax relief (30% EIS, claimed via self-assessment) | **£75,000 returned by HMRC** |
| Net cost to investor | £175,000 |
| Capital returned at exit (flat) | £250,000 |
| IHT liability removed from estate (40% of £250,000) | **£100,000 saved** |
| Without EIS: that £250,000 sits in estate, costs family | £100,000 in IHT at death |
| **Total benefit on £175,000 net outlay** | **£250,000 returned + £100,000 IHT saved = £350,000** |

*Even with zero investment growth, the family receives £350,000 in value on a net outlay of £175,000. The income tax relief alone recovers 43% of the gross investment before a single company performs.*

### Scenario B — Modest Growth (2× over holding period)

| Item | Amount |
|---|---|
| Amount invested | £250,000 |
| Income tax relief (30%) | **£75,000** |
| Net cost to investor | £175,000 |
| Value at death or exit (2× growth) | £500,000 |
| CGT on £250,000 gain | **Zero — wiped at death, or exempt if EIS period complete** |
| IHT on £500,000 (BPR after 2 years) | **Zero — fully exempt** |
| Equivalent conventional holding after IHT at 40% | £300,000 |
| **Family receives via EIS** | **£500,000 — £200,000 more than conventional route** |
| EIS estate context: removes £500,000 from £5M estate | **IHT on estate reduced by £200,000** |

*Growth compounds the IHT benefit — the exempt pot grows inside the EIS wrapper free of both CGT and IHT, widening the gap against conventional holdings with each passing year.*

### Scenario C — Worst Case: Company Fails Entirely

| Item | Amount |
|---|---|
| Amount invested | £250,000 |
| Income tax relief (30%) | **£75,000 received upfront** |
| Net capital at risk | £175,000 |
| Investment value | £0 (total failure) |
| Loss relief available (45% rate on £175,000 net loss) | **£78,750 recovered** |
| Total recovered from HMRC (relief + loss relief) | **£153,750** |
| **Maximum real loss to investor** | **£96,250 — approximately 39p in the pound** |
| IHT benefit: £250,000 removed from estate during holding period | **£100,000 IHT saved on that capital** |

*In the worst case, combined income tax relief and loss relief can reduce the effective net loss to approximately 39p in the pound. Even a failed EIS holding has reduced the taxable estate during the period it was held.*

---

## 5. Rolling Programme: Building Exemption Against a £5M Estate

Deploying £250,000 per year into EIS creates a rolling IHT-exempt portfolio. Each tranche passes the two-year BPR threshold in sequence, steadily reducing the estate's IHT exposure.

| Year | Invested | Cumulative EIS Portfolio | BPR-Exempt (after 2yrs) | Running IHT Saving on Death |
|---|---|---|---|---|
| 2025/26 | £250,000 | £250,000 | — | — |
| 2026/27 | £250,000 | £500,000 | £250,000 | **£100,000** |
| 2027/28 | £250,000 | £750,000 | £500,000 | **£200,000** |
| 2028/29 | £250,000 | £1,000,000 | £750,000 | **£300,000** |
| 2029/30 | £250,000 | £1,250,000 | £1,000,000 | **£400,000** |
| **Combined tax relief over 5 years** | | **5 × £75,000** | **= £375,000** | **Total tax relief benefit: £775,000** |

By year five, £1 million has moved outside the taxable estate — cutting the IHT liability on a £5 million estate from £1,800,000 to £1,400,000, a saving of £400,000. Combined with £375,000 in income tax relief, the total tax relief benefit across five years is approximately **£775,000 on £1.25 million deployed**.

*Tranches invested after April 6, 2026 are subject to the new £2.5M combined BPR/APR allowance; amounts above that threshold qualify at 50% relief only.*

---

## 6. Realistic Portfolio Outcomes: £1M Across Five Companies

| Company | Invested | Outcome | Return | Multiple |
|---|---|---|---|---|
| A | £200,000 | Fails entirely | £0 | 0× |
| B | £200,000 | Fails entirely | £0 | 0× |
| C | £200,000 | Capital returned flat | £200,000 | 1× |
| D | £200,000 | Modest growth | £320,000 | 1.6× |
| E | £200,000 | Strong performer | **£1,000,000** | **5×** |
| **Total** | **£1,000,000** | | **£1,520,000** | **1.52× gross** |

### Tax Relief Across the Portfolio

| Item | Amount |
|---|---|
| Income tax relief (30% on £1,000,000 — claimed upfront) | **£300,000** |
| Net cost after income tax relief | £700,000 |
| Loss relief — Company A (45% on £140,000 net loss) | **£63,000** |
| Loss relief — Company B (45% on £140,000 net loss) | **£63,000** |
| Total loss relief | **£126,000** |
| **Total tax relief across portfolio** | **£426,000** |
| Net cost of £1,000,000 portfolio after all relief | £574,000 |

*Loss relief is calculated on the net loss after income tax relief. Each failed company: £200,000 invested less £60,000 income tax relief already received = £140,000 net loss. Loss relief at 45%: £63,000 per company.*

### Overall Outcome for Investor and Estate

| Item | Amount |
|---|---|
| Net cost to investor (after all tax relief) | £574,000 |
| Capital returned across portfolio | **£1,520,000** |
| CGT on gains (EIS exemption, qualifying period met) | **Zero** |
| IHT on portfolio value at death (BPR after 2 years per tranche) | **Zero — fully exempt** |
| Without EIS: IHT on equivalent £1,520,000 at 40% | £608,000 owed |
| **Family receives via EIS route** | **£1,520,000 — £608,000 more than conventional route** |
| Total benefit on £574,000 net outlay | **£1,520,000 returned + £608,000 IHT saved = £2,128,000** |

Even with two complete failures, the portfolio delivers £1,520,000 in capital and removes £608,000 of IHT liability — on a net outlay of £574,000.

---

## 7. What Happens Depends on Sequence: Death Before or After Exit

The tax outcomes for the investor and their beneficiaries differ materially depending on whether companies exit before or after the investor's death.

| | Company Exits in Investor's Lifetime | Investor Dies Holding Shares | Company Fails After Death |
|---|---|---|---|
| **IHT** | Proceeds back in estate unless reinvested promptly into new EIS | **Zero — BPR applies. Full value passes IHT-free** | Zero — shares were already IHT-exempt; failure has no IHT consequence |
| **CGT (investor)** | **Zero — EIS CGT exemption applies if qualifying period met** | **Wiped at death — entire lifetime gain extinguished. No CGT owed** | No gain, no CGT issue |
| **CGT (beneficiary)** | N/A — exit already completed | Inherits at probate value (new base cost). CGT due only on growth after inheritance, at standard rates — EIS exemption does not transfer | Shares worth zero or near-zero — no CGT liability |
| **Loss relief** | **Available to investor — claimed against their income tax** | Not applicable — shares passed at value; no loss crystallised | **Not available to beneficiary — loss relief is personal to the original investor and cannot be inherited** |

> **Key planning implication**
>
> Loss relief is a personal tax relief — it belongs to the investor, not the investment. It cannot be passed to beneficiaries. For investors deploying EIS later in life, this means the benefit of loss relief on any failed companies is only available if those companies fail while the investor is alive.
>
> This strengthens the case for EIS investments in companies with shorter exit horizons — where outcomes are more likely to resolve within the investor's lifetime, allowing loss relief to be claimed if needed, and proceeds to be reinvested to maintain BPR coverage.

The CGT position at death is, by contrast, very favourable. Any gain accrued during the investor's lifetime is completely extinguished — the beneficiary inherits at probate value and only pays CGT on growth after that point. On a successful company worth £1,000,000 at death, a lifetime gain of £800,000 simply disappears.

---

## 8. Why This Requires Active Portfolio Management

Managing EIS as a deliberate IHT strategy — rather than a series of isolated investments — requires visibility across the whole picture:

- Which tranches have passed the two-year BPR threshold and are currently IHT-exempt
- Which are approaching qualification and when the clock completes
- When companies exit, triggering the need to reinvest before BPR coverage lapses
- How the EIS portfolio interacts with the rest of the estate — property, equities, pensions — to show the true residual IHT exposure
- Whether income tax relief has been correctly claimed for each tax year

**Unlock provides exactly this.** Your EIS portfolio sits alongside your full estate picture so you can see the real IHT exposure at any point, track each investment through its qualification period, and act on exit events before they create gaps in coverage.

For investors using EIS as a primary IHT vehicle, Unlock is the intelligence layer that makes the strategy coherent — not a collection of individual positions managed in isolation.

---

*This document is provided for illustrative and educational purposes only. It does not constitute financial, tax, or legal advice. All tax relief figures, thresholds, and allowances are based on legislation and published HMRC guidance as understood at March 2026 and may be subject to change. Tax reliefs depend on individual circumstances and HMRC eligibility criteria. All figures are illustrative only and should not be relied upon for investment decisions. EIS investments are high-risk, illiquid, and long-term in nature. Capital is at risk. Investors should seek independent financial and tax advice before making any investment.*

*Unlock is not authorised or regulated by the Financial Conduct Authority to provide financial advice.*

*Document version: v4 | Original: March 2026 | Last reviewed: 14 March 2026 | Status: Current — all figures correct to March 2026 legislation*
