# EIS: The Investor's Secret Weapon

**Unlock Investor Guidance Series**

*This document is for educational purposes only and does not constitute financial, tax, or investment advice. Tax treatment depends on individual circumstances and may change. Investors should seek independent professional advice before making investment decisions. Capital is at risk.*

---

## Part 1: The 2-Minute Version

The UK government will significantly subsidise you to invest in British companies.

That's not a gimmick. It's been policy since 1994. The Enterprise Investment Scheme (EIS) and its younger sibling, the Seed Enterprise Investment Scheme (SEIS), exist because the government wants private capital flowing into high-growth UK businesses. To make that happen, they offer investors tax reliefs that fundamentally change the risk-reward equation.

Here's what that looks like in practice:

- **30-50% of your investment comes back immediately** as income tax relief. Invest £100K in an EIS company, claim £30K off your tax bill. SEIS gives you 50%.
- **Profits are completely tax-free.** No Capital Gains Tax, provided you hold the shares for at least 3 years and the company continues to qualify. If the company 5x's, 10x's, or 100x's — you keep every penny.
- **If it fails, the government cushions the blow.** Loss relief means a higher-rate taxpayer only loses around 20-30p for every pound invested, depending on their marginal rate and how the relief is claimed.
- **After 2 years, it disappears from your estate.** EIS investments qualify for Business Property Relief — meaning zero inheritance tax.

One example. Sarah earns £120K. She invests £50K in an EIS-qualifying company. She claims £15K income tax relief immediately. Her real cost is £35K. If the company grows to 5x, she makes £250K — tax-free. If it fails completely, loss relief means she recovers around £15,750. Her actual downside: roughly £19,250. On a £50,000 investment.

That's asymmetric risk. Capped downside, uncapped upside, government-subsidised.

If you have a material income tax bill and you're not using EIS, you may be forgoing substantial government-backed reliefs available to qualifying investors.

---

## Part 2: Why You Haven't Heard About This

Every intelligent investor asks the same question: if EIS is this good, why hasn't someone told me?

The answer isn't that EIS is obscure. Over £34 billion has been invested through EIS and SEIS into nearly 59,000 UK companies since 1994. The government extended the scheme to 2035 because it works. Research suggests that around 40-50% of UK unicorn companies received EIS-backed funding at some point in their journey.

The reason you haven't heard about it is structural. The people you'd expect to tell you about it either can't, won't, or don't have the right incentive to.

### Your accountant can't recommend it

Accountants are not authorised by the Financial Conduct Authority (FCA) to provide investment advice. They can explain the tax mechanics after you've invested — how to claim the relief, when to file, how loss relief works. But they cannot say "you should invest in this company through EIS." It's a regulatory boundary, not a knowledge gap. Your accountant may be perfectly aware of EIS. They just aren't allowed to tell you to use it.

### Your financial adviser can, but only through funds

Financial advisers (IFAs) are FCA-authorised and can recommend EIS investments — but only regulated ones. EIS funds (managed portfolios run by FCA-authorised fund managers) are regulated products. Individual EIS companies are not.

This means your IFA can recommend an EIS fund that invests across 10-20 companies, managed by a fund manager taking 2% annual fees plus 20% of profits. What they cannot do is recommend that you invest directly in a specific EIS-qualifying company — because individual company shares are unregulated investments, and recommending them falls outside their permissions.

Here's why that matters: **EIS fund performance is, on the whole, disappointing.** Most funds target 2-3x returns, but many fail to deliver even that after fees. Total ongoing costs typically run at 3.5% per year plus arrangement fees on each transaction — so intermediaries take a significant share of whatever upside exists. Public performance data for EIS funds is virtually non-existent; what investors see in marketing materials are cherry-picked case studies and aspirational target returns. One of the best-performing EIS fund managers in the UK has delivered an average 2.6x ROI since 2001 — and that's considered an outlier, not the norm.

Meanwhile, the individual companies those funds invest in sometimes deliver extraordinary returns. One fund manager reported individual company exits at 8.7x, 14.2x, and 16.3x — but the fund-level return to investors, after losses on other holdings and after fees, is a fraction of those headline numbers. For many funds, the tax relief itself becomes the return — not the investment performance. That's the "tax tail wagging the investment dog" problem.

**The companies IFAs can recommend rarely deliver transformational returns. The companies they can't recommend are the ones that deliver 50x or 100x.**

The best-known EIS success stories — Revolut, Monzo, BrewDog, Wise, Thought Machine — all raised capital directly from early investors. Where those investments were made via funds, the fund structure significantly diluted the effective multiple for end investors. When a company returns 100x inside a 20-company fund, your share of that outcome is diluted to a 5x contribution (before the fund manager takes their cut). The fund structure caps your upside by design.

So the advisory system isn't broken — it's working exactly as regulated. But the effect is that investors are systematically steered toward the lower-returning version of EIS, while the highest-returning version remains invisible to anyone who relies on their IFA for guidance.

This is the gap Unlock fills. Not by providing regulated advice, but by providing the intelligence, due diligence, and access that lets investors evaluate individual EIS opportunities for themselves.

### EIS funds vs direct EIS — the structural gap

EIS funds invest across 10-20 companies. They offer diversification, professional management, and convenience. They're regulated, so advisers can recommend them. But performance data tells a sobering story — most funds target 2-3x, many deliver less than that after fees, and public performance data is scarce. The tax relief often ends up being the primary return, not the investment performance.

Direct EIS investment into individual companies is where the real wealth creation happens. But because individual company shares are unregulated investments, no IFA can point you toward them. You need to find them, evaluate them, and decide for yourself — which is exactly what most HNW investors don't have the time, tools, or deal flow to do.

The result is a two-tier system: a visible tier of EIS funds delivering steady, diluted returns that advisers can recommend, and an invisible tier of direct company investments delivering transformational returns that nobody in the regulated advice chain can tell you about.

Unlock's syndicate marketplace exists to make the invisible tier visible — with independent due diligence, structured access, and the tools to evaluate opportunities on your own terms.

### VCTs — the false alternative

Venture Capital Trusts (VCTs) are often presented as the main alternative to EIS. They're listed investment companies that pool investor capital and deploy it across 30-70 early-stage companies. They offer some tax benefits, but the comparison with EIS is not favourable for growth-focused investors:

| Feature | EIS (Direct) | VCT |
|---------|-------------|-----|
| Income tax relief | 30% | 20% (reduced from 30% in 2025 Budget) |
| Capital gains on profits | Tax-free | Tax-free |
| Loss relief | Yes — recovers up to 80% of loss | No |
| Inheritance tax relief | Exempt after 2 years | No |
| CGT deferral | Yes — defer gains from other assets | No |
| Annual investment limit | £1M (£2M for knowledge-intensive) | £200K |
| Minimum holding period | 3 years | 5 years |
| Typical return target | 10x+ (direct) / 2-3x (fund) | 5-7% annual income |
| Dividend tax treatment | Taxable | Tax-free |
| Liquidity | Low (private companies) | Low-medium (listed, but thin market) |

VCTs target income — typically 5-7% tax-free dividends annually, with total returns of 25-30% over 5 years. They're a tax-efficient savings product. For investors whose primary goals are capital growth, asymmetric risk, and estate planning rather than tax-efficient income, EIS typically offers stronger structural advantages.

The 2025 Autumn Budget made this clearer by reducing VCT income tax relief from 30% to 20%, while leaving EIS relief unchanged at 30%.

### The advisory gap is Unlock's opportunity

Nobody is currently helping HNW investors navigate direct EIS opportunities with independent due diligence, tax modelling, HMRC administration, and portfolio-level tracking. Financial advisers route you to funds. Accountants can't recommend. Platforms like Seedrs and Crowdcube prioritise deal volume over investor outcomes.

That gap — between what EIS offers and what investors can actually access — is what Unlock fills.

---

## Part 3: How It Actually Works — Three Investor Scenarios

The best way to understand EIS is through real situations. The following scenarios are illustrative and use simplified tax calculations. Individual circumstances vary — always seek professional advice before investing.

### Scenario A: The Growth Seeker — Using Your Tax Bill as an Investment Tool

**Profile:** James, 42. Earns £200K as a technology director. Pays approximately £63K in income tax annually. Has £800K across ISAs and a SIPP, mostly in global index trackers and a handful of blue-chip shares. No alternative investments. No EIS experience.

**The situation:** James has a concentrated, correlated portfolio. If public markets drop 30%, his entire wealth drops roughly 30%. He's been meaning to diversify but hasn't found a route into alternatives that doesn't involve high fees or opaque fund structures.

**The EIS approach:**

James invests £100K across 10 EIS-qualifying companies through Unlock's syndicate marketplace — £10K into each. Each company has been independently due-diligenced by Unlock.

**Immediate tax impact:**
- Claims 30% income tax relief: £30,000
- His next tax bill drops from £63K to £33K
- Effective cost of the £100K investment: £70,000

**Year 5 outcomes (illustrative portfolio):**

| Company | Investment | Outcome | Return | Tax treatment |
|---------|-----------|---------|--------|---------------|
| Company A | £10,000 | Fails | £0 | Loss relief claimable |
| Company B | £10,000 | Fails | £0 | Loss relief claimable |
| Company C | £10,000 | Fails | £0 | Loss relief claimable |
| Company D | £10,000 | Fails | £0 | Loss relief claimable |
| Company E | £10,000 | Fails | £0 | Loss relief claimable |
| Company F | £10,000 | Modest exit — 3x | £30,000 | Tax-free |
| Company G | £10,000 | Solid exit — 5x | £50,000 | Tax-free |
| Company H | £10,000 | Strong exit — 12x | £120,000 | Tax-free |
| Company I | £10,000 | Strong exit — 18x | £180,000 | Tax-free |
| Company J | £10,000 | Exceptional — 50x | £500,000 | Tax-free |

*Assumes higher-rate (45%) taxpayer and that loss relief is claimed against income. Actual relief depends on marginal rate and how relief is claimed. All figures are illustrative.*

**Total value received:** £927,500 on £70,000 effective cost. ~13x.

Strip out the 50x winner: £380,000 on £70,000 effective cost. Still 5.4x.

What if 8 out of 10 fail? Two companies surviving at 5x each = £100,000 gross. After income tax relief (£30K) and loss relief on 8 failures (£36K), the investor recovers £166,000 on a £100,000 investment. Still profitable despite an 80% failure rate.

---

### Scenario B: The Preserver — CGT Deferral + Inheritance Tax Planning

**Profile:** Margaret, 63. Recently sold a buy-to-let property for £400K, generating a £180K capital gain. Facing CGT of approximately £36,000. Estate valued at £2.1M. Concerned about inheritance tax.

**The EIS approach:** Margaret invests £180K into EIS-qualifying companies.

- Defers the entire £36,000 CGT liability (extinguished if held to death)
- Claims 30% income tax relief: £54,000
- After 2 years: £180K qualifies for BPR — IHT saving of £72,000

**Total tax benefit: £162,000 on a £180K investment. Effective cost: £18,000.**

**Important — April 2026 changes:** From April 6, 2026, 100% IHT relief on EIS is limited to the first £2.5M of qualifying assets per person. Above £2.5M, relief rate drops to 50%. For most HNW investors with EIS portfolios under £2.5M, the changes have no practical impact.

---

### Scenario C: The Legacy Builder — Family Wealth Strategy

**Profile:** David and Helen, 58. Combined estate £4.2M. Current IHT exposure approximately £1.2M. Each invests £250K in EIS-qualifying companies (£500K total).

- Combined income tax relief: £150,000
- Effective cost of £500K investment: £350,000
- After 2 years: BPR reduces estate exposure by £200,000

Even in a downside scenario where 80% of companies fail and the remaining return just 3x, the tax benefits alone (£150K income tax + £200K IHT) exceed the investment losses.

---

## Part 4: EIS vs Everything Else

| Feature | Direct EIS | EIS Fund | VCT | ISA | Pension (SIPP) |
|---------|-----------|----------|-----|-----|----------------|
| Income tax relief | 30% | 30% | 20%* | None | 20-45% |
| Annual limit | £1M (£2M KIC) | £1M | £200K | £20K | £60K |
| CGT on gains | Exempt | Exempt | Exempt | Exempt | Deferred |
| Loss relief | Yes | Yes | No | No | No |
| IHT exemption | After 2 years | After 2 years | No | No | Typically exempt |
| CGT deferral | Yes | Yes | No | No | No |
| Min holding period | 3 years | 3 years | 5 years | None | Age 57+ |
| Typical fees | Low/none | 2% + 20% carry | 2% + trail | 0.1-0.5% | 0.3-1% |

*VCT income tax relief reduced from 30% to 20% in the 2025 Autumn Budget*

**The key insight:** EIS is the only vehicle that combines upside protection (tax-free gains), downside protection (loss relief), estate protection (IHT exemption after 2 years), and current income offset (30% income tax relief) in a single investment.

---

## Part 5: The Maths of a Curated EIS Portfolio

**Evidence base:**
- ~60% of UK startups fail within 5 years (general population)
- ~20% failure rate for high-growth tracked companies
- A curated due-diligenced portfolio modelled conservatively at 50% failure
- £34 billion invested through EIS/SEIS into 59,000 companies since 1994
- 46.5% of all active UK unicorns received EIS-backed funding (Beauhurst 2024)
- 1,816 successful exits: 1,763 acquisitions, 53 IPOs

**Model portfolio: £100K across 10 companies**

| Outcome | Companies | Investment | Multiple | Return |
|---------|-----------|-----------|----------|--------|
| Fail | 5 | £50,000 | 0x | £0 |
| Moderate | 2 | £20,000 | 3-5x | £60,000-£100,000 |
| Strong | 2 | £20,000 | 12-18x | £240,000-£360,000 |
| Exceptional | 1 | £10,000 | 50x | £500,000 |

**Total value above original investment: ~£832,500. Return on effective cost (~£70K): ~13x.**

The asymmetry in one sentence: EIS reliefs mean you can afford to be wrong most of the time and still come out ahead. When you're right, the returns are tax-free and uncapped.

---

## Part 6: What Unlock Does For You

- **Opportunity access** — curated EIS/SEIS companies with independent due diligence reports
- **Allowance tracking** — remaining capacity across tax years, carry-back optimisation
- **Tax modelling** — income tax, CGT, and IHT impact before you commit
- **HMRC administration** — EIS3/SEIS3 certificate submission and compliance monitoring
- **Portfolio integration** — EIS alongside all other assets in the Unlock Asset Register
- **Ongoing monitoring** — holding period status, qualifying condition alerts

---

## Part 7: April 2026 — What's Changing

From April 6, 2026: 100% IHT relief on EIS is capped at £2.5M per person (combined with agricultural property). Above £2.5M, relief rate drops to 50% (effective 20% IHT on excess). Transferable between spouses — couples can shelter £5M.

**For most HNW investors with EIS portfolios under £2.5M, no practical impact.** EIS remains the most powerful IHT planning tool available in the UK.

**AIM shares:** Treated differently — drop from 100% to 50% BPR regardless of value, no £2.5M allowance. Direct EIS in private companies retains 100% relief up to £2.5M.

This is confirmed legislation via the Finance Bill 2025-26.

---

## Glossary

**BPR** — Business Property Relief. IHT exemption for qualifying business assets including EIS shares held 2+ years.

**CGT** — Capital Gains Tax. EIS gains are exempt.

**EIS** — Enterprise Investment Scheme. 30% income tax relief, CGT-free gains, loss relief, IHT exemption after 2 years.

**IHT** — Inheritance Tax. 40% on estates above nil-rate band (currently £325K + £175K RNRB).

**KIC** — Knowledge-Intensive Company. Higher EIS limits (£2M per investor).

**Loss Relief** — Failed EIS investment loss (minus income tax relief received) offset against income tax. Reduces effective loss to ~20-30p per pound for higher-rate taxpayers.

**SEIS** — Seed Enterprise Investment Scheme. 50% income tax relief, £200K annual limit.

**VCT** — Venture Capital Trust. 20% income tax relief, tax-free dividends, no loss relief or IHT exemption.

---

*Statistics drawn from HMRC National Statistics, Beauhurst EIS 30th Anniversary Report 2024, SyndicateRoom power law white paper, and publicly available fund manager disclosures. Full source references available on request.*

*Unlock is not a financial adviser and does not provide regulated investment advice. Scenarios are illustrative. Always consult a qualified adviser before investing.*

*© 2026 Unlock Services Limited. All rights reserved.*
