# UNLOCK ACCESS
## What Unlock Access Is

*A plain-English guide for investors who are reading about Unlock Access for the first time.*

| What it is | What it is not | What makes it different |
|---|---|---|
| A curated deal-flow service that identifies, evaluates, and supports early-stage EIS-qualifying companies — and connects them to sophisticated investors who have been qualified to access them. | A fund. A regulated investment manager. A financial adviser. Unlock Access does not manage money, hold assets, or make investment decisions on your behalf. | Every company is scored against 24 published criteria before you see it. Every fee and relationship is disclosed. Every investor is qualified before accessing opportunities. |

---

## The Proposition in Plain Terms

Most sophisticated investors who invest in EIS do so through passive funds — vehicles that select from deal flow they do not originate, apply evaluation frameworks they do not publish, and report to investors who cannot interrogate the logic. When things go wrong, investors find out late.

Unlock Access is built on a different premise. Every company on the platform has been scored against 24 published criteria before any investor sees it. Every scoring summary is shared with investors in full — not as a marketing document, but as the same evaluation the Unlock Access team used to make its own decision. Every investor is qualified before accessing opportunities. Every fee and relationship is disclosed.

**The objective is not to find unicorns.** It is to build a portfolio where winners systematically outnumber losers — where the combination of rigorous evaluation, EIS tax relief structures, and active post-investment support means that, across a 15-year programme, investors achieve a win rate materially higher than the unscored market average.

---

## The Four Parts of the Service

Unlock Access provides four things, each of which the EIS market typically leaves investors to arrange for themselves.

### GUIDANCE — How to think about EIS investing

Portfolio construction, diversification, risk calibration, and the 15-year programme architecture that gives early-stage investing its best chance of generating consistent returns. The intelligence layer that helps investors make better decisions — without making those decisions for them.

### TOOLS — The platform infrastructure

Tax modelling, HMRC compliance submissions, portfolio tracking, scoring summaries, and due diligence packs. Every tool needed to invest and manage EIS positions efficiently — built into a single service rather than assembled from scratch by each investor.

### ACCESS — Curated deal flow

Companies that have passed the evaluation framework. The Unlock Access investor network. Opportunities that most investors would not find independently — and, critically, would not be able to assess with confidence if they did.

### ADMINISTRATION — Investment and portfolio administration

The compliance process, EIS3 certificate management, HMRC submissions, and ongoing portfolio administration that most EIS platforms leave investors to handle alone. Unlock Access handles the paperwork so investors focus on the decisions.

---

## The Evaluation Framework

No company reaches investors before this stage is complete.

| Stage | What happens | Filter |
|---|---|---|
| Initial screening | Business model, market size, founder background, EIS eligibility | Eliminates companies that do not meet basic criteria |
| Scored evaluation | 24-criterion framework across People, Strategy, Execution, Cash | Score threshold required to proceed |
| Investor qualification | Risk capacity, context, and tax position confirmed | This is a filter, not a formality |
| Post-investment support | Ongoing relationship — reporting, context, risk indicators | The relationship does not end at close |

---

## How Unlock Access Is Funded

Unlock Access earns from the service it provides to investors and companies — not from product recommendations, trail fees, or commissions. There are no hidden commercial relationships. All fees are disclosed in full before any investment is made.

This transparency is structural, not aspirational. Unlock Access raises capital for its own pipeline companies — Unlock and Cloudworkz — and states this openly. Full fee and relationship disclosure is what makes the Guidance part of the service credible.

---

## The Team Behind the Service

Unlock Access was founded by Tom King, who has spent 15 years facilitating alternative investment opportunities for sophisticated private investors — with over £250 million in investment facilitated through a network of high-net-worth and often high-profile investors. Tom is one of a small number of UK founders to hold Scaling Up certification, and the evaluation framework described in this document draws directly on that methodology, adapted specifically for EIS investment.

**tom@unlockdd.com | www.unlockdd.com**

---

*This document is for information purposes only and does not constitute financial advice or an invitation to invest. Unlock Access does not hold FCA authorisation and operates as a deal-flow and information service. EIS and SEIS investments are high-risk and illiquid. Capital is at risk. Investors should seek independent financial advice before making any investment decision.*

*Original: March 2026 | Last reviewed: 14 March 2026 | Status: Current*
