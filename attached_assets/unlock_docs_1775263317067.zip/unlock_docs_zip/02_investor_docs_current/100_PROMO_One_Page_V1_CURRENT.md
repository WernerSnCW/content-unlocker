+----------------+----------------+-----------------+-----------------+
| Pre-money      | Ticket size    | EIS / SEIS      | Shares issued   |
| valuation      |                | eligible        |                 |
|                | **£20K --      |                 | **6 April       |
| **£6.5M**      | £500K**        | **Yes ---       | 2026**          |
|                |                | processed at    |                 |
|                |                | investment**    |                 |
+----------------+----------------+-----------------+-----------------+

**IFAs cover what's regulated. Your accountant covers what's taxable.
Nobody is looking at the whole picture.**

**Unlock gives you the whole picture.**

**What Unlock does**

Unlock is a portfolio intelligence platform for serious private
investors. It models tax drag across your entire estate --- ISAs,
pensions, property, EIS, alternatives --- in a single environment. The
Tax Intelligence Engine identifies where your current structure is
costing you money. The Decumulation Planner optimises which assets to
draw down, in which order, to minimise lifetime tax --- built
specifically around the April 2027 pension IHT rule change that inverts
conventional draw-last advice.

+-----------------------------------------------------------------------+
| **6 April 2026 --- the deadline that changes the maths.**             |
|                                                                       |
| EIS Inheritance Tax relief is currently unlimited at 100%. From 6     |
| April 2026 it is capped at £2.5M per estate (50% above the          |
| threshold). Shares issued before that date are grandfathered.         |
| Founding investors who commit now lock in uncapped relief             |
| permanently.                                                          |
+-----------------------------------------------------------------------+

**The investment**

+----------------------------------+-----------------------------------+
| Unlock is raising £1.2M at a     |   ------                          |
| £6.5M pre-money valuation, via   | --------- ----------- ----------- |
| Instant Investment through       |   **R                             |
| SeedLegals. EIS compliance is    | elief**      **EIS**     **SEIS** |
| processed at the point of        |                                   |
| investment --- not after round   |   **Income tax    30%         50% |
| close.                           |   relief**                        |
|                                  |                                   |
| **EIS / SEIS worked example**    |   *                               |
|                                  | *CGT on exit** Exempt      Exempt |
| You invest £50,000 under SEIS.   |                                   |
| You claim 50% income tax relief  |                                   |
| immediately: £25,000 back        |  **IHT (until 6  100%        100% |
| against your tax bill. Effective |   Apr)**                          |
| cost: £25,000. Profits on exit   |                                   |
| are tax-free. If the company     |   **Lo                            |
| fails, loss relief reduces your  | ss relief   \~27.5p/£   \~27.5p/£ |
| at-risk position further. The    |   (AR)**                          |
| government is backing half your  |   ------                          |
| downside.                        | --------- ----------- ----------- |
|                                  |                                   |
|                                  | *Loss relief est. for             |
|                                  | additional-rate taxpayers.        |
|                                  | Subject to adviser confirmation.* |
+----------------------------------+-----------------------------------+

**Founding investor terms --- never offered again**

  ------- --------------------------------------------------------------------
  **→**   **Anti-dilution until Series A.** Your ownership percentage is
          protected from dilution until the Growth Capital round. Your equity
          share doesn't erode as new capital comes in.

  ------- --------------------------------------------------------------------

  ------- --------------------------------------------------------------------
  **→**   **Pro-rata rights.** You have the right to participate in the Growth
          Capital round (Q2 2026) to maintain your ownership percentage.

  ------- --------------------------------------------------------------------

  ------- --------------------------------------------------------------------
  **→**   **Discount negotiated individually.** Based on ticket size and
          strategic contribution. Discussed in confidence on the discovery
          call.

  ------- --------------------------------------------------------------------

*Founding investor benefits also include lifetime platform access (no
subscription fee, ever), white-glove onboarding, and direct roadmap
input. These expire at public launch (Q1 2027).*

**How you exit**

Potential strategic acquirers include Bloomberg, Morningstar, Refinitiv,
and S&P Global --- all of whom have acquisition history in the UK wealth
data and portfolio analytics space. Comparable SaaS acquisitions in UK
wealth management have cleared £30--70M at Series B. These figures are
illustrative based on market comparables, not a forecast.

+-----------------------------------------------------------------------+
| **One conversation is all it takes.**                                 |
|                                                                       |
| Watch the two-minute product demo at www.unlockdd.com, then reply to  |
| arrange a call with Tom. The process from first conversation to       |
| investment complete typically takes three weeks.                      |
|                                                                       |
| **tom@unlockdd.com**                                                  |
+-----------------------------------------------------------------------+

**P.S.** *Shares issue 6 April 2026. If you'd like to talk before then,
reply directly to this email.*

*This document is for information purposes only and does not constitute
financial advice or an invitation to invest. Unlock is EIS/SEIS
eligible; eligibility does not guarantee relief. Tax treatment depends
on individual circumstances and should be verified with an independent
adviser. Capital is at risk. Early-stage investment involves a high
degree of risk including loss of capital. Intended for sophisticated and
high-net-worth investors only as defined by the Financial Services and
Markets Act 2000 (Financial Promotion) Order 2005. Return figures are
illustrative based on market comparables and are not forecasts. Unlock
Services Limited. Registered in England and Wales.*
