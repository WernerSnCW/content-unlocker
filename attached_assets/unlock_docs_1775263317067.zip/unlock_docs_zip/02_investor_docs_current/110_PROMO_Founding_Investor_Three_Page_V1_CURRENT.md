+-----------------------------------------------------------------------+
| **UNLOCK**                                                            |
|                                                                       |
| **Founding Investor Programme**                                       |
|                                                                       |
| *Institutional-grade portfolio intelligence. Built for investors      |
| who\'ve outgrown everything else.*                                    |
+-----------------------------------------------------------------------+

**The problem you already know**

Your wealth doesn't live in one place. Neither does the advice. Your IFA
covers what's regulated. Your accountant covers what's taxable. Nobody
is looking at the whole picture --- EIS holdings, ISAs, pensions,
property, alternatives --- at the same time, through the same lens.

The tools that exist are either too simple (aggregators that display,
not analyse) or too conflicted (platforms that earn from selling you
products). Institutional-grade analysis --- the kind that models tax
drag across your whole estate, stress-tests against multiple scenarios,
and tells you when your drawdown sequencing is costing you money --- has
never been available outside a private bank at £5,000 a year.

That's the gap Unlock fills.

**What Unlock is**

Unlock is a portfolio intelligence platform for serious private
investors. Not a broker. Not an aggregator. Not a robo-advisor. A
whole-of-wealth analysis and planning environment that works across
every asset class you actually hold.

+---+--------------------------------------------------------------------+
| * | **Living Asset Register**                                          |
| * |                                                                    |
| ● | One source of truth across every asset. Cash, ISAs, pensions,      |
| * | property, EIS, VCTs, alternatives. Always current, never manual.   |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Tax Intelligence Engine**                                        |
| * |                                                                    |
| ● | Models income tax, CGT, IHT, and pension interactions across your  |
| * | portfolio. Identifies drag before it happens.                      |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Portfolio Simulator**                                            |
| * |                                                                    |
| ● | Stress-test any scenario --- market shock, drawdown sequence,      |
| * | estate distribution --- before you commit.                         |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Decumulation Planner**                                           |
| * |                                                                    |
| ● | Optimises which assets to draw down, in which order, to minimise   |
| * | lifetime tax drag. Built around the April 2027 pension IHT rule    |
| * | change.                                                            |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Unlock Access (EIS/SEIS)**                                       |
| * |                                                                    |
| ● | Curated deal flow, direct portfolio service. Transparent fees. No  |
| * | conflicts buried in the small print.                               |
| * |                                                                    |
+---+--------------------------------------------------------------------+

The platform is already in use with founding investors. The Asset
Register and Unlock Access are operational. Tax Engine and Simulator are
in active build, fully funded by this raise.

**Why invest in Unlock --- not just use it**

Unlock is raising a founding round to complete the core build and take
the platform to public launch in Q1 2027. The market opportunity is
unambiguous: 1.8 million UK investors with investable assets above
£250,000, an advice gap that no current platform addresses, and a
regulatory environment that actively rewards the kind of tax-efficient
investing Unlock is built around.

The business model is subscription-led, not transaction-led. Unlock
earns from platform access, not from selling you investments. That
alignment --- not incidental --- is the structural moat.

+-----------------+-----------------+-----------------+-----------------+
| Pre-money       | Raise target    | Founding slots  | Share issuance  |
| valuation       |                 |                 |                 |
|                 | **£1.2M**       | **\~25 by       | **6 April       |
| **£6.5M**       |                 | design**        | 2026**          |
+-----------------+-----------------+-----------------+-----------------+

EIS/SEIS eligibility means the effective entry cost is significantly
lower than face value. For an additional-rate taxpayer investing £50,000
at SEIS terms: 50% income tax relief reduces the net cost to £25,000 at
the point of investment. Profits on exit are tax-free. Loss relief
limits downside further. The government is effectively backing half your
early-stage risk.

This is not investment advice. Tax relief figures are estimates based on
current HMRC rules; individual positions vary. We recommend independent
verification with your tax adviser before investing.

  --------------------------- --------------------- ---------------------
  **Relief type**             **EIS**               **SEIS**

  Income tax relief           30% of investment     50% of investment

  Capital gains on exit       Exempt (3-year hold)  Exempt (3-year hold)

  IHT relief (until 6 Apr     100% --- unlimited    100% --- unlimited
  2026)                                             

  Loss relief (additional     \~27.5p per £ at risk \~27.5p per £ at risk
  rate)                                             
  --------------------------- --------------------- ---------------------

Loss relief figure (\~27.5p per £ at risk) is for additional-rate
taxpayers. Higher-rate figure is \~30p. Figures subject to adviser
confirmation.

+-----------------------------------------------------------------------+
| **Why 6 April 2026 is the hard deadline**                             |
|                                                                       |
| From 6 April 2026, EIS Inheritance Tax relief is capped at £2.5M per    |
| individual (50% above the threshold). Currently, relief is unlimited  |
| at 100%. Shares issued before 6 April 2026 are grandfathered under    |
| current rules. Founding investors who commit before this date lock in |
| the full, uncapped relief.                                            |
+-----------------------------------------------------------------------+

**Why the valuation is credible**

£6.5M pre-money for a pre-launch SaaS platform with validated demand,
operational infrastructure, and a defensible data moat sits at the
conservative end of comparable early-stage UK fintech benchmarks.
Bloomberg Intelligence, Morningstar, and Refinitiv are the most natural
acquirers at scale. Comparable SaaS acquisitions in UK wealth management
have cleared £30--£70M at Series B. The founding round entry is priced
to reflect current stage honestly.

**The founding investor offer**

We are closing a round of approximately 25 founding investors. The
number is deliberate --- quality of strategic contribution matters more
than speed of capital. Founding investors receive terms and benefits
that will not be available at any subsequent round.

+---+--------------------------------------------------------------------+
| * | **Lifetime platform access**                                       |
| * |                                                                    |
| ● | Full access to every feature, today and as they launch. No         |
| * | subscription fee. Ever. While standard users pay £99--£249 per     |
| * | month, you pay nothing.                                            |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Anti-dilution until Series A**                                   |
| * |                                                                    |
| ● | Founding investors' ownership percentage is protected from         |
| * | dilution until the Growth Capital round (Q2 2026). Your equity     |
| * | share doesn't erode as new capital comes in.                       |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Instant Investment via SeedLegals**                              |
| * |                                                                    |
| ● | EIS compliance processed immediately at point of investment. EIS3  |
| * | certificates issued individually --- not batched. Arriving 15--40  |
| * | working days post-investment.                                      |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Pro-rata rights**                                                |
| * |                                                                    |
| ● | Founding investors have the right to participate in the Growth     |
| * | Capital round to maintain their ownership percentage.              |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Roadmap access and quarterly updates**                           |
| * |                                                                    |
| ● | Direct input into product direction. Quarterly investor updates    |
| * | with financial performance, user growth, and feature progress.     |
| * |                                                                    |
+---+--------------------------------------------------------------------+

  -----------------------------------------------------------------------
  **Founding investor discount is negotiated individually based on ticket
  size and strategic value. Details are discussed in confidence on the
  discovery call.**

  -----------------------------------------------------------------------

**Who this is for**

Founding investors in this round share a specific profile: they are
active private investors who understand the problem Unlock solves from
personal experience, who see the strategic value of backing a platform
they will actually use, and who are comfortable with early-stage risk
appropriately mitigated through EIS/SEIS structure.

You do not need to be a fintech expert. You need to be an investor who
has felt the friction this platform removes. If that is you, the
conversation is worth having.

**Next steps**

The process takes three steps and, typically, three weeks from first
conversation to investment complete.

+---+--------------------------------------------------------------------+
| * | **Discovery call (20 minutes)**                                    |
| * |                                                                    |
| ● | Confirm fit, discuss your portfolio context, and answer any        |
| * | initial questions. No commitment required.                         |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Platform demo (30 minutes)**                                     |
| * |                                                                    |
| ● | See the product live with your own asset classes as the frame.     |
| * | Founding investors tell us this is when it lands.                  |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Allocation and Instant Investment**                              |
| * |                                                                    |
| ● | Reserve your allocation. SeedLegals processes the Instant          |
| * | Investment agreement digitally. EIS compliance processed at the    |
| * | point of investment. Shares issued 6 April 2026.                   |
+---+--------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Tom King, Founder & CEO**                                           |
|                                                                       |
| tom@unlockdd.com                                                      |
|                                                                       |
| www.unlockdd.com                                                      |
+-----------------------------------------------------------------------+

*This document is for information purposes only and does not constitute
financial advice or an invitation to invest. Unlock is EIS/SEIS eligible
but eligibility does not guarantee relief. Tax treatment depends on
individual circumstances. Capital is at risk. Early-stage investment
involves a high degree of risk including loss of capital. This document
is intended for sophisticated and high-net-worth investors only as
defined by the Financial Services and Markets Act 2000 (Financial
Promotion) Order 2005. Please seek independent financial and tax advice
before making any investment decision. Unlock Services Limited.
Registered in England and Wales.*
