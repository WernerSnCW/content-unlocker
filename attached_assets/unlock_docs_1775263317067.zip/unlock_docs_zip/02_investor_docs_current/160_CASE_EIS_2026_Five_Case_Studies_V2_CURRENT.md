# UNLOCK ACCESS
# The Case for EIS 2026
### How EIS is used to build tax-free, generational wealth, and why 2026 is the time to act.

---

**EIS is most relevant to investors who tick one or more of these boxes:**

- You have a meaningful income tax bill — broadly, more than pensions, salary sacrifice, and ISA allowances have been able to absorb — and you would like to reduce it this tax year.
- You have a capital gain from a business sale, property disposal, or portfolio event that you would prefer not to pay in full this tax year.
- Your estate has IHT exposure, and the pension that used to help shelter it will be in scope from April 2027.
- You want exposure to early-stage UK companies with uncapped, CGT-free upside.

*You don't need to tick all four. Most investors come to EIS through one door and find the others open too.*

---

## Which profile is most relevant to you?

| If this sounds like you... | Go to |
|---|---|
| You have a meaningful income tax bill that pensions and ISAs haven't solved | **James (Case 1) or Sophie (Case 5)** |
| You've sold a business or property and face a CGT liability | **Richard (Case 2)** |
| Your pension was your estate plan — and April 2027 has broken it | **George (Case 3)** |
| You've recently retired with a higher-than-expected tax bill | **Martin (Case 4)** |
| You're a high earner in your 30s–40s building long-term tax-free wealth | **Sophie (Case 5)** |

---

## Why 2026 Is the Right Moment

The UK tax-advantaged landscape has shifted materially this year. Three structures that HNW investors have relied on have been curtailed or broken. One has not.

| Structure | Pre-2026 | 2026/27 Reality |
|---|---|---|
| VCTs | 30% income tax relief | Reduced to 20% from 6 April 2026 |
| Pensions (IHT) | Outside IHT scope entirely | In scope from 6 April 2027 |
| AIM shares (BPR) | 100% IHT relief | Reduced to 50% in all cases |
| **EIS/SEIS** | 30% / 50% income tax relief | **Unchanged — full reliefs intact** |

EIS is now the only mainstream UK structure with all four reliefs intact: immediate income tax reduction, CGT-free growth, loss relief, and IHT exemption after two years. The government has extended the scheme to 2035 and expanded company investment limits; companies can now raise up to £10M annually, up from £5M.

---

## Who This Document Is For

Direct investment into EIS-qualifying companies sits outside the scope of regulated financial advice in the UK. Your accountant can explain how EIS works and confirm the tax treatment, but cannot advise you to invest. Your financial adviser can recommend EIS funds managed by authorised discretionary managers, but cannot advise you to invest directly into individual companies.

The result is a structural gap. The investors best placed to benefit from direct EIS — those with meaningful income tax liabilities, significant capital gains, or estate planning requirements that conventional tools do not address — are precisely the investors whose professional advisers cannot point them toward it.

**The investors this document is written for have three things in common:**

**1. They have the liquidity to participate.** Capital committed should be genuinely surplus to requirements — money whose absence for five or more years creates no financial pressure.

**2. They have the time and inclination to engage.** In practice: reading the investment documentation for each company, signing a subscription agreement, and providing basic details to your accountant when the EIS3 certificate arrives. Unlock handles everything else.

**3. They are comfortable making decisions without being told what to do.** No regulated adviser will recommend a specific EIS company to you. The decision — which companies to back, how much to invest, and when — is yours entirely.

---

## How Returns Are Distributed

EIS investing follows a power law. NESTA's foundational UK study of 1,080 investments found that 9% of exits produced 80% of all positive cash flows. Unlock's research uses a 4/3/2/1 distribution per 10 companies:

| Companies | Outcome | Return multiple | Timeline |
|---|---|---|---|
| 4/10 | Write-off — total loss | 0x | Y 2–4 |
| 3/10 | Marginal exit | 2x | Y 4–7 |
| 2/10 | Strong exit | 6x | Y 7–10 |
| **1/10** | **Fund returner** | **20x** | **Y 10–15** |
| **Base Case** | **3.8× gross return across the portfolio** | **3.8x** | **All CGT-Free** |

The 3.8× base case sits above NESTA's 2.2× raw average for three reasons: EIS qualification acts as an involuntary quality filter; the EIS market professionalised significantly after 2012; and more recent data is more optimistic — the 2015 ERC study found 30% of investments expected to return 6× or more.

On the failures — four in ten — loss relief at 45% (additional-rate taxpayer) means the effective loss is approximately 38.5p per pound, not 100p. For a higher-rate taxpayer the figure is approximately 30p. On the exits, all gains are CGT-free.

*Sources: NESTA / BBAA (2009), Enterprise Research Centre / UKBAA (2015), Beauhurst / EISA 30th Anniversary Report (2024), GrowthInvest (2024), HMRC National Statistics.*

---

## How the Structure Works — David's Portfolio

David invests £10,000 into each of ten EIS-qualifying companies. Total deployed: £100,000. Income tax relief at 30%: £30,000. Effective cost after relief: £70,000.

| Companies | Outcome | Return multiple | Gross Return | Timeline |
|---|---|---|---|---|
| 4 | Write-off — total loss | 0x | £0 | Y 2–4 |
| 3 | Marginal exit | 2x | £60,000 | Y 4–7 |
| 2 | Strong exit | 6x | £120,000 | Y 7–10 |
| **1** | **Fund returner** | **20x** | **£200,000** | **Y 10–15** |
| **Total** | **4 losses. 6 exits.** | **3.8x gross** | **£380,000** | **All CGT-Free** |

Four failures cost David £23,800 net of loss relief at 45% (additional-rate taxpayer). Six exits return £380,000 entirely CGT-free — against an effective cost of £70,000 after income tax relief.

*The upside is uncapped and tax-free. The downside is materially reduced by the reliefs. That asymmetry is the structure.*

---

## CASE 1 — James
### A large income tax bill and nowhere left to put it efficiently.

James is a senior partner at a professional services firm. He earns £195,000 a year. His ISA has been maxed for fifteen years. His pension contributions are capped at the annual allowance. He pays just over £72,000 in income tax annually. The next £72,000 will go to HMRC the same way it always has. Unless he does something different.

**What EIS does for James:** EIS allows James to claim 30% of his investment back against his income tax bill in the year he invests. SEIS goes further: 50% relief. He blends both — £40,000 into SEIS, £80,000 into EIS — and his combined annual relief is £44,000. His effective annual cost is £76,000. HMRC funds the remaining £44,000. Any growth from companies that succeed is entirely free of CGT. Any cohort held for two years passes outside his estate without a trust, a gift, or a solicitor arrangement.

*Over fifteen years, James receives £660,000 in income tax relief — capital that would otherwise have gone to HMRC, returned to him in the year of investment before the underlying companies do anything at all.*

**Fifteen Years: EIS vs Paying Tax**

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (15yr) | £1,080,000 | £420,000 |
| Capital redirected into portfolio | £0 | £660,000 invested, not lost |
| Portfolio value at year 15 (base case) | £0 | £2,940,000 |
| CGT on exits | N/A | Zero |
| IHT position | Fully in estate | Full active portfolio outside estate |
| **Net financial position at year 15** | **£0 from the £660,000 paid to HMRC** | **£2,940,000 portfolio + £660,000 tax saved** |

*Annual investment £120,000 (£40,000 SEIS at 50% + £80,000 EIS at 30%). All figures illustrative. Capital at risk.*

---

## CASE 2 — Richard
### A business sale, a CGT liability, and an IHT problem that appeared overnight.

Richard has run his own business for twenty years. He draws salary and dividends of around £220,000 a year. For Richard, EIS is a response to events — and the events arrive quickly.

**Phase 1: Age 50–67 — Building the Portfolio**

For seventeen years, Richard invests £160,000 a year into a blend of SEIS and EIS-qualifying companies. Combined relief — £64,000 annually — reduces his income tax bill by nearly 80%.

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (17yr) | £1,360,000 | £272,000 |
| Capital redirected into portfolio | £0 | £1,088,000 invested, not lost |
| IHT position | Fully in estate | Full active portfolio outside estate |

**The Business Sale — Age 67**

Richard sells his business. Net proceeds generate a gain of approximately £600,000. After Business Asset Disposal Relief at 18%, his CGT liability stands at £108,000. In the year of the sale, he invests £400,000 into EIS-qualifying companies, deferring that liability in full. If he holds the shares until death, under current rules the deferred gain is extinguished entirely.

**Phase 2: Age 67–80 — Protection & Continuity**

In retirement, Richard continues investing annually: £50,000 into SEIS, £40,000 into EIS. Thirteen years in, approximately £1,390,000 of post-sale assets sit outside his estate. The IHT saving on those assets alone: approximately £556,000.

| | Without EIS | With EIS |
|---|---|---|
| CGT on business sale (£600k gain) | £180,000 paid | Deferred — extinguished on death |
| Post-sale assets in estate (13yr) | £1,390,000 IHT-exposed | £1,390,000 outside estate |
| IHT saving on exempt assets | £0 | ~£556,000 |
| Income tax relief (13yr) | £0 | £300,000 |

*All figures illustrative. Capital at risk.*

---

## CASE 3 — George
### A pension that used to shelter his estate. From April 2027, it doesn't.

George retired at 58 from financial services. His pension pot — built carefully over three decades — stands at £1.4M. For most of his retirement that pension has been his primary estate planning tool: it sits outside his estate, his sons inherit it free of IHT.

In October 2024, that plan changed. From 6 April 2027, unused pension pots and death benefits come into scope for inheritance tax. George's £1.4M pension will become fully IHT-exposed. His beneficiaries face a potential £560,000 tax bill.

| | Before April 2027 | After April 2027 |
|---|---|---|
| Pension Pot | £1,400,000 | £1,400,000 |
| IHT exposure | £0 | £560,000 |
| Current estate plan | Working | Broken |

**What EIS does for George:** EIS shares held for two years qualify for Business Property Relief and pass outside the estate — exactly what the pension used to do. He invests £35,000 a year — £20,000 into SEIS, £15,000 into EIS — generating £12,000 in combined relief applied against his tax bill.

| | Without EIS | With EIS |
|---|---|---|
| Assets outside estate at year 2 | £0 | £70,000 |
| Assets outside estate at year 5 | £0 | £175,000 |
| Assets outside estate at year 10 | £0 | £350,000 |
| IHT saving at year 10 | £0 | £140,000 |
| Income tax relief (10yr) | £0 | £120,000 |
| Portfolio value at year 10 (base case) | £0 | £573,000 |

*April 2027 is not a distant deadline. Investors who start the BPR clock now will have qualifying assets outside their estate before the new rules take effect.*

---

## CASE 4 — Martin
### Just retired. A tax bill he didn't expect. And the realisation that now is exactly the right time.

Martin spent his career in financial services, retiring recently as a senior executive. His pension drawdown, investment income, and consultancy work in the first years of retirement are generating a tax bill that surprises him. His ISA is full. His pension is already in drawdown. The conventional containers are used up.

**What EIS does for Martin:** Martin invests £60,000 — £20,000 into SEIS at 50%, £40,000 into EIS at 30% — generating £22,000 in combined income tax relief, applied directly against his tax bill this tax year. His effective cost is £38,000. The relief can also be carried back to the previous tax year.

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (10yr) | £220,000 | £0 (offset by relief) |
| Capital redirected into portfolio | £0 | £220,000 invested, not lost |
| Portfolio value at year 10 (base case) | £0 | £836,000 |
| CGT on exits | N/A | Zero |
| IHT position | Fully in estate | Active portfolio outside estate |
| **Net financial position at year 10** | **£0 from tax paid** | **£836,000 portfolio + £220,000 tax saved** |

*The emphasis is simple: do it now. The relief is this year's. The BPR clock starts this year. Every year of delay is a year of compounding that doesn't happen.*

---

## CASE 5 — Sophie
### High earner. Late 30s. Two decades of compounding ahead of her.

Sophie is a director at a technology company. She is 38, earns £215,000 a year, and pays just under £80,000 in income tax annually. Her ISA is maxed. Her pension contributions are capped. She has decades of peak earning ahead of her and no efficient place left to put significant capital.

**What EIS does for Sophie:** Sophie invests £100,000 a year — £20,000 into SEIS at 50%, £80,000 into EIS at 30% — generating £34,000 in combined income tax relief annually. Her effective annual cost is £66,000. HMRC funds the remaining £34,000. Every cohort that reaches two years qualifies for BPR. Every exit is CGT-free.

Sophie's advantage is time. A twenty-year programme allows more portfolio vintages to mature, more fund-returner outcomes to land, and more IHT-exempt cohorts to accumulate.

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (20yr) | £1,600,000 | £920,000 |
| Capital redirected into portfolio | £0 | £680,000 invested, not lost |
| Portfolio value at year 20 (base case) | £0 | £2,584,000 |
| CGT on exits | N/A | Zero |
| IHT position | Fully in estate | Substantial portfolio outside estate |
| **Net financial position at year 20** | **£0 from the £680,000 paid to HMRC** | **£2,584,000 portfolio + £680,000 tax saved** |

*The best time to start was last year. The second best time is this tax year.*

---

## The Same Structure. Five Entirely Different Purposes.

| | James | Richard | George | Martin | Sophie |
|---|---|---|---|---|---|
| Profile | Senior partner, peak earning | MD pre-sale; HNW retiree post-sale | Retired exec, pension problem | Recently retired, high tax bill | High earner, late 30s, long-term builder |
| Primary objective | Redirect tax into portfolio. Build CGT-free wealth. | Phase 1: wipe income tax. Phase 2: CGT deferral + IHT rebuild. | Rebuild IHT shelter; reduce income tax along the way. | Convert surprise tax bill into portfolio. Do it now. | Build 20-year EIS programme. Maximise relief compound effect. |
| Key relief | Income tax + CGT exemption | CGT deferral + BPR rebuild | BPR clock replaces broken pension shelter | Income tax relief, immediate impact | Income tax + long-run CGT-free growth |
| Urgency | Moderate — start sooner, compound longer | Event-driven — tied to the sale | High — April 2027 deadline | High — do it now, this tax year | Moderate — but every year delayed is compounding lost |

---

## Reference: The Four Reliefs

### 1. Income Tax Relief — 30% (EIS) or 50% (SEIS)

When you invest in a qualifying company, you can claim 30% of the amount invested as a reduction against your income tax bill — or 50% under SEIS. The relief is claimable via Self Assessment or PAYE tax code adjustment once the company has provided the EIS3 or SEIS3 certificate. Relief can also be carried back to the previous tax year.

### 2. Capital Gains Tax Exemption — 0%

If your investment grows and you sell after holding for at least three years, any profit is entirely exempt from Capital Gains Tax — provided the qualifying conditions are met throughout the holding period. There is no upper limit on the gain.

### 3. Loss Relief

Early-stage companies fail. What EIS changes is how much you actually lose. If an investment becomes worthless, the net loss can be offset against income or CGT. For a 45% taxpayer: effective loss on a failed SEIS investment is approximately 27.5p per pound; on EIS approximately 38.5p — assuming income tax relief was claimed in full and loss relief is available against income at the investor's marginal rate.

### 4. Inheritance Tax Relief — 0% after two years

EIS shares held for at least two years qualify for Business Property Relief and exit your estate entirely. From 6 April 2026, a new £2.5M allowance applies to the combined value of assets qualifying for 100% Agricultural Property Relief and Business Property Relief; 50% relief applies above that threshold. Directly-held EIS and SEIS shares in unquoted companies continue to qualify within the allowance.

---

## Reference: Risks, Context, and Relevance

**The risks, and they are real:**

- Capital loss — a significant proportion of early-stage companies fail; individual investments may lose their entire value.
- Illiquidity — EIS shares are not publicly traded; capital is committed for a minimum of three years to retain income tax relief, and realistically five to ten years before a liquidity event.
- Qualification loss — if a portfolio company loses its EIS qualifying status after you have claimed relief, HMRC can withdraw that relief and issue a clawback demand.
- Tax risk — EIS reliefs depend on qualifying conditions remaining met throughout the holding period; changes in legislation may affect future relief.
- Concentration risk — over-allocation to a small number of companies magnifies the impact of individual failures.

These risks are manageable — through diversification across a portfolio of companies, and through sizing each year's allocation to your actual tax liability rather than speculating beyond it.

---

## Direct Portfolio Building vs EIS Funds

Most investors who engage with EIS do so through a fund. It is the path of least resistance. It is also, for most investors who understand what they are giving up, the wrong choice.

**What you surrender in a fund:**
- Your relief timeline — shares are issued on the fund's timeline, not yours.
- Your HMRC submission — funds batch submissions; one investor's incomplete paperwork delays everyone's relief.
- Your investment decisions — fund managers select from deal flow that comes to them; you have no ability to decline a specific investment.
- Transparency — individual company performance is reported in aggregate.
- The fee structure — initial charge (1–2%), annual management fee (1.5–2.5%), performance fee (20–25%). These compound materially against net returns across a 15-year programme.

**The one genuine advantage of a fund:** administration. Unlock Access removes that advantage — individual submissions, individually processed, shares issued immediately.

---

## Is EIS Relevant to You?

EIS tends to be most relevant to investors who have at least one of: a meaningful income tax liability they would like to reduce immediately; capital gains from a property sale, business disposal, or portfolio rebalancing; an estate with IHT exposure that conventional tools have not fully addressed; or a portfolio that could benefit from diversification into early-stage UK companies.

It is less likely to be suitable for investors who need liquidity in the near term, who are uncomfortable with early-stage company risk, or who have no active UK income tax liability.

**The numbers in these profiles are illustrative. Yours are specific.** Unlock's tax planning tool models your income, your investment level, and your CGT position — including annual relief, multi-year projections, carry-back analysis, and IHT timeline.

---

## Annex: Investor Classification Definitions

**High Net Worth Individual** — Annual income of £170,000 or more; or net assets of £430,000 or more (excluding primary residence, qualifying insurance contracts, and pension entitlements).

**Self-Certified Sophisticated Investor** — Member of a business angel network for at least 6 months; or made more than one investment in an unlisted company in the prior two years; or worked in professional capacity in private equity or SME finance in the prior two years; or currently or recently a director of a company with annual turnover of at least £1 million.

*Investors who are uncertain whether they qualify should seek independent legal advice before proceeding.*

---

**To discuss your EIS portfolio:**

Tom King, Founder — Unlock  
tom@unlockdd.com | www.unlockdd.com

---

*This document is for educational purposes only and does not constitute financial advice or a personal recommendation. Capital is at risk. Tax reliefs depend on individual circumstances and may change. EIS/SEIS eligibility subject to HMRC qualifying conditions. IHT BPR from April 2026 subject to the new £2.5M combined APR/BPR allowance. Pension IHT changes subject to final legislation. © 2026 Unlock Services Limited.*

*Original: March 2026 | Last reviewed: 14 March 2026 | Status: Current*
