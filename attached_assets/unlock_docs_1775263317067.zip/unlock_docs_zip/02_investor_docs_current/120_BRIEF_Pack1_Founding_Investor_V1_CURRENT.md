**UNLOCK**

**Institutional-grade portfolio intelligence for the investors who have
never had it.**

A founding investor opportunity.

£1.2M raise at £6.5M pre-money valuation. Approximately 25 founding
slots.

*Private & Confidential --- Founding Investor Brief*

March 2026

**The Problem**

*Private investors with £1M+ portfolios face three persistent challenges
that institutions never encounter.*

**1. Fragmented Data**

Investors manage assets across multiple providers, advisers, and manual
systems. There is no single view. Most rely on spreadsheets and gut
instinct to understand what they own, what it cost, and how it is
performing. When you need to act, you are reconstructing your picture
from memory --- not reading it from a dashboard.

The consequence: decisions are made slowly, based on incomplete
information, by investors who are sophisticated enough to know that
something is wrong but have no tool to fix it.

**2. Inaccessible Complexity**

Professional-grade portfolio analysis --- scenario simulation,
stress-testing, forward-looking tax modelling --- is locked behind
institutional paywalls. It has always been available to wealth
management teams, private banks, and family offices. It has never been
made accessible to the private investors who manage comparable
portfolios.

The result: sophisticated investors are making capital allocation
decisions without the models, projections, and risk frameworks that
would be standard equipment at any institution. The playing field is not
level. It never has been.

**3. Conflicted Incentives**

Every existing platform --- Hargreaves Lansdown, Nutmeg, Crowdcube,
private banks --- earns from what it sells you. Platform fees, trail
commissions, fund charges, AUM percentages: all create a structural
misalignment between what the platform recommends and what serves the
investor.

There is no genuinely independent, investor-first platform at this
level. Not one that earns exclusively from the investor, builds
exclusively for the investor, and carries no product conflict. That gap
is Unlock.

+-----------------------------------------------------------------------+
| **The cumulative effect:**                                            |
|                                                                       |
| Sophisticated private investors --- £1M to £20M+ in total wealth ---  |
| are managing complex, multi-asset portfolios on spreadsheets, Google, |
| and gut instinct, while every platform they could use is designed to  |
| earn from them, not for them.                                         |
+-----------------------------------------------------------------------+

**The Solution**

*Unlock gives private investors the institutional-grade intelligence and
deal access they have always been locked out of --- without the
conflicts that come with it.*

One platform. Complete financial identity. UK tax intelligence built
forward in real time. No products to sell you. No commissions. No
conflicts.

**What Unlock Delivers**

  ----------------------- -----------------------------------------------
  **Service**             **What It Does for You**

  **Asset Register**      Consolidates every asset across all providers,
                          platforms, and wrappers into a single,
                          lot-level view. The first complete picture of
                          what you own. Operational for founding
                          investors now.

  **Portfolio Simulator** Stress-tests your portfolio under 30+ downside
                          scenarios. Models 'what-if' positions before
                          you commit capital. Know your actual risk
                          before you act, not after. In active
                          development.

  **Tax Intelligence      Models EIS, SEIS, CGT, IHT, pension drawdown,
  Engine**                and AIM BPR in real time, forward-looking, with
                          continuous HMRC rule-tracking. The UK
                          regulatory moat. Full build funded by this
                          raise.

  **Syndicate Access**    Curated access to vetted collective investment
                          opportunities at 8--10% fees versus the 9--14%
                          charged by crowdfunding platforms. Founding
                          investors receive priority allocation.

  **Unlock Access**       Curated EIS deal-flow and portfolio service.
                          Direct portfolio building --- not a fund. Four
                          pillars: Guidance, Tools, Access,
                          Administration. EIS compliance via SeedLegals.
                          Instant Investment process live.
  ----------------------- -----------------------------------------------

+-----------------------------------------------------------------------+
| **What this means in practice:**                                      |
|                                                                       |
| Know exactly what you own and what it costs. See how your portfolio   |
| holds up before a crash. Understand the tax interactions of every     |
| decision before you make it. Access deals that were previously closed |
| to retail investors. From one platform that has no interest in        |
| selling you anything.                                                 |
+-----------------------------------------------------------------------+

**Who This Is For**

Unlock is built for UK private investors with £1M--£20M+ in total
wealth: complex, multi-asset portfolios spread across five or more asset
classes, managed without the benefit of institutional tools.

**The Preserver (∼30% of target segment)**

Protecting wealth and minimising downside. Late accumulation,
transitioning to decumulation. Capital preservation is the dominant
objective. The Preserver uses Unlock to stress-test portfolios under 30+
scenarios, confirm that risk controls are genuinely working, and
validate adviser recommendations without conflict. Sequencing errors in
decumulation are irreversible --- no other platform models them against
an investor's actual holdings.

**The Growth Seeker (∼40% of target segment)**

Long-term wealth growth with calculated risk. Active accumulation,
typically 30--55, deploying capital into new positions. The Growth
Seeker uses Unlock to compare upside against downside before committing,
access vetted syndicates on better terms than crowdfunding platforms
offer, and track lot-level performance across a growing portfolio. This
persona often transitions toward Preserver characteristics as wealth
consolidates --- extending platform relevance across two lifecycle
phases.

**The Legacy Builder (∼30% of target segment)**

Intergenerational wealth transfer and tax efficiency. Spans late
accumulation through decumulation. The defining objective across both
phases is structuring wealth for the next generation with minimum tax
leakage. The Legacy Builder uses Unlock to model EIS/SEIS tax
advantages, plan IHT-efficient drawdown sequences, and ensure family
structures are documented and transferable.

The April 6, 2026 IHT rule changes --- EIS/SEIS relief capped at 100% up
to £2.5M per estate, 50% above that --- make timing acutely relevant.
Unlock is the only platform that models this across both accumulation
and decumulation simultaneously.

**Why Now**

*Four structural factors make this the right moment to build Unlock ---
and the right moment to invest.*

**1. April 6, 2026 IHT Rule Change**

From April 6, 2026, IHT relief on EIS/SEIS investments is capped at 100%
up to £2.5M per estate, with 50% relief on amounts above that
threshold. Investors who have been using EIS/SEIS for IHT mitigation
need to understand the new ceiling and structure their portfolios
accordingly --- before this date. Founding investors who close before
April 6 benefit from full BPR treatment under current rules.

**2. Technology Has Made This Possible**

AI now enables institutional-grade portfolio analysis at consumer cost.
What previously required a dedicated team or a £5,000+ annual adviser
relationship is now buildable at scale. Unlock benefits from this shift
structurally --- the cost curve has moved to make the product viable for
the first time.

**3. The Market Gap Is Specific and Large**

No genuinely independent, investor-first platform for UK private
investors with £1M--£20M in total wealth. Below that floor: retail
mass-market tools. Above it: family offices. In the middle: a large,
under-served, well-defined segment with no dedicated solution.

**4. The UK Regulatory Moat**

EIS, SEIS, CGT, IHT, pension drawdown, AIM BPR --- continuous HMRC
rule-tracking across all of these takes 18--24 months minimum to build
correctly. No comparable jurisdiction has this regulatory density. The
moat is real, decided, and fully funded by this raise. Early movers
benefit from a data flywheel that compounds as portfolio histories
accumulate.

**The Founding Investor Offer**

*Approximately 25 founding investors. £1.2M raise at £6.5M pre-money
valuation. These terms are not available after Q1 2027.*

**Investment Structure**

Unlock uses an Instant Investment via SeedLegals --- the UK's leading
EIS/SEIS investment platform, used in approximately 33% of UK funding
rounds. Instant Investment provides anti-dilution protection until
Series A and enables EIS compliance processing at the point of
investment.

Shares are issued on April 6, 2026. This date is fixed. It protects
founding investors from dilution during the Growth Capital round and
aligns with the IHT rule changes that take effect on the same date.

  -------------------------- --------------------------------------------
  **Term**                   **Detail**

  **Pre-money valuation**    £6.5M

  **Raise target**           £1.2M

  **Founding investor        ∼25 (quality-controlled)
  slots**                    

  **Instrument**             Instant Investment via SeedLegals

  **Share issuance date**    April 6, 2026 (fixed)

  **Ticket range**           £40,000 -- £500,000

  **EIS / SEIS relief**      Processed at point of investment via
                             SeedLegals

  **Founding investor        Negotiated individually based on strategic
  discount**                 value
  -------------------------- --------------------------------------------

**Five Lifetime Founding Investor Benefits**

-   Lifetime premium platform access *--- no subscription cost, ever.*

-   Priority syndicate allocation *--- first access to all vetted
    deal-flow.*

-   Founding investor discount *--- negotiated individually; not
    published.*

-   White-glove onboarding *--- direct portfolio setup with the Unlock
    team.*

-   Quarterly reporting and direct founder access *--- direct line to
    progress and strategy.*

+-----------------------------------------------------------------------+
| **On the ∼25 slots:**                                                 |
|                                                                       |
| The founding round is limited by design, not by artificial scarcity.  |
| Founding investors are not just capital --- they are network,         |
| credibility, and signal. The round is closed when we have the right   |
| investors, not when we have hit a number.                             |
+-----------------------------------------------------------------------+

**EIS & SEIS: The Tax Context**

*Government-backed tax reliefs that materially change the risk profile
of early-stage investing.*

EIS (Enterprise Investment Scheme) and SEIS (Seed Enterprise Investment
Scheme) are UK government programmes providing substantial tax reliefs
to investors in qualifying early-stage companies. When structured
correctly, they significantly reduce the investor's effective downside
exposure.

  ------------------------- ---------------------------------------------
  **Scheme**                **Income Tax Relief**

  **SEIS**                  50% of investment value

  **EIS**                   30% of investment value
  ------------------------- ---------------------------------------------

**Effective Cost Illustration --- £50,000 Invested Under SEIS**

  -------------------------- ---------------------- ----------------------
  **Tax bracket**            **45% Additional       **40% Higher Rate**
                             Rate**                 

  Investment                 £50,000                £50,000

  SEIS income tax relief     £25,000                £25,000
  (50%)                                             

  Effective cost after       £25,000                £25,000
  relief                                            

  Additional loss relief if  Up to £11,250 further  Up to £10,000 further
  company fails                                     

  Maximum net downside       ∼£13,750 (∼27.5p per   \~£15,000 (∼30p per £)
  exposure                   £)                     
  -------------------------- ---------------------- ----------------------

+-----------------------------------------------------------------------+
| **April 6, 2026 IHT change:**                                         |
|                                                                       |
| IHT relief on EIS/SEIS investments is capped at 100% up to £2.5M per    |
| individual from April 6, 2026. Relief on amounts above that threshold |
| reduces to 50%. Investors planning to use EIS/SEIS for IHT mitigation |
| should structure investments before this date to maximise relief      |
| under current rules.                                                  |
|                                                                       |
| Note: Tax treatment depends on individual circumstances and may       |
| change. This is not financial or tax advice. Investors should seek    |
| independent advice before making any investment decision.             |
+-----------------------------------------------------------------------+

**Traction & Team**

**Validation to Date**

-   40+ structured market interviews completed with UK HNW investors.

-   70% of surveyed investors confirmed they would pay for better
    portfolio intelligence tools.

-   Functional pre-alpha in active use by founding investors for live
    onboarding and demos.

-   Weekly user sessions validating usability and product-market fit.

-   Founding investor backing from former chairman of Barclays and
    former Director General of TISA.

-   Founding investor commitments active. Round in progress.

**The Team**

  ------------------ ----------------------------------------------------
                     **Role & Background**

  **Thomas King**    Founder & Chief Executive Officer. 12+ years in
                     investor-introduction and capital-facilitation
                     technology. Founder of Cloudworkz (AI operating
                     intelligence platform). £250M+ capital facilitated.
                     Leads product vision, investor relations, and the
                     founding round.

  **Werner Snyman**  Head of Product. 19 years in senior product roles at
                     Nedbank. Deep expertise in wealth management
                     platform architecture and user experience for
                     sophisticated investors.

  **William Corke**  Head of Service Delivery & Compliance. Track record
                     delivering multi-million-pound projects for FTSE 500
                     clients. Oversees investor onboarding, service
                     quality, and regulatory compliance.

  **Claudia Chavez** Co-Founder & Commercial Director. Fintech
                     partnerships and commercial development. Leads
                     strategic relationships, partner channels, and
                     commercial growth.
  ------------------ ----------------------------------------------------

**Next Steps**

*The process is direct. Founding investors who are ready to proceed can
be onboarded within one week.*

**Step 1 --- Discovery Call (20 minutes)**

A direct conversation with Tom King. The goal is to confirm fit on both
sides: whether the investment makes sense for you, and whether you bring
the kind of strategic value that matters at this stage.

**Step 2 --- Platform Demo (30 minutes)**

A live walkthrough of the founding-stage platform. You see what exists
today, what is in build, and how the product experience maps to your
portfolio type. Questions answered directly.

**Step 3 --- Reserve Allocation**

Confirm your allocation. SeedLegals processes the Instant Investment
agreement. EIS / SEIS compliance processed at point of investment.
Shares issued April 6, 2026.

**To start a conversation:**

Tom King \| Founder & CEO

tom@unlockdd.com \| unlockdd.com

*This document is private and confidential. It is intended solely for
the named recipient and must not be reproduced or distributed without
the prior written consent of Unlock. This document does not constitute
financial advice. Investment in early-stage companies carries
significant risk, including the possible loss of capital. EIS/SEIS
eligibility and tax treatment depend on individual circumstances and may
change. Recipients should seek independent financial and tax advice
before making any investment decision.*
