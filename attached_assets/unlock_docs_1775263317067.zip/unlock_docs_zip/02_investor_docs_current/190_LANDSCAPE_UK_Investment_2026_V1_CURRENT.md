**UK INVESTMENT LANDSCAPE 2026**

*Are You Actually Diversified?*

The Correlation Problem, The Advice Gap, and the Last Tax-Efficient
Window

**WHAT THIS REPORT REVEALS**

-   Why the 60/40 portfolio failed in 2022---and could fail again

-   The concentration risk hiding in most UK investor portfolios

-   How EIS limits your downside to 38p on the pound (worked example)

-   What changes on April 6, 2026---and what you lose if you wait

-   An investment opportunity you can actually evaluate

-   Action checklist by investor type

*Read time: 25 minutes*

January 2026

Strategic Overview

**What We\'re Trying to Achieve**

This report serves a dual purpose. On the surface, it\'s a comprehensive
analysis of the UK investment landscape for 2026---the kind of report
sophisticated investors would pay to read. Underneath, it\'s designed to
lead readers to a specific conclusion: that investing in Unlock as a
founding investor is the intelligent response to the problems described.

The strategy follows Warren Buffett\'s first principle: invest in what
you understand. Most investors can\'t truly evaluate robotics companies,
AI startups, or biotech opportunities. But a platform that solves
portfolio fragmentation, concentration risk, and the advice gap? They
live that problem daily. They can evaluate whether the solution is real
because they experience the pain.

**The Founding Investor Opportunity:** Unlock is raising a limited
founding round from investors who will shape the platform as it\'s
built. These are investors whose problems become product priorities. The
number of slots is genuinely limited---this isn\'t artificial scarcity,
it\'s a deliberate choice to ensure founding investors have meaningful
influence and the company maintains close relationships with its
earliest backers.

**The Deadline Is Real:** April 5, 2026 marks the end of the current tax
year. After April 6, BPR on EIS is subject to a new £2.5M combined cap
per estate. VCT relief drops from 30% to 20%. These aren\'t marketing
tactics---they\'re confirmed legislation. The window closes whether or
not someone acts.

**The Reader Journey:** By page 15, the reader should think: \'I have
problems I didn\'t fully recognise. Traditional diversification may not
protect me. The advice gap is real. There are tax-efficient structures
I\'m not using.\' By page 20: \'There\'s a company building exactly what
I need---and I can actually evaluate whether it will work because I
understand the problem.\' By page 22: \'I need to move before April.\'

Executive Summary

In 2022, the 60/40 portfolio---the foundation of conventional
diversification---had its worst year since the 1930s. Stocks fell 19%.
Bonds fell 13%. For the first time in decades, both fell together.

Investors who thought they were protected discovered they weren\'t.

This report examines whether it could happen again, what most investors
are missing, and what to do about it.

**THE THREE PROBLEMS**

**1. The Correlation Problem:** Traditional diversification assumes
stocks and bonds move differently. In 2022, that assumption failed.
Research suggests it could fail again if inflation proves sticky.
Stock-bond correlation reached +0.85 in 2023---the highest ever
recorded.

**2. The Concentration Problem:** Most investors who think they\'re
diversified aren\'t. UK investors average 50-65% of wealth in property
alone. Add employer stock, UK-focused funds, and regional
concentration---many portfolios have 70%+ exposure to a single economy
that could face a correction simultaneously.

**3. The Advice Gap:** The most tax-efficient investments---EIS and
SEIS---are the ones traditional advisors can\'t help with. Accountants
can\'t give investment advice. IFAs can\'t advise on unquoted
securities. You\'re largely on your own.

**THE DEADLINE**

April 5, 2026 is the last day of the current tax year---and the last
window for full IHT relief on EIS investments before new caps take
effect. From April 6, 100% Business Property Relief will be capped at
£2.5M combined across all qualifying business property (EIS direct and AIM shares). Above that threshold, relief
drops to 50% (effective 20% IHT rate). For investors with estate
planning goals, this isn\'t abstract. It\'s a real planning consideration.

**THE OPPORTUNITY**

Section 10 presents something different: a chance to invest in a company
solving the problems described in this report. One you can
evaluate---because you live the problem it addresses. Using the exact
EIS structure this report recommends. With a limited number of founding
investor slots available to those who want to shape the platform as
it\'s built.

But first, you need to understand what\'s at stake.

1\. The 2026 Landscape

Economic Context

The UK economy enters 2026 in better shape than many predicted. GDP
growth is estimated at 1.2-1.4%, placing it among the faster-growing G7
economies. Inflation has fallen to 3.2% and is expected to approach the
2% target by mid-year. The Bank of England has cut rates to 3.75% and
most economists expect further cuts to 3-3.5% by year end.

This is the benign scenario: soft landing achieved, gradual
normalisation underway.

But forecasts are often wrong. And the question sophisticated investors
should ask isn\'t \'what\'s the base case?\'---it\'s \'what happens to
my portfolio if the base case doesn\'t materialise?\'

What Could Go Wrong

**Inflation Resurgence:** Services inflation remains sticky. Wage growth
continues above target. If inflation spikes back above 4%, the Bank of
England would be forced to pause or reverse rate cuts. This is the
scenario where stocks AND bonds fall together---again.

**Recession:** The UK has narrowly avoided recession for two years.
Consumer spending is fragile. Business investment is weak. A negative
shock---global trade disruption, energy price spike, banking
stress---could tip the balance.

**Political Uncertainty:** Potential leadership challenges could drive
up borrowing costs. The gilt market\'s sensitivity to political risk was
demonstrated dramatically in 2022.

*The point isn\'t to predict which scenario occurs. It\'s to ask whether
your portfolio is stress-tested for any of them.*

2\. The Correlation Problem

Why 2022 Changed Everything

For decades, the foundational assumption of portfolio construction has
been that stocks and bonds are negatively correlated. When equities
fall, bonds rise---providing protection when you need it most. This
assumption underpins the classic 60/40 portfolio that millions of
investors rely on.

In 2022, that assumption failed catastrophically.

Stocks returned -19.2%. Bonds returned -13.0%. The 60/40 portfolio lost
16.7%---its worst year since the 1930s. This was the only year since
records began where both major asset classes fell simultaneously by
double digits.

Investors who thought they were protected discovered their
\'diversification\' was an illusion.

The Inflation Driver

What caused the correlation to flip? Inflation. When inflation surged,
central banks raised rates aggressively. Higher rates hurt both equities
(through higher discount rates) and bonds (directly through price-yield
relationship). The asset classes that are supposed to hedge each other
moved in lockstep.

Research from Vanguard shows that stock-bond correlation has been
consistently positive during high-inflation periods throughout history.
The negative correlation that investors learned to rely on only existed
during the low-inflation environment from 2000-2021.

In other words: the \'normal\' state that informed most investors\'
diversification strategies was actually the exception, not the rule.

Could It Happen Again?

Stock-bond correlation reached +0.85 in July 2023---the highest ever
recorded. While correlations have since declined as inflation moderated,
they remain elevated compared to the 2000-2021 period.

Barclays Private Bank research concludes: \'In periods of excessive
inflation (higher than 5%), the equity-bond correlation was always
positive, implying low, or no, diversification contribution from
bonds.\'

If inflation proves sticky in 2026---if services inflation remains
elevated, if wage growth doesn\'t moderate, if an energy shock
occurs---the correlation could turn positive again. Traditional
diversification would fail again.

**The question for your portfolio:** When did you last stress-test your
holdings against a scenario where stocks AND bonds fall together?

3\. Asset Class Overview

UK Equities: Attractive But Not Without Risk

UK equities offer genuinely attractive valuations. The FTSE 250 trades
at 12.4x forward earnings versus the S&P 500\'s 22.4x---the cheapest
relative valuation in 23 years. The index offers a 4.3% dividend yield.
Historically, UK mid-caps outperform in falling rate environments.

The opportunity is real. The question is whether your portfolio is
structured to capture it---or whether your UK equity exposure is
concentrated in a handful of names, dominated by employer stock, or
offset by property over-concentration elsewhere.

Property: The Concentration Trap

House price forecasts for 2026 are modest but positive: Rightmove
predicts 2%, Savills 2%, Nationwide 2-4%. Regional variation favours the
North and Midlands over London and the South East.

But forecasts aren\'t the issue. Concentration is.

UK property fell 16% in 2008 and took seven years to recover to
pre-crash levels. Many investors found themselves in negative equity,
unable to sell, with wealth locked in an asset they couldn\'t access
precisely when they needed liquidity most.

Section 5 examines the concentration problem in detail. For now, ask
yourself: what percentage of your total wealth is in property? Include
your primary residence equity, any buy-to-lets, any property funds.
What\'s the real number?

Bonds: Income Returns, Protection Questions

UK gilts offer the highest yields in a decade. Ten-year gilts yield
around 4.3%. For income-focused investors, this is genuinely attractive.

But bonds as portfolio protection? That assumption requires
re-examination after 2022. Bonds may well provide ballast if the next
crisis is deflationary (recession, credit crunch). They will not protect
you if the crisis is inflationary. And given the \'stagflation lite\'
risks---sticky inflation combined with weak growth---the traditional
bond allocation may not serve its intended purpose.

Gold: Genuine Diversification, No Income

Gold delivered 60%+ returns in 2025, with forecasts targeting \$3,000/oz
or higher. More importantly, gold is one of the few assets that
genuinely diversifies in crisis---its correlation to equities turns
negative precisely when protection matters most.

The limitation: gold produces no income. For investors who need their
portfolio to generate returns, gold can only ever be a minority
allocation---typically 5-10%.

Cash: Declining Returns, Clear Role

With rates expected to fall to 3-3.5%, cash returns will decline through
2026. The best savings rates should be locked in now.

Cash has a clear role: liquidity, optionality, dry powder. But holding
excessive cash in a falling rate environment is a guaranteed loss of
purchasing power.

4\. Scenario Analysis: What Happens When Forecasts Are Wrong

Understanding individual asset classes is necessary but insufficient.
Sophisticated portfolio management requires understanding how assets
interact---particularly when markets move against you.

Base Case: Soft Landing

If forecasts prove correct---inflation to 2%, rates to 3-3.5%, modest
growth---most portfolios perform adequately. UK equities gain 6-10%.
Property rises 2-4%. Bonds deliver 3-5% from yield plus modest capital
appreciation. Gold holds steady or rises slightly.

This is the scenario where doing nothing is probably fine.

Recession Scenario

UK equities fall 25-40% as earnings collapse. Property falls
15-20%---and you can\'t sell quickly to rebalance. Bonds potentially
rise if the Bank cuts rates aggressively. Gold rises 10-20% on
safe-haven demand. Cash preserves nominal value.

**The critical insight:** In a recession, property-heavy investors face
a double problem. Values fall AND they can\'t access the capital.
Liquidity matters precisely when it\'s hardest to achieve.

Inflation Resurgence

UK equities fall 10-20% as discount rates rise. Bonds fall 10-20%---a
repeat of 2022. Property is mixed (values may fall but rents may rise).
Gold rises 15-25% as an inflation hedge. Cash purchasing power erodes
rapidly.

**This is the scenario where traditional diversification fails.** Stocks
AND bonds fall together. The 60/40 portfolio doesn\'t protect you.
Investors who relied on bonds as their hedge discover they have no hedge
at all.

The Question You Should Be Asking

Most investors can\'t model these scenarios because they don\'t have
tools that connect all their holdings. Their ISA platform shows their
ISA. Their pension provider shows their pension. Their property equity
is an estimate. Their alternatives are in spreadsheets.

There\'s no single view. No scenario analysis. No correlation-aware
stress testing.

*If you\'re reading this thinking \'I should be able to do this
analysis\'---you\'re right. You should. But you probably can\'t, because
the tools don\'t exist for investors like you.*

5\. The Concentration Problem

Most investors who consider themselves diversified are not. They own
different things---property, stocks, maybe some bonds or alternatives.
But when examined closely, many portfolios have dangerous concentrations
that only reveal themselves in downturns.

A Portfolio You Might Recognise

Consider this investor---see if it sounds familiar:

Primary residence: £650,000 equity (after mortgage)

Buy-to-let: £380,000 equity

ISA: £180,000 (global tracker)

SIPP: £240,000 (60% equities, 15% property funds)

Cash: £85,000

Employer shares: £65,000

**Total: £1.6 million**

This investor feels diversified. They own \'different things.\' Let\'s
look at what they actually have:

**Property exposure:** £1.03M direct + £36K in SIPP property funds =
£1.066M = **67% of wealth**

**UK concentration:** Property (67%) + employer shares (4%) + UK portion
of funds (\~10%) = **\~81% exposed to UK economy**

**Illiquid assets: 67%** (property can\'t be sold quickly)

This is concentration hiding as diversification.

What Happens in a Downturn

If UK property falls 20%---which happened in 2008---this investor loses
over £200,000 in wealth. They can\'t sell the property quickly to
rebalance. If they also face job pressure (as often happens in
recessions), their employer shares are falling too. They need liquidity
precisely when they can\'t access it.

The \'diversification\' they thought they had provides no protection
when protection matters most.

Common Concentration Traps

**The Property Trap:** UK investors average 50-65% of wealth in property
(including primary residence). This isn\'t diversification---it\'s
concentration in a single, illiquid, regionally-correlated asset class.

**The Employer Trap:** Employees with significant company stock have
double exposure: their income AND their wealth depend on one company. If
the company struggles, they face job risk AND portfolio loss
simultaneously.

**The \'Alternatives\' Trap:** Owning whisky casks, fine wine, and
classic cars may feel like diversification. But these assets share
critical characteristics: illiquid, GBP-denominated, correlated to
discretionary wealth cycles. They fell in 2008-2009. They\'re not
genuine diversifiers.

The First Step Is Visibility

Try this exercise---if you can:

1.  List every asset you own (ISA, SIPP, GIA, property, alternatives,
    cash, company shares)

2.  Calculate the percentage of total wealth in each

3.  Identify anything above 25% in a single asset class

4.  Calculate your illiquid percentage

5.  Calculate your UK-only exposure

*If you can complete this exercise accurately in 10 minutes, you\'re
unusual. Most investors can\'t---because their holdings are scattered
across platforms with no consolidated view.*

6\. EIS and SEIS: The Tax Maths That Changes Everything

The UK government created the Enterprise Investment Scheme (EIS) and
Seed Enterprise Investment Scheme (SEIS) to encourage investment in
British growth companies. The tax incentives are extraordinary by
design---they compensate for the genuine risk of early-stage investing.

For sophisticated investors willing to do their homework, these
structures represent some of the most tax-efficient investments
available anywhere.

How the Maths Actually Works

**SEIS Worked Example (50% relief):**

You invest £50,000 in a SEIS-eligible company.

Income tax relief: 50% = £25,000 (claimed against your tax bill
immediately)

**Your effective cost: £25,000** (not £50,000)

**If the company succeeds (3x exit):** You receive £150,000. Capital
gains tax: £0 (SEIS profits are CGT-free after 3 years). Your profit:
£125,000 on £25,000 effective cost = 5x return on your real money at
risk.

**If the company fails completely:** You lose £50,000. Less income tax
relief already claimed: £25,000. Net loss for loss relief calculation:
£25,000. Loss relief at 45% tax rate: £11,250 recovered. Your actual
loss: £25,000 - £11,250 = £13,750. **You invested £50,000 and lost
£13,750---effectively 27.5p on the pound.**

**EIS Worked Example (30% relief):**

You invest £100,000 in an EIS-eligible company.

Income tax relief: 30% = £30,000

**Your effective cost: £70,000**

**If the company succeeds (5x exit):** You receive £500,000. CGT: £0.
Your profit: £430,000 on £70,000 effective cost = 6x+ return.

**If the company fails completely:** Loss relief at 45%: £31,500
recovered. Your actual loss: £70,000 - £31,500 = £38,500. **You invested
£100,000 and lost £38,500---effectively 38.5p on the pound.**

The Asymmetric Structure

This is what sophisticated investors seek: uncapped upside with capped,
cushioned downside. In traditional equity investment, if a stock goes to
zero, you lose 100%. In EIS/SEIS, your maximum actual loss is 27-39% of
your original investment---and your upside is unlimited and tax-free.

The risk is real---early-stage companies fail. But the structure
fundamentally changes the risk-reward equation.

The Inheritance Tax Dimension

After two years, EIS shares qualify for Business Property Relief---100%
exemption from Inheritance Tax.

For investors with estates above the nil-rate band, this is significant.
A £500,000 EIS portfolio removes £500,000 from your taxable estate,
potentially saving £200,000 in IHT (at 40%).

This combines with the income tax relief and CGT exemption. No other
mainstream investment structure offers this triple benefit.

7\. The April 2026 Deadline: What Changes and What You Lose

From April 6, 2026, the tax landscape changes significantly. These
aren\'t rumours or projections---they\'re confirmed legislation.

IHT Relief Cap

Currently, 100% Business Property Relief applies to qualifying EIS
investments regardless of amount. From April 6, 2026:

-   100% IHT relief will be capped at £2.5M combined (across EIS direct investments and AIM shares per estate)

-   Above £2.5M, relief drops to 50% (effective 20% IHT rate)

-   This applies to assets held at death, not date of investment

**What this means:** An investor with £3M in qualifying EIS investments
currently pays £0 IHT on those assets. From April 2026, they\'ll pay
IHT on the £500,000 above the cap at the effective 20% rate = £100,000
additional IHT. For most investors investing at sensible annual
allocations — £50,000–£250,000 per year — the cap is unlikely to bind
for several years.

VCT Relief Reduction

Income tax relief on Venture Capital Trusts drops from 30% to 20%. A
£50,000 VCT investment made before April 6 generates £15,000 tax relief.
After April 6: only £10,000. That\'s £5,000 lost for waiting.

The Decision Window

April 5, 2026 is the last day of the 2025/26 tax year. Investments made
by this date:

-   Qualify for current year income tax relief (claim back against
    2025/26 tax)

-   Start the 2-year clock for IHT relief under current rules

-   Lock in 30% VCT relief before it drops to 20%

For Legacy Builders with estate planning goals, this tax year is the
last window to lock in full IHT relief under current uncapped rules.
The decision isn\'t whether to invest in EIS eventually---it\'s whether
to invest before April 5, 2026.

8\. The Advice Gap: Why No One Can Help

Here\'s something most investors don\'t fully realise: when it comes to
tax-efficient investments in private companies, there\'s a structural
advice gap. The people you might naturally turn to for guidance often
cannot help---not won\'t, cannot.

Your Accountant

Accountants can explain the tax mechanics of EIS and SEIS---how the
reliefs work, what you can claim, how to submit paperwork. What they
cannot do is advise you on whether a specific investment is suitable for
your circumstances. That would be investment advice, which accountants
are not authorised to provide. The FCA does not regulate accountants.

Your IFA or Wealth Manager

Independent Financial Advisers are regulated by the FCA, but that
regulation only covers FCA-regulated products---ISAs, pensions, unit
trusts, investment bonds. Investment in private, unquoted companies
(which is what EIS and SEIS investments involve) falls outside the
FCA\'s regulatory scope. Most IFAs either cannot or will not advise on
these investments.

The Structural Result

The most tax-efficient investment structures available to UK investors
are precisely the ones where professional advice is hardest to obtain.
The people who could explain the tax benefits can\'t advise on
investment quality. The people who could advise on investment quality
often can\'t touch unquoted securities.

**The result: if you want to access EIS/SEIS benefits, you largely need
to do your own homework.**

What \'Doing Your Homework\' Actually Requires

**Understanding your own tax position:** What\'s your marginal income
tax rate? Do you have CGT gains that could be deferred? What\'s your
estate\'s IHT exposure?

**Understanding the investment:** Management team track record. Business
model viability. Market size and competition. Use of funds.

**Understanding the structure:** Has HMRC advance assurance been
obtained? What are the fees? What\'s the realistic hold period?

**Understanding portfolio fit:** What percentage of your portfolio is
appropriate for EIS? How does this correlate with your existing
holdings? What\'s your genuine risk capacity?

Even with investment knowledge, there\'s an analytical problem: How do
you model an EIS investment within your complete portfolio? How do you
understand the tax implications across your whole position? How do you
stress-test how this new holding affects your concentration risk?

*Most investors can\'t---because the tools don\'t exist.*

9\. Portfolio Construction for 2026

Given everything in this report---the correlation problem, the
concentration risk, the tax opportunities, the advice gap---what should
a sophisticated investor actually do?

Principles, Not Prescriptions

This report can\'t give you personalised advice---that\'s the advice gap
we\'ve just described. But we can outline principles that apply broadly:

**1. Know your actual allocation.** Not what you think it is---what it
actually is. Across all platforms, all wrappers, all asset types. Most
investors can\'t answer this question accurately.

**2. Understand your concentration.** If any single asset class exceeds
40% of your portfolio, you\'re concentrated. If any single holding
exceeds 15%, you\'re concentrated. If your illiquid assets exceed 50%,
you have a liquidity problem waiting to happen.

**3. Question your \'diversification.\'** Owning different things isn\'t
diversification if they move together. Property, UK equities, and
UK-focused alternatives may all fall together in a UK-specific crisis.

**4. Use your tax allowances.** ISA: £20,000/year. Pension: up to
£60,000/year. EIS: up to £1M/year (£2M for knowledge-intensive
companies). Every pound not sheltered is paying unnecessary tax.

**5. Consider asymmetric structures.** EIS/SEIS offers capped downside
with uncapped upside. For investors with capacity for some early-stage
risk, this asymmetry is valuable.

Sample Allocations by Investor Type

**The Preserver (Conservative, wealth protection focus):**

Core equities (global diversified): 40% \| Bonds/Gilts: 25% \| Gold: 5%
\| Cash: 15% \| Tax-efficient growth (EIS): 10% \| Property (REITs, not
BTL): 5%

**The Growth Seeker (Balanced, long-term growth focus):**

Core equities (global): 45% \| Bonds: 15% \| Alternative investments: 5%
\| Cash: 10% \| Tax-efficient growth (EIS/SEIS): 20% \| Property: 5%

**The Legacy Builder (IHT-focused, intergenerational planning):**

Core equities: 35% \| Bonds: 10% \| Tax-efficient + IHT-qualifying
(EIS): 35% \| Cash: 10% \| Property (diversified): 10%

*Note: These are illustrative frameworks, not recommendations. Your
allocation should reflect your specific circumstances, time horizon, and
risk tolerance.*

10\. An Investment You Can Actually Understand

The Buffett Principle

Warren Buffett\'s first rule: invest in what you understand.

Most investment opportunities ask you to evaluate technology you don\'t
build, markets you don\'t trade, or business models that require faith
in management you\'ve never met. You\'re betting that experts know what
they\'re doing.

This section presents something different.

The Problem You\'ve Just Experienced

If you\'ve read this far, you\'ve encountered problems you probably
recognise:

-   **Fragmented visibility:** Your holdings scattered across platforms
    with no complete picture

-   **Hidden concentration:** Portfolio risks you can\'t easily
    calculate

-   **Correlation blindness:** No tools to model how assets interact in
    stress

-   **Tax inefficiency:** Optimisation opportunities you can\'t see
    across your whole position

-   **The advice gap:** No independent guidance on alternatives and EIS

**You understand these problems because you live them.**

That understanding is valuable.

The Solution Being Built

**Unlock** is an investment intelligence platform for private investors
managing £250K-£5M across multiple asset classes. It provides:

-   **Consolidated portfolio view** across all platforms, wrappers, and
    asset types

-   **Scenario analysis** modelling how your holdings perform under
    different conditions

-   **Concentration alerts** identifying hidden risks in your allocation

-   **Tax optimisation** across your complete position

-   **EIS/SEIS integration** to evaluate tax-efficient opportunities
    within portfolio context

This is the tool you\'d pay for. This is the capability that should
exist.

Why This Investment Is Different

Unlike most startup investments---where you\'re betting on founders\'
ability to build something for customers you don\'t know---this
opportunity has a unique characteristic:

**You are the customer.**

The platform is built for investors exactly like you. The problems it
solves are your problems. You can evaluate the product because you
understand the need.

This is Buffett-compatible investing: a business model you can genuinely
assess because you live the problem it addresses.

The Founding Investor Programme

Unlock is raising a founding round from a limited number of investors
who will shape the platform as it\'s built.

**What founding investors receive:**

-   **Equity stake** at pre-launch valuation (£6.5M pre-money)

-   **Lifetime platform access** (no subscription fees, ever)

-   **Direct product influence** (your needs become roadmap priorities)

-   **Priority syndicate access** (first access to vetted EIS
    opportunities)

-   **Quarterly reporting** with direct founder access

**Why this structure matters:**

The founding investors ARE the initial users. Their portfolio problems
become product requirements. Their feedback shapes development
priorities. The company succeeds by solving problems for people who have
direct input into what those problems are.

This isn\'t typical startup investing where you hope the team builds the
right thing. You\'re ensuring they build what you need.

The EIS Alignment

Unlock qualifies for EIS.

This report has explained why EIS is attractive for sophisticated
investors. Now apply that analysis:

-   **30% income tax relief** on your investment

-   **Tax-free gains** if Unlock succeeds

-   **Loss relief** protecting \~60% of downside if it fails

-   **IHT exemption** after two years

You\'re investing using the exact structure this report recommends, in a
company whose success you can evaluate because you understand the
problem it solves.

A £50,000 investment costs £35,000 after tax relief. Maximum downside
with loss relief: approximately £14,000. Upside if the company achieves
its targets: 5-10x returns, tax-free.

This is EIS as it should be used: informed investment with structural
downside protection.

The Timing

Two deadlines matter:

**April 5, 2026:** End of 2025/26 tax year. Last date to claim EIS
relief against current year income. Last tax year to lock in full IHT
relief under current uncapped BPR rules.

**March 2026:** Founding round closes. After this, investment will be at
higher valuation (Growth Capital round) without founding investor
benefits.

If this opportunity makes sense for your portfolio, the window is now.

11\. Next Steps

Is This Right for You?

This opportunity fits investors who:

-   Recognise the problems described in this report from personal
    experience

-   Have capacity for early-stage investment (EIS should typically be
    10-20% of portfolio)

-   Understand that startups can fail, even with strong fundamentals

-   Value the ability to influence a product built for their needs

-   Want to apply EIS benefits to an investment they can genuinely
    evaluate

If that\'s not you, this report still provides a useful framework for
thinking about your portfolio.

If You Want to Learn More

The process is straightforward:

**Step 1: Discovery call (20 minutes)** --- Confirm fit, discuss your
portfolio situation, answer questions about Unlock.

**Step 2: Platform demo (30 minutes)** --- See the product. Understand
what it does and what\'s on the roadmap.

**Step 3: Your decision** --- Review terms, assess fit for your
portfolio, decide allocation.

**Step 4: If you proceed** --- Instant Investment via SeedLegals, EIS
paperwork handled by Unlock, onboarding to platform.

No obligation at any stage. The first call is simply to see if this
makes sense for your situation.

Contact

To schedule a discovery call:

**Tom King, Founder**

tom@unlockdd.com

www.unlockdd.com

12\. Action Checklist

**For All Investors:**

-   Calculate your actual asset allocation (not what you think it is)

-   Identify concentration risks above 30% in any single asset class

-   Review tax allowance usage (ISA, pension, EIS/SEIS)

-   Understand the April 2026 deadlines and how they affect you

**For Preservers (Wealth Protection Focus):**

-   Stress-test your portfolio: what happens if UK property falls 20%?

-   Check your liquidity: can you access 12 months\' expenses without
    selling assets?

-   Review your bond allocation given correlation breakdown risk

**For Growth Seekers (Long-Term Growth Focus):**

-   Calculate your effective returns after tax

-   Assess whether EIS tax relief would improve your risk-adjusted
    returns

-   Review opportunity cost of cash holdings in a falling rate
    environment

**For Legacy Builders (IHT Planning Focus):**

-   Calculate current IHT exposure (estate value minus £325K nil-rate
    band)

-   Understand April 2026 IHT relief cap and its impact on your planning

-   Model EIS allocation required for meaningful IHT reduction

-   Begin planning BEFORE April 5, 2026 tax year deadline

Conclusion

This report has covered substantial ground: the 2026 market outlook, the
correlation risks in traditional portfolios, the concentration problems
most investors don\'t see, and the tax-efficient structures that
sophisticated investors use.

But the most important insight isn\'t about markets. It\'s about a
structural gap in how private investors manage wealth.

**The tools don\'t exist.** Consolidated visibility, scenario analysis,
tax optimisation across complete portfolios, independent evaluation of
EIS opportunities---these capabilities should be available to anyone
managing serious money. They\'re not.

**Unlock is building them.** And because you understand the
problem---because you\'ve lived the fragmentation, the hidden
concentration, the advice gap---you can evaluate this investment in a
way that\'s impossible for most startup opportunities.

That\'s the Buffett advantage: invest in what you understand.

Whether or not you choose to invest in Unlock, this report provides a
framework for evaluating your portfolio differently:

-   Calculate your real concentration

-   Model your correlation exposure

-   Maximise your tax efficiency

-   Do your homework on alternatives

And if you recognise yourself in these pages---if the problems feel
personal---consider whether owning the solution might be the smartest
investment of all.

--- --- ---

**Important Notice**

This report is for informational purposes only and does not constitute
financial, tax, or investment advice. Investment values can fall as well
as rise, and you may get back less than you invest. Past performance is
not a reliable indicator of future results. Tax treatment depends on
individual circumstances and may change. EIS and SEIS investments carry
significant risks including the potential for total loss of capital.
Consult with qualified financial and tax professionals before making
investment decisions. Unlock is an early-stage company and investment
carries substantial risk.

---

## March 2026 Update: The Iran Conflict

*Added 14 March 2026*

Since this report was written in January 2026, the case for diversification has become materially stronger.

On 28 February 2026, US-Israeli airstrikes on Iran triggered a significant global energy shock. Brent crude rose from approximately £70 to over £100 per barrel within days. The Strait of Hormuz — through which approximately 20% of global oil supply transits — faces disruption risk. The OBR has specifically flagged the conflict as a risk to UK inflation and growth in its March 2026 Spring Forecast.

The consequences for UK investors are direct:

- **Bank of England rate cuts delayed.** Markets had priced near-certain cuts in March. These are now pushed to June at the earliest, with further cuts uncertain. Mortgage rates that had been falling are under upward pressure.
- **UK economy flatlined in January** — before the energy shock — growing 0% against a 0.2% forecast. The conflict adds to headwinds already in place.
- **Energy costs rising** across all asset classes — property running costs, business operating costs, and consumer spending power all under pressure.
- **Equity markets volatile.** FTSE 100 down. Global markets pricing in inflation risk and slower growth.

This is precisely the scenario this report warned about: a correlated shock to UK property, equities, pensions, and employment income simultaneously. Investors concentrated in UK assets have no uncorrelated component to cushion the impact.

The EIS argument is unchanged — and, if anything, strengthened. Early-stage UK companies with genuine technology or service moats are less correlated to global energy prices than residential property or public equities. The IHT argument remains unaffected; the April 6 deadline is a legislative fact independent of market conditions.

*Chatham House and Oxford Economics both project the conflict as likely to resolve within two months, with markets recovering as disruption fades. The structural concentration risk identified in this report, however, persists regardless of the conflict's duration.*

---

*Original: January 2026 | Last updated: 14 March 2026 (Iran conflict update added; BPR cap corrected to £2.5M; ASA → Instant Investment; founding round timeline updated) | Status: Current*