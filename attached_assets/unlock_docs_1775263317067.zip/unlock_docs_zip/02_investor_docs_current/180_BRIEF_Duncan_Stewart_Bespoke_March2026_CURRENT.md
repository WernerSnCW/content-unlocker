# UNLOCK ACCESS
# EIS, IHT, and Estate Planning
### A personal briefing for Duncan Stewart — March 2026

*This document is prepared for discussion purposes only and does not constitute financial advice or a personal recommendation. Capital is at risk. Tax reliefs depend on individual circumstances and qualifying conditions. All figures illustrative.*

---

## The Problem Worth Solving

A £5 million estate sounds like a success. And it is. It is also, under current UK inheritance tax rules, a significant liability for the people who will inherit it.

Most of that estate sits in conventional assets — property, investments, a pension. Each was the right decision at the time. None of them was chosen with IHT in mind. The result is a tax bill that does not have to be as large as it currently is.

| Asset | Est. Value | IHT Position |
|---|---|---|
| Primary residence | £1,200,000 | In estate — no relief |
| Investment portfolio | £1,800,000 | In estate — no relief |
| Pension (pre-April 2027) | £800,000 | Currently outside estate |
| Pension (from April 2027) | £800,000 | Fully IHT-exposed |
| **Total IHT exposure (post-April 2027)** | **~£5,000,000 taxable** | **IHT bill: ~£1,720,000** |

*NRB £325,000; RNRB £175,000 where applicable. Pension IHT changes announced but subject to final legislation from April 2027.*

The pension deserves specific attention. Until October 2024, it sat entirely outside the estate — a clean, efficient tool for passing wealth to beneficiaries. From 6 April 2027, unused pension pots and death benefits come into scope for inheritance tax. A £800,000 pension becomes an £800,000 IHT exposure overnight.

*The conventional tools that made sense for thirty years of accumulation are now structurally inadequate for estate transfer. EIS offers a replacement that does what the pension used to do — and more.*

---

## How EIS and SEIS Work

EIS (Enterprise Investment Scheme) and SEIS (Seed Enterprise Investment Scheme) are UK government-backed tax relief structures designed to channel private capital into early-stage companies. Investors receive four distinct reliefs, all of which apply simultaneously on the same investment.

| Relief | EIS | SEIS | Note |
|---|---|---|---|
| Income Tax | 30% of investment | 50% of investment | Claimable in year invested or carried back one year |
| Capital Gains | 100% exempt on exit | 100% exempt on exit | Qualifying exit after 3-year holding period. No upper limit on gain. |
| Loss Relief | ~38.5p/£ at 45% | ~27.5p/£ at 45% | Applied to net loss after income tax relief. Personal to original investor — cannot be inherited. |
| IHT / BPR | 0% after 2 years | 0% after 2 years | Business Property Relief. £2.5M combined APR/BPR allowance from April 2026. Most investors at sensible annual allocations unaffected. |

**Loss relief worked example:** For a 45% taxpayer investing £50,000 via SEIS — income tax relief of £25,000 leaves £25,000 net at risk. If the company fails, loss relief at 45% on the £25,000 = £11,250. Effective net loss: £13,750 (27.5p per £ invested). EIS equivalent: £50,000 invested, £15,000 relief, £35,000 at risk; loss relief at 45% = £15,750; effective net loss: £19,250 (38.5p per £).

**The critical point on loss relief:** it is personal to the original investor. If a company fails after the investor's death, beneficiaries receive no loss relief benefit. This is a sequencing consideration, not a structural problem — it simply means the structure is most efficient while the investor is alive to claim it.

---

## A £250,000 Annual Programme

The scenario modelled below assumes a £250,000 annual investment, blending SEIS (up to £200,000 annually at 50% relief) and EIS (remaining allocation at 30% relief). The combined income tax relief on £250,000 per year — using a blended rate reflecting the mix — is approximately £75,000 annually. Effective cost: £175,000 per year. HMRC funds the balance.

The BPR clock starts on the date shares are issued. Each year's cohort qualifies independently. By year 3, the first cohort has cleared the two-year BPR qualifying period and sits outside the estate entirely.

| Year | Invested | Income Tax Relief | Effective Cost | Assets Outside Estate | Cumulative IHT Saving |
|---|---|---|---|---|---|
| 1 | £250,000 | £75,000* | £175,000 | — | — |
| 2 | £250,000 | £75,000 | £175,000 | — | — |
| 3 | £250,000 | £75,000 | £175,000 | £250,000 (Yr 1 cohort) | £100,000 |
| 5 | £250,000 | £75,000 | £175,000 | £750,000 | £300,000 |
| 7 | £250,000 | £75,000 | £175,000 | £1,250,000 | £500,000 |
| **10** | **£250,000** | **£75,000** | **£175,000** | **£2,000,000** | **£800,000** |

*Year 1 relief claimable against that year's income tax liability, or carried back to the prior tax year. IHT saving calculated at 40% on assets outside estate above £325,000 NRB. All figures illustrative. Capital at risk.*

By year 10, over £2 million sits outside the estate entirely — reducing the IHT bill by approximately £800,000 at current rates, independent of portfolio performance.

---

## A Blended Portfolio: How the Numbers Work

The table below models a single year's £800,000 deployment across five companies, using the base case distribution consistent with NESTA research: two failures, two moderate exits, one strong exit. Loss relief is applied to the net loss after income tax relief — not the gross investment.

| Company | Invested | Income Tax Relief | Net at Risk | Outcome | Effective P&L |
|---|---|---|---|---|---|
| Company A (SEIS) | £50,000 | £25,000 (50%) | £25,000 | Total loss | Loss relief: £11,250 → net loss £13,750 |
| Company B (SEIS) | £50,000 | £25,000 (50%) | £25,000 | Total loss | Loss relief: £11,250 → net loss £13,750 |
| Company C (EIS) | £300,000 | £90,000 (30%) | £210,000 | 2× exit (£600,000) | Gain £300,000 — CGT-free |
| Company D (EIS) | £300,000 | £90,000 (30%) | £210,000 | 3× exit (£900,000) | Gain £600,000 — CGT-free |
| Company E (EIS) | £100,000 | £30,000 (30%) | £70,000 | 10× exit (£1,000,000) | Gain £900,000 — CGT-free |
| **TOTALS** | **£800,000** | **£260,000** | **£540,000** | **Net return: £2,472,500** | **Income tax saved: £260,000** |

*Loss relief at 45% applied to net loss after income tax relief. All exits CGT-free assuming 3-year qualifying holding period met. All figures illustrative. Capital at risk.*

The £260,000 income tax relief is received in the year of investment, before any company does anything. The two failures cost a net £27,500 combined. The three exits are entirely CGT-free.

---

## What Happens When: The Sequencing Matrix

One of the least-understood aspects of EIS investing is how the reliefs interact with the timing of exits relative to the investor's death.

**The critical asymmetry:** CGT on lifetime gains is wiped entirely at death. Loss relief is not — it is personal to the original investor and dies with them.

| Relief / Tax | Exit before death | Held until death | CGT deferral route |
|---|---|---|---|
| **IHT on EIS shares** | Payable if held < 2 yrs. Zero after 2-yr BPR qualifying period. | Zero — shares already qualified for BPR. Passes outside estate. | Zero — deferred gain extinguished. Original investment already outside estate. |
| **CGT on lifetime gains** | Payable at 20–24% on disposal. Crystallised in your lifetime. | Wiped entirely at death. Beneficiaries inherit at probate value with no CGT liability. | Deferred gain via EIS investment is extinguished on death under current rules. |
| **Loss relief** | Claimable by you against income or CGT in year of loss or carry-forward. | Cannot be inherited. If investment fails after your death, beneficiaries receive no loss relief benefit. | Not applicable — gain deferred, not realised. |

*CGT extinguishment on death applies to deferred gains under current rules and to unrealised gains (beneficiaries inherit at probate value). BPR and CGT extinguishment subject to legislation in force at the time of death. All information correct as at March 2026.*

**The optimal sequencing:** invest early, let the BPR clock run, and hold qualifying shares until death. CGT is extinguished. IHT is eliminated. Loss relief is less relevant at that horizon — the structure is designed to win on the exits, not recover on the failures.

---

## The IHT Impact: Estate Comparison

| Scenario | Without EIS | With EIS (10-yr programme) |
|---|---|---|
| Total estate value | £5,000,000 | £5,000,000 |
| Assets outside estate (EIS portfolio) | £0 | £2,000,000+ |
| Taxable estate | £5,000,000 | £3,000,000 |
| IHT bill (40% above £325k NRB) | ~£1,870,000 | ~£1,070,000 |
| **IHT saving** | **—** | **~£800,000 saved** |

*All figures illustrative. Capital at risk.*

The £800,000 IHT saving is conservative — it reflects only BPR relief on assets outside the estate. It does not include the income tax relief received annually (£750,000 over 10 years), nor any portfolio returns from company exits.

---

## Three Scenarios: Flat, Modest, Total Failure

**Scenario A — Portfolio returns 1× (flat — no growth, no losses)**

Income tax relief over 10 years: £750,000. Effective cost of £2,500,000 deployed: £1,750,000. Portfolio value: £2,500,000. CGT: zero. IHT saving: ~£800,000. Net position vs not investing: **+£1,550,000 ahead before any portfolio appreciation.**

**Scenario B — Portfolio returns 3.8× (base case distribution)**

Income tax relief over 10 years: £750,000. Effective cost: £1,750,000. Portfolio value: £9,500,000 (3.8× on £2,500,000). CGT: zero. IHT saving: ~£800,000 on qualifying holdings. **Substantially ahead on every measure.**

**Scenario C — Total portfolio failure (worst case)**

All companies fail. Income tax relief: £750,000 received and retained. Loss relief available on net losses after income tax relief — at 45% marginal rate, recovers a material proportion of the net capital at risk. **Even in the worst case, the income tax relief already received is not returned.**

*The income tax relief is received in the year of investment. It is not contingent on portfolio performance. In the worst case, it is what you keep.*

---

## Why 2026 Is the Right Moment

Three structures that have formed the backbone of HNW estate planning have been materially changed or broken in 2025/26:

- VCT income tax relief reduced from 30% to 20% from 6 April 2026. EIS retains 30%; SEIS retains 50%.
- Pensions brought into IHT scope from 6 April 2027. The primary estate planning tool for a generation of accumulation investors is broken. EIS/SEIS BPR is the primary remaining replacement.
- AIM shares BPR reduced from 100% to 50% in all cases from April 2026.

EIS is the only mainstream structure with all four reliefs intact. The scheme has been extended to 2035. Company investment limits have been doubled.

**For the BPR clock specifically:** investors who start a qualifying EIS investment programme before April 2027 will have cohorts qualifying for BPR before the pension IHT changes take full effect. Those who wait will not.

*April 2027 is not a distant deadline. The BPR clock needs to start now.*

---

## How Unlock Access Works

**What Unlock Access does:**
- Curated deal flow — pre-screened EIS and SEIS qualifying companies, presented with investment documentation for your review. Every investment is your decision.
- Shares issued immediately — on completion, shares are issued without delay. Your EIS qualifying period and BPR clock start from day one.
- Individual HMRC submissions — each investor's submission is processed individually, not batched. Your EIS3 certificate is not delayed by anyone else's paperwork.
- EIS3 certificate tracked and delivered — your certificate and Unique Investment Reference delivered directly to you, ready for your accountant.
- No capital in a pool — funds are deployed directly to the company on completion. Your capital works from day one.

**What Unlock Access does not do:** Unlock Access does not provide financial advice, does not recommend specific investments, and does not make investment decisions on your behalf.

*Unlock Access is operated by Unlock Services Limited. Tom King is the founder of both Unlock Services Limited and Cloudworkz, one of the companies currently available via Unlock Access. This dual-founder relationship is disclosed in full.*

---

## Important Information

- Tax reliefs depend on individual circumstances and on qualifying conditions being met and maintained throughout the holding period.
- EIS/SEIS shares are illiquid. Capital should be considered committed for a minimum of three years to retain income tax relief, and realistically five to ten years or more.
- Loss relief is personal to the original investor and cannot be inherited by beneficiaries.
- IHT BPR is subject to qualifying conditions and from April 2026 subject to the new £2.5M combined APR/BPR allowance.
- CGT extinguishment on death and deferred gain treatment are subject to legislation in force at the time of death.
- Unlock Services Limited does not provide regulated financial advice and is not authorised to do so. Investors should seek independent advice from a qualified adviser before investing.

*© 2026 Unlock Services Limited. Prepared March 2026. This document is confidential and prepared for the named recipient only.*

---

**Next step:** Reply to arrange a conversation before your call on 30 March.

Tom King — tom@unlockdd.com | www.unlockdd.com

*Prepared: March 2026 | Last reviewed: 14 March 2026 | Status: Current*
