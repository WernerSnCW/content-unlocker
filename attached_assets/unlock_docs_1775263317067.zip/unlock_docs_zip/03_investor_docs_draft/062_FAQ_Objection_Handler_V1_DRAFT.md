# Unlock — Frequently Asked Questions & Objection Handler
## For investors, agents, and advisers | Draft V1 | 2 April 2026

*This document is for information purposes only and does not constitute financial advice or an invitation to invest. Capital is at risk. Investors should seek independent professional advice before making any investment decision.*

---

## About Unlock

**What is Unlock?**

Unlock is a portfolio intelligence platform for UK private investors managing £250,000 to £5 million. It consolidates assets across all accounts, wrappers, platforms, and structures into a single view — and layers on tax intelligence, scenario modelling, and EIS deal-flow access.

The mission is simple: give private investors the same clarity, tools, and protections that institutions take for granted.

**Who is Unlock built for?**

Unlock is built for self-directed and adviser-informed investors who manage complex, multi-asset portfolios — property, equities, alternatives, ISAs, pensions, and EIS positions — across multiple platforms and wrappers. If you're working from spreadsheets, relying on partial views from individual platforms, or finding that your IFA cannot help with EIS directly, Unlock is built for you.

**Is Unlock financial advice?**

No. Unlock is a portfolio intelligence platform. It does not provide regulated financial advice, make investment recommendations, or tell you what to buy or sell. It gives you the data, modelling, and scenario analysis to arrive at better-informed decisions — and to arrive at meetings with your IFA or accountant already knowing your position.

**How does Unlock make money?**

Unlock earns from subscriptions — a monthly fee for platform access. There are no AUM-based charges, no trail fees, and no commission on any investment surfaced through the platform. Our incentive is your continued use of the platform, not the sale of any particular product.

---

## The Platform

**What does Unlock actually do?**

Five core capabilities:

*Asset Register* — A permanent, accurate record of everything you own across all accounts, platforms, wrappers, and family members. Lot-level cost basis tracking. Date-freeze for IHT and probate valuations. Currently operational for founding investor onboarding.

*Portfolio Simulator* — Scenario testing and stress modelling grounded in your actual positions. Models what happens to your specific portfolio under 30+ downside scenarios — markets down 30%, interest rates spike, property falls, stagflation. You see how your holdings hold up before a crisis, not after. In active development.

*Tax Intelligence Engine* — Real-time, forward-looking modelling of all UK tax interactions across EIS, SEIS, CGT, IHT, pension drawdown, and AIM BPR. Continuous HMRC rule-tracking. This is the core of what Unlock does. In active development; 18–24 months minimum for any competitor to replicate correctly.

*Syndicate Access* — Curated access to vetted collective investment opportunities at 8–10% fees, versus the 9–14% charged by Crowdcube, Seedrs, and comparable platforms. Founding investors receive priority allocation. Operational now.

*Unlock Access* — A curated EIS deal-flow and portfolio service. See the Unlock Access section below.

**What is the Decumulation Planner?**

The Decumulation Planner answers the question every investor approaching retirement needs to ask: given my assets, how long will my money last if I spend £X per year — and what is the optimal sequence to draw from those assets to minimise tax and maximise what I pass to my heirs?

It covers all major asset classes — cash, ISA, pension (DC/SIPP/workplace), investment property, VCT, EIS, and AIM shares — and models four drawdown strategies: tax-optimised, IHT-optimised, income-first, and growth-first.

*Status: Specification complete. Prototype build commencing.*

**How is Unlock different from my existing platforms?**

Most platforms are built for one thing: showing you what's on their platform. They have no visibility of what you hold elsewhere, no tax intelligence, and no scenario modelling. Unlock consolidates across all of them — and adds the intelligence layer on top.

Your IFA provides advice. Your accountant handles compliance. Unlock gives you the consolidated data and forward-looking modelling that makes both of those conversations more productive. It is not a replacement for professional advice — it is what you bring to those meetings.

**How is Unlock different from Moneyhub or other aggregators?**

Portfolio aggregators connect accounts and show you a consolidated balance. Unlock does that — and then models tax interactions, runs scenarios, tracks EIS qualifying periods, flags IHT exposure, and gives you actionable intelligence. It is a different capability level, built specifically for the complexity of HNW portfolios.

---

## EIS & SEIS

**What is EIS?**

EIS — the Enterprise Investment Scheme — is a UK government programme providing substantial tax reliefs on investments in qualifying early-stage companies. The four reliefs are:

*Income tax relief* — 30% of the amount invested, claimable via Self Assessment or PAYE. Claimable in the year of investment or carried back to the previous tax year.

*Capital Gains Tax exemption* — If your investment grows and you sell after holding for at least three years, any profit is entirely exempt from CGT. There is no upper limit on the qualifying gain.

*Loss relief* — If a company fails, the net loss can be set against income tax or CGT. For an additional-rate taxpayer, the effective downside on a failed EIS investment is approximately 38.5p per pound invested — not 100p — after income tax relief and loss relief are applied.

*Inheritance Tax relief* — EIS shares held for at least two years qualify for Business Property Relief (BPR) and exit your estate entirely, subject to the April 2026 cap described below.

**What is SEIS?**

SEIS — the Seed Enterprise Investment Scheme — applies to earlier-stage companies and provides higher relief rates: 50% income tax relief (versus 30% for EIS), plus CGT exemption and loss relief on the same basis. The annual investment limit under SEIS is £200,000.

For an additional-rate taxpayer investing £50,000 under SEIS: income tax relief of £25,000 is received in the year of investment. If the company fails, loss relief reduces the net loss to approximately £13,750. Effective downside: approximately 27.5p per pound.

**What has changed about BPR from April 2026?**

From April 6, 2026, IHT relief on EIS and SEIS investments is subject to a cap. 100% relief continues to apply up to £2,500,000 per estate. For amounts above that threshold, relief reduces to 50%. This is a significant structural change for investors who have been using EIS and SEIS for IHT mitigation.

This change is subject to final enactment. Investors planning to use EIS or SEIS for IHT mitigation should seek professional advice on the implications for their specific position.

**Can I carry back EIS income tax relief to last year?**

Yes. EIS and SEIS income tax relief can be carried back to the previous tax year, subject to the annual limits applying in that year. The claim is made via Self Assessment. The carry-back deadline for 2024/25 tax year claims is April 5, 2026 — the final day of the current tax year.

**What happens to EIS CGT relief at death?**

Any capital gain accrued on an EIS investment during your lifetime is completely extinguished at death. Your beneficiaries inherit at probate value and pay CGT only on growth after that point. The EIS exemption does not transfer to beneficiaries — but the gain wiping at death means the combination of EIS and estate planning is particularly powerful.

**What about loss relief at death?**

Loss relief is personal — it belongs to the investor, not the investment. If a company fails after your death, your beneficiaries cannot claim loss relief. This strengthens the case for EIS investments with shorter exit horizons for investors later in life.

**My IFA says they can't advise on EIS. Is that right?**

Yes. UK IFAs cannot provide regulated advice on individual EIS company investments. They can advise on EIS funds managed by authorised discretionary managers, and they can advise on VCTs. Direct EIS investment sits outside the scope of regulated advice entirely. This is not a gap in your IFA's capability — it is a structural feature of how the advice regime works.

It means the decision about which EIS companies to back is yours. Unlock gives you the data, tools, and structured information to make that decision well.

---

## IHT & Pension Planning

**What is happening with pension IHT from April 2027?**

Under current proposals, pension assets will be included within an individual's estate for IHT purposes from April 2027. Currently, pensions sit outside the estate and pass to beneficiaries without IHT. If this change is enacted, it would significantly affect the estate planning position of investors with large pension balances.

This change is subject to final enactment. It has been announced but has not yet received Royal Assent. Investors with substantial pension assets should model both scenarios — with and without pension IHT inclusion — when planning their estate strategy.

**How does Unlock help with IHT planning?**

Unlock's Tax Intelligence Engine models IHT exposure across the full portfolio — including EIS/SEIS BPR eligibility, AIM BPR tracking, pension exposure under both current and proposed rules, and the interaction between different asset classes and wrappers. It gives you the forward-looking picture before you act, not the reconstructed picture after.

---

## Unlock Access

**What is Unlock Access?**

Unlock Access is a curated EIS deal-flow and portfolio service. It connects qualified investors with early-stage EIS-qualifying companies that have passed a structured evaluation process.

Four pillars: Guidance — Tools — Access — Administration.

It is not a fund. You build your own EIS portfolio from Unlock's curated pipeline, with full visibility at every stage.

**How does Unlock Access evaluate companies?**

Every company is assessed against a 24-criterion framework across four dimensions before any investor sees it. The scoring summary for each company is shared with investors in full — the same evaluation the Unlock Access team used to make its own decision. This is structured disclosure, not a recommendation.

Absence from the platform is the filter. Companies that do not pass the evaluation do not appear. Investors see only companies that have met the threshold. That is the entire screening function.

**Does Unlock Access advise investors?**

No. Unlock Access does not hold FCA authorisation and operates as a deal-flow and information service. It provides structured disclosure — investors receive the evaluation framework, the scoring summary, and the company documentation, and make their own investment decisions. The decision about whether to invest, and how much, remains entirely with the investor.

**Is Unlock Access independent of the companies it features?**

Unlock Access raises capital for its own pipeline companies — Unlock and Cloudworkz — and states this openly. All fees and relationships are disclosed in full before any investment is made. The positioning is transparency and full disclosure, not claims of independence.

---

## The Founding Round

**What is the founding round?**

Unlock is raising £1.2 million at a £6.5 million pre-money valuation from approximately 25 founding investors. The investment instrument is an Instant Investment via SeedLegals. Shares issue on April 6, 2026.

Unlock holds SEIS advance assurance. The raise is EIS and SEIS qualifying, subject to individual circumstances.

**What is an Instant Investment?**

An Instant Investment is the investment instrument used in this round, processed via SeedLegals. It provides immediate EIS compliance processing and anti-dilution protection until Series A. It is not an ASA (Advanced Subscription Agreement), SAFE, or convertible note — it is a direct equity investment.

**What do founding investors receive?**

Founding investors receive equity in Unlock, EIS or SEIS tax reliefs subject to individual circumstances, priority allocation on all Unlock Access deal-flow, and white-glove onboarding — the founding team sets up your portfolio with your actual holdings, runs initial scenario analysis, and delivers a customised portfolio report. White-glove onboarding is a permanent benefit, not a time-limited offer.

**What is the minimum investment?**

£40,000. Maximum £500,000. Ticket sizes are discussed individually with the Unlock team.

**Who backs Unlock?**

Founding investor backers include a former Chairman of Barclays and the former Director General of TISA (The Investing and Savings Alliance).

---

## Common Objections

**"I already have an IFA who handles this."**

Your IFA is likely excellent at regulated advice. Unlock is not advice — it is your data layer. It consolidates your full portfolio so you arrive at IFA meetings knowing your position, not reconstructing it. Most IFAs find clients who use Unlock are better informed and faster to act. Unlock complements your IFA — it does not replace them.

**"I'm not interested in investing in early-stage companies."**

The platform intelligence — portfolio consolidation, tax modelling, scenario simulation — is available to all investors regardless of whether they use EIS or Unlock Access. The investment risk in early-stage companies is real and is not appropriate for everyone. The platform's value does not depend on your appetite for that risk.

**"I already invest in EIS through a fund."**

EIS funds provide access but limited visibility. You typically cannot see the underlying companies, the evaluation logic, or how each position interacts with your wider tax picture. Unlock Access gives you direct portfolio building with full visibility, and Unlock's platform shows you how each EIS position sits within your broader estate and tax position. Direct EIS and EIS funds are not mutually exclusive.

**"My accountant handles tax."**

Tax software is backward-looking. It tells you what happened last year. Unlock is forward-looking — you model scenarios before decisions, not after. Your accountant and Unlock are not alternatives. Unlock gives you the data that makes your accountant's work more precise and your year-end conversations more productive.

**"How is Unlock different from a spreadsheet?"**

A spreadsheet holds what you put in it. Unlock tracks cost basis at lot level, models 30+ stress scenarios, flags BPR qualifying periods, and applies HMRC rules to your actual positions in real time. A spreadsheet reflects where you are. Unlock tells you where you're heading.

**"What if the regulations change?"**

Unlock's Tax Intelligence Engine is built for continuous HMRC rule-tracking — regulatory change is not a risk to the platform, it is part of the value proposition. When rules change, Unlock models the impact across your portfolio before you act.

**"I'm happy with my current setup."**

Most investors who say this are managing fragmented portfolios across multiple providers, missing tax optimisation opportunities, and working without forward-looking scenario analysis. The question is not whether your current setup works — it is whether it is optimal. Unlock answers that question. A 20-minute demo makes it visible.

---

## Contact

**tom@unlockdd.com | www.unlockdd.com**

*This document does not constitute financial advice or an invitation to invest. Unlock Access does not hold FCA authorisation and operates as a deal-flow and information service. EIS and SEIS investments are high-risk and illiquid. Capital is at risk. Tax treatment depends on individual circumstances and may change. Investors should seek independent professional advice before making any investment decision.*

*April 2026 | Draft V1 | Status: Pending QC evaluation*
