# Unlock Investor Outreach Execution Plan
## 30,000 Database + Aircall + Pipedrive

**Last Updated:** March 14, 2026
> **V4 NOTE:** This document is aligned with Unlock Content Bank V4 (March 2026). All references to investment instrument use "Instant Investment" (not ASA, SAFE, or Advanced Subscription Agreement). Campaign start date updated to March 16, 2026.  
**Objective:** Convert 25 founding investors into committed capital (£1.2M+) via systematic 1-on-1 outreach — campaign start March 16, 2026  
**Primary Channel:** Cold/warm calls using 16-step Aircall playbook + Pipedrive tracking

---

## Part 1: Database Segmentation & Tier Strategy

### Why Segmentation Matters
Your 30,000 database is not homogeneous. You need to:
1. **Tier by likelihood** (Tier 1/2/3 investor profiles)
2. **Segment by persona** (Preserver/Growth Seeker/Legacy Builder)
3. **Identify warm intros** (existing relationships, recent activity)
4. **Assign dial sequence** (highest-probability calls first)

### Tier 1: Highest Probability (Warm + HNW + Active)
**Target:** ~300–500 investors  
**Profile:**
- Recent activity in your other platform (last 30 days)
- Portfolio size £500K–£5M+ (estimable from transaction history)
- Prior EIS/SEIS interest (documented in notes/tags)
- Existing relationship or warm intro available
- Age 35–65 (likely to have capital available)

**Conversion Expectation:** 25–35% demo booking rate, 30–40% Instant Investment close rate  
**Effort:** 1-2 outreach per investor (call + light follow-up)

### Tier 2: Medium Probability (HNW + Some Activity)
**Target:** ~1,500–2,000 investors  
**Profile:**
- Portfolio size £250K–£1M
- Some but not recent activity
- No documented EIS/SEIS interest (yet)
- Estimated fit based on asset class preferences
- Age 35–65

**Conversion Expectation:** 12–18% demo booking rate, 15–25% Instant Investment close rate  
**Effort:** 2-3 outreach attempts per investor

### Tier 3: Lower Probability (Exploratory)
**Target:** Remaining database  
**Profile:**
- Portfolio size <£250K or unknown
- Inactive or historical only
- May not be EIS/SEIS eligible
- Useful for brand awareness + list building

**Conversion Expectation:** 3–8% demo booking rate, 5–10% Instant Investment close rate  
**Effort:** Limited outreach; focus on high-volume list building

---

## Part 2: Pipedrive Configuration for Aircall Integration

### Pipeline Structure (Recommended)
Create a **five-stage pipeline** that mirrors your investor journey:

**Stage 1: Outreach Queued**
- Investor added to calling list
- Phone number verified
- Tier assigned (Tier 1/2/3)
- Persona estimated (Preserver/Growth Seeker/Legacy Builder)
- Call script selected (16-step playbook)

**Stage 2: Called (Demo Booked)**
- Aircall call logged automatically to Pipedrive
- Call duration, outcome, and agent notes captured
- Next action: Send demo confirmation email
- Booking date/time in Pipedrive custom field

**Stage 3: Demo Scheduled**
- Video demo link generated
- One-pager sent to investor
- Investor to join video call within 7 days
- Reminder: 24 hours before demo

**Stage 4: Demo Completed â†’ Pack 1 Sent**
- Demo outcome logged (enthusiastic/interested/skeptical/pass)
- Investor persona refined based on demo
- Pack 1 (Founding Investor Pack) emailed with personalized cover letter
- Follow-up call scheduled for 3–5 days post-demo

**Stage 5: Pack 1 â†’ Pack 2 (Decision Stage)**
- Pack 1 feedback received
- Investor interest level updated
- Pack 2 (Investor Information Memorandum) sent to qualified prospects
- Advisor/accountant loop initiated
- Instant Investment close target set

---

### Pipedrive Custom Fields (to add)

| Field Name | Type | Values | Purpose |
|---|---|---|---|
| Investor Tier | Dropdown | Tier 1 / Tier 2 / Tier 3 | Prioritize outreach |
| Investor Persona | Dropdown | Preserver / Growth Seeker / Legacy Builder | Personalize messaging |
| EIS/SEIS Eligible | Checkbox | Yes/No/Unknown | Compliance + tax positioning |
| Portfolio Size | Dropdown | <£250K / £250K-£1M / £1M-£5M / £5M+ | Ticket size expectation |
| Call Outcome | Dropdown | Demo Booked / Not Interested / Call Back Later / Wrong Number / Voicemail | Dial sequence logic |
| Demo Status | Dropdown | Scheduled / Completed / No-Show / Rescheduled | Pipeline tracking |
| Demo Feedback | Text | [Free-form notes] | Refinement + persona validation |
| Pack 1 Sent | Date | [Auto-populate] | Sales cycle tracking |
| Pack 2 Sent | Date | [Auto-populate] | Escalation tracking |
| Expected Ticket Size | Currency | £___ | Sales forecasting |
| Instant Investment Close Date | Date | [Investor-facing target] | Win planning |
| Advisor/Accountant Involved | Checkbox | Yes/No | Due diligence readiness |

---

### Aircall Integration Checklist
- [ ] Aircall â†’ Pipedrive webhook configured (calls auto-log to Pipedrive)
- [ ] Call recordings uploaded to Pipedrive deal records
- [ ] Agent screen pop enabled (Pipedrive investor record displays during call)
- [ ] Call disposition codes mapped to Pipedrive outcomes
- [ ] Call script available in Aircall interface (embed 16-step playbook as agent notes)

---

## Part 3: Dial Sequence & Weekly Targets

### 8-Week Campaign Overview

**Week 1–2: Tier 1 Blitz**
- **Target:** 300 Tier 1 investors called
- **Booking target:** 75–105 demos (25–35% conversion)
- **Dial pace:** 150 calls/week (roughly 30 calls/day across team)
- **Key focus:** Build momentum with highest-probability investors

**Week 3–4: Tier 1 Follow-Up + Tier 2 Ramp**
- **Target:** 50 Tier 1 follow-ups + 400 Tier 2 new calls
- **Booking target:** 20 Tier 1 follow-ups + 50–70 Tier 2 demos
- **Dial pace:** 225 calls/week
- **Key focus:** Close Tier 1 follow-ups; seed Tier 2 pipeline

**Week 5–6: Tier 2 Ramp + Demo Execution**
- **Target:** 600 Tier 2 calls + 40–50 demos conducted
- **Booking target:** 70–100 new Tier 2 demos + 12–15 Pack 1 sends
- **Dial pace:** 300 calls/week
- **Key focus:** Demo cadence (2–4 per day); Pack 1 deployment

**Week 7–8: Tier 2 Follow-Up + Close Focus**
- **Target:** 200 Tier 2 follow-ups + 50 demos conducted
- **Booking target:** 20–30 Pack 2 sends + 5–10 Instant Investment closes
- **Dial pace:** 150 calls/week (shift to closing)
- **Key focus:** Close Tier 1/2 investors; Instant Investment execution

**Total campaign reach:** ~1,500–2,000 investors contacted over 8 weeks

---

## Part 4: Call Script Integration with Aircall

### How to Use the 16-Step Playbook in Aircall

**Setup:**
1. Create an Aircall "call script" or embed in agent notes
2. Display as a **sidebar** during live calls (steps 1–16 visible)
3. Agent marks steps complete as they progress
4. Failed steps â†’ agent branches to objection handling

**Call Flow (Aircall Screen):**

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ UNLOCK INVESTOR OUTREACH - AIRCALL SCRIPT â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Investor: John Smith | Portfolio: £1.2M    â”‚
â”‚ Tier: 1 | Persona: Growth Seeker          â”‚
â”‚ EIS/SEIS Eligible: Yes                     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ â˜ Step 1: Greeting & Context              â”‚
â”‚ â˜ Step 2: Introduce EIS/SEIS              â”‚
â”‚ â˜ Step 3: Confirm Awareness & Risk        â”‚
â”‚ â˜ Step 4: Common Starting Point           â”‚
â”‚ â˜ Step 5: Correlation & Inflation         â”‚
â”‚ â˜ Step 6: Over-Concentration Reality      â”‚
â”‚ â˜ Step 7: Early-Stage Parallel & Unlock   â”‚
â”‚ â˜ Step 8: Identify Main Frustration       â”‚
â”‚ â˜ Step 9: Unlock's Solution               â”‚
â”‚ â˜ Step 10: Market Uncertainty             â”‚
â”‚ â˜ Step 11: Independent Investor Type      â”‚
â”‚ â˜ Step 12: Unlock Differentiation         â”‚
â”‚ â˜ Step 13: Suitability & Eligibility      â”‚
â”‚ â˜ Step 14: Segment & Decision Process     â”‚
â”‚ â˜ Step 15: Book Demo (Setup & Time)       â”‚
â”‚ â˜ Step 16: Commitment & Compliance        â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Call Outcome: [ ] Demo Booked              â”‚
â”‚              [ ] Not Interested            â”‚
â”‚              [ ] Call Back Later           â”‚
â”‚              [ ] Wrong Number              â”‚
â”‚              [ ] Voicemail                 â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

## Part 5: Agent Preparation & Objection Handling

### Pre-Launch Training (Day 1–2)

**Mandatory for all agents:**

1. **Watch:** 5-minute video overview of Unlock (problem/solution/why now)
2. **Read:** One-pager on three personas (Preserver/Growth Seeker/Legacy Builder)
3. **Role-play:** Mock call using 16-step script with senior agent
4. **Certification:** Complete 3 successful mock calls; pass objection quiz
5. **Live listen:** Shadow 5 calls with experienced agent before going live

**Success criteria:**
- Agent completes all 16 steps in natural conversation flow
- Agent adapts language to investor personality
- Agent correctly identifies investor persona during call
- Agent books 25%+ of calls into demos (minimum benchmark)

---

### Objection Handling Framework

**Key objections you'll hear:**

| Objection | Root Cause | Reframe | Next Action |
|---|---|---|---|
| "I'm not interested in early-stage investments" | Misunderstands Unlock's role | Unlock = platform to understand all your investments, not forced entry into new ones | Pivot to portfolio view + tax efficiency |
| "I don't have time for a demo" | Real or stalling | "It's 20 minutes, and most say it saves them 5+ hours on portfolio management per year" | Offer specific time window or recorded demo |
| "My IFA handles this" | Advisor gatekeeping | "Unlock isn't advice—it's your own intelligence layer. Your IFA will love the data you bring them." | Offer to include advisor in demo |
| "How do I know this isn't a scam?" | Legitimate concern | Name-drop credible early investors + Barclays board member reference | Send one-pager first, then demo |
| "What's the catch? Why is it cheap?" | Trust issue | "We make money on syndicate fees + subscriptions, not on product margins. Aligned incentives." | Explain revenue model clearly |
| "I'm happy with my current setup" | Status quo bias | "Most investors say that until they see they're missing 10–20% in returns due to fragmentation." | Use concrete example from Step 6 |
| "I'll think about it and call you back" | Fear of commitment | "Happy to—but let's grab 20 minutes first to see if it's even worth your time." | Pin down specific callback date |

**Agent notes:** When objection raised, mark in Pipedrive + log agent's reframe attempt. This data trains future calls.

---

## Part 6: Demo Execution (Week 1–8)

### Demo Cadence & Logistics

**Target:** 2–4 demos per day (Tom or senior team member)

**Setup:**
1. Investor receives email 24 hours before demo with:
   - Zoom/Teams link
   - One-pager ("What to Expect")
   - Unlock elevator pitch (30 seconds)
   - Note: "Capital at risk; this is an introduction, not advice"

2. Demo takes 20–25 minutes:
   - 3 min: Context + Unlock mission
   - 12 min: Live walkthrough (portfolio simulator, personas, syndicates, due diligence tools)
   - 5 min: Q&A + objection handling
   - 2 min: Outcome + next steps (Pack 1 if interested)

3. Post-demo email within 1 hour:
   - Thank you note
   - Pack 1 attached (personalized cover letter by persona)
   - Follow-up call scheduled 3–5 days later
   - Subject line: "Your Unlock Demo – [Investor Persona] Strategy Overview"

---

### Demo Persona-Specific Positioning

**If Preserver identified:**
- Lead with portfolio stress-test capability
- Show downside modeling + capital protection
- Emphasize "sleep at night" outcome
- Highlight risk controls built in

**If Growth Seeker identified:**
- Lead with syndicate access + deal flow
- Show portfolio upside potential
- Emphasize 8–10% fee advantage vs. competitors
- Highlight 10–20% performance uplift narrative

**If Legacy Builder identified:**
- Lead with tax efficiency tools
- Show EIS/SEIS integration + inheritance planning
- Emphasize family wealth modeling
- Highlight multi-generational outcomes

**One-pager sent after demo (tailored by persona):**

```
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        YOUR UNLOCK INVESTOR PROFILE
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

Based on our demo call, here's what we learned about you:

INVESTOR ARCHETYPE: Growth Seeker
â”œâ”€ Motivation: Long-term wealth growth with calculated risk
â”œâ”€ Strength: You understand diversification + upside potential
â””â”€ Unlock fit: Syndicates + portfolio simulation

YOUR CURRENT SITUATION:
â”œâ”€ Portfolio: Likely ~£1–2M across stocks, property, ISA
â”œâ”€ Challenge: Limited visibility into upside opportunities
â””â”€ Opportunity: Unlock syndicates at 8–10% (vs 9–14% market)

NEXT STEPS:
1. Review Pack 1 (Founding Investor overview) — 5 pages, 8 min read
2. Schedule 20-min follow-up call on [DATE/TIME]
3. If interested: Explore Pack 2 (full details) + Instant Investment structure

QUESTIONS? Email tom@unlockdd.com or call [PHONE]

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        Capital at risk. This is an introduction.
                  No advice given.
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
```

---

## Part 7: Pack 1 â†’ Pack 2 Conversion Sequence

### Post-Demo Email Sequence (Automated via Pipedrive)

**Email 1: Send immediately after demo**
- Subject: "Your Unlock Demo – [Persona] Strategy Overview"
- Body: Thank you + Pack 1 attached
- Tone: Warm, personalized, outcome-focused
- CTA: "Review Pack 1, then let's talk on [SCHEDULED DATE]"

**Email 2: Day 2 (if no response)**
- Subject: "Quick question: Was the demo useful?"
- Body: Light touch-base; offer to clarify any confusion
- Tone: Helpful, not pushy
- CTA: "Reply or call me"

**Email 3: Day 3 (24 hours before follow-up call)**
- Subject: "Tomorrow's call – Pack 1 questions?"
- Body: Remind of scheduled call; offer to address any Pack 1 questions
- Tone: Confirmatory
- CTA: Confirm time; send Zoom link

**Email 4: Day 5 (if Pack 1 well-received)**
- Subject: "Next level: Full transparency"
- Body: Introduce Pack 2; explain difference
- Tone: Exclusive, scarcity-driven
- CTA: "Ready to dive deep? Let's discuss Pack 2 details"

**Email 5: Day 7 (if interest confirmed)**
- Subject: "Pack 2 attached – Full investment details"
- Body: Pack 2 + custom cover letter addressing their specific situation
- Tone: Professional, detail-rich
- CTA: "Review with your accountant; let's schedule Stage 3 call"

---

### Follow-Up Call Script (Day 3–5 Post-Demo)

**Call objective:** Gauge interest, address Pack 1 questions, move to Pack 2

```
STAGE 2 FOLLOW-UP CALL (15 minutes)

Opening:
"Hi [Name], thanks for reviewing the demo. Quick check-in on 
what you thought—any questions about how Unlock works?"

Listen for:
- Enthusiasm (â†’ move to Pack 1 â†’ Pack 2 immediately)
- Skepticism (â†’ address specific objection)
- Hesitation (â†’ uncover real concern)

If enthusiasm:
"Fantastic—so the [PERSONA]-focused approach makes sense for 
your situation. Next step is Pack 1, which gives you the full 
investment overview, founding investor benefits, and how you'd 
participate. Have you had a chance to review it?"

If they've read Pack 1:
"What stood out to you? What would you like to know more about?"

Listen for objections and address with reframes above.

If they're ready to move forward:
"Perfect—so the next step is Pack 2, which is the full legal 
and financial details, valuation framework, and Instant Investment structure. 
This is typically something you'd review with your accountant 
or IFA. Fair to send that over?"

Closing:
"Great—I'll send Pack 2 over today. Would it make sense to 
schedule a call in 5–7 days once you and your advisor have 
reviewed? That way we can walk through any questions and get 
you comfortable with the terms."

[Confirm date/time for Stage 3 call]
```

---

## Part 8: Sales Metrics & Weekly Dashboard

### KPIs to Track (Update Daily)

**Daily Metrics (Aircall â†’ Pipedrive auto-log):**
- Calls completed: __ (Target: 30–40/day)
- Calls booked to demos: __ (Target: 25–35% conversion)
- Demo confirmations: __ (Target: 80% of booked show up)

**Weekly Metrics (Pipedrive report):**
| Metric | Target | Week 1 | Week 2 | Week 3 | Week 4 | Week 5 | Week 6 | Week 7 | Week 8 |
|---|---|---|---|---|---|---|---|---|---|
| Calls dialed | 150 | | | | | | | | |
| Demos booked | 38–50 | | | | | | | | |
| Pack 1 sent | 8–12 | | | | | | | | |
| Pack 2 sent | 2–4 | | | | | | | | |
| Instant Investment closes | 1–2 | | | | | | | | |
| Cumulative capital raised | | | | | | | | | £___ |

**Sample Pipedrive Dashboard View:**

```
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
                    UNLOCK FOUNDING ROUND TRACKER
                         Week of March 16, 2026
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

FUNNEL OVERVIEW:
â”œâ”€ Tier 1 Outreach: 300 investors contacted (75 booked demos)
â”œâ”€ Tier 2 Outreach: 0 (starting Week 3)
â”œâ”€ Demo Completed: 25 (12 Pack 1 sent, 2 Pack 2 sent)
â””â”€ Instant Investment Signed: 0 (target: 1 by end of week)

CONVERSION RATES:
â”œâ”€ Outreach â†’ Demo Booking: 25% (TARGET: 25–35%)
â”œâ”€ Demo â†’ Pack 1 Send: 48% (TARGET: 60%+)
â”œâ”€ Pack 1 â†’ Pack 2 Send: 17% (TARGET: 50%+)
â””â”€ Pack 2 â†’ Instant Investment: 0% (TARGET: 30%+, ramping Week 5+)

PIPELINE BY STAGE:
â”œâ”€ Scheduled Demos (Next 7 days): 18
â”œâ”€ Pack 1 Pending Response: 10
â”œâ”€ Pack 2 Pending Response: 2
â””â”€ Instant Investment Pending: 0

TEAM PERFORMANCE:
â”œâ”€ Tom (team lead): 8 calls/day | 6 demos booked | 3 Pack 1 sent
â”œâ”€ Agent 2: 12 calls/day | 8 demos booked | 4 Pack 1 sent
â”œâ”€ Agent 3: 10 calls/day | 7 demos booked | 5 Pack 1 sent
â””â”€ Total: 30 calls/day | 21 demos booked | 12 Pack 1 sent

RED FLAGS:
âš  Pack 1 â†’ Pack 2 conversion only 17% (should be 50%+)
  â†’ Action: Review Pack 1 positioning; add FAQ to email
âš  Demo completion rate 80% (normal; improve reminder emails)
  â†’ Action: Add SMS reminder 2 hours before demo

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
```

---

## Part 9: Aircall + Pipedrive Technical Setup

### Pre-Campaign Checklist

**Aircall Configuration:**
- [ ] Three agent accounts created (Tom + 2 agents)
- [ ] Phone number(s) configured (local UK number or vanity number)
- [ ] Dialer list uploaded (30,000 investors with phone numbers)
- [ ] Call script template created with 16-step playbook
- [ ] Recording enabled (for quality assurance + training)
- [ ] Voicemail drop script created: "Hi [Name], it's [Agent] from Unlock UK — I'm calling about a new platform for private investors. Quick 20-minute call might be valuable. Please call me back at [PHONE]."

**Pipedrive Configuration:**
- [ ] Custom fields added (see Part 2)
- [ ] Five-stage pipeline configured (see Part 2)
- [ ] Aircall integration enabled (calls auto-log)
- [ ] Email templates created (see Part 7)
- [ ] Automated workflows set up:
  - [ ] When demo booked â†’ send confirmation email + calendar invite
  - [ ] When demo completed â†’ send Pack 1 + follow-up reminder
  - [ ] When Pack 1 sent â†’ set 3-day reminder for follow-up call
  - [ ] When Pack 2 sent â†’ set 7-day reminder for Stage 3 call
- [ ] Reports created:
  - [ ] Daily call volume + booking rate
  - [ ] Weekly conversion metrics
  - [ ] Agent performance leaderboard
  - [ ] Revenue forecast (capital raised vs. target)

**Database Preparation:**
- [ ] 30,000 investor records imported to Pipedrive
- [ ] Phone numbers validated (remove duplicates, bad numbers)
- [ ] Tier 1/2/3 assignments made (via scoring or manual review)
- [ ] Persona estimates added (based on portfolio history)
- [ ] Do-not-call list filtered out (compliance)
- [ ] Calling list sequenced by tier + estimated conversion probability

**Compliance & Legal:**
- [ ] GDPR consent confirmed (phone number usage)
- [ ] TCPA compliance (US investors, if applicable)
- [ ] Call recording disclosure script in place
- [ ] "Capital at risk" disclaimer in all emails
- [ ] "No advice given" statement in all materials

---

## Part 10: Sample Outreach Calendar (8 Weeks)

### Week 1–2: Tier 1 Blitz (March 16 – April 5)

**Monday, March 16:**
- Agent training + mock calls (all day)
- Tom: 2–3 calibration calls before going live

**Tuesday, March 17 – Friday, March 21:**
- 30 calls/day (150 total)
- Target: 38–50 demos booked
- Daily standup: 5 PM (review call outcomes, adjust messaging)

**Monday, March 24:**
- Follow-up outreach on Tier 1 voicemails
- Begin scheduling demos for Week 1–2 completion
- 2–3 demo calls

**Tuesday, March 25 – Friday, March 28:**
- Continue Tier 1 calls + demo execution
- 30 calls/day + 2–3 demos/day
- Cumulative: ~50 demos scheduled by end of week

**Monday, Dec 1:**
- Tier 1 follow-up push (call-backs, reschedules)
- Demo execution ramps (4 demos/day)
- Pack 1 sending begins (12–15 targeted)

**Cumulative outcome Week 1–2:**
- ~300 Tier 1 calls
- ~75 demos booked
- ~25 demos completed
- ~12 Pack 1 sent

---

### Week 3–4: Tier 1 Follow-Up + Tier 2 Ramp (Dec 2 – Dec 15)

**Monday, Dec 2:**
- 20 Tier 1 follow-ups (voicemail call-backs, reschedules)
- 200 Tier 2 new calls begin
- Demo execution continues (3–4/day)

**Tuesday, Dec 3 – Friday, Dec 6:**
- 200 Tier 2 calls
- 2–3 Tier 1 follow-ups per day
- Demo execution: 2–3/day
- Pack 1 follow-ups: 2–3/day (investors who received Pack 1 last week)

**Monday, Dec 9 – Friday, Dec 13:**
- 200 Tier 2 calls (second wave)
- Demo execution: 3–4/day (ramping)
- Pack 2 sending begins (2–4 targeted)
- Stage 3 calls begin (demo follow-up + Pack 1 review discussions)

**Cumulative outcome Week 3–4:**
- ~50 Tier 1 follow-ups
- ~400 Tier 2 calls
- ~50–70 Tier 2 demos booked
- ~40 demos completed
- ~20 Pack 1 sent
- ~4 Pack 2 sent

---

### Week 5–6: Tier 2 Ramp + Demo Execution Surge (Dec 16 – Dec 29)

**Monday, Dec 16:**
- Holiday week prep: reduce to 20 calls/day (many investors traveling)
- Focus: Demo execution + Pack 2 depth discussions
- Demo execution: 3–4/day
- Pack 2 follow-ups: 2–3/day

**Tuesday, Dec 17 – Thursday, Dec 19:**
- Light calling (holiday season beginning)
- Maximum demo execution: 4/day
- Follow-up call blitz (Pack 1 reviewers)

**Friday, Dec 20 – Dec 26:**
- Holiday break (minimal calling, focus on admin + reporting)
- Demo execution: 2/day (investors available)

**Monday, Dec 27 – Wednesday, Dec 29:**
- Resume full calling (20–30 calls/day)
- Demo execution: 3–4/day
- Instant Investment close attempts begin (first targeted closes)

**Cumulative outcome Week 5–6:**
- ~250 Tier 2 calls
- ~40–50 demos completed
- ~15 Pack 1 sent
- ~8 Pack 2 sent
- ~1–2 Instant Investment closes (early momentum)

---

### Week 7–8: Close Focus (Dec 30 – Jan 13)

**Monday, Dec 30 – Friday, Jan 3:**
- Light calling (New Year holidays)
- 15–20 calls/day
- Heavy demo + follow-up focus
- Instant Investment close push: 5–10 targeted

**Monday, Jan 6 – Friday, Jan 10:**
- Full calling resume (30 calls/day)
- Demo execution: 3–4/day
- Instant Investment close push: 5–10 targeted
- Pack 2 depth calls: 3–4/day

**Monday, Jan 13 onwards:**
- Final push on pipeline
- Close remaining Stage 3 investors
- Begin Tier 2 follow-up wave (if cap not yet hit)

**Cumulative outcome Week 7–8:**
- ~200 calls (lighter week due to holidays)
- ~20 demos completed
- ~5–10 Pack 2 sent
- ~5–10 Instant Investment closes

---

### 8-Week Campaign Cumulative Targets

| Metric | Target | Realistic Range |
|---|---|---|
| **Calls dialed** | 1,500–2,000 | 1,600–1,800 |
| **Demos booked** | 300–400 | 280–350 |
| **Demos completed** | 200–250 | 150–200 |
| **Pack 1 sent** | 80–120 | 70–100 |
| **Pack 2 sent** | 30–50 | 20–35 |
| **Instant Investment signed** | 20–25 | 18–22 |
| **Capital raised** | £1.2M–£1.5M | £900K–£1.3M |

---

## Part 11: Agent Training Playbook

### Pre-Launch Training (2 Days)

**Day 1: Unlock Deep Dive**
- 30 min: Company overview (problem/solution/why now)
- 20 min: Three personas + their motivations
- 20 min: Key differentiators vs. competitors
- 20 min: EIS/SEIS tax relief explanation (must-know)
- 20 min: Traction narrative (Barclays reference, early investors, alpha users)
- 30 min: Q&A

**Day 2: Script & Mock Calls**
- 30 min: 16-step playbook walkthrough (steps 1–16 reviewed line by line)
- 30 min: Demo booking success factors (timing, positioning, commitment)
- 60 min: Agent 1 mock call (live with feedback)
- 60 min: Agent 2 mock call (live with feedback)
- 30 min: Objection handling deep dive
- 30 min: Success metrics + KPI expectations
- 30 min: Aircall + Pipedrive tool overview

**Certification:**
- Agent must complete 3 successful mock calls (25%+ demo booking rate)
- Agent must explain three personas in their own words
- Agent must answer 5 objection scenarios correctly
- Agent must shadow 3 live calls before going independent

---

### Ongoing Training (Weekly)

**Monday 9 AM: Weekly Standup**
- Review previous week's metrics
- Celebrate wins (highest booker, best conversion story)
- Identify challenges (common objections, missed closes)
- Refine script based on learnings

**Wednesday 2 PM: Agent Coaching (15 min per agent)**
- Listen to 2 live calls
- Provide real-time feedback
- Coach on persona identification or objection handling

**Friday 4 PM: Team Huddle**
- Cumulative week review
- Preview upcoming week targets
- Share success stories + replicable tactics

---

### Script Customization by Agent

**Tom's angle (founder):**
- "Hi [Name], it's Tom from Unlock. I'm calling a few investors who I think would really value what we've builtâ€¦"
- Position: Co-founder perspective, personal credibility
- Ideal for: Tier 1 warm intros, skeptical investors, large tickets

**Agent 2's angle (consultant):**
- "Hi [Name], I'm calling on behalf of Unlock, an investment intelligence platformâ€¦"
- Position: Product expert, thorough walkthrough
- Ideal for: Tier 2, systematic investors, detail-oriented

**Agent 3's angle (coach):**
- "Hi [Name], I'm helping investors optimize their portfolios using a new toolâ€¦"
- Position: Helpful advisor, outcomes-focused
- Ideal for: Tier 2, relationship-focused, growth seekers

---

## Part 12: Risk Mitigation & Contingency Plans

### What if demo booking rate is below 25%?

**Diagnosis:**
1. Are agents completing all 16 steps? (Check Aircall recordings)
2. Is the EIS/SEIS explanation landing? (Ask investors in post-call surveys)
3. Is the Unlock value prop clear? (Refine Step 7 messaging)
4. Are agents hitting the right persona? (Review Tier assignment)

**Response:**
- [ ] Extend Tier 1 outreach by 2 weeks
- [ ] Add FAQ one-pager to improve clarity
- [ ] Replace struggling agent with stronger performer
- [ ] Refine positioning based on objection patterns
- [ ] Increase call volume (if conversion flat, dial more to hit targets)

---

### What if demo-to-Pack-1 conversion is below 50%?

**Diagnosis:**
1. Is the demo experience strong? (Investor feedback)
2. Is Pack 1 positioning clear? (Refine email + cover letter)
3. Are there objections not being addressed in demo? (Listen to recordings)
4. Are investors expecting free access? (Clarify founding investor benefits)

**Response:**
- [ ] Add "What's Included" section to Pack 1 cover letter
- [ ] Create demo variant for Preservers (more downside focus)
- [ ] Send demo recording link for investors who want to review
- [ ] Increase follow-up touch points (24-hour email + phone call)
- [ ] Reduce Pack 1 length (aim for 6–8 pages instead of 10)

---

### What if Pack-2-to-Instant Investment conversion is below 25%?

**Diagnosis:**
1. Are investors involving advisors? (Check if advisor participation accelerates close)
2. Is Pack 2 too complex? (Investor feedback)
3. Are there pricing/valuation objections? (Revisit Instant Investment mechanics explanation)
4. Is scarcity message strong enough? (Update urgency language)

**Response:**
- [ ] Create simplified "Instant Investment at a Glance" one-pager
- [ ] Add worked examples (£50K, £100K, £250K investment scenarios)
- [ ] Offer "advisor deep dive call" to explain Pack 2 to accountants/IFAs
- [ ] Increase scarcity pressure (send "2 slots remaining" update)
- [ ] Extend Stage 3 call from 20 min to 30 min (more time to close)

---

### What if capital raise target is missed by 25% (£900K instead of £1.2M)?

**Fallback plan:**
1. **Tier 2 extension (Week 9–10):** Dial 500+ more Tier 2 investors (lower conversion but reach new segment)
2. **Growth Capital Round acceleration:** Move Growth Capital positioning forward (offer £250K additional raise at 20% discount, target growth investors)
3. **Referral bonus:** Offer existing founders 5% bonus for each new founder referral
4. **Strategic investors:** Reach out to family offices + syndicators for larger tickets (£250K–£500K)

---

## Part 13: Success Stories & Social Proof Collection

### Post-Instant Investment Close: Investor Testimonial Request

**Email (sent 24 hours after Instant Investment signed):**

```
Subject: Quick testimonial? (Helps us close others like you)

Hi [Investor Name],

Thanks for committing to Unlock. We're grateful for your belief in 
the platform.

Quick ask: Would you be open to a 2-minute video testimonial 
about what convinced you to invest? Investors later in the funnel 
often ask to hear from real founders/investors who've already 
committed. It would mean a lot.

No pressure—just reply if you're up for it.

Best,
Tom
```

**Video testimonial script (2 minutes):**
```
"Hi, I'm [Name]. I invested in Unlock because [KEY REASON]. 
What convinced me was [SPECIFIC FEATURE OR FOUNDER INSIGHT]. 
I think [TARGET INVESTOR TYPE] would really benefit from 
[USE CASE]. Tom and the team are [CREDIBILITY MARKER]."
```

**Use testimonial clips in:**
- Week 5+ outreach emails ("Recent founder [Name] saidâ€¦")
- Stage 2 demo followup (share video of similar investor)
- Pack 1 cover letters (personalized per persona)

---

## Part 14: End-of-Campaign Reporting

### Post-Campaign Summary (Week 9)

**Email to stakeholders:**

```
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
           UNLOCK FOUNDING ROUND FINAL RESULTS
                      8-Week Campaign Review
                      March 16 – May 10, 2026
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

CAMPAIGN OVERVIEW:
â”œâ”€ Investors contacted: 1,647
â”œâ”€ Database utilization: 5.5% of 30,000
â”œâ”€ Total demos completed: 185
â”œâ”€ Total Pack 1 sent: 87
â”œâ”€ Total Pack 2 sent: 28
â””â”€ Instant Investment agreements signed: 22

CAPITAL RESULTS:
â”œâ”€ Capital raised: £1.18M
â”œâ”€ Average ticket size: £53.6K
â”œâ”€ Discount utilization: 35–59% (tiered)
â”œâ”€ Target achievement: 98% of £1.2M goal
â””â”€ Founding investor slots filled: 22/25

CONVERSION FUNNEL:
â”œâ”€ Outreach â†’ Demo booking: 24.8% (target 25–35%)
â”œâ”€ Demo â†’ Pack 1 send: 55.4% (target 60%+)
â”œâ”€ Pack 1 â†’ Pack 2 send: 38.6% (target 50%+)
â””â”€ Pack 2 â†’ Instant Investment: 42.8% (target 30%+)

TEAM PERFORMANCE:
â”œâ”€ Tom: 12 Instant Investments closed (highest closer + founder credibility)
â”œâ”€ Agent 2: 6 Instant Investments closed (highest volume + consistency)
â”œâ”€ Agent 3: 4 Instant Investments closed (strong engagement quality)

LESSONS LEARNED:
1. Tier 1 investors converted at 45% demo â†’ Pack 1 (vs 60% target)
   â†’ Insight: Need warmer intro + personal referral to hit targets
   
2. Advisor involvement = 70% close rate (vs 35% without advisor)
   â†’ Action: Proactively offer advisor deep-dive calls in Stage 3
   
3. Growth Seekers booked demos at 35% (vs 22% overall)
   â†’ Action: Target Growth Seekers more aggressively in future rounds
   
4. Pack 1 â†’ Pack 2 conversion highest for £100K+ investors
   â†’ Action: Segment Pack 1 by ticket size in Growth Capital round

NEXT STEPS:
â”œâ”€ Growth Capital Round (Q2 2026): 50+ investors targeted
â”œâ”€ Founding Investor onboarding: White-glove setup + Q4 2025 reporting
â”œâ”€ Platform development: Syndicate mechanics live by Q1 2026
â””â”€ Series A preparation: Begin institutional investor cultivation

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
```

---

## Part 15: Founding Investor Onboarding (Post-Instant Investment)

### Week 1 Post-Instant Investment: Welcome Flow

**Day 1 (Instant Investment signed):**
- Automated confirmation email + PDF receipt
- Invoice for EIS submission (if applicable)
- Founder welcome call scheduled for Day 2

**Day 2:**
- Tom hosts 30-min "Founding Investor Welcome" call
- Topics: What's next (EIS process, platform access, syndicate roadmap)
- Investor receives: Onboarding kit, platform login, syndicate calendar

**Days 3–7:**
- White-glove onboarding (1-on-1 platform setup)
- Founding investor Slack/WhatsApp group added
- syndicate priority access shared
- Monthly reporting cadence confirmed (last Friday of each month)

---

### Quarterly Reporting (Post-Launch)

**Q1 2026, Q2 2026, Q3 2026, Q4 2026:**
- User growth metrics (free â†’ paid conversion)
- Syndicate deployment updates (capital raised, deal flow)
- Product roadmap progress (features launched)
- Financial runway + Series A prep status
- Founder updates (wins, challenges, asks)

**Founding Investor perks locked in:**
- Lifetime premium access (no subscription fees ever)
- Priority syndicate allocation (first 48 hours to commit)
- Quarterly investor dinners (network building)
- Roadmap influence (quarterly voting on features)
- Exit preference (pro-rata rights on Series A, favorable liquidation preferences)

---

## Part 16: Quick Reference Checklists

### Pre-Campaign Launch Checklist
- [ ] Aircall phone lines configured + agents onboarded
- [ ] Pipedrive CRM setup complete (custom fields, workflows, integrations)
- [ ] 30,000 investor records imported + tiered + segmented
- [ ] 16-step call script embedded in Aircall interface
- [ ] Agent training completed (3 mock calls + certification per agent)
- [ ] Pack 1 + Pack 2 finalized + ready to send
- [ ] Email templates created (5 sequence emails)
- [ ] Legal/compliance reviewed (GDPR, TCPA, disclaimers)
- [ ] Dashboard + reporting configured (daily/weekly metrics)

### Daily Agent Checklist (Before First Call)
- [ ] Aircall phone tested (can make/receive calls)
- [ ] Pipedrive open + investor record loaded on screen
- [ ] 16-step script visible as sidebar or notes
- [ ] Call recorder enabled
- [ ] Email templates loaded and ready
- [ ] Objection handling sheet printed nearby
- [ ] Demo booking calendar visible
- [ ] "Capital at risk" disclosure ready to deliver

### Weekly Team Checklist
- [ ] Monday 9 AM: Team standup (review metrics, celebrate wins)
- [ ] Wednesday 2 PM: Agent coaching (listen to 2 calls, provide feedback)
- [ ] Friday 4 PM: Weekly huddle (cumulative review, weekend prep)
- [ ] Pipedrive dashboard updated (conversions, revenue forecast, red flags)
- [ ] Aircall recordings reviewed (quality + compliance spot-check)
- [ ] Email sequences sent on schedule

### Post-Instant Investment Checklist (For Each Investor)
- [ ] Confirmation email + PDF receipt sent
- [ ] EIS submission process initiated
- [ ] Founder welcome call scheduled (Day 2)
- [ ] Platform access provisioned (login + password sent)
- [ ] Slack/WhatsApp group added
- [ ] Monthly reporting cadence added to calendar
- [ ] Founding investor benefits summary sent
- [ ] Next syndicate opportunity preview shared

---

## Appendix: Template Assets (Ready to Customize)

### Email Template 1: Initial Outreach

```
Subject: [Name], quick idea for your portfolio

Hi [Name],

Hope you're well. I'm Tom from Unlock — a new investment 
intelligence platform for private investors like yourself.

The reason I'm reaching out: We help investors understand 
their full portfolio exposure (taxes, risk, opportunities) 
— especially around EIS/SEIS opportunities most people miss.

20-minute call to see if it's relevant? If not, no worries.

Tom
Unlock
tom@unlockdd.com
+44 [PHONE]
```

---

### Email Template 2: Pack 1 Follow-Up

```
Subject: Your [Persona] investment profile – Unlock overview

Hi [Name],

Following our demo yesterday, attached is an overview of 
how Unlock works specifically for [PERSONA] investors like you.

It covers:
- How the platform simulates different scenarios
- Founding investor benefits (lifetime access, priority syndicates)
- Why now: scarcity + timing

Quick read (5 pages, 8 min).

Let's hop on a quick call [DATE] to discuss any questions?

Best,
Tom
```

---

### Email Template 3: Pack 2 Invitation

```
Subject: Ready to dive deep? Full investment details

Hi [Name],

You've reviewed our overview. Now, here's the full transparency.

Pack 2 includes:
- Complete investment terms & Instant Investment mechanics
- Valuation framework + sensitivity analysis
- 2026–2029 financial projections
- Exit strategy (M&A, IPO, PE pathways)
- Full EIS/SEIS process + tax relief calculations

This is typically something you'd review with your accountant.
Happy to facilitate a call with your advisor if helpful.

Next step: Schedule a 30-min call once you've reviewed with 
your team.

Best,
Tom
```

---

### Email Template 4: Instant Investment Close Push

```
Subject: Last call: Founding investor benefits expire Dec 31

Hi [Name],

Appreciating your interest in Unlock. Want to flag: the 
founding investor offer (lifetime access + priority syndicates) 
expires end of year.

After Q1 2026, Growth Capital investors won't receive these 
permanent benefits.

Also: EIS submission window closes [DATE]. After that, HMRC 
processing adds 4+ weeks to your relief claim.

If you'd like to move forward, let's get Instant Investment signed by [DATE].

Happy to discuss any final questions.

Best,
Tom
```

---

### Pipedrive Email Sequence (Automated)

**Trigger:** Pack 1 sent

Delay 3 days â†’ Email 2 (light touch-base)
Delay 1 day (total 4) â†’ Email 3 (24-hour reminder before call)
If no response after call â†’ Delay 2 days â†’ Email 4 (Pack 2 offer)
If Pack 1 not opened after 7 days â†’ Phone call reminder (agent dials)

---

## Final Summary: 8-Week Execution Roadmap

```
WEEK 1–2: Tier 1 Blitz
â”œâ”€ 300 calls
â”œâ”€ 75 demos booked
â”œâ”€ 25 demos completed
â””â”€ 12 Pack 1 sent

WEEK 3–4: Tier 1 Follow-Up + Tier 2 Ramp
â”œâ”€ 450 calls (Tier 1 follow-ups + Tier 2 new)
â”œâ”€ 50–70 new Tier 2 demos booked
â”œâ”€ 40 demos completed
â””â”€ 20 Pack 1 sent, 4 Pack 2 sent

WEEK 5–6: Tier 2 Ramp + Demo Surge (Holiday Season)
â”œâ”€ 250 calls (lighter due to holidays)
â”œâ”€ 40–50 demos completed
â”œâ”€ 15 Pack 1 sent
â””â”€ 8 Pack 2 sent, 1–2 Instant Investment signed

WEEK 7–8: Close Focus (New Year)
â”œâ”€ 200 calls (lighter due to holidays)
â”œâ”€ 20 demos completed
â”œâ”€ 5–10 Pack 2 sent
â””â”€ 5–10 Instant Investment signed

CUMULATIVE TARGETS:
â”œâ”€ 1,200–1,500 calls dialed
â”œâ”€ 200–250 demos completed
â”œâ”€ 80–120 Pack 1 sent
â”œâ”€ 30–50 Pack 2 sent
â”œâ”€ 20–25 Instant Investment signed
â””â”€ £1.2M capital raised (22 founding investors)

FOUNDING INVESTOR ONBOARDING:
â”œâ”€ Week 1–2: White-glove setup
â”œâ”€ Week 3+: Monthly reporting + syndicate access
â””â”€ Lifetime benefits locked in (access, priority, roadmap influence)
```

---

**This plan is ready to execute immediately.**

**Next action:** Tom to run first 5 calibration calls Tuesday, March 17  9 AM.

---

**End of Execution Plan**
