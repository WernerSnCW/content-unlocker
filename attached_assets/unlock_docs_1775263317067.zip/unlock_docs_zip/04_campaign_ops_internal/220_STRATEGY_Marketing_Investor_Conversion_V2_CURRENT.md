> **V4 NOTE — INTERNAL USE ONLY:** Updated March 2026. All investment instrument references use "Instant Investment". Discount tier percentages removed from this document per V4 rules (never publish specific tiers). Q1 2026 dates updated to Q1 2027.

# Unlock: Marketing & Investor Conversion Strategy Brief

**Strategic Consolidation for Document & Campaign Development**

---

## Executive Overview

Unlock is positioning itself as the independent, investor-first alternative to fragmented wealth management and product-driven platforms. This brief consolidates your 14+ investor documents into a coherent marketing and conversion framework, with specific guidance on document sequencing, messaging, and investor journey mapping.

**Core Mission**: Give private investors the same clarity, tools, and protections that institutions take for granted.

---

## Part 1: Investor Audience Architecture

### Three Core Investor Personas (Behavioral)

These are NOT generic risk bucketsâ€”they're research-backed archetypes derived from actual investor behavior, portfolios, and goals.

**1. The Preserver**
- *Motivation*: Protect wealth and minimize downside
- *Behaviors*: Low-volatility portfolios, capital protection focus, seeks validation for advisor recommendations
- *Pain Points*: Fragmented tools, poor downside modeling, conflicted advice
- *Platform Use*: Tests defensive strategies, confirms risk controls
- *Belief Shift Required*: Understands fragmentation is a big problem â†’ trusts Unlock as independent safeguard

**2. The Growth Seeker**
- *Motivation*: Long-term wealth growth with calculated risk
- *Behaviors*: Seeks high-growth opportunities, wants risk-managed entry, values portfolio simulation
- *Pain Points*: Lack of transparency in deals, retail-focused tools, dilution in crowdfunding
- *Platform Use*: Compares upside vs downside, explores syndicate opportunities
- *Belief Shift Required*: Recognizes Unlock's differentiation â†’ believes platform scales to deliver long-term value

**3. The Legacy Builder**
- *Motivation*: Plan intergenerational wealth transfers and tax efficiency
- *Behaviors*: Estate planning focus, balances growth with inheritance tax efficiency, models family scenarios
- *Pain Points*: Complexity of tax planning, lack of clarity in family wealth scenarios
- *Platform Use*: Models EIS/SEIS tax advantages, explores intergenerational structures
- *Belief Shift Required*: Accepts timing matters for wealth structuring â†’ trusts Unlock for analysis + tax tools

**Important**: Unlock has mapped 19 detailed personas across wealth tiers, risk profiles, investment approaches, and domain biases (property, tech, alts). These three archetypes are the public-facing frame; the 19 personas power product personalization and roadmap decisions.

### Investor Ticket Sizes & Readiness Levels

**Founding Investor Round (Current)**
- Target: Â£20Kâ€“Â£500K tickets
- Profile: Strategic HNW investors (Â£500Kâ€“Â£5M investable assets)
- Readiness: Active in EIS/SEIS, network-oriented, customer-development aligned
- Discount: Up to 50% (tiered by ticket size)
- Benefits: Lifetime premium access, white-glove service, priority deal flow, roadmap influence

**Growth Capital Round (Q2 2026)**
- Target: Â£50Kâ€“Â£500K tickets
- Profile: Growth-focused investors comfortable with scaling risk
- Readiness: FinTech/AI/RegTech experience, capable of customer acquisition support
- Discount: 10â€“20% (limited early-bird offers)
- Benefits: 2-year complimentary access, quarterly updates, syndication access

**Series A (Q1 2027)**
- Target: Â£250Kâ€“Â£2M tickets
- Profile: Institutional investors, board-ready
- Discount: None (priced round)
- Benefits: Board participation, strategic guidance, exit planning

---

## Part 2: The Marketing Funnel & Belief Stages

### Investor Journey Map: 4 Stages

**Stage 1: AWARENESS**
*Goal*: Generate initial interest and qualify fit
*Key Belief*: "There IS a big problem in wealth planning"

*Marketing Channel Examples*:
- Curated HNW networks (proprietary databases)
- PR/earned media (FT, City A.M., MoneyWeek)
- Thought leadership content (Substack, white papers)
- Targeted LinkedIn outreach
- Founder-hosted investor dinners

*Messaging Focus*:
- Problem statement: fragmentation, complexity, conflicted incentives
- Vision: levelling the playing field
- Proof: customer traction (2,500 free users, Â£172K run rate, founding investor commitments)

*Documents to Share*:
- Executive Summary (1 page)
- Investment Pitch (3â€“4 pages, presentation-ready)

---

**Stage 2: ENGAGEMENT**
*Goal*: Qualify interest and build credibility
*Key Belief*: "Unlock offers a credible, differentiated solution"

*Activities*:
- Personalized demo sessions (live or recorded)
- Custom portfolio modelling (white-glove onboarding trial)
- One-on-one founder conversations
- Investor workshop participation (co-creation feedback)
- Competitive landscape positioning

*Messaging Focus*:
- Institutional-grade tools + investor simplicity
- Independent, investor-led design (NOT product distribution)
- Customer-validated traction (alpha MVP, founding investor commitments)
- Team credibility and execution track record

*Documents to Share*:
- Full Business Plan (with financials)
- Competitive Analysis (positioning vs crowdfunding, robo-advisors, private banks)
- Marketing Strategy (network-driven growth funnel)
- Customer Development Profiles (investor personas + belief shifts)
- Value Proposition Canvas (pain/gain fit)
- Gap Fill Addendum (team bios, governance model, unit economics, feature set)
- App Walkthrough Script (product narrative + capabilities demo)

---

**Stage 3: DECISION**
*Goal*: Support commitment decision
*Key Belief*: "The strategy is investor-led. The team can execute. Returns justify the risk."

*Activities*:
- Detailed financial review (projections, unit economics, break-even)
- Legal/tax consultation prep (EIS/SEIS worked examples)
- Allocation planning (ticket size, discount tier, relief calculation)
- Soft commitment + allocation reservation
- Risk disclosure deep dive

*Messaging Focus*:
- Financial transparency: Â£6.5M valuation benchmarked against SaaS peers
- Sensitivity analysis: base (7.7x), upside (15x+), downside (3â€“5x)
- EIS/SEIS mechanics: 30â€“50% relief, inheritance tax benefits, HMRC timelines
- Scarcity: 25 founding slots (3 closed, 2 committed, 20 available)
- Urgency: EIS submission window timing, pre-launch benefits expire Q1 2027

*Documents to Share*:
- Investor Information Memorandum / Pack 2 (20â€“30 pages + appendices)
  - Full investment terms & Instant Investment mechanics
  - Valuation framework + sensitivity scenarios
  - Financial projections (2026â€“2029)
  - Go-to-market & growth strategy (full)
  - Exit strategy (named acquirers, IPO milestones, timeline)
  - Appendices: business plan, valuation paper, tax landscape, risk factors

---

**Stage 4: COMMITMENT & ONBOARDING**
*Goal*: Formalize investment and activate founding investor status
*Key Belief*: "I'm part of shaping the future of UK investing"

*Activities*:
- Instant Investment agreement execution (via SeedLegals)
- EIS/SEIS submission process
- Investor onboarding kit (platform access setup)
- Founding investor perks activation (white-glove service, concierge, roadmap access)
- Quarterly reporting cadence

*Messaging Focus*:
- Lifetime membership benefits locked in
- Direct founder/product team access
- Syndicate priority allocation
- Investor network events
- Product roadmap influence opportunities

*Documents to Share*:
- Instant Investment Terms (with worked examples)
- Investor Onboarding Kit (EIS/SEIS guidance, tax relief tracker)
- Founding Investor Pack (reassurance + benefit activation)
- Investor Reporting Templates (syndicate updates, dashboard access)

---

## Part 3: Document Architecture & Sequencing

### **Pack 1: Founding Investor Pack (Entry-Level, Persuasion-First)**

**Purpose**: Excite, persuade, establish exclusivity  
**Tone**: Emotional, benefits-led, accessible  
**Length**: 8â€“10 pages

**Contents**:
1. Welcome & Context (vision, emotional positioning)
2. Deal Basics (Headline: Â£6.5M pre-money, up to 50% discount)
3. EIS/SEIS Benefits (30â€“50% relief, 4-week HMRC payout, no worked examples)
4. Early Investor Perks (lifetime access, white-glove service, priority deal flow, events)
5. Investor Personas (Preserver, Growth Seeker, Legacy Builder + "19 mapped personas" mention)
6. Go-To-Market (Timeline visual: 2026 â†’ free launch, 2027 â†’ paid, 2028+ â†’ international)
7. Exit Strategy Headline (M&A, IPO, PE; 5â€“10x returns in 3â€“5 years)
8. Scarcity & Urgency (25 slots, pre-launch benefits, EIS submission window)
9. Appendices (Light): FAQ, high-level risk disclaimer

**Key Cross-References**: "Full details in the attached Investor Information Memorandum"

---

### **Pack 2: Investor Information Memorandum (Deep Dive, Due Diligence)**

**Purpose**: Full transparency; satisfy financial, legal, technical scrutiny  
**Tone**: Factual, precise, disclosure-first  
**Length**: 20â€“30 pages + appendices

**Contents**:
1. Welcome & Purpose (sets expectation: technical breakdown)
2. Investment Terms & Structure (Full)
   - Instant Investment mechanics (conversion, dilution, non-dilutive structure)
   - Legal framework (SeedLegals, FCA-aligned)
   - Discount: Negotiated individually (never published in documents)
   - EIS/SEIS process: quarterly vs >Â£20K immediate, loss relief, inheritance tax
   - Cross-reference: "Headline benefits in Pack 1; full process + examples here"

3. Valuation & Returns Framework
   - Market comparables (SaaS seed valuations Â£5â€“8M; Unlock @ Â£6.5M)
   - Sensitivity scenarios (base/upside/downside with exit multiples)
   - Cap table illustrations
   - ROI worked examples (£50k, £250k, £500k tickets at founding investor discount)
   - Cross-reference: "Headline valuation in Pack 1; detailed benchmarking here"

4. Financial Projections (Full)
   - 2026â€“2029 revenues, user growth, CAC/LTV, margins
   - Break-even analysis
   - Churn assumptions + unit economics detail

5. Go-To-Market & Growth Strategy (Full)
   - Acquisition channels (database, OneAI, media partnerships)
   - Sales funnel (cold call â†’ demo â†’ portfolio report â†’ close)
   - International rollout detail (Australia, Canada, US)

6. Exit Strategy (Full)
   - Named acquirers (Bloomberg, Morningstar, Refinitiv, Crowdcube, S&P Global)
   - IPO milestones (Â£20M+ ARR, 10k+ subscribers)
   - PE buyout pathway
   - Timeline milestones (Yr2: Â£20â€“30M valuation; Yr3: Â£50â€“70M; Yr4â€“5: Â£100M+)

7. Appendices (Full Transparency)
   - Business plan (full)
   - Valuation paper
   - Exit strategy (detailed)
   - UK tax-advantaged investment landscape
   - Investor personas & suitability mapping
   - Risk factors (market, regulatory, operational)
   - Full Instant Investment template
   - Competitive benchmarking

8. Closing Statement (scarcity, urgency, call to action)

---

### **Supporting Documents (Distribution by Stage)**

**Stage 1 (Awareness)**:
- Executive Summary
- Investment Pitch

**Stage 2 (Engagement)**:
- Business Plan (full narrative + financials)
- Competitive Analysis
- Marketing Strategy
- Customer Development Profiles
- Value Proposition Canvas
- Gap Fill Addendum (team, governance, unit economics)
- App Walkthrough Script

**Stage 3 (Decision)**:
- Pack 2: Investor Information Memorandum
- Financial Model & Projections (detailed)
- Growth Capital Pack (bridging narrative)

**Stage 4 (Commitment)**:
- Instant Investment Terms (from Pack 2)
- Investor Onboarding Kit
- Investor Reporting Templates

---

## Part 4: Key Messaging Pillars

### Problem Statement (Differentiator)
**"Private investors face three persistent challenges:"**

1. **Fragmented data** â€” across providers, advisors, manual systems
2. **Inaccessible complexity** â€” professional-grade analysis locked behind institutional paywalls
3. **Conflicted incentives** â€” platforms optimize for product sales, not investor outcomes

*Impact*: Most investors rely on spreadsheets, Google, and gut instinct while institutions have models, dashboards, teams.

---

### Solution Narrative (Value Proposition)
**"Unlock combines institutional-grade tools with investor-led simplicity"**

- **Portfolio Simulator** â€” stress-test and optimize portfolios with personalized "what-if" scenarios
- **Investor Personas** â€” Preserver, Growth Seeker, Legacy Builder archetypes guide strategy
- **Syndicates** â€” access vetted collective opportunities on transparent, fair terms (8â€“10% vs 9â€“14% market norm)
- **Tax Intelligence** â€” EIS/SEIS optimization + CGT deferral + inheritance tax planning
- **Independent Analytics** â€” institutional insights, not product distribution

---

### Why Now (Market Timing)
1. **Technology shift**: AI enables investor-grade simulations at consumer cost
2. **Market gap**: No independent investor-first platform at this level exists
3. **Policy tailwinds**: UK EIS/SEIS incentives make early-stage investing highly attractive
4. **Customer demand**: Alpha MVP attracting serious investor feedback and commitments

---

### Business Model & Scale (Financial Proof)
- **Revenue streams**: Premium subscriptions + syndicate transaction fees (8â€“10%) + strategic partnerships
- **2026**: Â£460K (beta testing, early syndicates)
- **2027**: Â£2.6M (public launch, scale)
- **2028**: Â£5M (strong growth trajectory)
- **2029**: Â£8.25â€“9.25M (mature ARR, syndicate expansion)

**Unit Economics**:
- CAC (paid user): ~Â£200
- LTV (paid user): Â£3,000â€“3,250
- LTV:CAC ratio: 15:1 (highly efficient)
- SaaS gross margin: ~80%
- Break-even achievable with modest HNW market penetration

---

### Exit & Returns (Investor Motivation)
- **5â€“10x returns expected within 3â€“5 years**
- **Strategic M&A**: Bloomberg, Morningstar, Refinitiv, Crowdcube (strategic fit for fintech/wealth managers)
- **IPO pathway**: Viable at Â£20M+ ARR + 10k+ subscribers
- **Timeline**: Year 2 (Â£20â€“30M valuation), Year 3 (Â£50â€“70M), Year 4â€“5 (Â£100M+, exit readiness)

**Illustrative ROI**:
- Â£500k invested at founding investor discount (illustrative):
  - ~Â£9.96M return at Â£50M exit (19.9x ROI)
  - ~Â£19.9M return at Â£100M exit (39.8x ROI)
  - ~Â£3.98M return at Â£20M exit (7.9x ROI)
  - *(All before SEIS/SEIS relief, which improves effective ROI further)*

---

## Part 5: The Dual-Pack Distribution Strategy

### Distribution Logic

**Pack 1 (Founding Investor Pack)** is the "lead magnet" designed to:
- Hook with emotional, benefits-led messaging
- Establish scarcity and urgency
- Create FOMO around founding investor status
- Transition warm leads to Stage 2 (engagement)

**Pack 2 (Investor Information Memorandum)** is the "trust builder" designed to:
- Provide full financial, legal, and technical transparency
- Answer due diligence questions comprehensively
- Address investor skepticism through detailed benchmarking and sensitivity analysis
- Enable informed decision-making for Stage 3 (decision) investors

### Key De-Duplication Rules

Where content must overlap (valuation, EIS, exit), **shift the depth and framing**:

**Valuation Example**:
- Pack 1: "£6.5M pre-money valuation. Founding investor discount negotiated individually."
- Pack 2: "Â£6.5M pre-money valuation benchmarked against SaaS comparables (Â£5â€“8M range); sensitivity analysis Â£4â€“10M; illustrative ROI models for different ticket sizes and exit scenarios"

**EIS Example**:
- Pack 1: "30â€“50% income tax relief, HMRC payout in ~4 weeks, inheritance tax benefits"
- Pack 2: "EIS/SEIS process explained: quarterly submission for most investors, immediate submission for >Â£20K commitments; loss relief cushions downside; inheritance tax exemption after 2 years; worked examples + tax relief calculator"

**Exit Example**:
- Pack 1: "Multiple exit pathways (M&A, IPO, PE); 5â€“10x returns within 3â€“5 years"
- Pack 2: "Named strategic acquirers (Bloomberg, Morningstar, Refinitiv, Crowdcube); IPO pathway at Â£20M+ ARR; detailed timeline: Yr2 (Â£20â€“30M), Yr3 (Â£50â€“70M), Yr4â€“5 (Â£100M+)"

---

## Part 6: Campaign Calendar & Channel Strategy

### Core Acquisition Channels

**1. Proprietary HNW Database (25,000+ investor profiles)**
- Direct outreach via cold call/email â†’ personalized portfolio demo
- Segmentation by persona type (Preserver, Growth Seeker, Legacy Builder)
- Calendar: Ongoing during founding round

**2. AI-Powered Qualification (OneAI)**
- Automated lead scoring and fit assessment
- Speeds qualification from awareness â†’ engagement
- Reduces sales friction for Stage 2 transition

**3. Content Marketing & Thought Leadership**
- White papers on wealth fragmentation and EIS/SEIS optimization
- Substack newsletter (investor intelligence, tax updates, market commentary)
- Case studies (founding investor testimonials, portfolio outcomes)
- SEO: Blog on alternative investing, portfolio simulation, tax relief

**4. Media & PR Partnerships**
- FT, City A.M., MoneyWeek (editor outreach, guest articles)
- Investor podcast appearances
- Earned media around funding announcements

**5. Founder-Hosted Investor Events**
- Small, curated investor dinners (8â€“12 people)
- Hands-on platform demos + investor feedback loops
- Network-building (founder-to-founder, investor-to-investor referrals)
- Focus: Preserver and Growth Seeker personas

**6. Syndicate-Driven Referrals (Network Effects)**
- Founding investors introduce peers into opportunities
- Tiered referral benefits incentivize word-of-mouth
- Community-building around co-investment opportunities

### Campaign Rhythm

**Q4 2025** (Founding Investor Round - Active):
- Send Pack 1 â†’ warm leads (curated database)
- Demo â†’ personalized portfolio report
- Follow-up â†’ Pack 2 to qualified prospects
- Close â†’ Instant Investment execution + EIS submission

**Q1 2026** (Transition to Growth Capital):
- Lessons learned from Founding round
- Pack 1 refinement based on investor feedback
- Begin Growth Capital round positioning (new pack framework)

**Q2 2026+** (Growth Capital Round):
- Proven traction narrative (user milestones, revenue run rate)
- Institutional investor outreach
- Series A preparation underway

---

## Part 7: Success Metrics & KPIs

### Stage 1: Awareness
- **Outreach volume**: 500+ prospects contacted per month
- **Open rate**: Pack 1 email open rate target 35%+
- **Demo booking rate**: 15% of opened emails â†’ demo scheduled

### Stage 2: Engagement
- **Demo-to-Pack 2 conversion**: 40%+ of demo attendees request Pack 2
- **Engagement depth**: Time spent on platform demos, Q&A volume, persona quiz completion
- **Belief shift validation**: Investor feedback on problem statement and differentiation

### Stage 3: Decision
- **Pack 2 â†’ allocation target**: 30%+ of Pack 2 recipients move to decision stage
- **Average ticket size**: Â£75Kâ€“Â£150K (80% in Â£50â€“250K band)
- **Discount distribution**: Track average discount negotiated per investor (internal only)
- **EIS/SEIS uptake**: % of investors pursuing tax relief vs. standard allocation

### Stage 4: Commitment
- **Founding round close rate**: Target 20 investors across 25 slots (80% fill)
- **Total capital raised**: Â£1.2M target (Â£675K minimum to proceed)
- **Time-to-close**: Average days from first Pack 1 to Instant Investment execution
- **Repeat referrals**: Percentage of founding investors bringing peer recommendations

### Long-Term (Post-Founding Round)
- **Founding investor satisfaction**: NPS score, product usage, syndicate participation
- **Advocacy velocity**: Founding investor referrals as % of new leads
- **Platform traction**: User milestones (2.5K free â†’ 28K free by 2026; 375 paid â†’ 3.6K paid by 2027)
- **Revenue runway**: ARR trajectory vs. projections (2026: Â£460K target)

---

## Part 8: Risk Mitigation & Investor Concerns

### Common Objections & Responses

**"How is Unlock different from Crowdcube/Seedrs?"**
- Unlock = private investor platform + professional analytics
- Crowdcube = retail crowdfunding (high dilution, low tax efficiency)
- Response: Show fee comparison table (8â€“10% vs 9â€“14%) and EIS/SEIS integration

**"What's the market size and adoption curve?"**
- Global wealth management = $100T+ AUM
- Target: HNW investors with Â£1Mâ€“Â£10M portfolios
- Acquisition proof: 2.5K free users in alpha; projected 28K by 2026
- Response: Share customer development profiles + go-to-market channels

**"What if adoption is slower than forecast?"**
- Sensitivity analysis in Pack 2: base case (7.7x), downside (3â€“5x)
- Break-even achievable with modest HNW penetration
- Response: Show conservative scenario with reassurance on path to profitability

**"Why should I trust the founding team?"**
- Tom King: 12+ years in investor-introduction tech, Â£250M+ capital facilitated
- Werner Snyman: 19 years digital transformation at Nedbank
- William Corke: Multi-million-pound growth projects for F500 + compliance expertise
- Claudia Chavez: Commercial strategy in fintech partnerships
- Response: Share Gap Fill Addendum + founder track record

**"What about regulatory risk (FCA, EIS)?"**
- William Corke leading compliance + EIS/SEIS structuring
- Quarterly EIS submissions managed + HMRC certificates tracked
- Legal framework (SeedLegals, FCA-aligned documentation)
- Response: Highlight compliance expertise in team bios + risk factor disclosure

---

## Part 9: Content Calendar (Quarterly)

### Q4 2025 (Founding Investor Push)
- **Week 1â€“2**: Pack 1 outreach to top 200 prospects (warm introduction emails)
- **Week 3â€“4**: Demo sessions + personalized portfolio reports
- **Week 5â€“8**: Pack 2 distribution to qualified leads + legal/tax consultation prep
- **Week 9â€“12**: Instant Investment closings + EIS submissions + investor onboarding
- **Content**: Founder blog on "The Case for Independent Investing"; Case study on alpha MVP traction

### Q1 2026 (Growth Capital Preparation)
- **Content**: "Founding Investor Success Stories" (testimonials + portfolio outcomes)
- **Event**: Founder investor dinner (Q4 attendees + new referrals)
- **Refinement**: Pack 1 v2 based on Stage 2 feedback; begin Growth Capital pack framework
- **Outreach**: Institutional investor qualification (VCs, family offices, growth funds)

### Q2 2026 (Growth Capital Round Launch)
- **Pack Development**: Growth Capital Pack 1 & 2 (proven traction narrative)
- **Messaging**: "We hit our milestonesâ€”here's what comes next"
- **Content**: Deep dive on user acquisition strategy, syndicate framework, international prep
- **Events**: Investor webinar + one-on-one partnerships meetings

### Q3â€“Q4 2026 (Pre-Series A Positioning)
- **Content**: Thought leadership on market gaps and competitive advantages
- **Partnerships**: Media co-marketing (FT, City A.M., MoneyWeek features)
- **Outreach**: Series A investor identification + warm introductions
- **Roadmap**: Product milestones + team expansion highlights

---

## Part 10: Key Takeaways & Next Steps

### For Marketing & Messaging:
1. **Lead with problem, not product** â€” fragmentation + conflicted incentives resonate across all personas
2. **Use personas to segment messaging** â€” Preserver emphasizes protection; Growth Seeker emphasizes opportunity; Legacy Builder emphasizes tax efficiency
3. **De-duplicate packs intentionally** â€” Pack 1 is persuasion, Pack 2 is precision. Different depth, different framing, no confusion
4. **Leverage community & network** â€” founding investors become evangelists; syndicate mechanics drive referrals
5. **Build urgency around SCARCITY** â€” 25 slots, EIS submission window, pre-launch benefits expiration

### For Investor Conversion:
1. **Stage 1 â†’ 2 transition**: Pack 1 â†’ warm demo â†’ personalized portfolio report
2. **Stage 2 â†’ 3 transition**: Engagement depth (product usage, founder access, belief validation) â†’ Pack 2 distribution
3. **Stage 3 â†’ 4 transition**: Financial clarity (valuation, EIS, exit scenarios) â†’ soft commitment â†’ Instant Investment execution
4. **Stage 4 activation**: White-glove onboarding + founding investor perks + quarterly updates

### For Document Development:
1. **Pack 1 finalization**: 8â€“10 pages, benefits-first, cross-reference to Pack 2 for detail
2. **Pack 2 finalization**: 20â€“30 pages + appendices, full transparency, disclosure-first, worked examples
3. **Supporting docs**: Keep modular (business plan, competitive analysis, personas, team bios) for Stage 2 deep dives
4. **Quality standard**: Professional design, consistent branding, hyperlinked cross-references

### Immediate Actions:
- [ ] Finalize Pack 1 (Founding Investor Pack) â€” 8â€“10 pages, benefits-led
- [ ] Finalize Pack 2 (Investor Information Memorandum) â€” 20â€“30 pages, full disclosure
- [ ] Create email templates for each stage (awareness, engagement, decision, commitment)
- [ ] Build outreach database segmentation (by persona, ticket size, industry)
- [ ] Schedule founder demos and investor dinners (Q4 2025)
- [ ] Establish KPI dashboard to track stage-by-stage conversion
- [ ] Set up quarterly reporting cadence for founding investors (post-close)

---

## Appendix: Document Status & File References

| Document | Stage | Status | Owner | Notes |
|----------|-------|--------|-------|-------|
| Pack 1: Founding Investor Pack | 1â€“2 | Draft | Marketing | 8â€“10 pages, benefits-led |
| Pack 2: Investor Information Memorandum | 2â€“3 | Draft | Finance/Legal | 20â€“30 pages + appendices |
| Executive Summary | 1 | Complete | Marketing | 1 page, presentation-ready |
| Investment Pitch | 1 | Complete | Marketing | 3â€“4 pages |
| Business Plan (Full) | 2 | Complete | Strategy | Narrative + financials |
| Competitive Analysis | 2 | Complete | Strategy | Positioning + benchmarking |
| Marketing Strategy | 2 | Complete | Marketing | Network-driven growth |
| Customer Development Profiles | 2 | Complete | Product | Three personas + belief shifts |
| Value Proposition Canvas | 2 | Complete | Product | Pain/gain fit framework |
| Gap Fill Addendum | 2 | Complete | Strategy | Team bios, governance, unit economics |
| App Walkthrough Script | 2 | Complete | Product | Product demo narrative |
| Financial Model & Projections | 3 | Complete | Finance | 2026â€“2029 projections |
| Growth Capital Pack | 3 | Template | Finance | For Q2 2026 round |
| Instant Investment Terms | 4 | Template | Legal | Via SeedLegals |
| Investor Onboarding Kit | 4 | Template | Operations | EIS/SEIS guidance + setup |
| Investor Reporting Templates | 4 | Template | Operations | Quarterly updates + dashboards |

---

**End of Brief**

*This consolidation is designed to be a working document for your marketing, sales, and investor relations teams. Use it to guide document development, campaign planning, and investor communications across all four stages of the funding journey.*
