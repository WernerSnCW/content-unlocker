> **V4 NOTE:** Updated March 2026. All pipeline stage names and email templates use "Instant Investment" not SAFE/ASA. Campaign dates updated to March 16, 2026 start.

# Pipedrive + Aircall Setup Guide for Unlock
## Complete Technical Configuration

**Objective:** Connect Aircall phone system to Pipedrive CRM so all calls auto-log, custom fields track investor stage, and workflows automate email sequences.

---

## Part A: Pipedrive Initial Setup

### Step 1: Create Your Five-Stage Pipeline

**Go to:** Settings â†’ Pipelines â†’ Add New Pipeline

**Pipeline Name:** "Unlock Founding Round"

**Stages (create in order):**

1. **Stage 1: Outreach Queued** (Pre-call)
   - Description: "Investor added to calling list, phone verified, tier assigned"
   - Color: Blue
   - Probability: 0% (not yet contacted)

2. **Stage 2: Called (Demo Booked)** (After call)
   - Description: "Call completed, demo booked or voicemail left"
   - Color: Yellow
   - Probability: 20% (early interest)

3. **Stage 3: Demo Scheduled** (Demo scheduled but not completed)
   - Description: "Video demo link sent, investor to join within 7 days"
   - Color: Orange
   - Probability: 40% (interested enough to attend)

4. **Stage 4: Demo Completed â†’ Pack 1 Sent** (Post-demo)
   - Description: "Demo delivered, Pack 1 sent, follow-up call scheduled"
   - Color: Purple
   - Probability: 60% (strong interest)

5. **Stage 5: Pack 1 â†’ Pack 2 (Decision Stage)** (Advanced stage)
   - Description: "Pack 2 sent, advisor loop initiated, Instant Investment targeting stage"
   - Color: Green
   - Probability: 75% (high-intent stage)

---

### Step 2: Add Custom Fields to Track Investor Journey

**Go to:** Settings â†’ Customize Fields â†’ Deals

**Add these fields (in order):**

| Field Name | Type | Values/Options | Required? | Notes |
|---|---|---|---|---|
| **Investor Tier** | Dropdown | Tier 1 / Tier 2 / Tier 3 | Yes | Determines dial priority |
| **Investor Persona** | Dropdown | Preserver / Growth Seeker / Legacy Builder | No (set after demo) | Drives personalized messaging |
| **EIS/SEIS Eligible** | Dropdown | Yes / No / Unknown | No | Compliance + tax positioning |
| **Portfolio Size (Estimate)** | Dropdown | <Â£250K / Â£250K-Â£1M / Â£1M-Â£5M / Â£5M+ | No | Ticket size prediction |
| **Phone Number** | Text | [auto-populated] | Yes | Aircall integration |
| **Email Address** | Email | [auto-populated] | Yes | For email sequences |
| **Call Outcome** | Dropdown | Demo Booked / Not Interested / Call Back Later / Wrong Number / Voicemail | Yes (after call) | Next action logic |
| **Aircall Call Recording** | URL | [auto-linked] | No (auto-populate) | Store recording link |
| **Aircall Call Duration (sec)** | Number | [auto-populate] | No | Track call length |
| **Demo Scheduled Date** | Date | [investor-provided] | No | Trigger reminders |
| **Demo Completed** | Checkbox | Yes/No | No | Workflow trigger |
| **Demo Feedback Score** | Dropdown | Very Interested (90-100) / Interested (70-89) / Neutral (50-69) / Lukewarm (30-49) / Not Interested (<30) | Yes (after demo) | Qualification gate |
| **Demo Feedback Notes** | Text | [Free-form] | No | Persona + objection details |
| **Pack 1 Sent Date** | Date | [auto-populate via workflow] | No | Track email deployment |
| **Pack 1 Opened** | Checkbox | Yes/No | No | Email tracking (if enabled) |
| **Pack 1 Response** | Dropdown | Enthusiastic / Interested / Lukewarm / Not Interested | No | Trigger Pack 2 logic |
| **Pack 2 Sent Date** | Date | [auto-populate] | No | Track escalation |
| **Pack 2 Opened** | Checkbox | Yes/No | No | Email tracking |
| **Advisor/Accountant Involved** | Checkbox | Yes/No | No | Due diligence readiness |
| **Expected Ticket Size** | Currency | Â£___ | No (estimate after Pack 2) | Sales forecasting |
| **Instant Investment Close Date (Target)** | Date | [assigned in Stage 4+] | No | Win planning |
| **Instant Investment Signed Date** | Date | [auto-populate on close] | No | Celebration + onboarding trigger |
| **Discount Negotiated** | Percentage | [Enter % agreed] | No (post-investment) | Internal tracking only — never shared with investors |
| **EIS/SEIS Submission Status** | Dropdown | Not Started / Pending / Submitted / Approved | No (post-investment) | Compliance tracking |
| **Founding Investor Status** | Dropdown | Committed / Pending / Not Pursuing | Yes | Final classification |

---

### Step 3: Configure Pipeline Automation (Workflows)

**Go to:** Settings â†’ Automation â†’ Workflows

**Workflow 1: Auto-Log Aircall Calls to Pipedrive**

- **Trigger:** New call in Aircall
- **Action:** Create deal in Pipedrive (Stage 1: Outreach Queued)
- **Details mapped:**
  - Caller: Tom/Agent Name
  - Phone: [From Aircall]
  - Call duration: [Auto-captured]
  - Recording link: [Auto-attached]
  - Timestamp: [Auto-set]

---

**Workflow 2: When Demo Booked â†’ Auto-Move to Stage 2 + Send Email**

- **Trigger:** Call Outcome = "Demo Booked"
- **Actions:**
  1. Move deal to Stage 2 (Called - Demo Booked)
  2. Send email: "Demo Confirmation â€“ Next Steps"
  3. Add task: "Send calendar invite + one-pager"
  4. Notify: Tom (internal note)

**Email template:**
```
Subject: Your Unlock Demo â€“ Confirmed

Hi [Investor Name],

Great news! Your demo is confirmed for [DATE/TIME] via Zoom.

Here's what to expect:
- 20-minute walkthrough of the Unlock platform
- Personalized portfolio simulation
- Q&A on investment strategy
- No advice givenâ€”just an introduction

ðŸ“Ž One-pager (attached) explains what we'll cover.

Link: [ZOOM_LINK]

See you then!
Tom
```

---

**Workflow 3: When Demo Completed + Feedback >70 â†’ Send Pack 1**

- **Trigger:** 
  - Demo Completed = Yes
  - Demo Feedback Score â‰¥ 70
- **Actions:**
  1. Move deal to Stage 4 (Demo Completed â†’ Pack 1 Sent)
  2. Send email: Pack 1 (Founding Investor Pack)
  3. Create task: "Follow-up call in 3 days"
  4. Send internal Slack notification

**Email template:**
```
Subject: Your Unlock Investor Overview â€“ [Persona Strategy]

Hi [Investor Name],

Following your demo, here's the complete Founding Investor overview 
tailored to your [PERSONA] profile.

ðŸ“Ž Pack 1 includes:
âœ“ Deal basics (Â£6.5M pre-money, up to 50% discount)
âœ“ EIS/SEIS benefits (30â€“50% relief, 4-week HMRC payout)
âœ“ Early investor perks (lifetime access, priority syndicates)
âœ“ 3 investor personas + your fit
âœ“ Go-to-market roadmap
âœ“ Exit strategy (5â€“10x in 3â€“5 years)

Quick read: 5 pages, 8 minutes.

Let's chat [DATE/TIME] to discuss questions?

Best,
Tom
```

---

**Workflow 4: When Pack 1 Response = Interested â†’ Auto-Send Pack 2**

- **Trigger:** Pack 1 Response = "Interested" or "Enthusiastic"
- **Actions:**
  1. Move deal to Stage 5 (Pack 1 â†’ Pack 2)
  2. Send email: Pack 2 (Investor Information Memorandum) with custom cover letter
  3. Create task: "Schedule Stage 3 deep-dive call (30 min)"
  4. Log in Slack: "New Pack 2 recipient: [Name] - [Persona]"

**Email template:**
```
Subject: Full Investment Details â€“ Pack 2 (Deep Dive)

Hi [Investor Name],

Ready to go deeper? Here's the full transparency.

ðŸ“Ž Pack 2 includes:
âœ“ Complete Instant Investment mechanics + worked examples
âœ“ Valuation framework + sensitivity analysis
âœ“ 2026â€“2029 financial projections
âœ“ Exit strategy (named acquirers, IPO milestones)
âœ“ EIS/SEIS tax relief walkthrough
âœ“ Risk factors + mitigation
âœ“ Full appendices (business plan, market analysis)

This is typically something you'd review with your accountant. 
Happy to facilitate a call if you'd like me to walk them through it.

Next step: Review with your team, then let's schedule a deep-dive 
call with you (and your advisor, if relevant).

Target: Instant Investment signature by [DATE] to lock in founding investor 
benefits.

Best,
Tom
```

---

**Workflow 5: When Instant Investment Signed â†’ Onboarding Flow**

- **Trigger:** Founding Investor Status = "Committed" (manually set upon Instant Investment signature)
- **Actions:**
  1. Move deal to Won (Close it)
  2. Update cumulative capital raised field
  3. Send email: Onboarding kit + founding investor perks summary
  4. Create task: "Schedule welcome call (Tom) for Day 2"
  5. Add investor to Slack group: #founding-investors
  6. Log in spreadsheet: Capital tracking + cap table
  7. Notify: Tom + CFO (revenue recognition)

**Email template:**
```
Subject: Welcome to Unlock â€“ Founding Investor Onboarding

Hi [Investor Name],

ðŸŽ‰ Instant Investment agreement signed! You're now an official Unlock Founding Investor.

Here's what's next:

âœ“ Onboarding kit (attached) â€” covers EIS process, platform setup, and current roadmap
âœ“ Platform access â€” login + password sent separately
âœ“ Founding investor Slack â€” join #founding-investors (private community)
âœ“ Welcome call â€” Tom calling tomorrow at [TIME]
âœ“ Q1 2026 syndicate preview â€” priority access to first deal flow

Your lifetime benefits are locked in:
â†’ Lifetime premium access (no subscription fees)
â†’ Priority syndicate allocation (first 48 hours)
â†’ Quarterly investor dinners
â†’ Roadmap influence (voting on features)

Questions? Reply to this email or call Tom directly: [PHONE]

Welcome to the founding investor family!

Best,
Tom
```

---

### Step 4: Set Up Email Templates (In Pipedrive)

**Go to:** Manage â†’ Email Templates

**Create 5 templates:**

1. **"Stage 1: Initial Demo Confirmation"**
   - Used when: Call Outcome = Demo Booked
   - Variables: [Name], [DateTime], [ZoomLink]

2. **"Stage 2: Pack 1 Follow-Up"**
   - Used when: Demo Completed + High Feedback
   - Variables: [Name], [Persona], [ScheduledCallDate]

3. **"Stage 3: Pack 2 Invitation"**
   - Used when: Pack 1 Response = Interested
   - Variables: [Name], [AdvisorOption], [SoftDeadline]

4. **"Stage 4: Instant Investment Close Push"**
   - Used when: Pack 2 viewed but no response after 5 days
   - Variables: [Name], [UrgencyDate], [ScarcityMessage]

5. **"Stage 5: Onboarding Kit"**
   - Used when: Instant Investment Signed
   - Variables: [Name], [EISProcess], [SlackLink], [WelcomeCallTime]

---

## Part B: Aircall Integration

### Step 1: Enable Aircall â†’ Pipedrive Webhook

**In Aircall:**
1. Go to Admin â†’ Integrations â†’ Pipedrive
2. Click "Connect"
3. Authorize Aircall to access your Pipedrive account
4. Select which phone line(s) to sync with Pipedrive
5. **Mapping settings:**
   - Incoming call â†’ Create deal in Pipedrive (if not exists)
   - Call data captured:
     - Caller phone number
     - Call duration
     - Call timestamp
     - Call recording link
     - Agent name
   - Auto-move to Stage 2 (Called) when call completes

---

### Step 2: Configure Agent Screen Pop

**In Aircall:**
1. Admin â†’ Phone Settings â†’ Screen Pop
2. Enable: "Display Pipedrive deal when call incoming"
3. Match on: Phone number
4. Display: Deal card (investor name, tier, persona, last note)

**What agent sees during call:**
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ INCOMING CALL: +44 20 XXXX XXXX            â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Investor Name: John Smith                  â”‚
â”‚ Tier: 1 | Persona: Growth Seeker           â”‚
â”‚ Portfolio: Â£1.2M | EIS Eligible: Yes       â”‚
â”‚ Last Note: "Interested in syndicates"      â”‚
â”‚ Call Duration: 6 min (ongoing)             â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ [MUTE] [HOLD] [TRANSFER] [RECORD]          â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

### Step 3: Aircall Call Disposition Codes

**In Aircall:** Admin â†’ Call Handling â†’ Disposition Codes

**Set up codes (agent selects at end of call):**

- **101** = Demo Booked (Move to Stage 2)
- **102** = Not Interested (Move to Lost, log as "No")
- **103** = Call Back Later (Move back to Stage 1, schedule callback)
- **104** = Wrong Number (Delete deal)
- **105** = Voicemail Left (Move to Stage 2, flag for follow-up)
- **106** = Interested, Send Info (Move to Stage 2, queue Pack 1)

**When agent selects code 101:**
```
Aircall asks: "What date/time for demo?"
Agent enters: [DATE/TIME]
Aircall auto-logs to Pipedrive â†’ Trigger Workflow 2 (confirmation email + calendar)
```

---

### Step 4: Call Recording Storage

**In Aircall:**
1. Admin â†’ Recording Settings â†’ Enable Recording
2. Storage: Cloud (Aircall servers)
3. Retention: 2 years
4. Disclosure: "This call may be recorded" â€” auto-played at call start

**In Pipedrive (Workflow):**
- Call recording automatically attached to deal record
- Accessible via custom field: [Aircall Call Recording] (URL link)
- Used for: Quality assurance, agent training, compliance

---

## Part C: Pipedrive Dashboard Setup

### Create Investor Campaign Dashboard

**Go to:** Reports â†’ Custom Dashboards â†’ New Dashboard

**Dashboard Title:** "Unlock Founding Round â€“ Live Campaign Tracker"

**Add 6 cards:**

---

**Card 1: Funnel Summary (Stacked Bar Chart)**

| Stage | Count | Conversion % |
|---|---|---|
| Outreach Queued | 1,500 | â€” |
| Called (Demo Booked) | 375 | 25% |
| Demo Completed â†’ Pack 1 | 200 | 53% |
| Pack 1 â†’ Pack 2 | 85 | 43% |
| Instant Investment Signed (Won) | 25 | 29% |

**Metric:** "Average conversion by stage"

---

**Card 2: Daily Call Volume (Line Chart)**

- X-axis: Date (Nov 18 â€“ Jan 13)
- Y-axis: Calls dialed per day
- Target line: 30 calls/day
- Actual: [Real-time from Aircall sync]

**Shows:** Are we meeting dial targets? Identify off days.

---

**Card 3: Capital Raised Progress (Gauge Chart)**

- Target: Â£1.2M
- Current: Â£[LIVE from SEIS/SEIS Signed deals]
- % to goal: [Auto-calculated]
- Color: Red (0â€“40%), Yellow (40â€“70%), Green (70â€“100%)

---

**Card 4: Demo Booking Rate (Metric Card)**

- Title: "Call â†’ Demo Booking Rate"
- Number: [% from (Called/Outreach Queued)]
- Benchmark: 25â€“35% target
- Color: Green if â‰¥25%, Yellow if 15â€“25%, Red if <15%

---

**Card 5: Investor Tier Breakdown (Pie Chart)**

- Tier 1: 300 (started Week 1)
- Tier 2: 600 (ramping Week 3+)
- Tier 3: 600 (exploratory)
- **Shows:** Which tier generating closes?

---

**Card 6: Avg Deal Size by Tier (Bar Chart)**

- Tier 1: Â£85,000 (higher tickets)
- Tier 2: Â£52,000 (mid-range)
- Tier 3: Â£32,000 (exploratory)

**Shows:** Which tier most valuable per close?

---

### Create Agent Performance Dashboard

**Go to:** Reports â†’ Custom Dashboards â†’ New Dashboard (Agent View)

**Dashboard Title:** "Agent Leaderboard â€“ [Date Range]"

**Add 4 cards:**

---

**Card 1: Calls Completed (Top Agent)**

| Agent | Calls | Demos Booked | Booking % | Pack 1 Sent | Instant Investment Closed |
|---|---|---|---|---|---|
| Tom | 180 | 45 | 25% | 20 | 12 |
| Agent 2 | 220 | 52 | 24% | 28 | 6 |
| Agent 3 | 185 | 42 | 23% | 16 | 4 |

**Sort by:** Calls completed (high to low)

---

**Card 2: Demo Booking Rate (Efficiency)**

| Agent | Booking % | Benchmark | Status |
|---|---|---|---|
| Agent 2 | 24% | 25% | âš  Slightly below target |
| Tom | 25% | 25% | âœ“ On target |
| Agent 3 | 23% | 25% | âš  Slightly below target |

**Insight:** Identify agent who needs coaching.

---

**Card 3: Instant Investment Close Rate (Effectiveness)**

| Agent | Pack 2s Sent | Instant Investments Closed | Close % |
|---|---|---|---|
| Tom | 12 | 12 | 100% â­ |
| Agent 2 | 28 | 6 | 21% |
| Agent 3 | 16 | 4 | 25% |

**Insight:** Tom closes best â†’ assign him to Stage 3 deep-dives.

---

**Card 4: Average Call Duration (Quality)**

| Agent | Avg Duration | Benchmark | Note |
|---|---|---|---|
| Tom | 8 min 42 sec | 8â€“10 min | Hitting 16-step script âœ“ |
| Agent 2 | 7 min 15 sec | 8â€“10 min | âš  Too short; rushing |
| Agent 3 | 9 min 30 sec | 8â€“10 min | âœ“ Good depth |

**Insight:** Agent 2 needs to slow down; more info-gathering.

---

## Part D: Contact Import & Database Setup

### Step 1: Prepare Your 30,000 Investor List

**CSV format (6 required columns):**

```
first_name,last_name,email,phone,tier,persona_estimate
John,Smith,john.smith@email.com,+44 20 XXXX XXXX,1,Growth Seeker
Jane,Doe,jane.doe@email.com,+44 121 XXXX XXXX,1,Preserver
David,Brown,david.brown@email.com,+44 161 XXXX XXXX,2,Legacy Builder
...
```

**Validation checks before import:**
- [ ] No duplicate phone numbers (flag duplicates)
- [ ] All phone numbers E.164 format (+44 + 10 digits)
- [ ] All emails valid (basic regex check)
- [ ] No missing first/last names
- [ ] Tier 1/2/3 assignments complete
- [ ] Persona estimates logical (based on portfolio history from your other platform)

---

### Step 2: Import to Pipedrive

**Go to:** Contacts â†’ Import Contacts

1. Upload CSV file
2. Map columns:
   - First Name â†’ [first_name]
   - Last Name â†’ [last_name]
   - Email â†’ [email]
   - Phone â†’ [phone]
   - Custom: Investor Tier â†’ [tier]
   - Custom: Investor Persona â†’ [persona_estimate]

3. On import completion:
   - Automatically create deals for each contact
   - Set all deals to Stage 1 (Outreach Queued)
   - Assign to agents (round-robin by tier)

---

### Step 3: Tier-Based Assignment

**In Pipedrive â†’ Manage â†’ Assign Deals:**

- **Tier 1 (300 contacts) â†’ Tom** (founder credibility + warmth)
- **Tier 2 (900 contacts) â†’ Agent 2 + Agent 3** (split evenly: Agent 2 = 450, Agent 3 = 450)
- **Tier 3 (800+ contacts) â†’ Agent 2 + Agent 3** (secondary list, dial after Tier 1/2 progressing)

**Why this assignment:**
- Tom on Tier 1 = warm + strategic (builds early momentum)
- Agents scale Tier 2 (volume dial + conversion)
- Tier 3 used to backfill if Tier 1/2 conversion slows

---

### Step 4: Set Up Calling Lists in Aircall

**In Aircall â†’ Campaign Manager:**

1. **Create Campaign 1: "Tier 1 Blitz"**
   - Contacts: 300 (from Pipedrive Tier 1)
   - Assigned to: Tom
   - Dial mode: Power dialer (auto-dial next contact when current call ends)
   - Agent: Tom
   - Hours: 9 AM â€“ 5 PM, Mondayâ€“Friday
   - Target: 30 calls/day

2. **Create Campaign 2: "Tier 2 Ramp"**
   - Contacts: 900 (Tier 2, from Pipedrive)
   - Assigned to: Agent 2 + Agent 3
   - Dial mode: Power dialer
   - Start date: Week 3 (Dec 2)
   - Target: 30 calls/day per agent

3. **Create Campaign 3: "Tier 3 Exploratory"**
   - Contacts: 800+ (Tier 3, from Pipedrive)
   - Assigned to: Agent 2 + Agent 3 (when Tier 1/2 progress slows)
   - Start date: Week 5 (Jan 1, post-holiday)
   - Target: 20 calls/day per agent

---

## Part E: Compliance & Legal Setup

### Step 1: GDPR Compliance

**In Pipedrive:**
- [ ] Add custom field: "Consent Type" (Existing customer / Warm intro / Cold outreach)
- [ ] Investors with "Cold outreach" = phone calls only (no SMS)
- [ ] Investors with "Existing customer" = phone + email + SMS allowed

**In Aircall:**
- [ ] Enable: "Consent recording disclosure"
- [ ] Auto-play at call start: "This call may be recorded for quality purposes. Do you consent?"
- [ ] If "No" â†’ auto-call termination + flag as "Did not consent"

**GDPR Data Retention:**
- Call recordings: Delete after 12 months (GDPR Article 5)
- Contact data: Retain as long as investor relationship active + 1 year after last interaction
- Deal records: Archive after 2 years (Instant Investment signed â†’ Series A â†’ exit)

---

### Step 2: FCA Compliance (No Advice Disclosure)

**In all emails:**
```
âš ï¸  IMPORTANT: Unlock provides investment intelligence platforms, 
not financial advice. Any introduction is for informational purposes 
only. You should not make any investment decision based on this 
communication without consulting a qualified financial advisor.

Capital at risk. No FSMA authorization. Past performance does not 
guarantee future results.
```

**In all Aircall calls:**
- [ ] Script includes: "This is an introduction, not advice. You should consult your advisor."
- [ ] Agent repeats before demo booking: "Capital at risk, no advice givenâ€”understood?"

---

### Step 3: EIS/SEIS Compliance

**Post-Instant Investment workflow:**
- [ ] Custom field: "EIS/SEIS Submission Status" (Not Started / Pending / Submitted / Approved)
- [ ] Task created: "EIS submission deadline: [DATE]"
- [ ] Investor receives: "EIS/SEIS Process" guide + tax relief calculator
- [ ] Accounting team follows up 2 weeks pre-deadline

---

## Part F: Testing & Quality Assurance

### Pre-Launch Checklist (48 hours before first call)

**Aircall Testing:**
- [ ] Make test call: Tom calls Agent 2, confirm call logs to Pipedrive
- [ ] Check: Call recording auto-uploads, metadata captured
- [ ] Check: Screen pop displays investor record on agent screen
- [ ] Check: Agent can select disposition code + see confirmation

**Pipedrive Testing:**
- [ ] Manually create test deal in Stage 1
- [ ] Trigger Workflow 1: Call recorded + auto-logs
- [ ] Trigger Workflow 2: Change Call Outcome to "Demo Booked" â†’ confirm email sent
- [ ] Trigger Workflow 3: Change Demo Feedback to 80 â†’ confirm Pack 1 sent
- [ ] Trigger Workflow 4: Change Pack 1 Response to "Interested" â†’ confirm Pack 2 sent

**Email Templates Testing:**
- [ ] Send test email for each template
- [ ] Verify: All [VARIABLES] populate correctly
- [ ] Verify: Links work (Zoom links, PDF attachments)
- [ ] Verify: Gmail/Outlook/Apple Mail rendering OK

**Database Testing:**
- [ ] Import 10 test records to Pipedrive
- [ ] Verify: Tier + Persona fields populated
- [ ] Verify: Deals created in Stage 1
- [ ] Verify: Deals assigned to correct agents

**Agent Training:**
- [ ] Tom completes 3 mock calls, records feedback
- [ ] Agent 2 completes 3 mock calls, records feedback
- [ ] Agent 3 completes 3 mock calls, records feedback
- [ ] All agents certify: "I understand the 16-step script and can execute it"

---

## Part G: Daily Operations Checklist

### Agent Daily Prep (Before 9 AM)

- [ ] Log into Aircall
- [ ] Log into Pipedrive
- [ ] Review today's calling list (Aircall Campaign Manager)
- [ ] Check for callbacks from yesterday (Pipedrive "Call Back Later" tasks)
- [ ] Verify: 16-step script visible (Aircall sidebar notes)
- [ ] Confirm: Email templates loaded (for Pack 1 sending)
- [ ] Test: 1 outbound call to self (verify recording, Pipedrive logging)

### Team Daily Standup (5:00 PM)

- [ ] **Tom:** Review day's calls, asks per agent (Tom leads)
- [ ] **Share wins:** "Agent 2 booked 5 demos todayâ€”what worked?"
- [ ] **Identify challenges:** "Demo booking rate at 22% today vs 25% targetâ€”why?"
- [ ] **Adjust next day:** "Agent 3 try adding [reframe] to Step 7 conversation"
- [ ] **Check dashboard:** Update Pipedrive campaign dashboard
- [ ] **Time:** 10 min max

### Weekly Metrics Review (Monday 9 AM)

- [ ] Pull Pipedrive report: Calls / Demos / Pack 1s / Pack 2s / Instant Investments
- [ ] Compare vs. targets (see Part 3: Weekly Targets)
- [ ] Identify red flags (demo booking <22%, Pack 1â†’2 <35%, etc.)
- [ ] Listen to 2â€“3 agent calls (quality check + coaching opportunity)
- [ ] Update agent leaderboard (celebrate top performer)

---

## Part H: Troubleshooting Guide

### "Aircall calls not appearing in Pipedrive"

1. Verify webhook enabled: Aircall Admin â†’ Integrations â†’ Pipedrive â†’ Connected âœ“
2. Check phone number format: Must be E.164 (+44 XXXX XXXX)
3. Verify deal creation rule: Settings â†’ Automation â†’ Workflows â†’ Check trigger
4. Test: Make 1 test call, verify Pipedrive deal created within 5 min
5. If still failing: Check API logs (Aircall Admin â†’ API Logs), contact support

---

### "Screen pop not displaying during call"

1. Verify setting enabled: Aircall Admin â†’ Phone Settings â†’ Screen Pop âœ“
2. Check match rule: Screen Pop set to match on "phone number" (not extension)
3. Verify contact phone exists in Pipedrive (exact match to call)
4. Clear browser cache, reload Aircall
5. If still failing: Upgrade Aircall plan (Screen Pop requires Professional+ tier)

---

### "Email template variables not populating"

1. Check variable syntax: Use [FirstName] not [first_name] or {{FirstName}}
2. Verify field exists in Pipedrive: Settings â†’ Customize Fields â†’ check field name
3. Verify field linked to email template: Template settings â†’ map fields
4. Send test email to yourself first (catches issues before investor sees)
5. If still failing: Switch to manual email (Tom types personalized message)

---

### "Workflow not triggering when conditions met"

1. Verify trigger condition exact: If workflow requires "Demo Feedback Score â‰¥ 70", confirm score is exactly 70+ (not 69)
2. Check: Are there multiple workflows with same trigger? (First one wins)
3. Verify: Deal has all required fields populated (workflow won't fire if missing)
4. Manual test: Manually change field to trigger value, confirm workflow fires
5. If still failing: Delete workflow, recreate it step-by-step

---

### "Agent can't see 16-step script during call"

1. Verify script loaded: Aircall â†’ Campaign Settings â†’ Agent Notes â†’ Paste 16-step script
2. Check: Is agent viewing Pipedrive deal card during call? (Script often there)
3. Alternative: Print 16-step script, tape to desk next to monitor
4. Use Aircall mobile app? (Scripts don't display well on phone)
5. Solution: Keep script on second monitor or printed page

---

## Appendix: Quick Reference Links

### Pipedrive Resources
- Integrations: app.pipedrive.com/admin/integrations
- Custom Fields: app.pipedrive.com/admin/customfields
- Workflows: app.pipedrive.com/admin/workflows
- Reports: app.pipedrive.com/reports
- Contacts: app.pipedrive.com/contacts

### Aircall Resources
- Admin Panel: aircall.io/app/admin
- Integrations: aircall.io/app/admin/integrations
- Campaign Manager: aircall.io/app/campaigns
- Call Recording: aircall.io/app/admin/recording
- Documentation: support.aircall.io

### Import Templates
- CSV import: [See Part D, Step 1]
- Workflow templates: [See Part A, Step 3]
- Email templates: [See Part C]

---

**This setup is ready to execute. All configurations are standard Pipedrive + Aircall features (no custom code required).**

**Total setup time: 4â€“6 hours (Pipedrive) + 2â€“3 hours (Aircall) + 1 hour (testing) = ~8 hours pre-launch.**

**Next action: Tom to schedule Pipedrive setup session with CRM admin (if you have one) or Aircall support. Otherwise, 1â€“2 day self-serve setup.**

---

**End of Setup Guide**
