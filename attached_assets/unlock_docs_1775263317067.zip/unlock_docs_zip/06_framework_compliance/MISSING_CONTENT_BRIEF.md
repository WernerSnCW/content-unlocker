# Unlock — Missing Content Brief
## What needs to be built | 2 April 2026

---

## Status Summary

| Category | Built & in package | Missing |
|---|---|---|
| Investor-facing send docs | 10 of 12 | 2 |
| Whitepapers | 0 of 4 | 4 |
| Technical specs | 1 of 2 | 1 (xlsx — not uploadable) |
| Internal ops docs | 4 of 6 | 2 (research source docs not uploaded) |
| Platform docs | 0 of 3 | 3 |

---

## Priority 1 — Needed This Week

### `196_MESSAGING_Post_April6_V1_DRAFT.md`
**What it is:** Urgency framing for after the April 6 tax year deadline passes. Replaces the current BPR/IHT/tax year deadline hook with: valuation step-up framing, Q1 2027 Series A trajectory, and the window before the Growth Capital round opens.

**Why urgent:** April 6 is in 4 days. Every investor-facing email and call script currently references the April 6 deadline as the primary urgency hook. Once it passes with no replacement messaging, agents have nothing to anchor to.

**Source material available:**
- Content Bank V4 (valuation, round timeline, Growth Capital round context)
- Marketing Strategy Brief (post-deadline messaging direction)
- Pack 1 (existing urgency framing to replace)

**Stage/persona relevance:** All stages, all personas. This replaces urgency hooks across the entire funnel.

**Generation test case:** This is the reference test case for the Content Generation & QC Engine (Stage 3). Building this first validates the full platform.

---

## Priority 2 — Needed Before Growth Capital Round (~8 weeks)

### `195_PROMO_Growth_Capital_Pack_V1_DRAFT.md`
**What it is:** Investor-facing pack for the Q2 2026 Growth Capital round. Equivalent function to the current Founding Investor three-pager (110) but positioned for the next raise stage: proven traction, expanded platform, Series A runway.

**Source material available:**
- Marketing Strategy Brief (Growth Capital round detail)
- Content Bank V4 (platform vision, product roadmap)
- Financial Model (not yet in project — needed before this can be fully built)

**Stage/persona relevance:** Outreach, Called — all personas.

**Blocker:** Financial Model projections not yet in the project library.

---

## Priority 3 — Platform Documentation (needed before any demo)

### `145_EXPLAINER_Decumulation_Planner_V1_DRAFT.md`
**What it is:** Investor-facing explainer for the Decumulation Planner feature. Currently referenced in demos but no standalone document exists. Must use exact compliance language: *"Specification complete. Prototype build commencing."*

**Source material available:**
- Decumulation Engine Spec V1.5 (400 — in package)
- Content Bank V4 (product status language)
- Pack 1 (existing product description sections)

**Stage/persona relevance:** Demo Complete, Decision — Preserver and Legacy Builder.

**Compliance constraint:** Must not describe the tool as live or available. Status language is fixed.

### Pitch Deck
**What it is:** No file exists anywhere in the project. Referenced in the index as needed but never built.

**Source material available:** All of it — Pack 1, Pack 2, Content Bank, Financial Model (when uploaded).

**Suggested structure:** Problem → Market → Solution → Product → Traction → Team → Round details → Ask.

**Blocker:** Requires Financial Model for traction/projection slides.

---

## Priority 4 — Whitepapers (medium priority, source material ready)

All four whitepapers have source material already in the project (300 and 310 research docs). None have been written. Ordered by likely conversion impact:

### `320_WHITEPAPER_IHT_Proof_Estate_Rolling_EIS_V1_DRAFT.md`
**Audience:** Legacy Builder — HNW investors with estate planning concerns
**Hook:** How a rolling EIS programme creates a compounding IHT-exempt estate over time
**Source:** IHT/EIS planning doc (170), Content Bank EIS/IHT sections, case studies (160)

### `340_WHITEPAPER_Pension_Problem_April2027_V1_DRAFT.md`
**Audience:** Preserver and Legacy Builder — anyone with significant pension assets
**Hook:** April 2027 pension IHT inclusion means the clock is running — what to do now
**Source:** Content Bank (pension IHT section), IHT planning doc (170)
**Compliance note:** Must carry "subject to final enactment" caveat throughout

### `330_WHITEPAPER_Advice_Gap_EIS_V1_DRAFT.md`
**Audience:** Cold HNW prospects — self-directed investors underserved by IFAs
**Hook:** Why IFAs can't help with EIS and what to do instead
**Source:** Content Bank (competitive analysis, IFA positioning), Access Explainer (140)

### `350_WHITEPAPER_Iran_Effect_Portfolio_Concentration_V1_DRAFT.md`
**Audience:** Cold HNW prospects — investors with concentrated tech/equity exposure
**Hook:** Geopolitical risk and portfolio concentration — why diversification into alternatives is now structural, not optional
**Source:** UK Investment Landscape (190), Content Bank

---

## Not Yet in Project Library (need uploading, not building)

| Document | Why it matters |
|---|---|
| Financial Model & Projections | Required for Pack 2 financial claims, pitch deck, Growth Capital pack. All financial figures in investor docs must trace to this. |
| Business Plan | Referenced in Pack 2 Appendix A. Needed for full due diligence pack. |
| Competitive Analysis | Referenced in Pack 2. Needed for SWOT and objection handling sections. |
| `300_RESEARCH_UK_Investment_Landscape_Source` | Source document for the 190 landscape report. Exists but not uploaded to this project. |
| `310_RESEARCH_Case_for_EIS_2026` | Source document for EIS case studies. Exists but not uploaded. |
| `410_SCHEMA_Information_V2` | 7-sheet information schema (xlsx). Exists but xlsx not uploadable to this project library. |

---

## What the Platform Can Generate (once Stage 3 is built)

The Content Generation & QC Engine can build any of the missing documents above, in order, using the source material already in this package. Suggested generation sequence:

1. `196` — Post-April 6 messaging (reference test case — do first)
2. `145` — Decumulation Planner explainer
3. `320` — IHT whitepaper
4. `340` — Pension Problem whitepaper
5. `330` — Advice Gap whitepaper
6. `350` — Iran Effect whitepaper
7. `195` — Growth Capital pack (after Financial Model is uploaded)

The pitch deck requires human judgment on structure and design — generation can produce a content draft but the deck itself needs a designer.

---

*Brief compiled: 2 April 2026 | Reference: 000_INDEX + 600_CHANGELOG + SBDS V2.1*
