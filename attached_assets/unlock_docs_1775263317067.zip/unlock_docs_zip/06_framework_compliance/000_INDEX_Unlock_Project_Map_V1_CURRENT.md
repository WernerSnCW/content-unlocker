# UNLOCK — PROJECT INDEX
## Navigation & Quick Reference | Version 1.0
**Last updated:** 14 March 2026 | **Campaign start:** 16 March 2026 | **April 6 deadline:** 23 days

---

## 🎯 PROJECT PURPOSE

Unlock is an investment intelligence platform for private investors managing £250K–£5M. This project covers the Founding Investor round: converting 25 investors from a 30,000-contact database into committed capital (£1.2M+) via systematic outreach — calls, demos, and a structured document pack sequence.

**Investment instrument:** Instant Investment (via SeedLegals)  
**Pre-money valuation:** £6.5M  
**Ticket range:** £20K–£500K  
**Key deadline:** April 6, 2026 (BPR/IHT rules change; tax year closes)

---

## 📁 FILE ORGANISATION

### 000–099: Navigation & System
| File | Purpose |
|---|---|
| `000_INDEX_Unlock_Project_Map_V1_CURRENT.md` | This file — master navigation |
| `010_INSTRUCTIONS_Agent_Brief_V1_CURRENT.md` | How to use this project; Claude session context |
| `020_GLOSSARY_Terms_V1_CURRENT.md` | Approved terminology; what to say / not say |
| `030_REGISTER_Document_Status_V1_CURRENT.md` | Version, status, and review schedule for every file |

### 100–199: Investor-Facing Send Documents
*These are the documents that go to investors. Every word matters.*

| File | Stage sent | Status |
|---|---|---|
| `100_PROMO_One_Page_V1_CURRENT.md` | Cold outreach / email attachment | ✅ Current |
| `110_PROMO_Founding_Investor_Three_Page_V1_CURRENT.md` | Cold outreach / forwardable | ✅ Current |
| `120_BRIEF_Pack1_Founding_Investor_V1_CURRENT.md` | Post-demo (Pack 1) | ✅ Current |
| `130_IIM_Pack2_Information_Memorandum_V1_CURRENT.md` | Qualified prospects (Pack 2) | ✅ Current |
| `140_EXPLAINER_Access_Service_V2_CURRENT.md` | Supplementary — Access service description | ✅ Current |
| `150_CASE_EIS_Investors_Secret_Weapon_V1_CURRENT.md` | Educational — cold HNW prospects | ✅ Current |
| `160_CASE_EIS_2026_Five_Case_Studies_V2_CURRENT.md` | EIS education with worked examples | ✅ Current |
| `170_PLANNING_IHT_EIS_5M_Estate_V4_CURRENT.md` | Legacy Builder persona — IHT planning | ✅ Current |
| `180_BRIEF_Duncan_Stewart_Bespoke_March2026_CURRENT.md` | Bespoke for Duncan Stewart call 30 Mar | ✅ Current |
| `190_LANDSCAPE_UK_Investment_2026_V1_CURRENT.md` | Long-form market report / lead magnet | ✅ Current |

**Planned (not yet built):**
| File | Purpose | Priority |
|---|---|---|
| `195_PROMO_Growth_Capital_Pack_V1_DRAFT.md` | Q2 2026 Growth Capital round documents | 🔴 High |
| `196_MESSAGING_Post_April6_V1_DRAFT.md` | Urgency framing after April 6 deadline passes | 🔴 High |

### 200–299: Campaign Operations (Internal Only — Never Share)
| File | Purpose | Status |
|---|---|---|
| `200_PLAN_Execution_30K_Database_V2_CURRENT.md` | Master campaign plan — DB tiers, pipeline, cadence | ✅ Current |
| `210_PIPELINE_Pipedrive_Aircall_Setup_V2_CURRENT.md` | CRM + call platform configuration | ✅ Current |
| `220_STRATEGY_Marketing_Investor_Conversion_V2_CURRENT.md` | Full marketing strategy — INTERNAL ONLY | ✅ Current |
| `230_EMAILS_Pack1_Templates_V2_CURRENT.txt` | Email templates for each pipeline stage | ✅ Current |

### 300–399: Research & Market Intelligence
| File | Purpose | Status |
|---|---|---|
| `300_RESEARCH_UK_Investment_Landscape_Source_V1_CURRENT.md` | Source document for 190_ send version | ✅ Current |
| `310_RESEARCH_Case_for_EIS_2026_V2_CURRENT.md` | EIS research and case studies source | ✅ Current |

**Planned whitepapers (source material exists, not yet written):**
| File | Audience | Priority |
|---|---|---|
| `320_WHITEPAPER_IHT_Proof_Estate_Rolling_EIS_V1_DRAFT.md` | Legacy Builder | 🟡 Medium |
| `330_WHITEPAPER_Advice_Gap_EIS_V1_DRAFT.md` | Cold HNW prospects | 🟡 Medium |
| `340_WHITEPAPER_Pension_Problem_April2027_V1_DRAFT.md` | Preserver / Legacy Builder | 🟡 Medium |
| `350_WHITEPAPER_Iran_Effect_Portfolio_Concentration_V1_DRAFT.md` | Cold HNW prospects | 🟡 Medium |

### 400–499: Technical Specifications
| File | Purpose | Status |
|---|---|---|
| `400_SPEC_Decumulation_Engine_V1_5_CURRENT.json` | Full technical spec — send to Werner | ✅ FINAL |
| `410_SCHEMA_Information_V2_CURRENT.xlsx` | 7-sheet information schema / propagation map | ✅ Current |

### 500–599: Agent Tools & Scripts
| File | Purpose | Status |
|---|---|---|
| `500_SCRIPT_Cold_Call_V1_CURRENT.md` | 9-section call script with qualification gates | ✅ Current |
| `510_PLAYBOOK_Agent_Training_V2_CURRENT.md` | 2-hour agent training programme | ✅ Current |
| `520_GUIDE_Investor_Personas_19_V1_CURRENT.md` | 19 personas — tier, signals, objections | ✅ Current |
| `530_CARD_Agent_Quick_Reference_V1_CURRENT.txt` | Print and tape to monitor | ✅ Current |

### 600–699: Compliance & Audit
| File | Purpose | Status |
|---|---|---|
| `600_CHANGELOG_Alignment_14Mar2026_CURRENT.md` | Full audit log — every change made 14 Mar 2026 | ✅ Current |
| `610_REGISTER_Document_Status_V1_CURRENT.md` | Live status register (mirrors 030_) | ✅ Current |

### 700–799: Source of Truth & Standards
| File | Purpose | Status |
|---|---|---|
| `700_CONTENT_Bank_V4_CURRENT.md` | Master messaging source — all copy anchors here | ✅ Current |
| `710_SYSTEM_Universal_Project_V1_CURRENT.md` | Project management system instructions | ✅ Current |

---

## 🚀 QUICK START FOR CLAUDE

**Finding documents:** Ask by category or purpose — e.g. "show me the current Pack 1" → look for `120_BRIEF_Pack1*_CURRENT`

**Creating new documents:** Use pattern `[NNN]_[TYPE]_[Description]_V1_DRAFT.md`, place in correct category range

**Updating documents:** Increment version (V1→V2), update status tag, move old version to 900s as `_SUPERSEDED`

**Compliance checks to run on any investor-facing document:**
- BPR cap = £2.5M per estate (not £1M)
- Investment instrument = "Instant Investment" (not ASA/SAFE/Advanced Subscription)
- No discount tier percentages published externally
- No platform pricing (£99/£249) in investor docs
- Pension IHT April 2027 carries caveat "subject to final legislation"
- BPR cap carries caveat "announced, not yet enacted" in technical contexts

---

## 📊 CURRENT STATUS

**Campaign:** Launching 16 March 2026  
**Phase:** Founding Investor Round — active outreach  
**Next hard deadline:** April 6, 2026 (tax year / BPR rule change)  
**Next review trigger:** April 7, 2026 (post-deadline messaging update)  
**Files in project:** 24 source + this index

---

## 🔴 OUTSTANDING BUILD ITEMS

1. **Post–April 6 messaging** (`196_`) — urgency framing shifts from tax deadline to valuation step-up. Needed by April 7.
2. **Growth Capital Round pack** (`195_`) — Q2 2026 launch ~8 weeks away. Zero documents exist.
3. **Decumulation Engine QA** — 4 test scenarios (simple portfolio, Tony Vine-Lott, large CLT gifting, death-in-year-4) not yet confirmed run before Werner handoff.
4. **4 whitepapers** (`320_`–`350_`) — source material exists in project, content not yet written.
5. **6 background PDFs** — Financial Model, Business Plan, Competitive Analysis, Customer Development Profiles, Feature Functions, Growth Capital Pack — not yet in project.

---

*Index created: 14 March 2026 | Maintained by: Tom King / Claude session*
