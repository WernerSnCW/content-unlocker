# Unlock — Complete Document Library
## All Foundation, Useable & Framework Documents | Compiled 3 April 2026

---

## Table of Contents

### PLATFORM SPECIFICATION & FRAMEWORK
- Platform Spec
- Missing Content Brief
- Project Index
- Agent Brief

### TIER 1 — FOUNDATIONAL SOURCE OF TRUTH
- Content Bank V4
- 19-Persona Suitability Guide

### INVESTOR-FACING DOCUMENTS — CURRENT
- One-Pager
- Three-Page Founding Investor Promo
- Pack 1 — Founding Investor Brief
- Pack 2 — Information Memorandum
- Unlock Access Explainer
- EIS: The Investor's Secret Weapon
- Five EIS Case Studies 2026
- IHT & EIS Planning — £5M Estate
- Duncan Stewart Bespoke Brief
- UK Investment Landscape 2026

### INVESTOR-FACING DOCUMENTS — DRAFT (GENERATED)
- FAQ & Objection Handler

### CAMPAIGN OPERATIONS — INTERNAL
- 30K Database Execution Plan
- Pipedrive & Aircall Setup
- Marketing & Investor Conversion Strategy
- Email Templates — All Pipeline Stages

### AGENT TOOLS
- Cold Call Script
- Agent Training Playbook
- Quick Reference Card

### COMPLIANCE & AUDIT
- Alignment Changelog — 14 March 2026

---

## Compliance Constants — Quick Reference

*These values must be consistent across every document in this library.*

| Constant | Value |
|---|---|
| BPR cap | £2,500,000 — "subject to final enactment" |
| VCT income tax relief | 20% (NOT 30%) |
| Pension IHT change | April 2027 — "subject to final enactment" |
| Decumulation Planner status | "Specification complete. Prototype build commencing." |
| Access framing | Structured disclosure — not scoring or advice |
| Instrument | Instant Investment (NOT ASA) |
| Tagline | "Clarity, without complexity" |
| Target portfolio range | £250K–£5M |
| Pre-money valuation | £6,500,000 |
| EIS income tax relief | 30% |
| SEIS income tax relief | 50% |
| EIS loss relief (45% taxpayer) | ~38.5p per £ |
| SEIS loss relief (45% taxpayer) | ~27.5p per £ |

---

# PLATFORM SPECIFICATION & FRAMEWORK

## Platform Spec
*Framework — Platform build spec V2.1 | 1,147 lines | 21 sections | 28 FRs*

---

*File not found: specs/SBDS_Unlock_Content_Intelligence_V2.md*


---

<!-- END OF DOCUMENT -->

## Missing Content Brief
*Framework — What needs to be built, priority order, blockers*

---

# Unlock — Missing Content Brief
## What needs to be built | 2 April 2026

---

## Status Summary

| Category | Built & in package | Missing |
|---|---|---|
| Investor-facing send docs | 10 of 12 | 2 |
| Whitepapers | 0 of 4 | 4 |
| Technical specs | 1 of 2 | 1 (xlsx — not uploadable) |
| Internal ops docs | 4 of 6 | 2 (research source docs not uploaded) |
| Platform docs | 0 of 3 | 3 |

---

## Priority 1 — Needed This Week

### `196_MESSAGING_Post_April6_V1_DRAFT.md`
**What it is:** Urgency framing for after the April 6 tax year deadline passes. Replaces the current BPR/IHT/tax year deadline hook with: valuation step-up framing, Q1 2027 Series A trajectory, and the window before the Growth Capital round opens.

**Why urgent:** April 6 is in 4 days. Every investor-facing email and call script currently references the April 6 deadline as the primary urgency hook. Once it passes with no replacement messaging, agents have nothing to anchor to.

**Source material available:**
- Content Bank V4 (valuation, round timeline, Growth Capital round context)
- Marketing Strategy Brief (post-deadline messaging direction)
- Pack 1 (existing urgency framing to replace)

**Stage/persona relevance:** All stages, all personas. This replaces urgency hooks across the entire funnel.

**Generation test case:** This is the reference test case for the Content Generation & QC Engine (Stage 3). Building this first validates the full platform.

---

## Priority 2 — Needed Before Growth Capital Round (~8 weeks)

### `195_PROMO_Growth_Capital_Pack_V1_DRAFT.md`
**What it is:** Investor-facing pack for the Q2 2026 Growth Capital round. Equivalent function to the current Founding Investor three-pager (110) but positioned for the next raise stage: proven traction, expanded platform, Series A runway.

**Source material available:**
- Marketing Strategy Brief (Growth Capital round detail)
- Content Bank V4 (platform vision, product roadmap)
- Financial Model (not yet in project — needed before this can be fully built)

**Stage/persona relevance:** Outreach, Called — all personas.

**Blocker:** Financial Model projections not yet in the project library.

---

## Priority 3 — Platform Documentation (needed before any demo)

### `145_EXPLAINER_Decumulation_Planner_V1_DRAFT.md`
**What it is:** Investor-facing explainer for the Decumulation Planner feature. Currently referenced in demos but no standalone document exists. Must use exact compliance language: *"Specification complete. Prototype build commencing."*

**Source material available:**
- Decumulation Engine Spec V1.5 (400 — in package)
- Content Bank V4 (product status language)
- Pack 1 (existing product description sections)

**Stage/persona relevance:** Demo Complete, Decision — Preserver and Legacy Builder.

**Compliance constraint:** Must not describe the tool as live or available. Status language is fixed.

### Pitch Deck
**What it is:** No file exists anywhere in the project. Referenced in the index as needed but never built.

**Source material available:** All of it — Pack 1, Pack 2, Content Bank, Financial Model (when uploaded).

**Suggested structure:** Problem → Market → Solution → Product → Traction → Team → Round details → Ask.

**Blocker:** Requires Financial Model for traction/projection slides.

---

## Priority 4 — Whitepapers (medium priority, source material ready)

All four whitepapers have source material already in the project (300 and 310 research docs). None have been written. Ordered by likely conversion impact:

### `320_WHITEPAPER_IHT_Proof_Estate_Rolling_EIS_V1_DRAFT.md`
**Audience:** Legacy Builder — HNW investors with estate planning concerns
**Hook:** How a rolling EIS programme creates a compounding IHT-exempt estate over time
**Source:** IHT/EIS planning doc (170), Content Bank EIS/IHT sections, case studies (160)

### `340_WHITEPAPER_Pension_Problem_April2027_V1_DRAFT.md`
**Audience:** Preserver and Legacy Builder — anyone with significant pension assets
**Hook:** April 2027 pension IHT inclusion means the clock is running — what to do now
**Source:** Content Bank (pension IHT section), IHT planning doc (170)
**Compliance note:** Must carry "subject to final enactment" caveat throughout

### `330_WHITEPAPER_Advice_Gap_EIS_V1_DRAFT.md`
**Audience:** Cold HNW prospects — self-directed investors underserved by IFAs
**Hook:** Why IFAs can't help with EIS and what to do instead
**Source:** Content Bank (competitive analysis, IFA positioning), Access Explainer (140)

### `350_WHITEPAPER_Iran_Effect_Portfolio_Concentration_V1_DRAFT.md`
**Audience:** Cold HNW prospects — investors with concentrated tech/equity exposure
**Hook:** Geopolitical risk and portfolio concentration — why diversification into alternatives is now structural, not optional
**Source:** UK Investment Landscape (190), Content Bank

---

## Not Yet in Project Library (need uploading, not building)

| Document | Why it matters |
|---|---|
| Financial Model & Projections | Required for Pack 2 financial claims, pitch deck, Growth Capital pack. All financial figures in investor docs must trace to this. |
| Business Plan | Referenced in Pack 2 Appendix A. Needed for full due diligence pack. |
| Competitive Analysis | Referenced in Pack 2. Needed for SWOT and objection handling sections. |
| `300_RESEARCH_UK_Investment_Landscape_Source` | Source document for the 190 landscape report. Exists but not uploaded to this project. |
| `310_RESEARCH_Case_for_EIS_2026` | Source document for EIS case studies. Exists but not uploaded. |
| `410_SCHEMA_Information_V2` | 7-sheet information schema (xlsx). Exists but xlsx not uploadable to this project library. |

---

## What the Platform Can Generate (once Stage 3 is built)

The Content Generation & QC Engine can build any of the missing documents above, in order, using the source material already in this package. Suggested generation sequence:

1. `196` — Post-April 6 messaging (reference test case — do first)
2. `145` — Decumulation Planner explainer
3. `320` — IHT whitepaper
4. `340` — Pension Problem whitepaper
5. `330` — Advice Gap whitepaper
6. `350` — Iran Effect whitepaper
7. `195` — Growth Capital pack (after Financial Model is uploaded)

The pitch deck requires human judgment on structure and design — generation can produce a content draft but the deck itself needs a designer.

---

*Brief compiled: 2 April 2026 | Reference: 000_INDEX + 600_CHANGELOG + SBDS V2.1*


---

<!-- END OF DOCUMENT -->

## Project Index
*Framework — Master navigation and file organisation*

---

# UNLOCK — PROJECT INDEX
## Navigation & Quick Reference | Version 1.0
**Last updated:** 14 March 2026 | **Campaign start:** 16 March 2026 | **April 6 deadline:** 23 days

---

## 🎯 PROJECT PURPOSE

Unlock is an investment intelligence platform for private investors managing £250K–£5M. This project covers the Founding Investor round: converting 25 investors from a 30,000-contact database into committed capital (£1.2M+) via systematic outreach — calls, demos, and a structured document pack sequence.

**Investment instrument:** Instant Investment (via SeedLegals)  
**Pre-money valuation:** £6.5M  
**Ticket range:** £20K–£500K  
**Key deadline:** April 6, 2026 (BPR/IHT rules change; tax year closes)

---

## 📁 FILE ORGANISATION

### 000–099: Navigation & System
| File | Purpose |
|---|---|
| `000_INDEX_Unlock_Project_Map_V1_CURRENT.md` | This file — master navigation |
| `010_INSTRUCTIONS_Agent_Brief_V1_CURRENT.md` | How to use this project; Claude session context |
| `020_GLOSSARY_Terms_V1_CURRENT.md` | Approved terminology; what to say / not say |
| `030_REGISTER_Document_Status_V1_CURRENT.md` | Version, status, and review schedule for every file |

### 100–199: Investor-Facing Send Documents
*These are the documents that go to investors. Every word matters.*

| File | Stage sent | Status |
|---|---|---|
| `100_PROMO_One_Page_V1_CURRENT.md` | Cold outreach / email attachment | ✅ Current |
| `110_PROMO_Founding_Investor_Three_Page_V1_CURRENT.md` | Cold outreach / forwardable | ✅ Current |
| `120_BRIEF_Pack1_Founding_Investor_V1_CURRENT.md` | Post-demo (Pack 1) | ✅ Current |
| `130_IIM_Pack2_Information_Memorandum_V1_CURRENT.md` | Qualified prospects (Pack 2) | ✅ Current |
| `140_EXPLAINER_Access_Service_V2_CURRENT.md` | Supplementary — Access service description | ✅ Current |
| `150_CASE_EIS_Investors_Secret_Weapon_V1_CURRENT.md` | Educational — cold HNW prospects | ✅ Current |
| `160_CASE_EIS_2026_Five_Case_Studies_V2_CURRENT.md` | EIS education with worked examples | ✅ Current |
| `170_PLANNING_IHT_EIS_5M_Estate_V4_CURRENT.md` | Legacy Builder persona — IHT planning | ✅ Current |
| `180_BRIEF_Duncan_Stewart_Bespoke_March2026_CURRENT.md` | Bespoke for Duncan Stewart call 30 Mar | ✅ Current |
| `190_LANDSCAPE_UK_Investment_2026_V1_CURRENT.md` | Long-form market report / lead magnet | ✅ Current |

**Planned (not yet built):**
| File | Purpose | Priority |
|---|---|---|
| `195_PROMO_Growth_Capital_Pack_V1_DRAFT.md` | Q2 2026 Growth Capital round documents | 🔴 High |
| `196_MESSAGING_Post_April6_V1_DRAFT.md` | Urgency framing after April 6 deadline passes | 🔴 High |

### 200–299: Campaign Operations (Internal Only — Never Share)
| File | Purpose | Status |
|---|---|---|
| `200_PLAN_Execution_30K_Database_V2_CURRENT.md` | Master campaign plan — DB tiers, pipeline, cadence | ✅ Current |
| `210_PIPELINE_Pipedrive_Aircall_Setup_V2_CURRENT.md` | CRM + call platform configuration | ✅ Current |
| `220_STRATEGY_Marketing_Investor_Conversion_V2_CURRENT.md` | Full marketing strategy — INTERNAL ONLY | ✅ Current |
| `230_EMAILS_Pack1_Templates_V2_CURRENT.txt` | Email templates for each pipeline stage | ✅ Current |

### 300–399: Research & Market Intelligence
| File | Purpose | Status |
|---|---|---|
| `300_RESEARCH_UK_Investment_Landscape_Source_V1_CURRENT.md` | Source document for 190_ send version | ✅ Current |
| `310_RESEARCH_Case_for_EIS_2026_V2_CURRENT.md` | EIS research and case studies source | ✅ Current |

**Planned whitepapers (source material exists, not yet written):**
| File | Audience | Priority |
|---|---|---|
| `320_WHITEPAPER_IHT_Proof_Estate_Rolling_EIS_V1_DRAFT.md` | Legacy Builder | 🟡 Medium |
| `330_WHITEPAPER_Advice_Gap_EIS_V1_DRAFT.md` | Cold HNW prospects | 🟡 Medium |
| `340_WHITEPAPER_Pension_Problem_April2027_V1_DRAFT.md` | Preserver / Legacy Builder | 🟡 Medium |
| `350_WHITEPAPER_Iran_Effect_Portfolio_Concentration_V1_DRAFT.md` | Cold HNW prospects | 🟡 Medium |

### 400–499: Technical Specifications
| File | Purpose | Status |
|---|---|---|
| `400_SPEC_Decumulation_Engine_V1_5_CURRENT.json` | Full technical spec — send to Werner | ✅ FINAL |
| `410_SCHEMA_Information_V2_CURRENT.xlsx` | 7-sheet information schema / propagation map | ✅ Current |

### 500–599: Agent Tools & Scripts
| File | Purpose | Status |
|---|---|---|
| `500_SCRIPT_Cold_Call_V1_CURRENT.md` | 9-section call script with qualification gates | ✅ Current |
| `510_PLAYBOOK_Agent_Training_V2_CURRENT.md` | 2-hour agent training programme | ✅ Current |
| `520_GUIDE_Investor_Personas_19_V1_CURRENT.md` | 19 personas — tier, signals, objections | ✅ Current |
| `530_CARD_Agent_Quick_Reference_V1_CURRENT.txt` | Print and tape to monitor | ✅ Current |

### 600–699: Compliance & Audit
| File | Purpose | Status |
|---|---|---|
| `600_CHANGELOG_Alignment_14Mar2026_CURRENT.md` | Full audit log — every change made 14 Mar 2026 | ✅ Current |
| `610_REGISTER_Document_Status_V1_CURRENT.md` | Live status register (mirrors 030_) | ✅ Current |

### 700–799: Source of Truth & Standards
| File | Purpose | Status |
|---|---|---|
| `700_CONTENT_Bank_V4_CURRENT.md` | Master messaging source — all copy anchors here | ✅ Current |
| `710_SYSTEM_Universal_Project_V1_CURRENT.md` | Project management system instructions | ✅ Current |

---

## 🚀 QUICK START FOR CLAUDE

**Finding documents:** Ask by category or purpose — e.g. "show me the current Pack 1" → look for `120_BRIEF_Pack1*_CURRENT`

**Creating new documents:** Use pattern `[NNN]_[TYPE]_[Description]_V1_DRAFT.md`, place in correct category range

**Updating documents:** Increment version (V1→V2), update status tag, move old version to 900s as `_SUPERSEDED`

**Compliance checks to run on any investor-facing document:**
- BPR cap = £2.5M per estate (not £1M)
- Investment instrument = "Instant Investment" (not ASA/SAFE/Advanced Subscription)
- No discount tier percentages published externally
- No platform pricing (£99/£249) in investor docs
- Pension IHT April 2027 carries caveat "subject to final legislation"
- BPR cap carries caveat "announced, not yet enacted" in technical contexts

---

## 📊 CURRENT STATUS

**Campaign:** Launching 16 March 2026  
**Phase:** Founding Investor Round — active outreach  
**Next hard deadline:** April 6, 2026 (tax year / BPR rule change)  
**Next review trigger:** April 7, 2026 (post-deadline messaging update)  
**Files in project:** 24 source + this index

---

## 🔴 OUTSTANDING BUILD ITEMS

1. **Post–April 6 messaging** (`196_`) — urgency framing shifts from tax deadline to valuation step-up. Needed by April 7.
2. **Growth Capital Round pack** (`195_`) — Q2 2026 launch ~8 weeks away. Zero documents exist.
3. **Decumulation Engine QA** — 4 test scenarios (simple portfolio, Tony Vine-Lott, large CLT gifting, death-in-year-4) not yet confirmed run before Werner handoff.
4. **4 whitepapers** (`320_`–`350_`) — source material exists in project, content not yet written.
5. **6 background PDFs** — Financial Model, Business Plan, Competitive Analysis, Customer Development Profiles, Feature Functions, Growth Capital Pack — not yet in project.

---

*Index created: 14 March 2026 | Maintained by: Tom King / Claude session*


---

<!-- END OF DOCUMENT -->

## Agent Brief
*Framework — Session context and project instructions*

---

# UNLOCK — AGENT BRIEF & CLAUDE SESSION CONTEXT
## How to Use This Project | V1 | Current
**Last updated:** 14 March 2026

---

## WHAT THIS PROJECT IS

Unlock is raising a Founding Investor round from a 30,000-contact database. This Claude project contains every document, script, template, and spec needed to run that campaign — from first call to Instant Investment close.

**You are Tom King, founder.** Claude is your campaign intelligence layer.

---

## APPROVED TERMINOLOGY — USE THESE EXACT WORDS

| ✅ Say this | ❌ Never say this |
|---|---|
| Instant Investment | ASA / Advanced Subscription Agreement / SAFE |
| £2.5M BPR cap per estate | £1M BPR cap |
| Negotiated individually | Specific discount percentages |
| Transparency / full disclosure | Independent (as a positioning claim) |
| ADMINISTRATION (fourth pillar) | Execution (old fourth pillar name) |
| Growth Capital Round (Q2 2026) | Second round / Series A (at this stage) |

---

## DOCUMENT HIERARCHY

**When in doubt about what to say or send, check in this order:**

1. `700_CONTENT_Bank_V4` — master source of truth for all messaging
2. The specific document being used
3. `020_GLOSSARY_Terms` — for precise wording
4. This file — for context and rules

**Never derive investor-facing copy from memory. Always anchor to 700_.**

---

## THE INVESTOR JOURNEY (5 pipeline stages)

| Stage | Pipedrive stage | Document sent | Follow-up |
|---|---|---|---|
| 1 | Outreach Queued | — | Call from `500_SCRIPT` |
| 2 | Called → Demo Booked | — | Demo confirmation email (`230_EMAILS`) |
| 3 | Demo Scheduled | `100_` or `110_` One-pager / Promo | 24hr reminder |
| 4 | Demo Complete | `120_BRIEF` Pack 1 | Call in 3–5 days |
| 5 | Pack 1 → Decision | `130_IIM` Pack 2 | Advisor loop → close |

---

## THREE INVESTOR PERSONAS

| Persona | % of HNW | Key language | Lead document |
|---|---|---|---|
| Preserver | 30% | "capital protection," "peace of mind," "risk controls" | `190_LANDSCAPE` |
| Growth Seeker | 40% | "upside," "transparency," "deal flow," "syndicates" | `150_CASE` Secret Weapon |
| Legacy Builder | 30% | "inheritance," "IHT," "family," "succession" | `170_PLANNING` IHT Estate |

19 detailed sub-personas in `520_GUIDE_Investor_Personas`.

---

## KEY FIGURES — MEMORISE THESE

| Figure | Value | Note |
|---|---|---|
| Pre-money valuation | £6.5M | Founding round |
| Raise target | £1.2M+ | 25 founding investors |
| Ticket range | £20K–£500K | |
| Database size | 30,000 | Segmented Tier 1/2/3 |
| EIS income tax relief | 30% | Up to £1M/year (£2M KIC) |
| SEIS income tax relief | 50% | Up to £200K/year |
| BPR cap (from Apr 6) | £2.5M per estate | EIS direct + AIM only. VCT excluded. Announced, not enacted. |
| VCT relief drop | 30% → 20% | From April 6, 2026 |
| Pension IHT exposure | From April 2027 | Subject to final legislation |
| EIS loss relief (45% taxpayer) | ~38.5p/£ | On net loss after income tax relief |
| SEIS loss relief (45% taxpayer) | ~27.5p/£ | On net loss after income tax relief |
| Platform pricing | £99/£249 | INTERNAL ONLY — never in investor docs |
| Campaign start | 16 March 2026 | |
| April 6 deadline | 23 days away | Tax year + BPR rule change |

---

## COMPLIANCE RULES — CHECK EVERY INVESTOR DOC

Before any investor-facing document is sent or updated:

- [ ] BPR cap = £2.5M (not £1M)
- [ ] Investment instrument = "Instant Investment"
- [ ] No discount percentages published
- [ ] No platform pricing (£99/£249) visible
- [ ] Pension IHT caveat present where referenced
- [ ] BPR cap caveat present in technical contexts ("announced, modelled — not yet enacted law")
- [ ] Contact details present: tom@unlockdd.com | www.unlockdd.com
- [ ] Legal disclaimer present on all investor docs

---

## UPCOMING BUILD ITEMS

| Priority | Item | Target |
|---|---|---|
| 🔴 Urgent | Post–April 6 messaging (`196_`) | Ready by April 7 |
| 🔴 High | Growth Capital Round pack (`195_`) | Ready by end of April |
| 🟡 Medium | Decumulation Engine QA — send to Werner | This week |
| 🟡 Medium | 4 whitepapers (`320_`–`350_`) | May 2026 |

---

## WHAT CHANGED ON 14 MARCH 2026

Full change log in `600_CHANGELOG_Alignment_14Mar2026`. Summary:

- **BPR cap corrected from £1M → £2.5M** across every document (13 fixes in docx files alone — this was the most widespread error)
- ASA/SAFE → Instant Investment (2 remaining instances fixed)
- Encoding corruption fixed across 4 ops docs
- Stale dates corrected in execution plan
- 3 status register flags cleared (documents were already compliant)

---

*Brief created: 14 March 2026*


---

<!-- END OF DOCUMENT -->

# TIER 1 — FOUNDATIONAL SOURCE OF TRUTH

## Content Bank V4
*Tier 1 — Master messaging source. All copy anchors here. Primary source of truth.*

---

**UNLOCK**

Content Bank

Consolidated source of truth for all marketing, sales, and
communications content

**Content Status Overview**

This document consolidates all Unlock content assets extracted from
existing project documents. It serves as the single source of truth for
marketing, sales, and communications.

  --------------------------- -------------- ------------------------------
  **Content Item**            **Status**     **Source / Notes**

  Mission & Vision            Ready          Play to Win, Investment Pitch

  Values                      Ready          Derived from P2W / positioning

  Business Description        Ready          Business Plan, Investment
                                             Pitch

  Industry & Market           Ready          Competitive Analysis, Business
                                             Plan

  Narrative                   Ready          Pack 1, Marketing Brief
  (Problem/Solution/Why Now)                 

  Product Pillars             Ready          Multiple docs

  Target Audience             Ready          Play to Win --- decided
                                             segment

  Buyer Personas (3           Ready          Customer Dev Profiles,
  archetypes)                                Marketing Brief

  Buyer Personas (19          Ready          Investor Personas &
  detailed)                                  Suitability Guide

  Pain Points                 Ready          Pack 1, Business Plan

  Value Proposition           Ready          Marketing Brief, Value Prop
                                             Canvas

  Products & Services         Ready          App Walkthrough, Feature
  (detailed)                                 Functions

  Benefits per service        Complete ---   Scattered across docs
                              consolidated   
                              in Content     
                              Bank V3        

  Pricing                     Ready          Financial Model, Pitch Deck

  Partnerships                Ready          Multiple docs

  Key Messaging / Storybrand  Ready          Marketing Brief, Agent
                                             Playbook

  Competitor Analysis         Ready          Competitive Analysis doc

  SWOT                        Complete ---   Risks in Business Plan
                              consolidated   
                              in Content     
                              Bank V3        

  Financial Projections       Ready          Financial Model doc

  Regulatory & Compliance     Ready          Pack 1, Pack 2, Personas Guide
  (EIS/SEIS)                                 

  Case for EIS (whitepaper)   Ready          Standalone whitepaper

  FAQs                        Complete ---   Objections in Agent Playbook
                              consolidated   
                              in Content     
                              Bank V3        

  Glossary                    Complete ---   Pack 2 appendix structure
                              consolidated   
                              in Content     
                              Bank V3        

  Case Studies / Testimonials To be added    Pre-launch --- not yet
                              post-launch    available

  Content Calendar            To be built    Comes after content bank is
                                             complete
  --------------------------- -------------- ------------------------------

**0. Document Architecture & Content Hierarchy**

This section maps what feeds what across all Unlock content. Every
investor-facing document, every sales tool, and every product framing
derives from a small set of foundational decisions. Understanding the
hierarchy prevents drift, ensures consistency, and clarifies which
document to update first when strategy changes.

**Tier 1 --- Foundational Strategy (Primary Sources of Truth)**

*These documents make decisions. Everything else interprets or applies
them. If these change, everything downstream must be reviewed.*

  --------------------- --------------------- ----------------------------
  **Document**          **What it decides**   **Propagates into**

  **Play to Win         Winning aspiration,   Everything. Mission,
  Strategy Workshop**   where to play, how to positioning, product
                        win, required         roadmap, capability build,
                        capabilities,         investor narrative.
                        management systems.   
                        The primary strategic 
                        document.             

  **19-Persona          Full investor         The 3 public personas,
  Suitability Guide**   segmentation:         calling scripts, CRM
                        portfolio size, age,  segmentation, product
                        lifecycle stage,      personalisation, Pack 1/2
                        approach, risk        targeting.
                        profile, fit tier.    

  **Financial Model &   ARR trajectory,       All investor-facing
  Projections**         CAC/LTV, churn, unit  financial claims, pricing
                        economics, valuation, justification, SWOT
                        exit milestones.      financial risks, Pack 2
                                              financial sections.

  **Value Proposition   Jobs-to-be-done,      Core VP statement,
  Canvas**              pains, gains, and     by-persona VP, Pack 1
                        product-fit per       problem framing, product
                        persona. Pain         benefit language, objection
                        reliever / gain       responses.
                        creator mapping.      

  **Decumulation Engine Full algorithm, UK    Decumulation Planner product
  Spec (v1.2)**         tax matrix per asset  claims in Pack 1/2 and pitch
                        class, four drawdown  deck. Tax treatment per
                        strategies,           asset class. Drawdown
                        trust/gifting logic,  strategy descriptions.
                        warning system,       Competitive differentiation
                        output schema.        re: VCT/EIS/pension
                        Prototype build       planning.
                        commencing March      
                        2026.                 
  --------------------- --------------------- ----------------------------

**Tier 2 --- Structural Content (Derived from Tier 1, Feed Tier 3)**

*These documents translate strategic decisions into structured content.
They are the source material for all investor-facing and sales-facing
outputs. Update when Tier 1 changes or when new evidence requires
revision.*

  --------------------- --------------------- ----------------------------
  **Document**          **Role**              **Propagates into**

  **Business Plan**     Full narrative:       Pack 2 Appendix A, investor
                        vision, market,       deck narrative, team bios.
                        roadmap, team, org    
                        structure. Internal   
                        and Pack 2.           

  **Marketing &         Investor journey map, Pack 1, Pack 2 structure,
  Investor Conversion   funnel stages, belief email templates, calling
  Brief**               shifts, document      scripts, demo framing,
                        sequencing, KPIs,     outreach cadence.
                        risk mitigation.      

  **Competitive         Landscape mapping,    SWOT (Strengths/Threats),
  Analysis**            competitor            Pack 2 Appendix G, objection
                        limitations, how      handling, positioning
                        Unlock wins by        language.
                        category.             

  **App Walkthrough     Feature-level product Benefits Per Service
  Script**              narrative: what each  (Section 15), demo scripts,
                        tool does, demo flow, product descriptions in Pack
                        adviser-facing        1/2.
                        outputs.              
  --------------------- --------------------- ----------------------------

**Tier 3 --- Investor-Facing Outputs (Derived, Not Primary)**

*These are the documents investors and agents actually touch. They must
be consistent with Tier 1 and 2 but should never be edited to resolve a
strategic question --- trace back upstream instead.*

  --------------------- ---------------- -----------------------------------------
  **Document**          **Audience**     **Draws from (Tier 1 / Tier 2)**

  **Pack 1 --- The      Founding         VP Canvas, Marketing Brief (belief
  Opportunity (Founding investors (Stage shifts, journey stages), Financial Model
  Investor Brief)**     2)               (claims), 19-Persona Guide (targeting),
                                         Play to Win (positioning).

  **Pack 2 --- Investor Investors at     Financial Model (all figures), Business
  Terms & Due Diligence decision stage   Plan, Competitive Analysis, VP Canvas,
  (IIM)**               (Stage 3)        Risk Factors, ASA/SeedLegals structure.

  **Investor Pitch      Warm investors,  Play to Win (narrative structure), VP
  Deck**                demo follow-up   Canvas (problem/solution), Financial
                        (Stage 2--3)     Model (traction claims), 3-persona frame.

  **Agent Training      Outreach agents  19-Persona Guide (identification +
  Playbook & Calling    (Stage 1)        messaging), Marketing Brief (funnel), VP
  Scripts**                              Canvas (pain points), Competitive
                                         Analysis (objection handling).

  **Unlock Access       EIS investors    4-pillar structure
  Explainer**           (pre-company     (Guidance/Tools/Access/Administration),
                        docs)            transparency framing, VP Canvas,
                                         Financial Model (fee structure).
  --------------------- ---------------- -----------------------------------------

**Propagation Rules**

1\. **Strategy changes upstream before language changes downstream.** If
a positioning claim in Pack 1 feels wrong, the problem is not in Pack 1
--- it is in the Play to Win Workshop or VP Canvas. Fix it there first.

2\. **The 3 personas are a public simplification of the 19.** The
19-persona guide is the operational truth. The 3 archetypes are the
communication frame. If a persona in Pack 1 misfires with an investor,
the diagnosis lives in the 19-persona guide --- not in the Pack 1 copy.

3\. **Financial claims must trace to the Financial Model.** No figure in
any investor-facing document should be stated without a traceable source
in the Financial Model. If projections update, all downstream documents
containing those figures require review.

4\. **Lifecycle stage (accumulation / decumulation) is a Tier 1 lens.**
It is embedded in the 19-persona guide and must be reflected in persona
descriptions, value propositions, product benefit language, and calling
scripts. It is not a Tier 3 addition --- it is a Tier 1 structural
dimension that has been under-represented in derived documents.

5\. **Terminology is controlled in the Glossary (Section 17).** When a
term appears in multiple documents (e.g. "Instant Investment" not "ASA",
"Administration" not "Execution"), the Glossary is the authority. Any
downstream document using a deprecated term requires correction.

**1. Mission & Vision**

**Mission Statement**

***Give private investors the same clarity, tools, and protections that
institutions take for granted.***

**Winning Aspiration (Play to Win)**

***Every UK investor with £1M--£20M+ has a complete, accurate picture of
their financial identity --- before they act, not after.***

This is a category claim, not a niche. Volume without the right segment
is noise.

**What Winning Is Not**

-   Not the largest AUM

-   Not the most users

-   Not the best returns

-   Not replacing IFAs --- they are distribution partners, not
    competitors

**2. Values**

Unlock's values are encoded in its strategic decisions, not stated as
corporate platitudes. They are operational commitments.

  ---------------------- ------------------------------------------------
  **Independence**       No product conflicts, no trail fees, no
                         commission. Unlock earns only from the investor.
                         Every existing platform has a conflict. This is
                         non-negotiable.

  **Transparency**       Structural independence: no commission on any
                         product, no AUM fee, no trail fee. Unlock earns
                         from subscriptions only --- no incentive to
                         recommend one ISA, fund, or platform over
                         another. Unlock Access is a separate, disclosed
                         bolt-on service for investors building EIS/SEIS
                         portfolios; it is opt-in and fully transparent
                         about its connection to the startup studio. The
                         platform's independence claim is not undermined
                         by Unlock Access because Unlock Access is
                         structurally separate and disclosed --- not
                         hidden.

  **Investor-first**     Every product decision, fee structure, and
                         partnership is evaluated against a single
                         question: does this serve the investor's
                         interest?

  **Clarity over         Institutional-grade intelligence, expressed in
  complexity**           plain English. Investors should understand their
                         complete financial picture without needing a
                         finance degree.

  **Integrity under      Genuine urgency (EIS deadlines, valuation
  pressure**             step-ups) replaces artificial scarcity.
                         Sophisticated investors see through
                         manipulation.
  ---------------------- ------------------------------------------------

**3. Business Description**

**What Unlock Is**

Unlock is a next-generation portfolio intelligence and investment access
platform for UK private investors. It gives investors with £1M--£20M+ in
total wealth a complete, accurate picture of their financial identity
--- across all asset classes, wrappers, and providers --- with
institutional-grade tools that are independent, transparent, and
investor-led.

**What Unlock Does**

  ---------------------- ------------------------------------------------
  **Portfolio            Consolidates multi-asset, multi-platform
  Intelligence**         portfolios into a single connected view.
                         Lot-level cost basis tracking. Forward-looking
                         tax interactions modelled in real time.

  **Scenario             Stress-test portfolios under 30+ downside
  Simulation**           scenarios. Model 'what if' situations before
                         committing capital. Compare upside vs downside
                         transparently.

  **Tax Intelligence     EIS, SEIS, CGT, IHT, pension drawdown, AIM BPR
  Engine**               --- modelled continuously with live HMRC
                         rule-tracking. The UK regulatory moat.

  **Syndicate Access**   Vetted collective investment opportunities at
                         transparent 8--10% fees (vs 9--14% market norm).
                         First access to founding investors.

  **Unlock Access**      Curated EIS deal-flow and portfolio service.
                         Four pillars: Guidance, Tools, Access,
                         Administration. Direct portfolio building ---
                         not a fund.
  ---------------------- ------------------------------------------------

**Stage of Development**

Founding investor round: £1.2M target at £6.5M pre-money valuation. \~25
investors. Campaign launched November 2025. Shares issued April 6, 2026.
Public launch targeted Q1 2027. Current build: founding-stage desktop
application (Electron/SQLite) delivering automated portfolio data
collection for founding investors. Local-first architecture --- platform
integrations (Fundsmith, True Potential, and others) are automated via
browser automation running on the investor's own machine, because these
platforms do not expose public APIs. Portfolio summary data is pushed to
a cloud layer for web and mobile access. This is the correct
architecture for the problem, not a workaround --- it is the only way to
automate data collection without storing credentials remotely.
Decumulation Planner: full technical specification complete (v1.2, March
2026). Prototype build commencing.

**4. Industry & Market**

**Market Context**

The UK wealth management and alternative investment platform market is
large but fragmented. Most platforms are built for product distribution
or mass-market retail users --- not high-net-worth private investors who
manage complex, multi-asset portfolios.

**The Three Problems Unlock Solves**

  ---------------------- ------------------------------------------------
  **Fragmented Data**    Investors manage assets across multiple
                         providers, advisers, and manual systems. There
                         is no single view. Most rely on spreadsheets and
                         gut instinct.

  **Inaccessible         Professional-grade analysis is locked behind
  Complexity**           institutional paywalls. Portfolio simulation,
                         stress-testing, and tax modelling are not
                         available to private investors at accessible
                         cost.

  **Conflicted           Every existing platform optimises for product
  Incentives**           sales, not investor outcomes. Hargreaves
                         Lansdown, Nutmeg, Crowdcube --- all have product
                         conflicts. Unlock does not.
  ---------------------- ------------------------------------------------

**Why Now**

-   Technology shift: AI enables investor-grade simulations at consumer
    cost for the first time

-   Market gap: No independent, investor-first platform at this level
    exists in the UK

-   Policy tailwinds: UK EIS/SEIS incentives make early-stage investing
    highly attractive

-   IHT rule changes: April 6, 2026 changes (100% EIS/SEIS relief capped
    at £2.5M per estate, 50% above) create genuine urgency for
    structuring decisions

-   UK regulatory moat: EIS, SEIS, CGT, IHT, pension drawdown --- 18--24
    months minimum to build correctly. No comparable jurisdiction has
    this regulatory density

**Target Segment**

  ---------------------- ------------------------------------------------
  **Wealth range**       £1M--£20M+ in total wealth

  **Portfolio type**     Complex, multi-platform, multi-asset. No family
                         office. Sophisticated but not fully serviced.

  **Below floor**        £1M: insufficient complexity to justify the
                         platform

  **Above ceiling**      £20--50M+: family offices exist and serve this
                         segment

  **Geography (Phase     UK only. HMRC complexity is the moat. Diluting
  1)**                   too early breaks the thesis.

  **Geography (Phase     English-speaking common law jurisdictions post
  2)**                   Series A: Ireland, Australia, Canada, Singapore
  ---------------------- ------------------------------------------------

**5. Core Narrative**

**Problem Statement**

Private investors with £1M+ portfolios face three persistent challenges
that institutions never encounter: their data is fragmented across
providers and platforms, professional-grade analysis is locked behind
institutional paywalls, and every platform they use has a conflict of
interest --- it earns from products, not from investor outcomes.

The result: sophisticated investors are making decisions based on
spreadsheets, Google, and gut instinct while institutions have models,
dashboards, and entire teams. The playing field is not level.

**Solution**

Unlock combines institutional-grade tools with investor-led simplicity.
One platform that assembles the complete financial identity --- UK tax
intelligence, forward-looking, investor-controlled --- that no
conflicted incumbent can replicate.

**Brand Story**

Unlock was built on a simple observation: the tools that institutions
use to understand and protect wealth have never been made available to
the private investors who need them most. Wealth managers, private
banks, and fintech platforms all serve investors --- but all earn from
what they sell them, not from how well they do.

Unlock is the platform built entirely on the other side of that
equation. No products. No commissions. No conflicts. Just the
intelligence layer that lets private investors see their complete
financial picture, model their decisions before making them, and access
opportunities on terms that actually work in their favour.

The founding investors are not just capital. They are the first proof
that this matters.

**Storybrand One-Liner**

***Unlock gives private investors the institutional-grade intelligence
and deal access they've always been locked out of --- without the
conflicts that come with it.***

**6. Target Audience & Buyer Personas**

**Audience Summary**

  ---------------------- ------------------------------------------------
  **Who**                UK HNW and UHNW private investors

  **Portfolio size**     £1M--£20M+ in total wealth (£250K--£5M
                         investable focus for founding round)

  **Approach**           Self-directed or adviser-informed. Not
                         adviser-dependent.

  **Assets**             Typically 5+ asset classes: property, equities,
                         alternatives, cash, pensions, possibly business
                         equity

  **Attitude**           Frustrated by fragmentation. Willing to pay for
                         clarity. Interested in tax optimisation and
                         alternatives access.

  **Not**                Purely passive investors, retail mass-market,
                         family office tier (above £20--50M)
  ---------------------- ------------------------------------------------

**The Three Core Personas**

**1. The Preserver**

  ---------------------- ------------------------------------------------
  **Motivation**         Protect wealth and minimise downside. Sleep at
                         night.

  **Behaviours**         Low-volatility portfolios. Capital protection
                         focus. Seeks validation for adviser
                         recommendations.

  **Pain Points**        Fragmented tools. Poor downside modelling.
                         Conflicted advice.

  **Platform Use**       Stress-test portfolios under 30+ scenarios.
                         Confirm risk controls. Model defensive
                         strategies.

  **Key Language**       'capital protection', 'risk controls',
                         'validation', 'peace of mind'

  **Approx. share**      \~30% of HNW investors

  **Lifecycle Stage**    Primarily **late accumulation transitioning to
                         decumulation**. Typically 50--70, wealth
                         established, capital preservation now dominant
                         over growth. Key decumulation concerns: drawdown
                         sequencing, income sustainability, not outliving
                         the portfolio. The Preserver's stress-testing
                         use case applies throughout both phases but
                         becomes existential in decumulation --- the
                         consequences of getting sequencing wrong are
                         irreversible. Unlock's value for this persona
                         grows as they age.
  ---------------------- ------------------------------------------------

**2. The Growth Seeker**

  ---------------------- ------------------------------------------------
  **Motivation**         Long-term wealth growth with calculated risk.

  **Behaviours**         Seeks high-growth opportunities but wants
                         risk-managed entry. Values portfolio simulation.
                         Attracted to syndicates.

  **Pain Points**        Lack of transparency in deals. Retail-focused
                         tools. Dilution in crowdfunding.

  **Platform Use**       Compare upside vs downside. Access vetted
                         syndicates at fair terms. Track lot-level
                         performance.

  **Key Language**       'upside', 'opportunity', 'transparency',
                         'syndicates', 'deal flow'

  **Approx. share**      \~40% of HNW investors

  **Lifecycle Stage**    Primarily **active accumulation**. Typically
                         30--55, portfolio growing, actively deploying
                         capital into new positions. The accumulation
                         phase is where Unlock's portfolio simulator,
                         syndicate access, and tax intelligence tools
                         deliver maximum transactional value --- every
                         new position, every deal comparison, every
                         EIS/SEIS decision benefits from the platform.
                         LTV argument: this persona often converts to
                         Preserver characteristics as wealth
                         consolidates, extending platform relevance
                         across two lifecycle phases.
  ---------------------- ------------------------------------------------

**3. The Legacy Builder**

  ---------------------- ------------------------------------------------
  **Motivation**         Plan intergenerational wealth transfer and tax
                         efficiency.

  **Behaviours**         Estate planning focus. Balances growth with IHT
                         efficiency. Models family scenarios.

  **Pain Points**        Complexity of tax planning. Lack of clarity
                         across family wealth structures.

  **Platform Use**       Model EIS/SEIS tax advantages. Family scenario
                         planning. IHT optimisation.

  **Key Language**       'inheritance', 'tax efficiency', 'family',
                         'succession', 'legacy'

  **Approx. share**      \~30% of HNW investors

  **Lifecycle Stage**    Spans both phases --- **late accumulation
                         through early decumulation, with
                         intergenerational transfer as the defining
                         objective of both**. Typically 45--70. In
                         accumulation: building an EIS/SEIS-efficient
                         portfolio, using tax wrappers correctly, staging
                         wealth transfer. In decumulation: sequencing
                         asset drawdown to minimise IHT exposure,
                         ensuring family structures are documented and
                         transferable, modelling estate scenarios. The
                         April 2026 IHT rule changes (relief capped at
                         £2.5M per estate) make lifecycle timing
                         acutely relevant --- the Legacy Builder must act
                         before the threshold changes. Unlock is the only
                         platform that models this across both phases
                         simultaneously.
  ---------------------- ------------------------------------------------

**7. Value Proposition**

**Core Value Proposition**

*For UK private investors with complex, multi-asset portfolios who are
frustrated by fragmentation, conflicted advice, and inaccessible tools
--- Unlock is the only platform that assembles their complete financial
identity with UK tax intelligence, forward-looking modelling, and
investor-controlled access to vetted opportunities --- without the
conflicts every other platform carries.*

**Value by Persona**

  ---------------------- ------------------------------------------------
  **The Preserver**      Stress-test 30+ downside scenarios. Confirm risk
                         controls are working. Model defensive strategies
                         with institutional clarity. Know your portfolio
                         is protected before a crash, not after.

  **The Growth Seeker**  Access vetted early-stage opportunities normally
                         closed to retail investors. Compare upside vs
                         downside transparently before committing.
                         Syndicates at 8--10% fees vs 9--14% market norm.

  **The Legacy Builder** Model family scenarios and IHT efficiency.
                         Maximise EIS/SEIS benefits for tax-optimised
                         wealth structuring. Plan generational wealth
                         with precision tools, not spreadsheets.
  ---------------------- ------------------------------------------------

**Independence as Differentiator**

-   No product conflicts, no trail fees, no commission at any point

-   Every existing platform (Hargreaves Lansdown, Nutmeg, Crowdcube,
    private banks) has a conflict --- they earn from what they sell you

-   Unlock earns only from the investor --- subscriptions and syndicate
    participation fees

-   This is the identity of the business. Non-negotiable.

**Value Proposition by Lifecycle Stage**

The three personas describe investor identity. Lifecycle stage describes
where they are in their wealth journey. These are independent dimensions
--- a Legacy Builder in accumulation has different immediate needs than
a Legacy Builder entering decumulation. The value proposition shifts
accordingly. This table is the operative framing for product messaging,
feature prioritisation, and long-term LTV arguments.

  --------------- -------------- ---------------------- ----------------------
  **Persona**     **Stage**      **Core value Unlock    **Primary features**
                                 delivers**             

  **Growth        Accumulation   Maximise risk-adjusted Portfolio simulator,
  Seeker**                       returns. Access deals  syndicate access,
                                 normally closed to     lot-level performance
                                 retail. Know before    tracking, EIS/SEIS tax
                                 you commit --- model   intelligence.
                                 upside and downside on 
                                 every position before  
                                 deploying capital.     

  **Preserver**   Late           Confirm the portfolio  Portfolio simulator
                  accumulation   is protected as it     (30+ scenarios),
                                 grows. Stress-test now safety lights, asset
                                 --- not when markets   register, onboarding
                                 fall. Validate that    risk checks.
                                 adviser                
                                 recommendations are    
                                 genuinely unbiased.    

  **Preserver**   Decumulation   Ensure the portfolio   Tax intelligence
                                 sustains income        engine (drawdown
                                 without catastrophic   sequencing), portfolio
                                 sequencing errors.     simulator, reports &
                                 Know which assets to   adviser packs (KYS for
                                 draw first, in what    income planning).
                                 order, with what tax   
                                 impact. The stakes are 
                                 highest here ---       
                                 errors are             
                                 irreversible.          

  **Legacy        Accumulation   Build a tax-efficient  Tax intelligence
  Builder**                      portfolio that is      engine (EIS/SEIS/IHT),
                                 structured for         Unlock Access
                                 transfer from day one. deal-flow, asset
                                 Use EIS/SEIS within    register (lot-level
                                 the full risk          cost basis), portfolio
                                 framework --- not in   simulator.
                                 isolation. Every       
                                 investment decision    
                                 carries an IHT         
                                 dimension.             

  **Legacy        Decumulation   Transfer wealth with   Reports & adviser
  Builder**                      clarity and minimum    packs (probate/IHT
                                 tax leakage. Ensure    valuation), tax
                                 family structures are  intelligence engine
                                 documented and         (estate sequencing),
                                 transferable. Sequence asset register
                                 drawdown to protect    (date-freeze for IHT).
                                 IHT-efficient assets   
                                 for as long as         
                                 possible. The next     
                                 generation inherits a  
                                 complete picture, not  
                                 chaos.                 
  --------------- -------------- ---------------------- ----------------------

**LTV implication:** Unlock's platform value does not diminish as
investors age --- it shifts. A Growth Seeker in accumulation who remains
on the platform as their priorities shift toward preservation, then
decumulation, is a multi-decade relationship. The data flywheel means
the platform becomes harder to leave, not easier, as the investor's
complete financial history accumulates inside it. This is the structural
argument for low churn and high LTV --- and it must be present in
product design, pricing rationale, and investor narrative.

**8. Products & Services**

**Core Platform Services**

**Portfolio Intelligence**

  ---------------------- ------------------------------------------------
  **What it does**       Consolidates assets across all providers,
                         platforms, wrappers, and structures into a
                         single connected view

  **Key features**       Lot-level cost basis tracking. Multi-asset
                         integration (ISAs, broker accounts, pension
                         providers, property, alternatives).
                         Adviser-grade output formatting.

  **Benefit**            Investors see their complete financial picture
                         for the first time. Hidden exposures and
                         dependencies surface naturally.

  **Status**             Operational for founding investor onboarding
                         (white-glove). Automated connections on roadmap.
  ---------------------- ------------------------------------------------

**Scenario Simulation (Portfolio Simulator)**

  ---------------------- ------------------------------------------------
  **What it does**       Stress-tests portfolios under 30+ downside
                         scenarios and models 'what-if' situations before
                         capital is committed

  **Key features**       Personalised scenario modelling. Upside/downside
                         comparison. Defensive strategy modelling.

  **Benefit**            Make decisions based on modelled outcomes, not
                         gut instinct. Know before you act.

  **Status**             Core capability. In active development.
  ---------------------- ------------------------------------------------

**UK Tax Intelligence Engine**

  ---------------------- ------------------------------------------------
  **What it does**       Models EIS, SEIS, CGT, IHT, pension drawdown,
                         and AIM BPR interactions in real time,
                         forward-looking, with continuous HMRC
                         rule-tracking

  **Key features**       EIS/SEIS optimisation. CGT deferral modelling.
                         Inheritance tax planning. Pension drawdown
                         sequencing.

  **Benefit**            The tax decisions most investors get wrong ---
                         or pay an adviser to navigate --- become visible
                         and actionable within the platform.

  **Status**             Decided capability. Core moat. 18--24 months
                         minimum to replicate. Full build funded by this
                         raise.
  ---------------------- ------------------------------------------------

**Syndicate Access**

  ---------------------- ------------------------------------------------
  **What it does**       Provides access to vetted collective investment
                         opportunities on transparent, fair terms

  **Key features**       8--10% fees vs 9--14% market norm. Priority
                         access for founding investors. Curated, not open
                         crowdfunding.

  **Benefit**            Access to early-stage opportunities normally
                         closed to retail investors. Better economics
                         than alternatives.

  **Status**             Operational. Founding investors get priority
                         allocation.
  ---------------------- ------------------------------------------------

**Unlock Access (EIS Deal-Flow Service)**

  ---------------------- ------------------------------------------------
  **What it is**         A curated EIS deal-flow and portfolio service
                         --- separate from the core platform but
                         integrated with it

  **Four pillars**       Guidance --- Tools --- Access --- Administration

  **Key distinction**    Direct portfolio building, not a fund. Full
                         transparency on all pipeline companies and
                         terms.

  **Transparency note**  Unlock Access raises for its own pipeline
                         companies. This is disclosed openly --- the
                         positioning is transparency, not independence.

  **EIS compliance**     Processed via SeedLegals. Operational. Instant
                         investment process live.
  ---------------------- ------------------------------------------------

**Decumulation Planner**

  ---------------------- ------------------------------------------------
  **What it is**         A planning tool that answers: given my assets,
                         how long will my money last if I spend X per
                         year, and what is the optimal sequence to draw
                         assets to minimise tax and maximise the estate
                         passed to heirs? Technical specification v1.2
                         complete. Prototype build commencing March 2026.

  **Asset classes        Cash, ISA (including flexible ISA), pension
  covered**              (DC/SIPP/workplace), investment property, VCT,
                         EIS, AIM shares. Full UK tax treatment per class
                         including wrapper override rules. IFAs cannot
                         advise on VCT/EIS drawdown sequencing --- this
                         is a structural advice gap Unlock fills.

  **Drawdown             Four strategies: Tax-optimised (minimise income
  strategies**           tax and CGT drag), IHT-optimised (maximise
                         estate passed to heirs), Income-first,
                         Growth-first. Each produces a different asset
                         draw priority order. User selects strategy;
                         platform models all four for comparison.

  **Key modelled         Toggleable: proposed April 2026 BPR cap (£2.5M at
  scenarios**            100%, 50% above) and proposed April 2027 pension
                         IHT inclusion. Trust and gifting: NEFI, CLT
                         7-year rolling window with NRB stacking, PET
                         taper relief schedule. Year-indexed tax
                         parameters for multi-decade plans. 35-year
                         shadow projection always runs alongside user's
                         selected plan horizon.

  **Why no incumbent has Requires lot-level data from the asset register
  built this**           --- which platforms with product conflicts
                         cannot provide without exposing competitor
                         holdings. A platform that earns from
                         recommending products cannot model "draw from
                         your ISA before your pension to preserve BPR
                         exemption on your VCT" without undermining its
                         own revenue model. Structural independence is
                         what makes the Decumulation Planner possible.

  **Build status**       Technical specification v1.2 complete (March
                         2026). Prototype build commencing. The
                         specification has been reviewed for algorithm
                         correctness, edge cases, tax law accuracy (UK
                         2025/26), and implementation feasibility. Source
                         document: Unlock Decumulation Engine Technical
                         Specification v1.2.
  ---------------------- ------------------------------------------------

**9. Pricing**

**Subscription Tiers (Platform)**

  ---------------------- ------------------------------------------------
  **Free**               Basic access. Entry-level portfolio view.
                         Natural upgrade triggers as portfolio complexity
                         grows.

  **Standard ---         Core platform access. Portfolio intelligence,
  £99/month**            scenario simulation, tax modelling.

  **Premium ---          Full platform access. Priority syndicate
  £249/month**           allocation. Adviser-grade outputs.
  ---------------------- ------------------------------------------------

**Syndicate Fees**

8--10% of capital raised per syndicate. Gross margin 90%+. Minimal cost
per syndicate.

**Founding Investor Terms (Platform Access)**

Founding investors receive lifetime premium access at no subscription
cost --- permanently. This is a one-time benefit, never offered after Q1
2027.

**Unit Economics**

  ---------------------- ------------------------------------------------
  **CAC**                £200 (warm introductions, referrals, content)

  **LTV**                £3,000--£3,250 (3--5 year average lifetime)

  **LTV:CAC ratio**      10:1 to 15:1

  **Payback period**     \~3 months at steady state
  ---------------------- ------------------------------------------------

**Future Revenue Streams**

  ---------------------- ------------------------------------------------
  **Challenger Bank      Est. £50M+ addressable. Per-enquiry or licensing
  DD-as-a-Service**      fee.

  **Family Office Wealth Est. £30--84M addressable. Enterprise
  Intelligence**         subscription.

  **White-Label          Institutional. Usage-based + annual licence.
  Reporting & API**      
  ---------------------- ------------------------------------------------

**10. Key Messaging**

**Primary Messages**

-   Private investors deserve the same clarity that institutions take
    for granted.

-   Your wealth is scattered across platforms, advisers, and
    spreadsheets. Unlock brings it together.

-   Every other platform earns from what it sells you. Unlock earns only
    from you.

-   Institutional-grade tools. Without the institutional price or the
    institutional conflicts.

-   Know your complete financial picture before you act --- not after.

**Key Talking Points by Channel**

**Cold Outreach / First Call**

-   EIS/SEIS hook: government schemes that let investors use their
    income tax to buy shares in high-growth companies. 30--50% income
    tax relief, tax-free profits, loss relief covers downside.

-   Most investors' portfolios are correlated. Even pensions. If markets
    fall 30%, fragmented investors are worst hit.

-   Most investors started in the same place --- ISAs, some stocks,
    maybe a property. Unlock is for those who've gone beyond that.

**Demo / Engagement**

-   One platform across all asset classes, providers, and wrappers ---
    for the first time.

-   We model your tax position forward, not just backward.

-   Syndicates at 8--10% vs the 9--14% you pay on crowdfunding
    platforms.

**Decision Stage**

-   Founding investors lock in lifetime access, best valuation, and
    priority deal flow --- permanently.

-   April 6, 2026 IHT rule changes create a genuine structuring
    deadline.

-   25 founding slots by design. This is quality control, not artificial
    scarcity.

**Objection Handling Summary**

  ---------------------- ------------------------------------------------
  **I have an IFA**      IFAs can't advise on individual EIS company
                         investments --- only EIS funds and VCTs. Unlock
                         fills the gap they legally can't.

  **I'm already          Most investors think they're diversified but
  diversified**          hold correlated assets. Unlock shows you what's
                         actually happening across the full picture.

  **Too early-stage for  EIS relief means you're risking 50p on the pound
  me**                   (additional rate) or less. The government
                         underwrites 50% of your downside.

  **I'll wait and see**  Founding terms --- valuation, discount, lifetime
                         access --- are never offered again. Every month
                         you wait is a higher entry price.

  **I don't have time**  Set it up once. Monthly insights. No daily
                         management. One platform, one view.
  ---------------------- ------------------------------------------------

**11. Competitor Analysis**

**Competitive Landscape**

  ---------------------- ------------------------------------------------
  **Nutmeg, Moneyfarm**  Retail robo-advisors. Not designed for
                         sophisticated HNW investors. Limited tax
                         intelligence. Product-driven.

  **Hargreaves Lansdown, Product distribution platforms. Earn from what
  AJ Bell**              they sell. Not independent decision tools. No
                         scenario simulation.

  **Crowdcube, Seedrs**  Retail crowdfunding. High dilution (9--14%
                         fees). Limited tax efficiency tools. No
                         portfolio intelligence.

  **Private banks /      Exclusive and costly. Not scalable. Available
  family offices**       only above £20--50M. Relationship-driven, not
                         tool-driven.
  ---------------------- ------------------------------------------------

**Why Unlock Wins**

-   Only platform with no product conflicts --- earns solely from the
    investor

-   Only platform with UK tax intelligence modelled forward in real time
    (EIS, SEIS, CGT, IHT, pensions)

-   Institutional-grade scenario simulation at consumer-accessible cost

-   Syndicate access at better economics than crowdfunding (8--10% vs
    9--14%)

-   The regulatory moat (UK tax complexity) takes 18--24 months minimum
    to replicate correctly

**Competitive Fee Comparison**

  -------------------------- ---------------------- ---------------------
  **Platform**               **Typical Fees**       **Investor
                                                    Alignment**

  Private Banks              1--2% AUM +            Weak --- earns from
                             performance fees       AUM, not outcomes

  Crowdfunding               9--14% of funds raised Weak --- earns from
  (Crowdcube/Seedrs)                                deal volume

  Wealth Platforms (Nutmeg   0.4--1% AUM            Weak --- product
  etc.)                                             distribution

  Unlock                     £99--£249/month +      Strong --- aligned
                             8--10% syndicate fees  with investor success
                             only                   
  -------------------------- ---------------------- ---------------------

**12. Regulatory & Compliance**

**EIS / SEIS Overview**

  ---------------------- ------------------------------------------------
  **EIS Income Tax       30% of investment value claimable against income
  Relief**               tax

  **SEIS Income Tax      50% of investment value claimable against income
  Relief**               tax

  **CGT exemption**      Profits from qualifying companies are tax-free
                         on exit

  **Loss relief**        If the company fails, further relief reduces net
                         loss significantly

  **IHT exemption**      EIS/SEIS shares qualify for Business Property
                         Relief --- exempt from IHT after 2 years

  **April 6, 2026        IHT relief on EIS/SEIS capped at 100% up to £2.5M
  change**               per individual, 50% above. Creates genuine
                         planning urgency.
  ---------------------- ------------------------------------------------

**Investment Structure**

  ---------------------- ------------------------------------------------
  **Instrument**         Instant Investment via SeedLegals, as part of
                         Unlock Access

  **Platform**           SeedLegals (used in 33% of UK rounds)

  **EIS compliance**     Processed at founding investor stage.
                         Operational. Instant investment process live.

  **Share issuance**     April 6, 2026 --- protects founding investors
                         from dilution during Growth Capital round

  **Anti-dilution**      Ownership % guaranteed until Series A
  ---------------------- ------------------------------------------------

**IFA Advice Gap Note**

IFAs cannot advise on individual EIS company investments --- only EIS
funds and VCTs. This is a structural feature of UK financial regulation,
not a limitation of Unlock. It means sophisticated investors evaluating
direct EIS opportunities have no regulated adviser to turn to. Unlock
fills exactly this gap with intelligence tools and due diligence
support.

**13. Financial Summary**

**Revenue Projections**

  --------------- --------------- ------------- ----------------- ----------------
  **Year**        **2026**        **2027**      **2028**          **2029**

  Revenue         \~£1.4M         \~£3.0M       \~£5.0M           £8.25M--£9.25M

  *Notes*         *Beta + early   *Public       *Subscription +   *Mature ARR*
                  syndicates*     launch*       syndicate growth* 
  --------------- --------------- ------------- ----------------- ----------------

**Exit Strategy**

  ---------------------- ------------------------------------------------
  **Strategic M&A**      Named acquirers: Bloomberg, Morningstar,
                         Refinitiv, Crowdcube, S&P Global. Valuation
                         range £20--50M.

  **IPO pathway**        At £20M+ ARR with 10k+ subscribers. Potential
                         valuations £50M--£100M+.

  **PE Buyout**          Fintech PE at ARR multiples --- 7--10x for
                         profitable SaaS.

  **Base case timeline** 5--10x returns within 3--5 years.
  ---------------------- ------------------------------------------------

**14. FAQs**

Compiled from objection handling in the Agent Playbook and investor Q&A
patterns across Pack 1, Pack 2, and call scripts.

**About Unlock**

**What is Unlock?**

Unlock is a portfolio intelligence and investment access platform for UK
private investors with £1M--£20M+ in total wealth. It consolidates
multi-asset portfolios into a single view, models tax decisions forward
in real time, and provides access to vetted investment opportunities at
transparent fees.

**How is Unlock different from Hargreaves Lansdown or Nutmeg?**

HL and Nutmeg are product distribution platforms --- they earn from what
they sell you. Unlock has no products to sell. It earns only from
subscriptions and syndicate participation fees. Every existing platform
has a conflict of interest. Unlock does not.

**Is Unlock FCA regulated?**

Unlock operates within FCA and EIS/SEIS compliance frameworks. EIS
compliance is processed via SeedLegals, the UK's leading EIS/SEIS
platform used in 33% of UK rounds.

**About EIS / SEIS**

**What is EIS?**

The Enterprise Investment Scheme is a UK government programme that
provides significant tax reliefs to investors in qualifying early-stage
companies: 30% income tax relief, CGT-free profits on exit, loss relief,
and IHT exemption after 2 years.

**Can my IFA advise me on this?**

IFAs are not permitted to advise on individual EIS company investments
--- only on EIS funds and VCTs. This is a structural feature of UK
regulation. Unlock provides the intelligence tools and due diligence
support that fill this gap.

**What is the April 2026 IHT change?**

From April 6, 2026, IHT relief on EIS/SEIS investments is capped at 100%
up to £2.5M per estate, with 50% relief on amounts above that
threshold. Investors planning to use EIS/SEIS for IHT mitigation need to
structure investments before this date to maximise relief.

**About Investing in Unlock**

**What instrument is used?**

Unlock Access uses an Instant Investment structure via SeedLegals,
providing immediate EIS relief processing and anti-dilution protection
until Series A.

**When are shares issued?**

April 6, 2026. This date is fixed to protect founding investors from
dilution during the Growth Capital round, and aligns with the IHT rule
changes.

**What are the founding investor terms?**

£1.2M raise at £6.5M pre-money valuation. \~25 investors. Lifetime
premium platform access. Priority syndicate allocation. White-glove
onboarding. Quarterly reporting and direct founder access. Investor
network events.

**15. Benefits Per Service**

Consolidated from Pack 1, App Walkthrough, Feature Functions, and
investor documents. Each service is described with its core features and
the specific investor benefit.

**1. Asset Register**

  ---------------------- ------------------------------------------------
  **What it is**         The single source of financial truth. A
                         permanent, accurate record of everything an
                         investor owns across all accounts, platforms,
                         wrappers, and family members.

  **Core features**      Lot-level tracking (date, units, price paid per
                         purchase). Cost basis evolution to current
                         value. Income tracking (dividends, interest,
                         coupons) with routing visibility. Document
                         linkage (statements, contract notes,
                         valuations). Household view across people,
                         wrappers, and entities. Date-freeze for
                         IHT/probate valuations. Plain language queries.

  **Investor benefit**   Know exactly what you own, what it cost, what
                         it's worth, and what it's doing --- across every
                         asset class in one place. No spreadsheets. No
                         reconstruction. One source of truth that
                         compounds in value as the dataset grows.

  **Who benefits most**  All three personas. Foundation of every other
                         service. Particularly high value for Legacy
                         Builders (IHT date-freeze, succession
                         documentation) and Preservers (hidden
                         correlation exposure).
  ---------------------- ------------------------------------------------

**2. Onboarding & Safety Lights**

  ---------------------- ------------------------------------------------
  **What it is**         A structured assessment that gives investors a
                         clear picture of how safe their portfolio is
                         today, what a better target allocation looks
                         like, and a realistic tax-aware transition plan.

  **Core features**      Red/amber/green safety checks on concentration,
                         liquidity, and cash runway. Belief-informed
                         scenario tilt (growth, inflation, interest
                         rates, currency) without overriding safety
                         signals. Target allocation vs current holdings
                         comparison. CGT-aware transition plan spread
                         across tax years. Wrapper optimisation
                         recommendations including Bed & ISA where
                         appropriate.

  **Investor benefit**   Know within minutes whether your portfolio has
                         structural problems --- too concentrated, too
                         illiquid, too little cash. Get a credible path
                         to a better allocation that accounts for your
                         actual tax position, not a generic model
                         portfolio.

  **Who benefits most**  Preservers (safety and risk control). Growth
                         Seekers who want to understand their starting
                         position before deploying capital. Any investor
                         making a significant reallocation.
  ---------------------- ------------------------------------------------

**3. Portfolio Simulator**

  ---------------------- ------------------------------------------------
  **What it is**         Scenario testing and stress modelling grounded
                         in the investor's actual positions. Models what
                         happens to a real portfolio under defined
                         conditions --- not a hypothetical model
                         portfolio.

  **Core features**      30+ downside scenario models (markets crash 30%,
                         interest rates spike, property falls,
                         stagflation). Macro belief integration (growth,
                         inflation, rates, currency, credit). Upside vs
                         downside comparison. Consistent with asset
                         register --- all insights are traceable to
                         actual positions.

  **Investor benefit**   Make decisions based on modelled outcomes, not
                         gut instinct. See how your specific portfolio
                         holds up before a crash happens --- not after.
                         Know your actual risk before committing capital.

  **Who benefits most**  Preservers (stress-testing defensive
                         strategies). Growth Seekers (comparing upside vs
                         downside before committing). Any investor
                         considering a significant new position.
  ---------------------- ------------------------------------------------

**4. Tax Intelligence Engine**

  ---------------------- ------------------------------------------------
  **What it is**         Real-time, forward-looking modelling of all UK
                         tax interactions across EIS, SEIS, CGT, IHT,
                         pension drawdown, and AIM BPR --- with
                         continuous HMRC rule-tracking. This is Unlock's
                         core defensive moat.

  **Core features**      EIS/SEIS relief tracking and optimisation. CGT
                         crystallisation timing and deferral modelling.
                         IHT planning and inheritance scenario modelling.
                         Pension drawdown sequencing. AIM BPR eligibility
                         tracking. Year-end tax planning --- stops being
                         a reconstruction exercise.

  **Investor benefit**   This is what HNW investors pay accountants and
                         advisers for --- modelled inside the platform,
                         forward-looking, and grounded in actual
                         holdings. See exactly how timing and structure
                         decisions save or cost you money before you make
                         them.

  **Who benefits most**  Legacy Builders (IHT and EIS/SEIS planning).
                         Growth Seekers with EIS/SEIS exposure. Any
                         investor approaching year-end or making
                         significant disposals.
  ---------------------- ------------------------------------------------

**5. Reports & Adviser Packs**

  ---------------------- ------------------------------------------------
  **What it is**         Structured summaries generated from the asset
                         register --- not rebuilt manually each time.
                         Professional-grade outputs for tax returns,
                         probate, and adviser meetings.

  **Core features**      Know Your Situation (KYS) packs formatted for
                         IFAs, accountants, and solicitors. Tax return
                         preparation summaries. Probate and IHT valuation
                         reports. Portfolio performance reports with
                         lot-level attribution. Shareable, adviser-grade
                         format.

  **Investor benefit**   Walk into any adviser meeting with a complete,
                         structured picture of your portfolio. Stop
                         spending hours pulling together data for your
                         accountant at year-end. Have the documentation
                         needed for probate or IHT instantly available.

  **Who benefits most**  Legacy Builders (probate, succession, IHT). Any
                         investor working with IFAs, accountants, or
                         solicitors. Investors approaching year-end or
                         managing a significant estate.
  ---------------------- ------------------------------------------------

**6. Syndicate Access**

  ---------------------- ------------------------------------------------
  **What it is**         Curated access to vetted collective investment
                         opportunities typically available only to
                         institutional investors or larger funds --- on
                         transparent, fair terms.

  **Core features**      8--10% fees vs 9--14% crowdfunding market norm.
                         Founding investor priority allocation.
                         Integrated with portfolio view --- new positions
                         modelled within existing risk framework before
                         commitment. Community of serious investors
                         evaluating deals together.

  **Investor benefit**   Access early-stage opportunities previously
                         closed to retail investors, at better economics
                         than the alternatives. See how any new position
                         fits within your existing portfolio before
                         committing --- not after.

  **Who benefits most**  Growth Seekers (deal flow, upside access).
                         Legacy Builders using EIS/SEIS for IHT planning.
                         Entrepreneurs with barbell portfolios seeking
                         early-stage allocation.
  ---------------------- ------------------------------------------------

**7. Unlock Access (EIS Deal-Flow Service)**

  ---------------------- ------------------------------------------------
  **What it is**         A curated EIS deal-flow and portfolio service.
                         Direct portfolio building --- not a fund.
                         Investors build their own EIS portfolio from
                         Unlock's curated pipeline, with full visibility
                         at every stage.

  **Four pillars**       Guidance --- Tools --- Access --- Administration

  **Investment process** Instant Investment via SeedLegals. EIS
                         compliance processed at point of investment.
                         Immediate relief processing. Anti-dilution
                         protection until Series A.

  **Transparency note**  Unlock Access raises for its own pipeline
                         companies. This is stated openly. Positioning is
                         full transparency and disclosure --- not
                         independence claims.

  **Investor benefit**   Build a direct, curated EIS portfolio with full
                         visibility --- not through a fund where you
                         can't see the underlying companies. EIS
                         compliance handled end-to-end. No paperwork
                         burden.

  **Who benefits most**  Legacy Builders using EIS for IHT mitigation.
                         Growth Seekers wanting direct early-stage
                         exposure. Any investor wanting to build an EIS
                         portfolio without fund fees or opacity.
  ---------------------- ------------------------------------------------

**16. SWOT Analysis**

Consolidated from the Play to Win Strategy Workshop, Risk Factors (Pack
2 structure), Competitive Analysis, and Business Plan. Honest assessment
of Unlock's current position.

**Strengths**

  ---------------------- ------------------------------------------------
  **No product           Earn only from subscriptions and syndicate fees.
  conflicts**            Every incumbent --- Hargreaves Lansdown, Nutmeg,
                         Crowdcube --- has a product conflict. This is
                         Unlock's identity, not just a positioning claim.
                         Structurally impossible for a product platform
                         to replicate without dismantling its business
                         model.

  **UK tax regulatory    EIS, SEIS, CGT, IHT, pension drawdown, AIM BPR
  moat**                 --- continuous HMRC rule-tracking. 18--24 months
                         minimum to replicate correctly. No comparable
                         jurisdiction has this regulatory density.
                         Decided capability, fully funded by this raise.

  **Lot-level data       Every investor builds a proprietary dataset:
  flywheel**             lot-level cost basis, holding periods, tax
                         interactions. Unlock owns this data. It
                         compounds in value over time and is impossible
                         to replicate retrospectively. The longer a user
                         stays, the harder it is to leave.

  **Validated market     40+ market interviews completed. 70% of surveyed
  demand**               investors said they would pay for better
                         portfolio tools. Functional pre-alpha in active
                         use for live demos. Weekly user sessions
                         validating usability. Demand confirmed for asset
                         register and tax intelligence specifically.

  **Credible founding    Backing from former chairman of Barclays and
  investor backing**     director general of TISA. Founding investor
                         commitments active. This is proof of concept in
                         the target segment --- HNW investors who
                         understand the problem are putting money in.

  **Proprietary HNW      30,000+ UK HNW investor profiles. Direct
  database**             outreach channel that does not depend on paid
                         acquisition. Founding round is being closed
                         through this database. This is a structural
                         distribution advantage competitors cannot buy.

  **Clear segment        £1M--£20M total wealth. Below £1M: insufficient
  focus**                complexity. Above £20--50M: family offices
                         exist. The segment is under-served,
                         well-defined, and large enough to build a
                         significant business. No competitor is squarely
                         positioned here.
  ---------------------- ------------------------------------------------

**Weaknesses**

  ---------------------- ------------------------------------------------
  **Pre-launch,          Public launch targeted Q1 2027. Revenue at
  pre-revenue at scale** founding stage is pre-scale. Current build:
                         founding-stage desktop application with
                         automated data collection live for founding
                         investors. Decumulation Planner specification
                         complete, prototype commencing. The platform's
                         full capability is not yet live --- this is the
                         typical risk profile for a seed-stage technology
                         company, mitigated by working product in use,
                         complete technical specifications, and a
                         credible milestone roadmap.

  **Founder-led trust    Tom conducts all demos at this stage.
  dependency**           Credibility cannot yet be delegated. This is by
                         design for the founding round (25 slots, quality
                         over volume), but it creates a scaling
                         constraint that must be resolved before Growth
                         Capital round outreach at volume.

  **Automated data       Multi-asset data integration (ISA platforms,
  connections not yet    broker accounts, pension providers, property
  live**                 registries) is on the roadmap. Manual lot-level
                         entry is operational for founding investors via
                         white-glove onboarding. Full automation requires
                         additional build time and funding.

  **No testimonials      Pre-launch. Social proof from live platform
  yet**                  users does not yet exist. Founding investor
                         commitments and senior-level backing partially
                         compensate, but user testimonials and case
                         studies are unavailable until post-launch. This
                         is expected and temporary.

  **Series A             Full platform build and Growth Capital ambitions
  dependency**           require follow-on funding. Failure to raise
                         Series A would constrain growth trajectory.
                         Mitigated by: break-even projected at Year 2 ARR
                         (£3M), strong unit economics (LTV:CAC 10--15:1),
                         and a realistic pathway to profitability without
                         Series A.
  ---------------------- ------------------------------------------------

**Opportunities**

  ---------------------- ------------------------------------------------
  **April 2026 IHT rule  IHT relief on EIS/SEIS capped at 100% up to £2.5M
  changes**              per individual from April 6, 2026. Creates
                         genuine urgency for HNW investors to structure
                         portfolios now. Unlock's tax intelligence engine
                         and Unlock Access are directly positioned to
                         help investors navigate this deadline.

  **IFA advice gap**     IFAs cannot advise on individual EIS company
                         investments --- only EIS funds and VCTs. This is
                         regulatory, structural, and permanent. Unlock
                         fills exactly this gap. IFAs are potential
                         distribution partners (referring clients who
                         need tools they can't provide), not competitors.

  **AI cost curve**      AI now enables institutional-grade portfolio
                         analysis at consumer cost. What used to require
                         a dedicated team or a £5,000+/year adviser
                         relationship is now buildable at scale. Unlock
                         benefits from this shift structurally --- early
                         AI-led reporting reduces unit cost as user base
                         grows.

  **Adviser network as   IFAs, accountants, and solicitors refer HNW
  distribution**         clients who need tools they cannot legally
                         provide. KYS packs formatted for adviser use
                         make Unlock a complement to professional advice,
                         not a threat. This channel is low-CAC and
                         high-trust when activated at scale.

  **Institutional        Challenger banks (DD-as-a-Service, est. £50M+
  white-label            addressable), family offices (est. £30--84M
  expansion**            addressable), and institutional white-label
                         (usage-based + licence) represent expansion
                         revenue streams post-Series A. These are
                         post-launch opportunities, not distractions from
                         the founding phase.

  **Geographic           English-speaking common law jurisdictions
  expansion**            post-Series A: Ireland, Australia, Canada,
                         Singapore. Australia may move earlier than the
                         current sequencing assumes. UK regulatory
                         complexity is the moat --- the geographic
                         expansion thesis holds once domestic market
                         position is established.
  ---------------------- ------------------------------------------------

**Threats**

  ---------------------- ------------------------------------------------
  **Incumbent response** Large platforms (Hargreaves Lansdown,
                         Interactive Investor) could attempt to add
                         portfolio intelligence features. Mitigated by:
                         their product conflict makes genuine
                         independence impossible; UK tax complexity takes
                         18--24 months minimum to build correctly; the
                         data flywheel advantages early movers.

  **FCA / EIS rule       HMRC or FCA changes to EIS/SEIS rules, AML/KYC
  changes**              requirements, or data protection regulations
                         could affect the tax intelligence engine or
                         investor eligibility. The platform is designed
                         for continuous HMRC rule-tracking --- regulatory
                         change is built into the operating model, not an
                         afterthought.

  **Slower HNW adoption  HNW investors are cautious. Trust takes time to
  than forecast**        build. If adoption is 20% slower than projected,
                         break-even shifts to Year 3 rather than Year 2,
                         but the business remains viable. The freemium
                         model provides a lower-friction entry point that
                         reduces adoption risk.

  **Market downturn      A significant market downturn could reduce
  reducing investor      appetite for early-stage investing and
  appetite**             alternative assets. Counter-intuitively,
                         portfolio stress-testing and downside scenario
                         modelling become more valuable in a downturn ---
                         risk management tools tend to attract users when
                         markets fall.

  **Data accuracy and    A platform handling sensitive financial data for
  cybersecurity**        HNW investors must maintain high standards of
                         data accuracy, uptime, and cybersecurity. A
                         breach or data error in a portfolio of this
                         complexity would be reputationally damaging.
                         This is a standard technology risk, managed
                         through architecture decisions and security
                         investment.
  ---------------------- ------------------------------------------------

**17. Glossary**

Terms used across Unlock documents, investor materials, and internal
communications. Grouped by category.

**Tax & Regulatory**

  ------------------ ----------------------------------------------------
  **Term**           **Definition**

  **EIS**            Enterprise Investment Scheme. UK government
                     programme providing 30% income tax relief on
                     investments up to £1M/year in qualifying early-stage
                     companies, CGT exemption on profits, loss relief,
                     and IHT exemption after 2 years.

  **SEIS**           Seed Enterprise Investment Scheme. UK government
                     programme providing 50% income tax relief on
                     investments up to £200K/year in qualifying
                     seed-stage companies. Higher relief than EIS;
                     available only to earlier-stage companies.

  **CGT**            Capital Gains Tax. UK tax on profit made when
                     disposing of an asset that has increased in value.
                     Unlock's tax intelligence engine models CGT
                     crystallisation timing and deferral opportunities
                     across all holdings.

  **IHT**            Inheritance Tax. UK tax on the estate of a deceased
                     person above the nil-rate band (£325K). EIS and SEIS
                     shares qualify for Business Property Relief and are
                     exempt from IHT after 2 years. From April 6, 2026,
                     this relief is capped at 100% up to £2.5M per
                     individual (50% above that threshold).

  **AIM BPR**        AIM (Alternative Investment Market) Business
                     Property Relief. Shares in qualifying AIM-listed
                     companies held for 2+ years may qualify for 100%
                     relief from IHT. Tracked by Unlock's tax
                     intelligence engine.

  **Bed & ISA**      The process of selling shares held in a general
                     investment account and immediately repurchasing them
                     within an ISA wrapper, sheltering future gains from
                     CGT. Recommended by Unlock's onboarding tool where
                     appropriate.

  **Loss Relief**    Under EIS/SEIS, if the company fails, investors can
                     claim loss relief against income tax or CGT. For an
                     additional-rate taxpayer investing £50K under SEIS:
                     effective net loss is approximately £11.25K after
                     all reliefs. Correctly stated as "risking
                     approximately 22p in the pound" (not 20p, which
                     applies only under specific conditions).

  **FCA**            Financial Conduct Authority. UK financial services
                     regulator. Unlock operates within FCA-aligned
                     practices. IFAs are FCA-regulated and cannot advise
                     on individual EIS company investments --- only EIS
                     funds and VCTs.

  **VCT**            Venture Capital Trust. A UK listed company that
                     invests in early-stage businesses. IFAs can advise
                     on VCTs (unlike direct EIS investments). VCT
                     investors do not own shares directly in underlying
                     companies --- this is the key distinction from
                     Unlock Access's direct portfolio approach.
  ------------------ ----------------------------------------------------

**Investment Terms**

  ------------------- ----------------------------------------------------
  **Term**            **Definition**

  **Instant           The investment instrument used by Unlock Access,
  Investment**        processed via SeedLegals. Enables immediate EIS
                      compliance processing, anti-dilution protection
                      until Series A, and a streamlined digital signing
                      process. Always use "Instant Investment" --- not
                      "ASA" or "SAFE" --- in all Unlock materials.

  **Pre-money         The value of a company before new investment capital
  valuation**         is received. Unlock's founding round pre-money
                      valuation is £6.5M. Post-money valuation =
                      pre-money + capital raised.

  **Anti-dilution**   Protection that prevents an early investor's
                      ownership percentage from being reduced by
                      subsequent funding rounds. Founding investors'
                      ownership percentage is guaranteed until Series A
                      via the Instant Investment structure.

  **Syndicate**       A collective investment vehicle where multiple
                      investors pool capital to participate in a single
                      opportunity. Unlock syndicates charge 8--10% fees vs
                      the 9--14% typical of crowdfunding platforms.

  **SPV**             Special Purpose Vehicle. A legal entity created
                      specifically to hold a single investment, used to
                      pool multiple investors into one cap table entry.
                      Often used in syndicate structures.

  **Pro-rata rights** The right of an existing investor to participate in
                      future funding rounds to maintain their ownership
                      percentage. Founding investors have pro-rata rights
                      to participate in the Growth Capital round.

  **Series A / B /    Sequential priced funding rounds following seed
  C**                 stage. Series A (typically £2--10M): first
                      institutional round, product-market fit established.
                      Series B: scaling round. Series C+: growth and
                      pre-exit. Unlock's Series A is targeted for Q1 2027
                      post public launch.

  **SeedLegals**      UK legal and investment platform used in
                      approximately 33% of UK funding rounds. Processes
                      Unlock's Instant Investment agreements and EIS/SEIS
                      compliance. Provides a standardised digital signing
                      process.
  ------------------- ----------------------------------------------------

**Financial & Business Metrics**

  ------------------ ----------------------------------------------------
  **Term**           **Definition**

  **ARR**            Annual Recurring Revenue. The annualised value of
                     subscription contracts. Key SaaS health metric.
                     Unlock projections: \~£1.4M (2026), \~£3.0M (2027),
                     \~£5.0M (2028), £8.25--9.25M (2029).

  **CAC**            Customer Acquisition Cost. The total cost to acquire
                     one paying customer. Unlock CAC (paid user): £200,
                     driven by warm introductions, referrals, and content
                     rather than paid advertising.

  **LTV**            Lifetime Value. The total revenue generated from a
                     single customer over their relationship with the
                     business. Unlock LTV (paid user): £3,000--3,250
                     (3--5 year average lifetime). LTV:CAC ratio of
                     10--15:1.

  **Churn**          The percentage of paying customers who cancel their
                     subscription in a given period. Unlock model: 5%
                     monthly Year 1--2, declining to 3% by Year 4--5 as
                     the data flywheel increases switching cost.

  **Freemium**       A pricing model where basic access is free with
                     natural upgrade triggers as portfolio complexity
                     grows. Unlock's free tier provides entry-level
                     portfolio view; paid tiers (£99 and £249/month)
                     unlock full capabilities. Reduces adoption friction
                     for HNW investors new to the platform.

  **AUM**            Assets Under Management. The basis on which
                     traditional wealth managers and platforms (e.g.
                     Hargreaves Lansdown, Nutmeg) typically charge fees
                     --- a percentage of the total portfolio value.
                     Unlock does not charge on AUM. This is a deliberate
                     structural difference that eliminates a core
                     conflict of interest.
  ------------------ ----------------------------------------------------

**Platform Terminology**

  ------------------ ----------------------------------------------------
  **Term**           **Definition**

  **Lot-level        Decomposing a holding into its individual purchase
  tracking**         transactions ("lots"), each with its own date,
                     number of units, price paid, and associated costs.
                     Foundation of accurate cost basis calculation, CGT
                     modelling, and holding period tracking. Technically
                     hard to implement correctly; operationally live for
                     founding investor onboarding.

  **Cost basis**     The original value of an asset for tax purposes ---
                     typically the purchase price plus associated costs.
                     Determines the taxable gain on disposal. Unlock
                     tracks cost basis at lot level, making CGT
                     calculations accurate and defensible.

  **KYS pack**       Know Your Situation pack. Unlock's structured
                     portfolio summary report, formatted for use in
                     meetings with IFAs, accountants, and solicitors.
                     Generated from the asset register --- not rebuilt
                     manually. Adviser-grade output.

  **Safety lights**  Unlock's red/amber/green portfolio health checks in
                     the onboarding tool. Flags structural issues: too
                     little cash or liquidity runway, excessive
                     concentration in a single asset, or too much in
                     illiquid or hard-to-value holdings. Explained in
                     plain English with specific levers.

  **White-glove      A fully personal onboarding process where the
  onboarding**       founding team sets up the investor's portfolio with
                     their actual holdings, runs initial scenario
                     analysis, and delivers a customised portfolio
                     report. Provided to all founding investors as a
                     permanent benefit. Transitions to self-serve after
                     public launch.

  **Unlock Access**  The curated EIS deal-flow and portfolio service,
                     operating alongside the core Unlock platform. Four
                     pillars: Guidance, Tools, Access, Administration.
                     Direct portfolio building --- not a fund. Raises for
                     its own pipeline companies, disclosed transparently.
                     Investment processed via Instant Investment on
                     SeedLegals.

  **Data flywheel**  A compounding competitive advantage where each
                     user's data (lot-level cost basis, holding periods,
                     tax interactions) increases the platform's
                     intelligence and the user's switching cost over
                     time. The longer an investor uses Unlock, the harder
                     it becomes to leave --- their entire financial
                     history lives in the platform.

  **Accumulation**   The phase of an investor's lifecycle where the
                     primary objective is growing wealth --- building
                     positions, compounding returns, and increasing
                     portfolio value. Typically characterised by regular
                     contributions, higher risk tolerance, and longer
                     investment horizons. Unlock's Growth Seeker and
                     early-stage Legacy Builder personas are primarily in
                     accumulation. The platform's portfolio simulator,
                     syndicate access, and tax intelligence tools are all
                     directly relevant to accumulation-phase decisions.

  **Decumulation**   The phase where the investor transitions from
                     growing wealth to systematically drawing on it ---
                     funding income, meeting liabilities, managing estate
                     transfer, and preserving capital for heirs. The
                     primary concern shifts from return maximisation to
                     sequencing: which assets to liquidate first, in what
                     order, and with what tax impact. As investors age,
                     Unlock's value shifts from accumulation tools to
                     decumulation intelligence: liquidation sequencing,
                     income planning, pension drawdown modelling, and
                     estate transfer. No incumbent has built this
                     capability across all UK asset classes (ISA,
                     pension, VCT, EIS, AIM, property) simultaneously.
                     Unlock's Decumulation Planner technical
                     specification (v1.2) is complete. Prototype build
                     commencing March 2026. The spec covers full UK tax
                     matrix per asset class, four drawdown strategies
                     (tax-optimised, IHT-optimised, income-first,
                     growth-first), trust and gifting logic including
                     NEFI, CLT and PET mechanics, toggleable scenarios
                     for proposed April 2026 BPR cap and April 2027
                     pension IHT changes, and a year-indexed tax
                     parameter schedule for multi-decade plans.

  **Drawdown         The tactical decision of which accounts or asset
  sequencing**       types to access first when drawing income in
                     retirement or decumulation --- for example, drawing
                     from GIA before ISA to preserve tax-sheltered
                     growth, or from pension last to defer IHT exposure.
                     Sequencing errors are costly and largely
                     irreversible. Unlock's tax intelligence engine
                     models drawdown sequencing decisions across all
                     account types simultaneously, accounting for each
                     investor's actual holdings, tax position, and
                     intended timeline.
  ------------------ ----------------------------------------------------

**18. Content Assets --- Whitepapers**

The following whitepaper is included as a standalone content asset
within this bank. It serves as thought leadership, investor education
material, and a demonstration of Unlock's subject-matter authority on
EIS investing.

  ---------------------- ------------------------------------------------
  **Title**              The Case for EIS: Why UK Private Investors
                         Should Take Enterprise Investment Schemes
                         Seriously

  **Purpose**            Thought leadership. Investor education.
                         Top-of-funnel content for HNW audience.

  **Status**             Complete. Standalone document.

  **Audience**           HNW investors considering EIS for the first
                         time, or those already using EIS who want a
                         rigorous framework

  **Key themes**         EIS mechanics and tax relief. Risk/reward
                         framing. IHT interaction. April 2026 rule
                         changes. How to build a direct EIS portfolio vs
                         fund route.
  ---------------------- ------------------------------------------------

19\. Dos and Don'ts: Terminology & Content Rules

This section is the authoritative reference for terminology, framing,
and content rules across all Unlock investor and marketing materials.
Any AI agent, copywriter, or document builder working from this content
bank must follow these rules without exception. When in doubt, this
section overrides any other instruction.

19.1 Investment Instrument Terminology

**RULE: The investment instrument is called "Instant Investment".
Always. In every document.**

  ---------------- ------------------------ -------------------------------
  **Context**      **Use This**             **Never Use**

  **Investment     ✔ Instant Investment     ✘ ASA / Advanced Subscription
  instrument                                Agreement / SAFE
  name**                                    

  **Unlock Access  ✔ Administration         ✘ Execution
  fourth pillar**                           

  **EIS            ✔ EIS3                   ✘ EIS13
  certificate                               
  reference**                               

  **Investor type  ✔ Founding investor      ✘ Seed investor / early
  label**                                   investor / angel investor

  **Discount       ✔ "Negotiated            ✘ Publishing specific % tiers
  tiers**          individually based on    in any document
                   strategic value"         

  **Decumulation   ✔ "Specification         ✘ "Live" / "Available" /
  Planner status** complete. Prototype      "Launching soon"
                   build commencing."       

  **EIS loss risk  ✔ State bracket:         ✘ "20p on the pound" / "30p in
  framing**        "\~27.5p per £           the pound" (as if universal)
                   (additional rate)"       

  **Unlock Access  ✔ "Full transparency.    ✘ "Independent" (for Unlock
  independence     Unlock Access raises for Access specifically)
  claim**          its own pipeline         
                   companies. This is       
                   stated openly."          

  **Scarcity       ✔ "\~25 slots by design. ✘ "Only 3 slots remaining!" /
  framing (25      Quality control, not     manufactured countdown urgency
  slots)**         artificial scarcity."    
  ---------------- ------------------------ -------------------------------

19.2 Stage and Status Language

The platform is founding-stage and pre-public-launch. Status language
must match actual development stage at time of writing. Use the approved
phrases below. Do not invent alternatives.

  ------------------ ------------------------ ----------------------------
  **Feature /        **Approved phrase**      **Do not say**
  Status**                                    

  **Asset Register** Operational for founding Live / Available to all
                     investor onboarding      users / Fully launched

  **Tax Intelligence Decided capability. In   Live / Available / You can
  Engine / Portfolio active development. Full use this today
  Simulator**        build funded by this     
                     raise.                   

  **Decumulation     Specification complete   Live / Available / Launching
  Planner**          (v1.2, March 2026).      soon / In beta
                     Prototype build          
                     commencing.              

  **Public launch    Public launch targeted   Launching soon / Coming soon
  date**             Q1 2027                  / Almost ready
  ------------------ ------------------------ ----------------------------

19.3 Tone and Framing Rules

  ----------------------------------- -----------------------------------
  **✔ DO**                            **✘ DON'T**

  State genuine urgency: April 2026   Manufacture urgency with countdown
  IHT deadline, valuation step-up,    clocks, "only X slots left!", or
  share issuance date                 false deadlines

  Describe IFAs as structural         Call IFAs a "limitation" or
  partners, not competitors. They     position them as the problem. The
  fill an adjacent role.              advice gap is structural
                                      regulation, not their failure.

  State risks honestly in Pack 2.     Bury, minimise, or omit risks.
  Mitigations follow each risk.       Sophisticated investors notice
                                      omissions.

  Frame financial projections as      Present revenue projections as
  "management estimates" or           guaranteed or as "targets we will
  "forward-looking projections".      hit".

  Frame Tom's dual-founder role       Hedge, apologise for, or downplay
  (Unlock + Cloudworkz) as a          the dual-founder role as a conflict
  structural advantage with a clear   or distraction.
  rationale.                          

  Use exclamation marks sparingly     Use "game-changing",
  (zero in investor documents).       "revolutionary", "disruptive",
                                      "world-class", or any
                                      unsubstantiated superlative.
  ----------------------------------- -----------------------------------

**How to use this section: Before sending any document to an investor or
publishing any content, run a check against Sections 19.1--19.3. If a
term, phrase, or status claim does not appear in the "Use This" or "DO"
column, do not use it.**

*--- END OF CONTENT BANK ---*

Unlock \| Content Bank \| March 2026 \| Version 3.0


---

<!-- END OF DOCUMENT -->

## 19-Persona Suitability Guide
*Tier 1 — Full 19-persona framework with signals, pain points, objections, tiering*

---

# UNLOCK INVESTOR PERSONAS: SUITABILITY GUIDE & CALLING REFERENCE
## Campaign Framework for 19-Persona Investor Database

**Document Version:** 1.0  
**Created:** November 17, 2025  
**Purpose:** Rapid persona identification + message customization for agent calls  
**Audience:** Tom, agents, CRM admin, campaign coordinator

---

## EXECUTIVE SUMMARY

Unlock's platform solves portfolio **fragmentation and visibility** for self-directed, independent-minded investors with £250K–£5M+ portfolios who manage diverse assets (property, tech, alternatives, traditional).

**Core Unlock User Profile:**
- Self-directed or advisor-informed (not advisor-dependent)
- Manages 5+ asset classes or complex holdings
- Interested in tax optimization, risk modeling, or alternatives access
- Frustrated by lack of consolidated visibility
- Willing to pay for institutional-grade intelligence

This guide maps 19 investor personas against Unlock fit, providing:
1. **Tier 1-3 classification** (priority ranking)
2. **Quick-ID signals** (how to spot them on calls)
3. **Pain point alignment** (what frustrates them)
4. **Message customization** (what to emphasize)
5. **Objection rebuttals** (how to reframe misalignment)

---

## PART 1: TIER 1 PERSONAS (HIGHEST PRIORITY)
### Target these first: Excellent fit + proven conversion

---

### **P005: The Legacy Builder** â­â­â­â­â­

**Profile:**
- Portfolio: £2.4M (HNW tier)
- Age: 40–65
- Approach: Self-directed
- Risk: Moderate
- Key drives: Intergenerational wealth transfer, IHT mitigation, estate planning

**Why Perfect Fit:**
- Unlock core: Tax + multi-asset consolidation + alternatives visibility
- EIS/SEIS integration directly addresses their April 6, 2026 planning window
- Intergenerational structures need unified portfolio view
- High-value transactions (£1M–£3M) justify platform subscription

**On-Call Signals:**
- Mentions: "building wealth for the next generation," "trust structures," "property + investments across different places," "tax efficient," "IHT concerned"
- Portfolio composition: 50% property, 30% tech, 40% alternatives—truly fragmented

**Pain Points to Probe:**
1. "How do you currently view your entire portfolio across property, stocks, and alternatives together?"
2. "What's your approach to IHT planning when assets are in different wrappers/structures?"
3. "Are you using EIS/SEIS as part of your strategy? How do you model the tax impact across your full portfolio?"

**Unlock Positioning:**
> "Legacy Builders typically have wealth spread across property, equities, alternatives, and possibly trusts or family structures. Unlock consolidates that across all asset classes so you can model intergenerational impact *and* optimize every investment for tax efficiency. You can see EIS/SEIS opportunities within your full risk framework, not in isolation."

**Key Message:**
"Portfolio visibility + tax optimization + alternatives modeling = intergenerational confidence"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "I have an accountant handling tax" | "Unlock isn't replacing your accountant—it's your intelligence layer *before* you talk to them. You bring better data to those conversations. Plus, dynamic modeling as rules change (like April 6) happens in real-time." |
| "This feels complex for what I do" | "That's exactly why you need it. Your portfolio *is* complex—Unlock simplifies the view so you see consolidated risk, tax efficiency, and opportunities. Without it, complexity is hidden." |
| "I don't have time to learn new tools" | "No learning curve. You get personalized monthly reports analyzing your portfolio against your goals. Read the report, make decisions. That's it." |

**Close Script:**
"Let's run a quick analysis of your current holdings. I'll show you the consolidated view + highlight any tax optimization opportunities specific to your structure. That way you can see exactly what Unlock reveals. Forty-five minutes—does next Tuesday or Thursday work better?"

---

### **P011: The ISA/SIPP Maximiser** â­â­â­â­â­

**Profile:**
- Portfolio: £680K
- Age: 30–60
- Approach: Self-directed
- Risk: Growth
- Key drives: Tax wrapper optimization, tax-efficient products (VCT/EIS), fee minimization

**Why Perfect Fit:**
- Tax optimization (score 5.0/5) is Unlock's core feature
- ISA/SIPP mechanics + EIS/SEIS integration = Unlock's differentiation
- High alternative bias (35%) + growth focus = wants to diversify beyond public markets
- Platform automates annual allowance planning

**On-Call Signals:**
- Mentions: "maximizing my ISA," "SIPP strategy," "tax-efficient," "VCT/EIS," "avoiding fees," "long-term growth"
- Questions about: annual allowance, carry-forward, tax-efficient product selection
- Sophisticated mindset: already optimizing, wants to optimize *more*

**Pain Points to Probe:**
1. "How do you currently track whether you're using your full ISA and SIPP allowances each year?"
2. "Do you have a strategy for tax-efficient products like EIS or VCTs, or are those ad-hoc?"
3. "If rules change (like the April 6 SEIS changes), how quickly can you model impact across your portfolio?"

**Unlock Positioning:**
> "ISA/SIPP Maximisers are already tax-smart. Unlock takes that to the next level by automating annual allowance tracking, modeling tax-efficient product allocation (EIS/VCT), and showing exactly where fees leak. It's the difference between 'tax-efficient' and 'optimally tax-efficient.'"

**Key Message:**
"Maximum tax efficiency + growth + minimal fees = more wealth kept"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "I already know my ISA limits" | "That's the baseline. Unlock goes further: it models *which account type* makes most sense for *which investment* given your tax profile, income level, and goals. Some people are better off in a GIA with specific losses harvested than in an ISA. Unlock surfaces that." |
| "I don't have time for tax planning" | "Exactly. Unlock automates it. You get quarterly rebalancing recommendations that are already tax-efficient. No manual tracking needed." |
| "Tax software already does this" | "Tax software is backward-looking (last year's return). Unlock is forward-looking (next 10 years). You model scenarios, run allocation analysis, and optimize *before* year-end, not after." |

**Close Script:**
"Let me show you something: we'll model your current ISA/SIPP/GIA split and show you the tax impact of moving £X to EIS vs keeping it in your ISA. Takes 20 minutes, and you'll see immediately where Unlock adds value. When could we do that?"

---

### **P014: The High Net Worth Inheritor** â­â­â­â­â­

**Profile:**
- Portfolio: £3.2M (HNW+ tier)
- Age: 25–45
- Approach: Full-service (learning to self-direct)
- Risk: Moderate
- Key drives: Preserve inherited wealth, professional governance, diversify from legacy concentrations

**Why Perfect Fit:**
- Young wealth + uncertain expertise = desire for professional-grade tools
- High alternatives exposure (40%) + property (55%) = fragmented holding structure
- Learning curve creates opportunity for platform adoption
- Multi-generational planning window = long LTV

**On-Call Signals:**
- Mentions: "inherited," "family wealth," "learning how to manage it," "my father/mother had property," "should probably diversify," "want professional approach"
- Age: Noticeably younger than asset base suggests
- Humility: "I'm not sure what I'm doing, to be honest"

**Pain Points to Probe:**
1. "How are you currently viewing the portfolio your parents built? Are all the pieces in one place?"
2. "What's your plan for the property concentration you inherited—is it core holdings or diversify over time?"
3. "Are you getting professional advice, or managing this yourself? Either way, where do you wish you had more visibility?"

**Unlock Positioning:**
> "High Net Worth Inheritors face a unique challenge: preserve and grow wealth you didn't build yourself, often with legacy concentrations (typically property or single-stock holdings). Unlock provides the 'intelligence layer' that advisors use, plus the governance framework to manage multi-asset complexity. It's how you go from inheriting wealth to *managing* wealth professionally."

**Key Message:**
"Inherited wealth + professional governance + diversification visibility = confidence to manage it"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "I have an advisor/family office helping" | "Perfect—Unlock works alongside them. You get the consolidated view across all assets (they may see pieces), and you can bring smarter questions to those conversations." |
| "This seems like a lot for what I need" | "Not yet, but you're building it. In 10 years you'll have £5–10M+, family succession questions, tax complexity, alternatives exposure. Better to have the right *system* now than retrofit it later." |
| "I'm not investing enough to justify this" | "You're at £3.2M—you're exactly where this pays for itself. One tax optimization saves £5–20K. One alternatives decision adds £50–500K. Platform cost is £X/month. The ROI is month one." |

**Close Script:**
"Let me do something: I'll consolidate your portfolio across all holdings and run a 'legacy diversification' analysis—show you what's concentrated, what opportunities you might be missing, and what a better-diversified version looks like. Thirty minutes, and you'll see the full picture in one place. When works?"

---

### **P015: The Entrepreneur** â­â­â­â­â­

**Profile:**
- Portfolio: £1.1M (personal liquid)
- Age: 28–55
- Approach: Self-directed
- Risk: Growth/Opportunistic
- Key drives: Barbell liquidity, reinvestment in business, EIS/SEIS, diversification outside business

**Why Perfect Fit:**
- Unlock's alternatives focus (50% bias) perfectly suits startup/early-stage investing
- Barbell approach (ample cash + growth) = Unlock's core modeling
- EIS/SEIS reliance + personal equity = exactly what Unlock was built for
- Business income volatility = wants stress-tested personal portfolio

**On-Call Signals:**
- Mentions: "running a business," "reinvesting in the company," "using EIS to fund ideas," "need portfolio away from the business," "can't have all eggs in one basket," "want to stress-test personal portfolio"
- Sophisticated: already thinking about risk management
- Impatient: wants solutions yesterday, values speed

**Pain Points to Probe:**
1. "How do you currently stress-test your personal portfolio if the business hits a rough quarter?"
2. "When you're considering EIS/SEIS investments, how do you model them within your full personal portfolio risk?"
3. "Do you have a clear split between 'business reinvestment' capital and 'personal wealth' capital? How do you manage that separation?"

**Unlock Positioning:**
> "Entrepreneurs have a unique portfolio structure: business equity (illiquid, concentrated), personal investments (EIS/SEIS, opportunities), and cash (barbell safety). Unlock models this 'barbell' so you see: (a) what happens if the business needs cash, (b) which growth investments fit your risk tolerance, and (c) how personal diversification hedges business concentration. That's intelligence most entrepreneurs lack."

**Key Message:**
"Barbell clarity + EIS/SEIS modeling + business volatility hedging = confident growth decisions"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "My business is where the real value is" | "Agreed. But if you're tying 80%+ of your net worth to the business, *personal* portfolio becomes the safety net. Unlock is about sizing that net correctly and stress-testing it. That lets you take more risk *in* the business." |
| "I'm too busy to manage this" | "Exactly why you need it. Set it once, get monthly insights. No daily management—just quarterly reviews and annual adjustments." |
| "I don't have time for another platform" | "This is your business portfolio management. Everything else you can ignore. One platform, one place, monthly report. That's it." |

**Close Script:**
"Here's what I want to show you: we'll model your personal portfolio with business volatility factored in—stress-test for a bad quarter, show you what EIS/SEIS investments actually move the needle on risk, and highlight where you have optionality. Twenty minutes, and you'll see things you've never modeled before. When?"

---

### **P019: The HNW Family Office Client** â­â­â­â­â­

**Profile:**
- Portfolio: £8.5M (UHNW tier)
- Age: 40–70
- Approach: Full-service (family office)
- Risk: Sophisticated
- Key drives: Multi-generational preservation, institutional alternatives, tax/legal coordination

**Why Perfect Fit:**
- Highest portfolio value = highest LTV
- Alternatives exposure (50%) + property (60%) = maximum fragmentation
- Multi-asset complexity requires integrated platform
- Family office typically lacks consolidated view—Unlock fills gap
- Long-term relationship potential (10+ years)

**On-Call Signals:**
- Mentions: "family office," "managing for children/grandchildren," "trust structures," "alternative investments," "coordinating across advisors," "complexity across firms"
- Setup: Multiple advisors (wealth, tax, legal) operating in silos
- Sophistication: Understands portfolio theory, wants institutional approach

**Pain Points to Probe:**
1. "With multiple advisors (wealth, tax, legal), how do you currently get a consolidated view of portfolio risk and tax efficiency?"
2. "Are your alternative investments (PE, hedge funds, direct deals) visible to your wealth advisor, or managed separately?"
3. "When you're modeling scenarios (market downturns, tax law changes, succession), how many spreadsheets does that take?"

**Unlock Positioning:**
> "Family Office Clients manage institutional-scale portfolios across multiple asset classes, advisors, and time horizons. The problem: each advisor sees their piece (wealth, tax, legal), but no one sees the whole. Unlock becomes the 'intelligence hub'—consolidated view across all assets, scenario modeling across tax/risk/return, and the data infrastructure for coordinated decision-making. It's what family offices use."

**Key Message:**
"Consolidated visibility + multi-generational modeling + institutional alternatives access = optimized family wealth"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "We have a family office handling this" | "Unlock works alongside your FO. In fact, most family offices *use* platforms like this to manage complexity and coordinate across advisors. It's not replacing anyone—it's the intelligence layer that makes everyone more effective." |
| "We've built processes over 20 years" | "Exactly. You have the *processes*, but probably not the *platform*. Unlock codifies what you're already doing manually and scales it—fewer errors, faster modeling, better decisions." |
| "This feels like overhead" | "It's the opposite. One integrated platform costs less than hiring another FO staff member, but gives you 10x more visibility and speed. First optimization saves the cost. First scenario model pays for years." |

**Close Script:**
"I'd like to understand your current setup better—how many advisors are coordinating on your portfolio, which asset classes they each manage, and what scenarios you're modeling for the next generation. Then I'll map where Unlock fills coordination gaps and what efficiency we unlock. Thirty minutes—this week?"

---

## PART 2: TIER 2 PERSONAS (SECONDARY TARGET)
### Strong fit + good conversion probability

---

### **P001: The Retirement Planner** â­â­â­â­

**Profile:**
- Portfolio: £1.25M (upper mass-affluent)
- Age: 55–70
- Approach: Hybrid (mix of advice + self-directed)
- Risk: Balanced
- Key drives: Sustainable income, capital preservation, tax optimization, longevity planning

**Why Good Fit:**
- Income focus + tax wrapper optimization (ISA/SIPP) align with Unlock
- Drawdown sequencing modeling = key Unlock feature
- Diversification across asset classes (30% property, 30% tech, 25% alternatives) = fragmentation
- High liquidity needs (9 months) = wants stress-tested withdrawal strategies

**Quick Qualifier:**
"Are you currently modeling where you'll draw income from in retirement—which accounts to access first, how to minimize tax, and whether your strategy will last 30+ years?"

**Key Message:**
"Drawdown sequencing + tax optimization + longevity modeling = income confidence"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "I have a pension advisor" | "Unlock isn't replacing them. It's your personal portfolio view *alongside* the pension. Most people have ISA/SIPP/GIA that need coordinating. Unlock does that." |
| "Too close to retirement for new tools" | "Actually, perfect timing. Next 5 years are critical for withdrawal strategy. Better to get the modeling right now than discover inefficiency later." |

**Close Script:**
"Let me model your specific drawdown strategy: which accounts to access in what order, tax impact, and how long your portfolio lasts. We can compare that to what you're currently planning. Thirty minutes?"

---

### **P006: The Tech Worker** â­â­â­â­

**Profile:**
- Portfolio: £840K
- Age: 25–45
- Approach: Self-directed
- Risk: Growth
- Key drives: Diversify away from employer risk, RSU/option management, tax efficiency

**Why Good Fit:**
- Concentration risk (single employer stock) = Unlock's core use case
- High tax optimization needs (vesting events, share sales, gains management)
- Tech-native user = platform adoption easy
- Growth horizon long = time for alternatives exposure

**Quick Qualifier:**
"How do you currently manage the risk of having so much of your net worth in your employer's stock? What's your plan to diversify?"

**Key Message:**
"Employer concentration hedging + tax-efficient diversification + growth modeling = career confidence"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "I don't think my company stock will crash" | "Hope for the best, plan for the worst. You have £X concentrated in one stock—what happens if it drops 30%? Unlock helps you model that scenario and build a hedge." |
| "I have a financial advisor already" | "Does your advisor actively model your vesting events and help you execute tax-efficient sales? Unlock automates that and tracks concentration risk real-time." |

**Close Script:**
"Let me show you your current risk profile with that employer concentration and model three scenarios: (1) stock stays strong, (2) stock drops 20%, (3) you need to sell into market weakness. You'll see immediately where hedging matters. Twenty minutes?"

---

### **P007: The Dividend Seeker** â­â­â­â­

**Profile:**
- Portfolio: £650K
- Age: 45–70
- Approach: Hybrid
- Risk: Income
- Key drives: Dependable dividend income, tax-efficient yield, diversification

**Why Good Fit:**
- Tax wrapper optimization (ISA/SIPP) = core feature
- Income focus + alternatives interest (25%) = diversification play
- Dividend tax planning (basic rate vs higher rate, franking credits) = Unlock modeling
- Moderate alternatives bias = open to new opportunities

**Quick Qualifier:**
"How do you currently optimize your dividend income for tax—are you using your ISA allowance strategically, or just buying wherever?"

**Key Message:**
"Dividend income + tax efficiency + growth opportunities = reliable cash flow"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "Dividends are straightforward" | "Income is, but tax optimization isn't. If you're paying higher rate tax on dividends in a GIA when you have ISA room, you're leaving money on the table. Unlock surfaces that." |
| "I like simple, low-cost products" | "Unlock isn't about complexity—it's about efficiency. It tells you *which* low-cost products fit your tax profile and where to hold them." |

**Close Script:**
"Let me analyze your current dividend allocation: which accounts they're in, what your tax liability is, and where you could restructure to keep more. Thirty minutes, and you'll see the inefficiencies clearly."

---

### **P010: The Financial Advisor** â­â­â­â­

**Profile:**
- Portfolio: £950K (professional investor)
- Age: 35–60
- Approach: Self-directed
- Risk: Balanced+
- Key drives: Model portfolios, compliance evidence, cost efficiency, client outcomes

**Why Good Fit:**
- Professionals using Unlock as compliance + modeling tool
- Alternative exposure (35%) + diversification-focused = client approach
- Risk controls (balanced+) = fiduciary mindset
- Potential for B2B expansion (advisor recommending to clients)

**Quick Qualifier:**
"How do you currently model and evidence suitability for your client portfolios—where does that live?"

**Key Message:**
"Compliance automation + model portfolio management + client outcome tracking = efficient practice"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "I have existing tools" | "Do they consolidate across asset classes and provide real-time risk reporting? Unlock is designed for what advisors *specifically* need." |

**Close Script:**
"I'd like to understand your current compliance framework and show you how Unlock could automate suitability evidence and client reporting. Forty-five minutes?"

---

### **P013: The Cautious Accumulator** â­â­â­â­

**Profile:**
- Portfolio: £320K
- Age: 30–50
- Approach: Hybrid
- Risk: Conservative
- Key drives: Steady accumulation, low drawdown risk, capital protection, rebalancing

**Why Good Fit:**
- Risk-averse investors benefit from downside modeling + rebalancing automation
- Tax optimization (score 3.0/5) still valuable
- Liquidity needs (9 months) = wants accessible portfolio
- Disciplined approach = good platform adopter

**Quick Qualifier:**
"How do you currently ensure your portfolio stays aligned with your risk tolerance—do you rebalance, or let it drift?"

**Key Message:**
"Disciplined rebalancing + downside protection + tax efficiency = steady wealth building"

**Objection Rebuttals:**

| Objection | Rebuttal |
|-----------|----------|
| "My portfolio is simple" | "That's actually the advantage. Simple but well-structured beats complex and scattered. Unlock keeps it simple *and* optimal." |
| "I don't need fancy tools" | "It's not fancy—it's automatic. Set it once, get quarterly rebalancing alerts. That's it." |

**Close Script:**
"Let me run a rebalancing analysis on your portfolio: show you where it's drifted from your target allocation, what tax-efficient rebalancing looks like, and how much that could add over 5 years. Twenty minutes?"

---

## PART 3: TIER 3 PERSONAS (CONDITIONAL/LOWER PRIORITY)
### Moderate fit; pursue if time allows

---

### **P002: The Property Lover** ðŸŸ¡

**Fit Assessment:** Moderate (if open to rebalancing)

**Quick Qualifier:** "You mentioned property is 85% of your portfolio. Is that intentional, or would you like to explore more balance?"

**Key Message (if fit):** "Property expertise + liquid diversification = complete wealth building"

**Key Message (if poor fit):** "Sounds like property is your core strength. Unlock works best when you have multi-asset fragmentation."

**Red Flag:** Refuses to discuss rebalancing. If so, move on—not a fit.

---

### **P003: The Crypto Enthusiast** ðŸŸ¡

**Fit Assessment:** Moderate (if seeking rebalancing, not portfolio concentration)

**Quick Qualifier:** "With 51% in crypto, are you looking to hold that allocation, or rebalance to reduce volatility?"

**Key Message (if fit):** "Core portfolio hedging + volatility management + growth opportunities beyond crypto"

**Red Flag:** "Crypto is my core strategy." If so, not a fit.

---

### **P004: The Old Fashioned Saver** ðŸŸ¡

**Fit Assessment:** Moderate (if seeking inflation hedging or small growth component)

**Quick Qualifier:** "Are you happy with your cash/bonds allocation, or interested in exploring small growth components?"

**Key Message (if fit):** "Capital preservation + inflation hedging + modest growth = sustainable income"

**Red Flag:** "I'm happy as-is." If so, move on.

---

### **P008: The Young Professional** ðŸŸ¡

**Fit Assessment:** Moderate (too early, but high future potential)

**Quick Qualifier:** "With a £170K portfolio right now, what's your growth trajectory? Are you expecting to accumulate significantly?"

**Key Message (if fit):** "Build the right habits now. In 5 years you could be at £500K—better to have the infrastructure ready."

**Key Message (if poor fit):** "Your portfolio is perfectly positioned for simple indexing. Come back when you're at £250K+ with diverse holdings."

**Follow-up Strategy:** Low priority for this campaign, but tag for future nurture (they're on trajectory).

---

### **P009: The Global Nomad** ðŸŸ¡

**Fit Assessment:** Moderate (niche currency + tax residency angle)

**Quick Qualifier:** "With living across borders, how do you currently handle multi-currency exposure and tax residency optimization?"

**Key Message (if fit):** "Global diversification + currency management + tax residency optimization = location-independent wealth"

**Red Flag:** "I just use simple global funds." If so, lower priority.

---

### **P018: The Concentrated Stock Holder** ðŸŸ¡

**Fit Assessment:** Moderate (one-time analysis vs. ongoing platform)

**Quick Qualifier:** "How long have you held that concentrated position? What's your timeline for diversification?"

**Key Message:** "Concentration risk modeling + tax-efficient hedging strategy + phased diversification plan"

**Caution:** After one-time analysis/recommendation, may not need ongoing platform. Use as door-opener; focus on getting them to broader financial review.

---

## PART 4: NOT RECOMMENDED (DON'T TARGET)
### Misalignment too high; better use of dial time elsewhere

---

### **âŒ P012: The Defined Benefit Heavy**

**Why Skip:** DB pension provides income floor. Personal portfolio is secondary. Not value-seeking.

**If They Call You:** "Your DB pension is doing the heavy lifting for income. What about your personal investments—do you want to optimize those?"

**If They Stay:** Show ISA/SIPP modeling, but don't emphasize alternatives/complexity. Keep it simple.

---

### **âŒ P016: The BTL Mogul**

**Why Skip:** 90% property concentration + leveraged debt. Extreme concentration = different problem.

**If They Call You:** "Your portfolio is 90% property—that's your expertise, not ours. We focus on multi-asset diversification."

**Don't Spend Time:** These investors typically resist diversification. Not a fit.

---

### **âŒ P017: The Pension Drawdown Specialist**

**Why Skip:** Defensive focus + sequence-of-returns risk. Different platform need.

**If They Call You:** "You're focused on sustainable withdrawals in drawdown. That's important, but requires different tools than Unlock offers."

**Exception:** If they also have substantial non-pension portfolio (GIA with alternatives), could be secondary fit.

---

---

## PART 5: CALLING FRAMEWORK BY PERSONA TIER

### **TIER 1 PERSONAS: 45-60 Minute Deep Dive**

**Flow:**
1. Understand current structure (fragmentation, assets, advisors)
2. Identify key pain point (tax, visibility, alternatives, risk)
3. Position Unlock as solution
4. Offer specific analysis (15-20 min demo or follow-up)
5. Close: Schedule demo or send personalized report

**Example Script (P005 - Legacy Builder):**
> "Hi [Name], quick context—I've been reaching out to investors who are actively managing multi-asset portfolios and interested in intergenerational planning. Based on your profile, I thought you might be a fit. Do you have 10 minutes?"
>
> *[If yes]* "Great. Quick question: when you're thinking about building wealth for the next generation across property, investments, and potentially trusts—how do you currently see your entire portfolio in one place?"
>
> *[Listen for pain point: "Hard to see across advisors," "Tax complexity," "Don't know where to diversify"]*
>
> "That's exactly what we've built Unlock for. It's an independent platform that consolidates everything—property, stocks, alternatives, even trusts—and shows you consolidated tax efficiency, risk, and opportunities across the entire portfolio. Particularly valuable with the April 6 EIS/SEIS rule changes coming."
>
> "Would it be helpful to see a specific analysis of your portfolio structure—show you what consolidation looks like and where tax optimization sits? Thirty minutes, and you'll see exactly what we surface."

---

### **TIER 2 PERSONAS: 30-45 Minute Overview**

**Flow:**
1. Confirm portfolio structure + key challenge
2. Quick pain point identification
3. Unlock value prop (specific to their challenge)
4. Offer lightweight analysis or report
5. Close: Follow-up call in 3-5 days

**Example Script (P006 - Tech Worker):**
> "Hi [Name], I'm reaching out to tech professionals who've accumulated wealth in employer stock and are looking to diversify. Sound like you?"
>
> *[If yes]* "The challenge most face: employer stock concentration + tax-efficient diversification. How are you currently managing that risk?"
>
> *[Listen]* "Right. Unlock helps you model exactly that—what happens if your stock drops 30%, where your concentration risk sits, and how to diversify tax-efficiently. We can show you a phased plan that minimizes tax drag."
>
> "Would a quick analysis help—I could show you your current risk profile and a diversification strategy. Twenty minutes?"

---

### **TIER 3 PERSONAS: 15-20 Minute Qualifier**

**Flow:**
1. Quick rapport + context
2. Single qualifying question
3. Listen for fit signal
4. If fit: Offer lightweight report or nurture sequence
5. If poor fit: Graceful exit ("sounds like you're in a good place; we'll check in in a year")

**Example Script (P008 - Young Professional):**
> "Hi [Name], quick question—with a £170K portfolio focused on index funds, are you planning to stay simple, or expecting to get more complex as you accumulate?"
>
> *[If "staying simple"]* "Perfect. You're exactly where you should be. No reason for Unlock yet. But as you hit £250K+ with more complex holdings, reach out."
>
> *[If "expecting complexity"]* "Smart thinking. Here's what I'd suggest: in 5 years when you're at £500K with alternatives + property, better to have the right infrastructure already set up. How about I send you a simple portfolio framework that prepares you for that transition?"

---

## PART 6: COMMON OBJECTIONS BY PERSONA TYPE

### **HNW / Complex Investors (P005, P014, P019)**

| Objection | Rebuttal | Follow-up |
|-----------|----------|-----------|
| "I have advisors for this" | "Unlock isn't replacing your advisors—it's your intelligence layer that makes them better. You bring consolidated data to conversations instead of relying on their partial views." | "When we show you the full portfolio view, you'll see insights your advisors don't have." |
| "This feels like overhead" | "One tax optimization saves your cost for 1-2 years. One alternatives decision can add £50-500K. It's not overhead—it's margin." | "When was the last time you modeled your full portfolio against your goals?" |
| "I'm satisfied with my current setup" | "Great. Probably means your advisors are good, not that your structure is optimal. What if there were 10-15% efficiency gains on the table? Would that be worth exploring?" | "Thirty minutes to answer that question—worth it?" |

### **Tax-Focused Investors (P011, P007)**

| Objection | Rebuttal | Follow-up |
|-----------|----------|-----------|
| "My accountant handles tax" | "Tax software is backward-looking. Unlock is forward-looking. You model scenarios *before* year-end instead of optimizing after. Accountant + Unlock = better decisions." | "Can your accountant tell you today whether your current allocation minimizes next year's tax?" |
| "Tax is complicated" | "Exactly. Which is why you need a system that simplifies it. Unlock reduces complexity to: 'Here's your tax impact, here's how to optimize.'" | "What if you had one number that told you your tax efficiency, updated monthly?" |
| "I already maximize my ISA" | "ISA is the baseline. Unlock goes deeper—optimal accounts for each investment, carry-forward planning, tax-loss harvesting across accounts. ISA-max is table stakes." | "What if we could identify £5-15K in tax savings you're currently missing?" |

### **Concentration Risk Holders (P006, P018)**

| Objection | Rebuttal | Follow-up |
|-----------|----------|-----------|
| "My stock will keep going up" | "Hope for the best, plan for the worst. You're betting your career AND your net worth on one company. What if you could decouple those risks?" | "What would it take to diversify systematically without missing upside?" |
| "I'll diversify when X happens" | "That's gambling on timing. Most people miss the trigger and wake up 5 years later with the same concentration. Better to have a plan and execute it methodically." | "What if we built a phased plan you execute regardless of stock price?" |
| "Diversification means tax drag" | "Wrong premise. Tax-inefficient diversification is expensive. Tax-efficient diversification saves money. That's what Unlock is for." | "What if I could show you a diversification plan with *lower* tax drag than staying concentrated?" |

### **Retirees / Income-Focused (P001, P017)**

| Objection | Rebuttal | Follow-up |
|-----------|----------|-----------|
| "I'm close enough to retirement" | "Exactly why this matters. Next 5 years of withdrawal strategy define the next 30. Better to optimize now." | "Have you stress-tested your withdrawals for a market downturn in year 2?" |
| "My pension handles income" | "Right. But most people have ISA/SIPP/GIA that need sequencing. Unlock coordinates that to minimize tax and sequence longevity risk." | "What's your current strategy for which account to access first?" |
| "I don't want to take more risk" | "Unlock isn't about more risk—it's about *right* risk and tax efficiency. Most retirees are over-conservative, missing safe growth." | "What if you could take the same risk you're taking now but earn 1-2% more annually?" |

---

## PART 7: QUICK-REFERENCE CALL CHECKLIST

### **Before You Dial:**
- [ ] Check persona assignment (from Pipedrive notes or past activity)
- [ ] If unclear, pick qualifying question from Part 5
- [ ] Have one pain point probe ready (specific to that persona)
- [ ] Identify Unlock value prop for that persona (see Part 5)

### **During the Call:**
- [ ] Build rapport (30 seconds)
- [ ] Context + quick qualifier (60 seconds)
- [ ] Listen for pain point / portfolio structure (120 seconds)
- [ ] Map pain to Unlock (60 seconds)
- [ ] Offer specific next step (demo, analysis, report) (30 seconds)
- [ ] Close or reschedule (30 seconds)

### **If Weak Fit:**
- [ ] Graceful exit ("sounds like you're doing well; we'll reach out in a year")
- [ ] Tag in CRM for nurture / future review
- [ ] Move to next call

### **If Strong Fit:**
- [ ] Schedule specific next step (demo Tuesday, report by Friday, etc.)
- [ ] Capture all portfolio details (asset classes, advisors, key challenges)
- [ ] Send follow-up email with specific agenda
- [ ] Brief Tom before demo (key insights about this investor)

---

## PART 8: FOLLOW-UP MESSAGING BY PERSONA

### **After Demo (Pack 1 Send)**

**Tier 1 Personas (High-Value):**
> "Based on our conversation, I think there's significant value in consolidating your portfolio within Unlock. Here's Pack 1—it explains the platform, shows sample analysis, and pricing. One thing stands out from our conversation: [specific insight about their portfolio]. That alone could save you [£X or Y% of fees]. Take a look and let's reconnect."

**Tier 2 Personas (Strong Fit):**
> "Thanks for the conversation. I've attached our Founding Investor Brief—shows exactly how Unlock handles [their specific challenge: tax optimization / concentration risk / multi-generational planning]. Notice section on [specific insight]—we see that impact in portfolios like yours. Questions, give me a call."

**Tier 3 Personas (Conditional):**
> "Appreciate you taking my call. Based on our conversation, you might find value in Unlock when [trigger: portfolio reaches £500K / adds alternatives / complexity increases]. For now, I'm sending this overview. No rush—but reach out when timing feels right."

---

## PART 9: DOCUMENT REFERENCE LINKS

Use these docs to support calls and demos:

| Scenario | Reference Doc |
|----------|----------------|
| "Show me Unlock basics" | Unlock_App_Walkthrough_Script_v2.pdf |
| "What's the business model?" | Unlock_Investment_Pitch.pdf |
| "Show me market context" | Unlock_Marketing_and_Investor_Conversion_Strategy_Brief.md |
| "How do I model scenarios?" | Unlock_Portfolio_Simulator (in platform) |
| "Tax optimization deep-dive" | Unlock_App_Walkthrough_Script_v2.pdf (Scenarios tab) |
| "Competitive positioning" | Unlock_Competitive_Analysis.pdf |
| "Investor pack details" | Unlock_Pack_1_Founding_Investor_Brief_Updated.docx + PACK_2_STRUCTURE_OUTLINE.md |

---

## PART 10: SUCCESS METRICS BY PERSONA TIER

### **Target Metrics (Per 100 dials)**

| Metric | Tier 1 | Tier 2 | Tier 3 |
|--------|--------|--------|--------|
| Call Connection Rate | 35%+ | 30%+ | 20%+ |
| Demo Booking Rate | 25%+ | 18%+ | 10%+ |
| Pack 1 Send Rate | 60%+ of demos | 40%+ of demos | 20%+ of demos |
| Pack 2 Send Rate | 50%+ of Pack 1s | 30%+ of Pack 1s | 10%+ of Pack 1s |
| Instant Investment Close Rate | 30%+ of Pack 2s | 20%+ of Pack 2s | 5%+ of Pack 2s |

### **Quality Checks**

- [ ] Are Tier 1 personas getting 45-60 min calls (not 10 min), with deep portfolio discussion?
- [ ] Are Tier 2 personas getting specific value prop (not generic pitch)?
- [ ] Are Tier 3 personas being qualified quickly (not time-wasted)?
- [ ] Are demos being prepped with persona-specific insights?
- [ ] Are follow-ups referencing call-specific pain points (not generic)?

---

## APPENDIX: PERSONA QUICK-REFERENCE MATRIX

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ TIER 1: HIGHEST PRIORITY (Dial First)                              â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ P005: Legacy Builder          â”‚ £2.4M  â”‚ 40-65 â”‚ Multi-asset + tax  â”‚
â”‚ P011: ISA/SIPP Maximiser      â”‚ £680K  â”‚ 30-60 â”‚ Tax + growth       â”‚
â”‚ P014: HNW Inheritor           â”‚ £3.2M  â”‚ 25-45 â”‚ Wealth + alts      â”‚
â”‚ P015: Entrepreneur            â”‚ £1.1M  â”‚ 28-55 â”‚ Barbell + EIS      â”‚
â”‚ P019: FO Client               â”‚ £8.5M  â”‚ 40-70 â”‚ Multi-gen + coords â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ TIER 2: STRONG FIT (Secondary Target)                              â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ P001: Retirement Planner      â”‚ £1.25M â”‚ 55-70 â”‚ Drawdown + tax     â”‚
â”‚ P006: Tech Worker             â”‚ £840K  â”‚ 25-45 â”‚ Concentration + fx â”‚
â”‚ P007: Dividend Seeker         â”‚ £650K  â”‚ 45-70 â”‚ Income + tax       â”‚
â”‚ P010: Financial Advisor       â”‚ £950K  â”‚ 35-60 â”‚ Compliance + risk  â”‚
â”‚ P013: Cautious Accumulator    â”‚ £320K  â”‚ 30-50 â”‚ Risk + rebalance   â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ TIER 3: CONDITIONAL (Lower Priority / Future)                      â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ P002: Property Lover          â”‚ £1.2M  â”‚ 35-60 â”‚ Diversify from RE  â”‚
â”‚ P003: Crypto Enthusiast       â”‚ £780K  â”‚ 22-40 â”‚ Rebalance + hedge  â”‚
â”‚ P004: Old Fashioned Saver     â”‚ £450K  â”‚ 50-75 â”‚ Inflation + growth â”‚
â”‚ P008: Young Professional      â”‚ £170K  â”‚ 22-35 â”‚ Future potential   â”‚
â”‚ P009: Global Nomad            â”‚ £510K  â”‚ 28-50 â”‚ Currency + tax     â”‚
â”‚ P018: Concentrated Stock      â”‚ £950K  â”‚ 35-60 â”‚ One-time analysis  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ DON'T TARGET: Misalignment Too High                                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ P012: DB Heavy                â”‚ £420K  â”‚ 50-70 â”‚ Income-secure      â”‚
â”‚ P016: BTL Mogul               â”‚ £2.8M  â”‚ 35-65 â”‚ RE concentration   â”‚
â”‚ P017: Pension Drawdown        â”‚ £850K  â”‚ 58-75 â”‚ Sequence risk      â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

## FINAL NOTES FOR TOM

**Dial Sequencing Strategy:**
1. **Weeks 1-2:** Focus 80% on Tier 1 (deep conversations, 45+ min calls)
2. **Weeks 2-4:** Mix Tier 1 + Tier 2 (45 min + 30 min calls)
3. **Weeks 5-8:** Tier 1 + Tier 2 + Tier 3 (prioritize by booking rate)

**Agent Coaching:**
- Tier 1 calls take longer but convert better—don't rush them
- Tier 2 needs specific value prop (not generic "institutional clarity")
- Tier 3 needs quick qualifier—if weak fit, move on fast
- Quality > Quantity on Tier 1; Volume matters on Tier 3

**Demo Preparation:**
- Before every demo, brief the demoing agent: "This is a [Persona]. Key challenge: [X]. Show them [Y] first."
- Customize demo walkthrough by persona (not generic)
- Focus on persona-specific pain point (1-2 features max)

**Pack 1 Customization:**
- Tier 1 gets personalized cover letter highlighting their specific pain point
- Tier 2 gets standard pack + personal note on relevant section
- Tier 3 gets standard pack with "check back when..." timeline

---

**Document Version:** 1.0  
**Last Updated:** November 17, 2025  
**Next Review:** After Week 2 of campaign (reassess conversion rates by persona)


---

<!-- END OF DOCUMENT -->

# INVESTOR-FACING DOCUMENTS — CURRENT

## One-Pager
*Stage: Outreach / Called | All personas | 100_PROMO*

---

+----------------+----------------+-----------------+-----------------+
| Pre-money      | Ticket size    | EIS / SEIS      | Shares issued   |
| valuation      |                | eligible        |                 |
|                | **£20K --      |                 | **6 April       |
| **£6.5M**      | £500K**        | **Yes ---       | 2026**          |
|                |                | processed at    |                 |
|                |                | investment**    |                 |
+----------------+----------------+-----------------+-----------------+

**IFAs cover what's regulated. Your accountant covers what's taxable.
Nobody is looking at the whole picture.**

**Unlock gives you the whole picture.**

**What Unlock does**

Unlock is a portfolio intelligence platform for serious private
investors. It models tax drag across your entire estate --- ISAs,
pensions, property, EIS, alternatives --- in a single environment. The
Tax Intelligence Engine identifies where your current structure is
costing you money. The Decumulation Planner optimises which assets to
draw down, in which order, to minimise lifetime tax --- built
specifically around the April 2027 pension IHT rule change that inverts
conventional draw-last advice.

+-----------------------------------------------------------------------+
| **6 April 2026 --- the deadline that changes the maths.**             |
|                                                                       |
| EIS Inheritance Tax relief is currently unlimited at 100%. From 6     |
| April 2026 it is capped at £2.5M per estate (50% above the          |
| threshold). Shares issued before that date are grandfathered.         |
| Founding investors who commit now lock in uncapped relief             |
| permanently.                                                          |
+-----------------------------------------------------------------------+

**The investment**

+----------------------------------+-----------------------------------+
| Unlock is raising £1.2M at a     |   ------                          |
| £6.5M pre-money valuation, via   | --------- ----------- ----------- |
| Instant Investment through       |   **R                             |
| SeedLegals. EIS compliance is    | elief**      **EIS**     **SEIS** |
| processed at the point of        |                                   |
| investment --- not after round   |   **Income tax    30%         50% |
| close.                           |   relief**                        |
|                                  |                                   |
| **EIS / SEIS worked example**    |   *                               |
|                                  | *CGT on exit** Exempt      Exempt |
| You invest £50,000 under SEIS.   |                                   |
| You claim 50% income tax relief  |                                   |
| immediately: £25,000 back        |  **IHT (until 6  100%        100% |
| against your tax bill. Effective |   Apr)**                          |
| cost: £25,000. Profits on exit   |                                   |
| are tax-free. If the company     |   **Lo                            |
| fails, loss relief reduces your  | ss relief   \~27.5p/£   \~27.5p/£ |
| at-risk position further. The    |   (AR)**                          |
| government is backing half your  |   ------                          |
| downside.                        | --------- ----------- ----------- |
|                                  |                                   |
|                                  | *Loss relief est. for             |
|                                  | additional-rate taxpayers.        |
|                                  | Subject to adviser confirmation.* |
+----------------------------------+-----------------------------------+

**Founding investor terms --- never offered again**

  ------- --------------------------------------------------------------------
  **→**   **Anti-dilution until Series A.** Your ownership percentage is
          protected from dilution until the Growth Capital round. Your equity
          share doesn't erode as new capital comes in.

  ------- --------------------------------------------------------------------

  ------- --------------------------------------------------------------------
  **→**   **Pro-rata rights.** You have the right to participate in the Growth
          Capital round (Q2 2026) to maintain your ownership percentage.

  ------- --------------------------------------------------------------------

  ------- --------------------------------------------------------------------
  **→**   **Discount negotiated individually.** Based on ticket size and
          strategic contribution. Discussed in confidence on the discovery
          call.

  ------- --------------------------------------------------------------------

*Founding investor benefits also include lifetime platform access (no
subscription fee, ever), white-glove onboarding, and direct roadmap
input. These expire at public launch (Q1 2027).*

**How you exit**

Potential strategic acquirers include Bloomberg, Morningstar, Refinitiv,
and S&P Global --- all of whom have acquisition history in the UK wealth
data and portfolio analytics space. Comparable SaaS acquisitions in UK
wealth management have cleared £30--70M at Series B. These figures are
illustrative based on market comparables, not a forecast.

+-----------------------------------------------------------------------+
| **One conversation is all it takes.**                                 |
|                                                                       |
| Watch the two-minute product demo at www.unlockdd.com, then reply to  |
| arrange a call with Tom. The process from first conversation to       |
| investment complete typically takes three weeks.                      |
|                                                                       |
| **tom@unlockdd.com**                                                  |
+-----------------------------------------------------------------------+

**P.S.** *Shares issue 6 April 2026. If you'd like to talk before then,
reply directly to this email.*

*This document is for information purposes only and does not constitute
financial advice or an invitation to invest. Unlock is EIS/SEIS
eligible; eligibility does not guarantee relief. Tax treatment depends
on individual circumstances and should be verified with an independent
adviser. Capital is at risk. Early-stage investment involves a high
degree of risk including loss of capital. Intended for sophisticated and
high-net-worth investors only as defined by the Financial Services and
Markets Act 2000 (Financial Promotion) Order 2005. Return figures are
illustrative based on market comparables and are not forecasts. Unlock
Services Limited. Registered in England and Wales.*


---

<!-- END OF DOCUMENT -->

## Three-Page Founding Investor Promo
*Stage: Outreach / Called | All personas | 110_PROMO*

---

+-----------------------------------------------------------------------+
| **UNLOCK**                                                            |
|                                                                       |
| **Founding Investor Programme**                                       |
|                                                                       |
| *Institutional-grade portfolio intelligence. Built for investors      |
| who\'ve outgrown everything else.*                                    |
+-----------------------------------------------------------------------+

**The problem you already know**

Your wealth doesn't live in one place. Neither does the advice. Your IFA
covers what's regulated. Your accountant covers what's taxable. Nobody
is looking at the whole picture --- EIS holdings, ISAs, pensions,
property, alternatives --- at the same time, through the same lens.

The tools that exist are either too simple (aggregators that display,
not analyse) or too conflicted (platforms that earn from selling you
products). Institutional-grade analysis --- the kind that models tax
drag across your whole estate, stress-tests against multiple scenarios,
and tells you when your drawdown sequencing is costing you money --- has
never been available outside a private bank at £5,000 a year.

That's the gap Unlock fills.

**What Unlock is**

Unlock is a portfolio intelligence platform for serious private
investors. Not a broker. Not an aggregator. Not a robo-advisor. A
whole-of-wealth analysis and planning environment that works across
every asset class you actually hold.

+---+--------------------------------------------------------------------+
| * | **Living Asset Register**                                          |
| * |                                                                    |
| ● | One source of truth across every asset. Cash, ISAs, pensions,      |
| * | property, EIS, VCTs, alternatives. Always current, never manual.   |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Tax Intelligence Engine**                                        |
| * |                                                                    |
| ● | Models income tax, CGT, IHT, and pension interactions across your  |
| * | portfolio. Identifies drag before it happens.                      |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Portfolio Simulator**                                            |
| * |                                                                    |
| ● | Stress-test any scenario --- market shock, drawdown sequence,      |
| * | estate distribution --- before you commit.                         |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Decumulation Planner**                                           |
| * |                                                                    |
| ● | Optimises which assets to draw down, in which order, to minimise   |
| * | lifetime tax drag. Built around the April 2027 pension IHT rule    |
| * | change.                                                            |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Unlock Access (EIS/SEIS)**                                       |
| * |                                                                    |
| ● | Curated deal flow, direct portfolio service. Transparent fees. No  |
| * | conflicts buried in the small print.                               |
| * |                                                                    |
+---+--------------------------------------------------------------------+

The platform is already in use with founding investors. The Asset
Register and Unlock Access are operational. Tax Engine and Simulator are
in active build, fully funded by this raise.

**Why invest in Unlock --- not just use it**

Unlock is raising a founding round to complete the core build and take
the platform to public launch in Q1 2027. The market opportunity is
unambiguous: 1.8 million UK investors with investable assets above
£250,000, an advice gap that no current platform addresses, and a
regulatory environment that actively rewards the kind of tax-efficient
investing Unlock is built around.

The business model is subscription-led, not transaction-led. Unlock
earns from platform access, not from selling you investments. That
alignment --- not incidental --- is the structural moat.

+-----------------+-----------------+-----------------+-----------------+
| Pre-money       | Raise target    | Founding slots  | Share issuance  |
| valuation       |                 |                 |                 |
|                 | **£1.2M**       | **\~25 by       | **6 April       |
| **£6.5M**       |                 | design**        | 2026**          |
+-----------------+-----------------+-----------------+-----------------+

EIS/SEIS eligibility means the effective entry cost is significantly
lower than face value. For an additional-rate taxpayer investing £50,000
at SEIS terms: 50% income tax relief reduces the net cost to £25,000 at
the point of investment. Profits on exit are tax-free. Loss relief
limits downside further. The government is effectively backing half your
early-stage risk.

This is not investment advice. Tax relief figures are estimates based on
current HMRC rules; individual positions vary. We recommend independent
verification with your tax adviser before investing.

  --------------------------- --------------------- ---------------------
  **Relief type**             **EIS**               **SEIS**

  Income tax relief           30% of investment     50% of investment

  Capital gains on exit       Exempt (3-year hold)  Exempt (3-year hold)

  IHT relief (until 6 Apr     100% --- unlimited    100% --- unlimited
  2026)                                             

  Loss relief (additional     \~27.5p per £ at risk \~27.5p per £ at risk
  rate)                                             
  --------------------------- --------------------- ---------------------

Loss relief figure (\~27.5p per £ at risk) is for additional-rate
taxpayers. Higher-rate figure is \~30p. Figures subject to adviser
confirmation.

+-----------------------------------------------------------------------+
| **Why 6 April 2026 is the hard deadline**                             |
|                                                                       |
| From 6 April 2026, EIS Inheritance Tax relief is capped at £2.5M per    |
| individual (50% above the threshold). Currently, relief is unlimited  |
| at 100%. Shares issued before 6 April 2026 are grandfathered under    |
| current rules. Founding investors who commit before this date lock in |
| the full, uncapped relief.                                            |
+-----------------------------------------------------------------------+

**Why the valuation is credible**

£6.5M pre-money for a pre-launch SaaS platform with validated demand,
operational infrastructure, and a defensible data moat sits at the
conservative end of comparable early-stage UK fintech benchmarks.
Bloomberg Intelligence, Morningstar, and Refinitiv are the most natural
acquirers at scale. Comparable SaaS acquisitions in UK wealth management
have cleared £30--£70M at Series B. The founding round entry is priced
to reflect current stage honestly.

**The founding investor offer**

We are closing a round of approximately 25 founding investors. The
number is deliberate --- quality of strategic contribution matters more
than speed of capital. Founding investors receive terms and benefits
that will not be available at any subsequent round.

+---+--------------------------------------------------------------------+
| * | **Lifetime platform access**                                       |
| * |                                                                    |
| ● | Full access to every feature, today and as they launch. No         |
| * | subscription fee. Ever. While standard users pay £99--£249 per     |
| * | month, you pay nothing.                                            |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Anti-dilution until Series A**                                   |
| * |                                                                    |
| ● | Founding investors' ownership percentage is protected from         |
| * | dilution until the Growth Capital round (Q2 2026). Your equity     |
| * | share doesn't erode as new capital comes in.                       |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Instant Investment via SeedLegals**                              |
| * |                                                                    |
| ● | EIS compliance processed immediately at point of investment. EIS3  |
| * | certificates issued individually --- not batched. Arriving 15--40  |
| * | working days post-investment.                                      |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Pro-rata rights**                                                |
| * |                                                                    |
| ● | Founding investors have the right to participate in the Growth     |
| * | Capital round to maintain their ownership percentage.              |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Roadmap access and quarterly updates**                           |
| * |                                                                    |
| ● | Direct input into product direction. Quarterly investor updates    |
| * | with financial performance, user growth, and feature progress.     |
| * |                                                                    |
+---+--------------------------------------------------------------------+

  -----------------------------------------------------------------------
  **Founding investor discount is negotiated individually based on ticket
  size and strategic value. Details are discussed in confidence on the
  discovery call.**

  -----------------------------------------------------------------------

**Who this is for**

Founding investors in this round share a specific profile: they are
active private investors who understand the problem Unlock solves from
personal experience, who see the strategic value of backing a platform
they will actually use, and who are comfortable with early-stage risk
appropriately mitigated through EIS/SEIS structure.

You do not need to be a fintech expert. You need to be an investor who
has felt the friction this platform removes. If that is you, the
conversation is worth having.

**Next steps**

The process takes three steps and, typically, three weeks from first
conversation to investment complete.

+---+--------------------------------------------------------------------+
| * | **Discovery call (20 minutes)**                                    |
| * |                                                                    |
| ● | Confirm fit, discuss your portfolio context, and answer any        |
| * | initial questions. No commitment required.                         |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Platform demo (30 minutes)**                                     |
| * |                                                                    |
| ● | See the product live with your own asset classes as the frame.     |
| * | Founding investors tell us this is when it lands.                  |
| * |                                                                    |
+---+--------------------------------------------------------------------+

+---+--------------------------------------------------------------------+
| * | **Allocation and Instant Investment**                              |
| * |                                                                    |
| ● | Reserve your allocation. SeedLegals processes the Instant          |
| * | Investment agreement digitally. EIS compliance processed at the    |
| * | point of investment. Shares issued 6 April 2026.                   |
+---+--------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Tom King, Founder & CEO**                                           |
|                                                                       |
| tom@unlockdd.com                                                      |
|                                                                       |
| www.unlockdd.com                                                      |
+-----------------------------------------------------------------------+

*This document is for information purposes only and does not constitute
financial advice or an invitation to invest. Unlock is EIS/SEIS eligible
but eligibility does not guarantee relief. Tax treatment depends on
individual circumstances. Capital is at risk. Early-stage investment
involves a high degree of risk including loss of capital. This document
is intended for sophisticated and high-net-worth investors only as
defined by the Financial Services and Markets Act 2000 (Financial
Promotion) Order 2005. Please seek independent financial and tax advice
before making any investment decision. Unlock Services Limited.
Registered in England and Wales.*


---

<!-- END OF DOCUMENT -->

## Pack 1 — Founding Investor Brief
*Stage: Demo Complete / Decision | All personas | 120_BRIEF*

---

**UNLOCK**

**Institutional-grade portfolio intelligence for the investors who have
never had it.**

A founding investor opportunity.

£1.2M raise at £6.5M pre-money valuation. Approximately 25 founding
slots.

*Private & Confidential --- Founding Investor Brief*

March 2026

**The Problem**

*Private investors with £1M+ portfolios face three persistent challenges
that institutions never encounter.*

**1. Fragmented Data**

Investors manage assets across multiple providers, advisers, and manual
systems. There is no single view. Most rely on spreadsheets and gut
instinct to understand what they own, what it cost, and how it is
performing. When you need to act, you are reconstructing your picture
from memory --- not reading it from a dashboard.

The consequence: decisions are made slowly, based on incomplete
information, by investors who are sophisticated enough to know that
something is wrong but have no tool to fix it.

**2. Inaccessible Complexity**

Professional-grade portfolio analysis --- scenario simulation,
stress-testing, forward-looking tax modelling --- is locked behind
institutional paywalls. It has always been available to wealth
management teams, private banks, and family offices. It has never been
made accessible to the private investors who manage comparable
portfolios.

The result: sophisticated investors are making capital allocation
decisions without the models, projections, and risk frameworks that
would be standard equipment at any institution. The playing field is not
level. It never has been.

**3. Conflicted Incentives**

Every existing platform --- Hargreaves Lansdown, Nutmeg, Crowdcube,
private banks --- earns from what it sells you. Platform fees, trail
commissions, fund charges, AUM percentages: all create a structural
misalignment between what the platform recommends and what serves the
investor.

There is no genuinely independent, investor-first platform at this
level. Not one that earns exclusively from the investor, builds
exclusively for the investor, and carries no product conflict. That gap
is Unlock.

+-----------------------------------------------------------------------+
| **The cumulative effect:**                                            |
|                                                                       |
| Sophisticated private investors --- £1M to £20M+ in total wealth ---  |
| are managing complex, multi-asset portfolios on spreadsheets, Google, |
| and gut instinct, while every platform they could use is designed to  |
| earn from them, not for them.                                         |
+-----------------------------------------------------------------------+

**The Solution**

*Unlock gives private investors the institutional-grade intelligence and
deal access they have always been locked out of --- without the
conflicts that come with it.*

One platform. Complete financial identity. UK tax intelligence built
forward in real time. No products to sell you. No commissions. No
conflicts.

**What Unlock Delivers**

  ----------------------- -----------------------------------------------
  **Service**             **What It Does for You**

  **Asset Register**      Consolidates every asset across all providers,
                          platforms, and wrappers into a single,
                          lot-level view. The first complete picture of
                          what you own. Operational for founding
                          investors now.

  **Portfolio Simulator** Stress-tests your portfolio under 30+ downside
                          scenarios. Models 'what-if' positions before
                          you commit capital. Know your actual risk
                          before you act, not after. In active
                          development.

  **Tax Intelligence      Models EIS, SEIS, CGT, IHT, pension drawdown,
  Engine**                and AIM BPR in real time, forward-looking, with
                          continuous HMRC rule-tracking. The UK
                          regulatory moat. Full build funded by this
                          raise.

  **Syndicate Access**    Curated access to vetted collective investment
                          opportunities at 8--10% fees versus the 9--14%
                          charged by crowdfunding platforms. Founding
                          investors receive priority allocation.

  **Unlock Access**       Curated EIS deal-flow and portfolio service.
                          Direct portfolio building --- not a fund. Four
                          pillars: Guidance, Tools, Access,
                          Administration. EIS compliance via SeedLegals.
                          Instant Investment process live.
  ----------------------- -----------------------------------------------

+-----------------------------------------------------------------------+
| **What this means in practice:**                                      |
|                                                                       |
| Know exactly what you own and what it costs. See how your portfolio   |
| holds up before a crash. Understand the tax interactions of every     |
| decision before you make it. Access deals that were previously closed |
| to retail investors. From one platform that has no interest in        |
| selling you anything.                                                 |
+-----------------------------------------------------------------------+

**Who This Is For**

Unlock is built for UK private investors with £1M--£20M+ in total
wealth: complex, multi-asset portfolios spread across five or more asset
classes, managed without the benefit of institutional tools.

**The Preserver (∼30% of target segment)**

Protecting wealth and minimising downside. Late accumulation,
transitioning to decumulation. Capital preservation is the dominant
objective. The Preserver uses Unlock to stress-test portfolios under 30+
scenarios, confirm that risk controls are genuinely working, and
validate adviser recommendations without conflict. Sequencing errors in
decumulation are irreversible --- no other platform models them against
an investor's actual holdings.

**The Growth Seeker (∼40% of target segment)**

Long-term wealth growth with calculated risk. Active accumulation,
typically 30--55, deploying capital into new positions. The Growth
Seeker uses Unlock to compare upside against downside before committing,
access vetted syndicates on better terms than crowdfunding platforms
offer, and track lot-level performance across a growing portfolio. This
persona often transitions toward Preserver characteristics as wealth
consolidates --- extending platform relevance across two lifecycle
phases.

**The Legacy Builder (∼30% of target segment)**

Intergenerational wealth transfer and tax efficiency. Spans late
accumulation through decumulation. The defining objective across both
phases is structuring wealth for the next generation with minimum tax
leakage. The Legacy Builder uses Unlock to model EIS/SEIS tax
advantages, plan IHT-efficient drawdown sequences, and ensure family
structures are documented and transferable.

The April 6, 2026 IHT rule changes --- EIS/SEIS relief capped at 100% up
to £2.5M per estate, 50% above that --- make timing acutely relevant.
Unlock is the only platform that models this across both accumulation
and decumulation simultaneously.

**Why Now**

*Four structural factors make this the right moment to build Unlock ---
and the right moment to invest.*

**1. April 6, 2026 IHT Rule Change**

From April 6, 2026, IHT relief on EIS/SEIS investments is capped at 100%
up to £2.5M per estate, with 50% relief on amounts above that
threshold. Investors who have been using EIS/SEIS for IHT mitigation
need to understand the new ceiling and structure their portfolios
accordingly --- before this date. Founding investors who close before
April 6 benefit from full BPR treatment under current rules.

**2. Technology Has Made This Possible**

AI now enables institutional-grade portfolio analysis at consumer cost.
What previously required a dedicated team or a £5,000+ annual adviser
relationship is now buildable at scale. Unlock benefits from this shift
structurally --- the cost curve has moved to make the product viable for
the first time.

**3. The Market Gap Is Specific and Large**

No genuinely independent, investor-first platform for UK private
investors with £1M--£20M in total wealth. Below that floor: retail
mass-market tools. Above it: family offices. In the middle: a large,
under-served, well-defined segment with no dedicated solution.

**4. The UK Regulatory Moat**

EIS, SEIS, CGT, IHT, pension drawdown, AIM BPR --- continuous HMRC
rule-tracking across all of these takes 18--24 months minimum to build
correctly. No comparable jurisdiction has this regulatory density. The
moat is real, decided, and fully funded by this raise. Early movers
benefit from a data flywheel that compounds as portfolio histories
accumulate.

**The Founding Investor Offer**

*Approximately 25 founding investors. £1.2M raise at £6.5M pre-money
valuation. These terms are not available after Q1 2027.*

**Investment Structure**

Unlock uses an Instant Investment via SeedLegals --- the UK's leading
EIS/SEIS investment platform, used in approximately 33% of UK funding
rounds. Instant Investment provides anti-dilution protection until
Series A and enables EIS compliance processing at the point of
investment.

Shares are issued on April 6, 2026. This date is fixed. It protects
founding investors from dilution during the Growth Capital round and
aligns with the IHT rule changes that take effect on the same date.

  -------------------------- --------------------------------------------
  **Term**                   **Detail**

  **Pre-money valuation**    £6.5M

  **Raise target**           £1.2M

  **Founding investor        ∼25 (quality-controlled)
  slots**                    

  **Instrument**             Instant Investment via SeedLegals

  **Share issuance date**    April 6, 2026 (fixed)

  **Ticket range**           £40,000 -- £500,000

  **EIS / SEIS relief**      Processed at point of investment via
                             SeedLegals

  **Founding investor        Negotiated individually based on strategic
  discount**                 value
  -------------------------- --------------------------------------------

**Five Lifetime Founding Investor Benefits**

-   Lifetime premium platform access *--- no subscription cost, ever.*

-   Priority syndicate allocation *--- first access to all vetted
    deal-flow.*

-   Founding investor discount *--- negotiated individually; not
    published.*

-   White-glove onboarding *--- direct portfolio setup with the Unlock
    team.*

-   Quarterly reporting and direct founder access *--- direct line to
    progress and strategy.*

+-----------------------------------------------------------------------+
| **On the ∼25 slots:**                                                 |
|                                                                       |
| The founding round is limited by design, not by artificial scarcity.  |
| Founding investors are not just capital --- they are network,         |
| credibility, and signal. The round is closed when we have the right   |
| investors, not when we have hit a number.                             |
+-----------------------------------------------------------------------+

**EIS & SEIS: The Tax Context**

*Government-backed tax reliefs that materially change the risk profile
of early-stage investing.*

EIS (Enterprise Investment Scheme) and SEIS (Seed Enterprise Investment
Scheme) are UK government programmes providing substantial tax reliefs
to investors in qualifying early-stage companies. When structured
correctly, they significantly reduce the investor's effective downside
exposure.

  ------------------------- ---------------------------------------------
  **Scheme**                **Income Tax Relief**

  **SEIS**                  50% of investment value

  **EIS**                   30% of investment value
  ------------------------- ---------------------------------------------

**Effective Cost Illustration --- £50,000 Invested Under SEIS**

  -------------------------- ---------------------- ----------------------
  **Tax bracket**            **45% Additional       **40% Higher Rate**
                             Rate**                 

  Investment                 £50,000                £50,000

  SEIS income tax relief     £25,000                £25,000
  (50%)                                             

  Effective cost after       £25,000                £25,000
  relief                                            

  Additional loss relief if  Up to £11,250 further  Up to £10,000 further
  company fails                                     

  Maximum net downside       ∼£13,750 (∼27.5p per   \~£15,000 (∼30p per £)
  exposure                   £)                     
  -------------------------- ---------------------- ----------------------

+-----------------------------------------------------------------------+
| **April 6, 2026 IHT change:**                                         |
|                                                                       |
| IHT relief on EIS/SEIS investments is capped at 100% up to £2.5M per    |
| individual from April 6, 2026. Relief on amounts above that threshold |
| reduces to 50%. Investors planning to use EIS/SEIS for IHT mitigation |
| should structure investments before this date to maximise relief      |
| under current rules.                                                  |
|                                                                       |
| Note: Tax treatment depends on individual circumstances and may       |
| change. This is not financial or tax advice. Investors should seek    |
| independent advice before making any investment decision.             |
+-----------------------------------------------------------------------+

**Traction & Team**

**Validation to Date**

-   40+ structured market interviews completed with UK HNW investors.

-   70% of surveyed investors confirmed they would pay for better
    portfolio intelligence tools.

-   Functional pre-alpha in active use by founding investors for live
    onboarding and demos.

-   Weekly user sessions validating usability and product-market fit.

-   Founding investor backing from former chairman of Barclays and
    former Director General of TISA.

-   Founding investor commitments active. Round in progress.

**The Team**

  ------------------ ----------------------------------------------------
                     **Role & Background**

  **Thomas King**    Founder & Chief Executive Officer. 12+ years in
                     investor-introduction and capital-facilitation
                     technology. Founder of Cloudworkz (AI operating
                     intelligence platform). £250M+ capital facilitated.
                     Leads product vision, investor relations, and the
                     founding round.

  **Werner Snyman**  Head of Product. 19 years in senior product roles at
                     Nedbank. Deep expertise in wealth management
                     platform architecture and user experience for
                     sophisticated investors.

  **William Corke**  Head of Service Delivery & Compliance. Track record
                     delivering multi-million-pound projects for FTSE 500
                     clients. Oversees investor onboarding, service
                     quality, and regulatory compliance.

  **Claudia Chavez** Co-Founder & Commercial Director. Fintech
                     partnerships and commercial development. Leads
                     strategic relationships, partner channels, and
                     commercial growth.
  ------------------ ----------------------------------------------------

**Next Steps**

*The process is direct. Founding investors who are ready to proceed can
be onboarded within one week.*

**Step 1 --- Discovery Call (20 minutes)**

A direct conversation with Tom King. The goal is to confirm fit on both
sides: whether the investment makes sense for you, and whether you bring
the kind of strategic value that matters at this stage.

**Step 2 --- Platform Demo (30 minutes)**

A live walkthrough of the founding-stage platform. You see what exists
today, what is in build, and how the product experience maps to your
portfolio type. Questions answered directly.

**Step 3 --- Reserve Allocation**

Confirm your allocation. SeedLegals processes the Instant Investment
agreement. EIS / SEIS compliance processed at point of investment.
Shares issued April 6, 2026.

**To start a conversation:**

Tom King \| Founder & CEO

tom@unlockdd.com \| unlockdd.com

*This document is private and confidential. It is intended solely for
the named recipient and must not be reproduced or distributed without
the prior written consent of Unlock. This document does not constitute
financial advice. Investment in early-stage companies carries
significant risk, including the possible loss of capital. EIS/SEIS
eligibility and tax treatment depend on individual circumstances and may
change. Recipients should seek independent financial and tax advice
before making any investment decision.*


---

<!-- END OF DOCUMENT -->

## Pack 2 — Information Memorandum
*Stage: Decision | All personas | 130_IIM*

---

**UNLOCK**

**Investor Information Memorandum**

Founding Round --- 2025 / 2026

Prepared for: \[Investor Name\]

Prepared by: Tom King, Founder & CEO, Unlock

Date: March 2026

*This document is private and confidential. It is intended solely for
the named recipient. It supplements the Founding Investor Brief (Pack 1)
with full financial, legal, and operational detail to support investment
due diligence. It does not constitute financial advice. Recipients
should seek independent financial and tax advice before making any
investment decision.*

**Document Contents**

  ----------------------- -----------------------------------------------
  **Section**             **Contents**

  **1. Investment Terms & Instant Investment mechanics, founding investor
  Structure**             terms, worked example, SeedLegals process,
                          timeline

  **2. Valuation &        Valuation rationale, comparables, sensitivity
  Returns Framework**     analysis, exit scenarios

  **3. Financial          5-year revenue, user growth, unit economics,
  Projections**           break-even analysis

  **4. The Platform &     Full product description with build status for
  Product**               each service

  **5. Go-to-Market       Acquisition channels, sales funnel, partner
  Strategy**              strategy

  **6. Risk Factors**     Full risk disclosure with mitigations

  **7. Regulatory &       EIS/SEIS mechanics, IFA advice gap, April 2026
  Compliance**            IHT changes

  **Appendix A**          Team & Governance

  **Appendix B**          Competitive Analysis

  **Appendix C**          Glossary of Key Terms
  ----------------------- -----------------------------------------------

**1. Investment Terms & Structure**

**1.1 The Investment Instrument: Instant Investment via SeedLegals**

Unlock uses Instant Investment via SeedLegals --- the UK's leading
EIS/SEIS investment platform. Instant Investment is the instrument used
in this founding round. It enables immediate EIS compliance processing
and provides structural anti-dilution protection until Series A.

SeedLegals is the UK\'s leading EIS/SEIS investment platform, used in
approximately 33% of UK funding rounds. The use of SeedLegals ensures
full HMRC compliance, professional share issuance documentation, and a
standardised process familiar to UK advisers and solicitors.

**Key features of the Instant Investment structure:**

-   EIS compliance processed at point of investment --- not after round
    close.

-   Anti-dilution protection: founding investor ownership percentage is
    protected until Series A.

-   Shares issued on a fixed date: April 6, 2026.

-   Legally standardised: SeedLegals template, familiar to advisers and
    solicitors.

**1.2 Founding Investor Terms**

Founding investors invest at £6.5M pre-money valuation via the Instant
Investment structure described above. The round target is £1.2M across
approximately 25 investors.

Founding investor discounts are negotiated individually based on the
strategic value the investor brings beyond capital. Discount tiers are
not published. Tickets range from £40,000 to £500,000.

  -------------------------- --------------------------------------------
  **Term**                   **Founding Investors**

  **Pre-money valuation**    £6.5M

  **Round target**           £1.2M

  **Number of investors**    ∼25

  **Instrument**             Instant Investment via SeedLegals

  **Platform**               SeedLegals (HMRC-compliant)

  **Share issuance date**    April 6, 2026 (fixed)

  **Ticket range**           £40,000 -- £500,000

  **Founding investor        Negotiated individually
  discount**                 

  **Anti-dilution**          Ownership % protected until Series A
  -------------------------- --------------------------------------------

**1.3 Worked Example: £50,000 Investment Under SEIS**

  ----------------------- -----------------------------------------------
  **Step**                **Detail**

  **Investment made**     £50,000 via Instant Investment (SeedLegals)

  **SEIS income tax       HMRC returns £25,000 to investor via Self
  relief (50%)**          Assessment

  **Effective cost after  £25,000
  relief**                

  **Share issuance**      April 6, 2026: shares issued in investor\'s
                          name

  **If investment         Profits are tax-free on exit after 3-year
  succeeds**              qualifying hold

  **If company fails**    Additional loss relief reduces net loss further
                          (amount depends on tax bracket)

  **IHT exemption**       Qualifying EIS/SEIS shares are IHT-exempt after
                          2 years (subject to April 2026 cap)
  ----------------------- -----------------------------------------------

*Note: EIS and SEIS tax treatment depends on individual circumstances.
This example is illustrative. Investors should confirm eligibility and
relief with a qualified tax adviser.*

**1.4 Investment Process & Timeline**

  ------------------ ----------------------------------------------------
  **Stage**          **Action**

  **Day 1**          Investor confirms soft commitment. Tom King confirms
                     founding investor terms.

  **Days 2--3**      SeedLegals prepares Instant Investment agreement.
                     Investor reviews (solicitor optional, typically
                     £500).

  **Day 4**          Instant Investment agreement signed electronically.
                     Capital transferred to Unlock's designated account.

  **Days 5--7**      SeedLegals issues shares. Investor receives share
                     certificate. HMRC application submitted.

  **Weeks 2--4**     HMRC processes EIS/SEIS application. Tax relief
                     confirmed for Self Assessment claim.

  **April 6, 2026**  Shares formally issued on this date across all
                     founding investors.

  **Ongoing**        Quarterly investor updates. Direct founder access.
                     Platform access --- lifetime, premium.
  ------------------ ----------------------------------------------------

**2. Valuation & Returns Framework**

**2.1 Valuation Rationale**

The £6.5M pre-money valuation is set at the founding round to reflect
the stage of development, validated demand, and the regulatory moat
being built. It is benchmarked against comparable early-stage B2B SaaS
and fintech platforms at seed stage in the UK.

The valuation represents a discount to projected forward milestones.
Founding investors enter at the lowest valuation this business will ever
be offered at, ahead of public launch, Growth Capital round, and the
full platform build funded by this raise.

**2.2 Projected Returns: Base Case**

  ------------- ------------------- ------------------- ------------------
  **Horizon**   **Scenario**        **Projected         **Multiple on
                                    Valuation**         Entry (£6.5M)**

  **Year 2--3** Strategic M&A       £20--£30M           3--5×
                (early)                                 

  **Year 3--4** Strategic M&A       £50--£70M           8--11×
                (primary)                               

  **Year 4--5** PE buyout / IPO     £100M+              15×+
                pathway                                 
  ------------- ------------------- ------------------- ------------------

*Projected returns are not guaranteed. These figures represent
management estimates based on comparable transactions and the financial
model. Actual outcomes may differ materially.*

**2.3 Strategic Exit Considerations**

Named strategic acquirers operating in adjacent markets: Bloomberg,
Morningstar, Refinitiv, Crowdcube, S&P Global. Each has a rationale:
Unlock's proprietary lot-level data asset, UK tax intelligence
capability, and the HNW investor base are all acquirable assets in the
context of a larger wealth intelligence platform.

IPO pathway: at £20M+ ARR with 10,000+ subscribers. Fintech PE buyout:
at 7--10× ARR multiples for profitable SaaS with demonstrable moat.

Base case: 5--10× returns within 3--5 years. Projections are management
estimates; actual outcomes depend on execution and market conditions.

**3. Financial Projections**

**3.1 Revenue Projections (2026--2029)**

  ---------- ---------------- ------------------- --------------------------
  **Year**   **Revenue**      **Stage**           **Notes**

  **2026**   ∼£1.4M           Beta + early        Growth Capital round.
                              syndicates          Platform in limited
                                                  access.

  **2027**   ∼£3.0M           Public launch       Q1 2027 public launch.
                                                  Subscription growth
                                                  accelerating.

  **2028**   ∼£5.0M           Subscription +      Established product.
                              syndicate growth    Multiple revenue streams
                                                  active.

  **2029**   £8.25M--£9.25M   Mature ARR          Institutional channels
                                                  opening. Year 5 EBITDA
                                                  positive.
  ---------- ---------------- ------------------- --------------------------

*These are forward-looking projections based on management assumptions.
They are not guaranteed and should not be relied upon as forecasts.*

**3.2 User Growth**

  -------------- ------------------ ------------------ --------------------
  **Year**       **Free Users**     **Paid Users**     **Notes**

  **2026**       10,000             500                Beta cohort.
                                                       Founding investor
                                                       onboarding.

  **2027**       28,000             1,200              Public launch.
                                                       Content-led growth.

  **2028**       50,000+            3,600              Adviser referral
                                                       channel activating.
  -------------- ------------------ ------------------ --------------------

**3.3 Unit Economics**

  ------------------------ ------------------- --------------------------
  **Metric**               **Figure**          **Notes**

  **Customer Acquisition   £200                Warm introductions,
  Cost (CAC)**                                 referrals, content. Does
                                               not include paid
                                               acquisition.

  **Lifetime Value (LTV)** £3,000--£3,250      3--5 year average lifetime
                                               on current churn
                                               assumptions.

  **LTV:CAC ratio**        10:1 to 15:1        Strong structural
                                               economics. Referral
                                               flywheel improves this
                                               over time.

  **Payback period**       ∼3 months (steady   At mature conversion
                           state)              rates. Longer in early
                                               build phase.

  **Gross margin           High margin SaaS    Infrastructure cost per
  (subscription)**                             user is minimal at scale.

  **Gross margin           90%+                Minimal cost per syndicate
  (syndicates)**                               at current volumes.
  ------------------------ ------------------- --------------------------

**3.4 Use of Founding Round Funds (£1.2M)**

  ---------------- ---------------- -------------- ----------------------------
  **Category**     **Allocation**   **Amount**     **Priority**

  **Product & AI   35%              ∼£420,000      Tax intelligence engine,
  Development**                                    portfolio simulator, asset
                                                   register automation.

  **Go-to-Market & 32%              ∼£384,000      Growth Capital round
  Sales**                                          outreach, content, adviser
                                                   partnerships.

  **Team &         21%              ∼£252,000      Engineering, compliance,
  Operations**                                     service delivery hires.

  **Working        12%              ∼£144,000      18--24 month operational
  Capital**                                        runway to Year 3
                                                   profitability.
  ---------------- ---------------- -------------- ----------------------------

**4. The Platform & Product**

Unlock is a founding-stage platform. The following table describes each
service, its current build status, and the investor benefit. Build
status is stated honestly. Claims are not made for capabilities not yet
live.

**Asset Register**

The single source of financial truth. A permanent, accurate record of
everything an investor owns across all accounts, platforms, wrappers,
and family members.

Core features: Lot-level tracking (date, units, price paid per
purchase). Cost basis evolution to current value. Income tracking
(dividends, interest, coupons) with routing visibility. Document linkage
(statements, contract notes, valuations). Household view across people,
wrappers, and entities. Date-freeze for IHT/probate valuations. Plain
language queries.

*Build status: Operational for founding investor onboarding. Automated
multi-platform connections on roadmap.*

**Portfolio Simulator**

Scenario testing and stress modelling grounded in the investor's actual
positions. Models what happens to a real portfolio under defined
conditions --- not a hypothetical model portfolio.

Core features: 30+ downside scenario models (markets crash 30%, interest
rates spike, property falls, stagflation). Macro belief integration.
Upside vs downside comparison. All insights traceable to actual
positions.

*Build status: Decided capability. In active development. Full build
funded by this raise.*

**Tax Intelligence Engine**

Real-time, forward-looking modelling of all UK tax interactions across
EIS, SEIS, CGT, IHT, pension drawdown, and AIM BPR. Continuous HMRC
rule-tracking. This is Unlock's core defensive moat.

Core features: EIS/SEIS relief tracking and optimisation. CGT
crystallisation timing and deferral modelling. IHT planning and
inheritance scenario modelling. Pension drawdown sequencing. AIM BPR
eligibility tracking.

*Build status: Decided capability. Core moat. 18--24 months minimum for
any competitor to replicate correctly. Full build funded by this raise.*

**Syndicate Access**

Curated access to vetted collective investment opportunities at 8--10%
fees versus the 9--14% charged by Crowdcube, Seedrs, and comparable
platforms. Founding investors receive priority allocation on all
deal-flow.

*Build status: Operational. Founding investors have priority access
now.*

**Unlock Access --- EIS Deal-Flow Service**

A curated EIS deal-flow and portfolio service. Direct portfolio building
--- not a fund. Investors build their own EIS portfolio from Unlock's
curated pipeline, with full visibility at every stage. Four pillars:
Guidance, Tools, Access, Administration.

Transparency note: Unlock Access raises for its own pipeline companies.
This is stated openly. The positioning is full transparency and
disclosure --- not claims of independence from deal-flow.

*Build status: Operational. EIS compliance processed via SeedLegals.
Instant Investment process live.*

**Decumulation Planner**

A planning tool that answers: given my assets, how long will my money
last if I spend £X per year --- and what is the optimal sequence to draw
assets to minimise tax and maximise the estate passed to heirs? Asset
classes covered: Cash, ISA (including flexible ISA), pension
(DC/SIPP/workplace), investment property, VCT, EIS, AIM shares.

Four drawdown strategies: Tax-optimised (minimise income tax and CGT
drag), IHT-optimised (maximise estate), Income-first, Growth-first. Each
produces a different asset draw priority order. User selects strategy;
platform models all four for comparison.

*Build status: Technical specification v1.2 complete (March 2026).
Prototype build commencing. This capability is funded by the founding
round.*

**5. Go-to-Market Strategy**

**5.1 Customer Acquisition Channels**

  -------------------- --------------------------------------- -------------
  **Channel**          **Description**                         **Stage**

  **Proprietary HNW    30,000+ UK HNW investor profiles.       Active now
  database**           Direct outreach channel. Founding round 
                       being closed through this database.     

  **Warm introductions Network-driven introductions from       Active now
  & referrals**        founding investors, advisers, and       
                       existing relationships.                 

  **Content & thought  Long-form content on EIS/SEIS, IHT      In build
  leadership**         planning, portfolio intelligence.       
                       Establishes authority in target         
                       segment.                                

  **Media & PR         Specialist financial press and          In build
  partnerships**       HNW-facing media. Thought leadership    
                       positioning for Tom King.               

  **Founder-hosted     Private events for qualified HNW        In build
  investor events**    prospects. High-trust, low-friction     
                       conversion environment.                 

  **Syndicate-driven   Founding investors and syndicate        Active now
  referrals**          participants refer their networks.      
                       Network effect with high trust signals. 
  -------------------- --------------------------------------- -------------

**5.2 IFA & Adviser Partner Channel**

IFAs are not competitors. They are potential distribution partners. IFAs
are legally prohibited from advising on individual EIS company
investments --- they can only advise on EIS funds and VCTs. Unlock fills
exactly this gap with intelligence tools and due diligence support.

KYS (Know Your Situation) packs, formatted for adviser meetings, make
Unlock a complement to professional advice rather than a threat to it.
IFA referrals to Unlock are low-CAC and high-trust when the channel is
activated at scale.

**5.3 Founding Round vs Growth Capital Round**

Founding round (current): quality-controlled, founder-led, closed
through the proprietary database and network. Approximately 25
investors. Not a volume exercise.

Growth Capital round (Q2 2026 target): volume playbook. Outreach
infrastructure (Pipedrive CRM, Aircall), agent training, content-led
inbound, and adviser partnerships all active. This is what the
go-to-market allocation in the founding round budget is building toward.

**6. Risk Factors**

The following risks are disclosed without softening. Each is real. Each
has a mitigation. Investors should read this section carefully and seek
independent advice.

  ---------------- ----------------------------- ------------------------
  **Risk**         **Detail**                    **Mitigation**

  **Pre-launch,    Public launch targeted Q1     Working product in use.
  pre-revenue at   2027. Revenue at founding     Complete technical
  scale**          stage is pre-scale. Current   specifications. Credible
                   build is founding-stage       milestone roadmap.
                   desktop application.          Break-even projected at
                                                 Year 2 ARR.

  **Founder-led    Tom King conducts all demos   By design for founding
  trust            at this stage. Credibility    round (25 slots). Growth
  dependency**     cannot yet be delegated.      Capital round requires
                                                 delegation --- agent
                                                 playbook and training
                                                 infrastructure being
                                                 built.

  **Automated data Multi-asset integration (ISA  White-glove onboarding
  connections not  platforms, broker accounts,   operational now.
  yet live**       pension providers) is on the  Automated connections
                   roadmap. Manual onboarding    funded by this raise.
                   operational for founding      
                   investors.                    

  **No user        Pre-launch. Social proof from 40+ market interviews.
  testimonials     live platform users does not  70% would pay. Founding
  yet**            yet exist.                    investor commitments and
                                                 senior-level backing
                                                 provide partial
                                                 compensation.

  **Series A       Full platform build and       Break-even projected
  dependency**     Growth Capital ambitions      without Series A at Year
                   require follow-on funding.    2 ARR (£3M). Strong unit
                                                 economics (LTV:CAC
                                                 10--15:1). Realistic
                                                 profitability pathway.

  **Incumbent      Large platforms could attempt Product conflict makes
  competitive      to add portfolio intelligence genuine independence
  response**       features.                     impossible for
                                                 incumbents. UK tax
                                                 complexity takes 18--24
                                                 months minimum to build
                                                 correctly. Data flywheel
                                                 advantages early movers.

  **EIS/SEIS rule  HMRC or FCA changes to        Platform designed for
  changes**        EIS/SEIS rules could affect   continuous HMRC
                   tax relief availability.      rule-tracking.
                                                 Regulatory change is a
                                                 risk for investors in
                                                 any EIS/SEIS vehicle.
  ---------------- ----------------------------- ------------------------

**7. Regulatory & Compliance**

**7.1 EIS & SEIS Overview**

  ------------ ---------------- ------------------ ------------------- ----------
  **Scheme**   **Income Tax     **Annual Limit**   **CGT**             **IHT**
               Relief**                                                

  **SEIS**     50%              £200,000 per year  Tax-free after 3    Exempt
                                                   years; loss relief  after 2
                                                   if company fails    years
                                                                       (April
                                                                       2026 cap
                                                                       applies)

  **EIS**      30%              £1,000,000 per     Tax-free after 3    Exempt
                                year (standard     years; CGT deferral after 2
                                EIS)               available; loss     years
                                                   relief if company   (April
                                                   fails               2026 cap
                                                                       applies)
  ------------ ---------------- ------------------ ------------------- ----------

*Note: Tax treatment depends on individual circumstances and is subject
to HMRC rules which may change.*

**7.2 The April 6, 2026 IHT Change**

From April 6, 2026, IHT relief on EIS/SEIS investments is subject to a
new cap: 100% relief applies up to £2.5M per estate; relief on amounts
above that threshold reduces to 50%. This is a significant structural
change for HNW investors who have been using EIS/SEIS for IHT
mitigation.

Investors planning to use EIS/SEIS for IHT mitigation purposes should
structure their investments before April 6, 2026 to maximise relief
under current rules. Founding investors who close before this date
benefit from full BPR treatment on their qualifying shares.

+-----------------------------------------------------------------------+
| **Important:**                                                        |
|                                                                       |
| This is not manufactured urgency. The April 6, 2026 change is         |
| confirmed HMRC policy. Investors with existing EIS/SEIS positions or  |
| planning new ones should review their position with a qualified tax   |
| adviser before this date.                                             |
+-----------------------------------------------------------------------+

**7.3 The IFA Advice Gap**

IFAs are not permitted to advise on individual EIS company investments
under current FCA regulations. They can only advise on EIS funds and
VCTs. This is a structural feature of UK financial regulation, not a
limitation of Unlock.

It means that sophisticated investors evaluating direct EIS
opportunities have no regulated adviser to turn to for guidance on
individual company investments. Unlock fills exactly this gap:
intelligence tools, due diligence support, and portfolio-level modelling
that IFAs cannot legally provide.

IFAs are therefore potential distribution partners --- not competitors.
They refer clients who need tools and information the IFA cannot legally
provide.

**Appendix A. Team & Governance**

  -------------- ------------------- ------------------------------------
                 **Role**            **Background**

  **Thomas       Founder & Chief     12+ years building
  King**         Executive Officer   investor-introduction and
                                     capital-facilitation technology.
                                     Founder of Cloudworkz (AI operating
                                     intelligence platform for SMBs).
                                     £250M+ capital facilitated across
                                     investment platforms. Leads product
                                     vision, investor relations, and the
                                     founding round. Dual-founder role
                                     across Unlock and Cloudworkz is a
                                     structural advantage: the Cloudworkz
                                     platform directly supports Unlock's
                                     content and outreach infrastructure.

  **Werner       Head of Product     19 years in senior product
  Snyman**                           leadership roles at Nedbank. Deep
                                     expertise in wealth management
                                     platform architecture, user
                                     experience design for sophisticated
                                     investors, and financial product
                                     build.

  **William      Head of Service     Track record delivering
  Corke**        Delivery &          multi-million-pound projects for
                 Compliance          FTSE 500 clients. Oversees investor
                                     onboarding quality, service delivery
                                     standards, and regulatory compliance
                                     across all investor-facing
                                     processes.

  **Claudia      Co-Founder &        Fintech partnerships and commercial
  Chavez**       Commercial Director development. Leads strategic partner
                                     relationships, commercial channel
                                     development, and growth initiatives.
                                     Co-founder with responsibility for
                                     commercial scaling.
  -------------- ------------------- ------------------------------------

**Advisory**

Founding investor backing from: former Chairman of Barclays and former
Director General of TISA. These are not nominal advisers. They are
investors who have assessed the opportunity and committed capital ---
which is a materially stronger signal than advisory board membership.

**Appendix B. Competitive Analysis**

Unlock competes in a market where every incumbent has a product conflict
it cannot resolve without dismantling its own business model. The
competitive analysis reflects this structural reality.

  ------------------ ---------------------- -------------- ------------------------- ---------------------
  **Competitor       **What They Offer**    **Fees**       **What They Lack**        **Why Unlock Wins**
  Type**                                                                             

  **IFAs & Wealth    Holistic financial     1--2% AUM +    Cannot advise on          Unlock fills the
  Managers**         advice.                fees           individual EIS company    EIS/SEIS direct
                     Relationship-driven.                  investments. Earn from    investment gap IFAs
                                                           product recommendations.  cannot touch.
                                                           Relationship-dependent,   Complement, not
                                                           not tool-dependent.       competitor.

  **DIY              Full control. Low      Near-zero      No modelling, no tax      Unlock replaces
  (Spreadsheets)**   cost. Manual.          direct cost    intelligence, no scenario reconstruction with
                                                           simulation. Manual        intelligence. Upgrade
                                                           reconstruction is fragile path for the
                                                           and time-consuming.       sophisticated
                                                                                     self-directed
                                                                                     investor.

  **Portfolio        Data aggregation       Freemium / low Limited tax intelligence. Unlock delivers
  Aggregators (e.g.  across accounts.       subscription   No scenario simulation.   institutional-grade
  Moneyhub)**                                              No EIS/SEIS deal-flow.    modelling on top of
                                                           Not built for HNW         aggregated data.
                                                           complexity.               Entirely different
                                                                                     capability level.

  **Crowdfunding     EIS deal access.       9--14% of      High fees.                Unlock offers better
  Platforms          Community of           funds raised   Retail-focused. No        economics (8--10%),
  (Crowdcube,        investors.                            portfolio intelligence.   better structure
  Seedrs)**                                                No tax optimisation       (Instant Investment
                                                           tools. No anti-dilution   anti-dilution), and
                                                           protection standard.      portfolio
                                                                                     integration.

  **Private Banks &  Comprehensive wealth   1--2% AUM +    Only accessible above     Unlock democratises
  Family Offices**   management.            performance    £20--50M.                 the capability layer:
                                            fees; entry    Relationship-driven, not  same intelligence,
                                            £20--50M+      tool-driven. Not          without the AUM
                                                           scalable.                 threshold or the
                                                                                     conflicts.
  ------------------ ---------------------- -------------- ------------------------- ---------------------

**Appendix C. Glossary of Key Terms**

  ------------------- ---------------------------------------------------
  **Term**            **Definition**

  **Instant           The investment instrument used in this founding
  Investment**        round. Processed via SeedLegals. Provides immediate
                      EIS compliance processing and anti-dilution
                      protection until Series A.

  **EIS (Enterprise   UK government programme providing 30% income tax
  Investment          relief on investments in qualifying early-stage
  Scheme)**           companies, plus CGT exemption and IHT benefits.

  **SEIS (Seed        UK government programme providing 50% income tax
  Enterprise          relief on investments in qualifying seed-stage
  Investment          companies. Higher relief rate; lower annual limit
  Scheme)**           than EIS.

  **IHT (Inheritance  UK tax on the estate of a deceased person above the
  Tax)**              nil-rate band. EIS/SEIS investments qualify for
                      Business Property Relief (IHT exemption) after 2
                      years, subject to the April 2026 cap.

  **BPR (Business     HMRC provision making qualifying business assets
  Property Relief)**  (including EIS/SEIS shares) exempt from IHT after 2
                      years of qualifying ownership.

  **CGT (Capital      UK tax on gains from the disposal of assets.
  Gains Tax)**        EIS/SEIS qualifying investments are CGT-exempt on
                      profits after a 3-year qualifying hold.

  **LTV (Lifetime     Total revenue expected from a single customer over
  Value)**            the duration of their relationship with the
                      platform. Unlock LTV: £3,000--£3,250.

  **CAC (Customer     Total cost to acquire a single new paying customer.
  Acquisition Cost)** Unlock CAC: £200.

  **ARR (Annual       Annualised value of recurring subscription
  Recurring           contracts. The primary revenue metric for SaaS
  Revenue)**          businesses.

  **SeedLegals**      UK\'s leading EIS/SEIS investment platform used in
                      ∼33% of UK funding rounds. Handles Instant
                      Investment processing, share issuance, and HMRC
                      compliance documentation.

  **Instant           The investment instrument used across Unlock Access
  Investment**        and this founding round. Processed via SeedLegals.
                      Enables immediate EIS compliance and anti-dilution
                      protection.

  **Decumulation**    The phase of an investor's wealth journey in which
                      they draw down assets to fund expenditure, rather
                      than accumulating new assets. Distinct from
                      accumulation in risk profile, tax implications, and
                      planning priorities.
  ------------------- ---------------------------------------------------

*This document is private and confidential. It is intended solely for
the named recipient and must not be reproduced or distributed without
the prior written consent of Unlock. This document does not constitute
financial advice. Investment in early-stage companies carries
significant risk, including the possible loss of capital. EIS/SEIS
eligibility and tax treatment depend on individual circumstances and are
subject to HMRC rules which may change. Recipients should seek
independent financial and tax advice before making any investment
decision. Unlock does not guarantee returns. All financial projections
are management estimates and should not be relied upon as forecasts.*


---

<!-- END OF DOCUMENT -->

## Unlock Access Explainer
*Stage: Demo Complete / Decision | Growth Seeker, Legacy Builder | 140_EXPLAINER*

---

# UNLOCK ACCESS
## What Unlock Access Is

*A plain-English guide for investors who are reading about Unlock Access for the first time.*

| What it is | What it is not | What makes it different |
|---|---|---|
| A curated deal-flow service that identifies, evaluates, and supports early-stage EIS-qualifying companies — and connects them to sophisticated investors who have been qualified to access them. | A fund. A regulated investment manager. A financial adviser. Unlock Access does not manage money, hold assets, or make investment decisions on your behalf. | Every company is scored against 24 published criteria before you see it. Every fee and relationship is disclosed. Every investor is qualified before accessing opportunities. |

---

## The Proposition in Plain Terms

Most sophisticated investors who invest in EIS do so through passive funds — vehicles that select from deal flow they do not originate, apply evaluation frameworks they do not publish, and report to investors who cannot interrogate the logic. When things go wrong, investors find out late.

Unlock Access is built on a different premise. Every company on the platform has been scored against 24 published criteria before any investor sees it. Every scoring summary is shared with investors in full — not as a marketing document, but as the same evaluation the Unlock Access team used to make its own decision. Every investor is qualified before accessing opportunities. Every fee and relationship is disclosed.

**The objective is not to find unicorns.** It is to build a portfolio where winners systematically outnumber losers — where the combination of rigorous evaluation, EIS tax relief structures, and active post-investment support means that, across a 15-year programme, investors achieve a win rate materially higher than the unscored market average.

---

## The Four Parts of the Service

Unlock Access provides four things, each of which the EIS market typically leaves investors to arrange for themselves.

### GUIDANCE — How to think about EIS investing

Portfolio construction, diversification, risk calibration, and the 15-year programme architecture that gives early-stage investing its best chance of generating consistent returns. The intelligence layer that helps investors make better decisions — without making those decisions for them.

### TOOLS — The platform infrastructure

Tax modelling, HMRC compliance submissions, portfolio tracking, scoring summaries, and due diligence packs. Every tool needed to invest and manage EIS positions efficiently — built into a single service rather than assembled from scratch by each investor.

### ACCESS — Curated deal flow

Companies that have passed the evaluation framework. The Unlock Access investor network. Opportunities that most investors would not find independently — and, critically, would not be able to assess with confidence if they did.

### ADMINISTRATION — Investment and portfolio administration

The compliance process, EIS3 certificate management, HMRC submissions, and ongoing portfolio administration that most EIS platforms leave investors to handle alone. Unlock Access handles the paperwork so investors focus on the decisions.

---

## The Evaluation Framework

No company reaches investors before this stage is complete.

| Stage | What happens | Filter |
|---|---|---|
| Initial screening | Business model, market size, founder background, EIS eligibility | Eliminates companies that do not meet basic criteria |
| Scored evaluation | 24-criterion framework across People, Strategy, Execution, Cash | Score threshold required to proceed |
| Investor qualification | Risk capacity, context, and tax position confirmed | This is a filter, not a formality |
| Post-investment support | Ongoing relationship — reporting, context, risk indicators | The relationship does not end at close |

---

## How Unlock Access Is Funded

Unlock Access earns from the service it provides to investors and companies — not from product recommendations, trail fees, or commissions. There are no hidden commercial relationships. All fees are disclosed in full before any investment is made.

This transparency is structural, not aspirational. Unlock Access raises capital for its own pipeline companies — Unlock and Cloudworkz — and states this openly. Full fee and relationship disclosure is what makes the Guidance part of the service credible.

---

## The Team Behind the Service

Unlock Access was founded by Tom King, who has spent 15 years facilitating alternative investment opportunities for sophisticated private investors — with over £250 million in investment facilitated through a network of high-net-worth and often high-profile investors. Tom is one of a small number of UK founders to hold Scaling Up certification, and the evaluation framework described in this document draws directly on that methodology, adapted specifically for EIS investment.

**tom@unlockdd.com | www.unlockdd.com**

---

*This document is for information purposes only and does not constitute financial advice or an invitation to invest. Unlock Access does not hold FCA authorisation and operates as a deal-flow and information service. EIS and SEIS investments are high-risk and illiquid. Capital is at risk. Investors should seek independent financial advice before making any investment decision.*

*Original: March 2026 | Last reviewed: 14 March 2026 | Status: Current*


---

<!-- END OF DOCUMENT -->

## EIS: The Investor's Secret Weapon
*Stage: Called / Demo Booked | Growth Seeker, Legacy Builder | 150_CASE*

---

# EIS: The Investor's Secret Weapon

**Unlock Investor Guidance Series**

*This document is for educational purposes only and does not constitute financial, tax, or investment advice. Tax treatment depends on individual circumstances and may change. Investors should seek independent professional advice before making investment decisions. Capital is at risk.*

---

## Part 1: The 2-Minute Version

The UK government will significantly subsidise you to invest in British companies.

That's not a gimmick. It's been policy since 1994. The Enterprise Investment Scheme (EIS) and its younger sibling, the Seed Enterprise Investment Scheme (SEIS), exist because the government wants private capital flowing into high-growth UK businesses. To make that happen, they offer investors tax reliefs that fundamentally change the risk-reward equation.

Here's what that looks like in practice:

- **30-50% of your investment comes back immediately** as income tax relief. Invest £100K in an EIS company, claim £30K off your tax bill. SEIS gives you 50%.
- **Profits are completely tax-free.** No Capital Gains Tax, provided you hold the shares for at least 3 years and the company continues to qualify. If the company 5x's, 10x's, or 100x's — you keep every penny.
- **If it fails, the government cushions the blow.** Loss relief means a higher-rate taxpayer only loses around 20-30p for every pound invested, depending on their marginal rate and how the relief is claimed.
- **After 2 years, it disappears from your estate.** EIS investments qualify for Business Property Relief — meaning zero inheritance tax.

One example. Sarah earns £120K. She invests £50K in an EIS-qualifying company. She claims £15K income tax relief immediately. Her real cost is £35K. If the company grows to 5x, she makes £250K — tax-free. If it fails completely, loss relief means she recovers around £15,750. Her actual downside: roughly £19,250. On a £50,000 investment.

That's asymmetric risk. Capped downside, uncapped upside, government-subsidised.

If you have a material income tax bill and you're not using EIS, you may be forgoing substantial government-backed reliefs available to qualifying investors.

---

## Part 2: Why You Haven't Heard About This

Every intelligent investor asks the same question: if EIS is this good, why hasn't someone told me?

The answer isn't that EIS is obscure. Over £34 billion has been invested through EIS and SEIS into nearly 59,000 UK companies since 1994. The government extended the scheme to 2035 because it works. Research suggests that around 40-50% of UK unicorn companies received EIS-backed funding at some point in their journey.

The reason you haven't heard about it is structural. The people you'd expect to tell you about it either can't, won't, or don't have the right incentive to.

### Your accountant can't recommend it

Accountants are not authorised by the Financial Conduct Authority (FCA) to provide investment advice. They can explain the tax mechanics after you've invested — how to claim the relief, when to file, how loss relief works. But they cannot say "you should invest in this company through EIS." It's a regulatory boundary, not a knowledge gap. Your accountant may be perfectly aware of EIS. They just aren't allowed to tell you to use it.

### Your financial adviser can, but only through funds

Financial advisers (IFAs) are FCA-authorised and can recommend EIS investments — but only regulated ones. EIS funds (managed portfolios run by FCA-authorised fund managers) are regulated products. Individual EIS companies are not.

This means your IFA can recommend an EIS fund that invests across 10-20 companies, managed by a fund manager taking 2% annual fees plus 20% of profits. What they cannot do is recommend that you invest directly in a specific EIS-qualifying company — because individual company shares are unregulated investments, and recommending them falls outside their permissions.

Here's why that matters: **EIS fund performance is, on the whole, disappointing.** Most funds target 2-3x returns, but many fail to deliver even that after fees. Total ongoing costs typically run at 3.5% per year plus arrangement fees on each transaction — so intermediaries take a significant share of whatever upside exists. Public performance data for EIS funds is virtually non-existent; what investors see in marketing materials are cherry-picked case studies and aspirational target returns. One of the best-performing EIS fund managers in the UK has delivered an average 2.6x ROI since 2001 — and that's considered an outlier, not the norm.

Meanwhile, the individual companies those funds invest in sometimes deliver extraordinary returns. One fund manager reported individual company exits at 8.7x, 14.2x, and 16.3x — but the fund-level return to investors, after losses on other holdings and after fees, is a fraction of those headline numbers. For many funds, the tax relief itself becomes the return — not the investment performance. That's the "tax tail wagging the investment dog" problem.

**The companies IFAs can recommend rarely deliver transformational returns. The companies they can't recommend are the ones that deliver 50x or 100x.**

The best-known EIS success stories — Revolut, Monzo, BrewDog, Wise, Thought Machine — all raised capital directly from early investors. Where those investments were made via funds, the fund structure significantly diluted the effective multiple for end investors. When a company returns 100x inside a 20-company fund, your share of that outcome is diluted to a 5x contribution (before the fund manager takes their cut). The fund structure caps your upside by design.

So the advisory system isn't broken — it's working exactly as regulated. But the effect is that investors are systematically steered toward the lower-returning version of EIS, while the highest-returning version remains invisible to anyone who relies on their IFA for guidance.

This is the gap Unlock fills. Not by providing regulated advice, but by providing the intelligence, due diligence, and access that lets investors evaluate individual EIS opportunities for themselves.

### EIS funds vs direct EIS — the structural gap

EIS funds invest across 10-20 companies. They offer diversification, professional management, and convenience. They're regulated, so advisers can recommend them. But performance data tells a sobering story — most funds target 2-3x, many deliver less than that after fees, and public performance data is scarce. The tax relief often ends up being the primary return, not the investment performance.

Direct EIS investment into individual companies is where the real wealth creation happens. But because individual company shares are unregulated investments, no IFA can point you toward them. You need to find them, evaluate them, and decide for yourself — which is exactly what most HNW investors don't have the time, tools, or deal flow to do.

The result is a two-tier system: a visible tier of EIS funds delivering steady, diluted returns that advisers can recommend, and an invisible tier of direct company investments delivering transformational returns that nobody in the regulated advice chain can tell you about.

Unlock's syndicate marketplace exists to make the invisible tier visible — with independent due diligence, structured access, and the tools to evaluate opportunities on your own terms.

### VCTs — the false alternative

Venture Capital Trusts (VCTs) are often presented as the main alternative to EIS. They're listed investment companies that pool investor capital and deploy it across 30-70 early-stage companies. They offer some tax benefits, but the comparison with EIS is not favourable for growth-focused investors:

| Feature | EIS (Direct) | VCT |
|---------|-------------|-----|
| Income tax relief | 30% | 20% (reduced from 30% in 2025 Budget) |
| Capital gains on profits | Tax-free | Tax-free |
| Loss relief | Yes — recovers up to 80% of loss | No |
| Inheritance tax relief | Exempt after 2 years | No |
| CGT deferral | Yes — defer gains from other assets | No |
| Annual investment limit | £1M (£2M for knowledge-intensive) | £200K |
| Minimum holding period | 3 years | 5 years |
| Typical return target | 10x+ (direct) / 2-3x (fund) | 5-7% annual income |
| Dividend tax treatment | Taxable | Tax-free |
| Liquidity | Low (private companies) | Low-medium (listed, but thin market) |

VCTs target income — typically 5-7% tax-free dividends annually, with total returns of 25-30% over 5 years. They're a tax-efficient savings product. For investors whose primary goals are capital growth, asymmetric risk, and estate planning rather than tax-efficient income, EIS typically offers stronger structural advantages.

The 2025 Autumn Budget made this clearer by reducing VCT income tax relief from 30% to 20%, while leaving EIS relief unchanged at 30%.

### The advisory gap is Unlock's opportunity

Nobody is currently helping HNW investors navigate direct EIS opportunities with independent due diligence, tax modelling, HMRC administration, and portfolio-level tracking. Financial advisers route you to funds. Accountants can't recommend. Platforms like Seedrs and Crowdcube prioritise deal volume over investor outcomes.

That gap — between what EIS offers and what investors can actually access — is what Unlock fills.

---

## Part 3: How It Actually Works — Three Investor Scenarios

The best way to understand EIS is through real situations. The following scenarios are illustrative and use simplified tax calculations. Individual circumstances vary — always seek professional advice before investing.

### Scenario A: The Growth Seeker — Using Your Tax Bill as an Investment Tool

**Profile:** James, 42. Earns £200K as a technology director. Pays approximately £63K in income tax annually. Has £800K across ISAs and a SIPP, mostly in global index trackers and a handful of blue-chip shares. No alternative investments. No EIS experience.

**The situation:** James has a concentrated, correlated portfolio. If public markets drop 30%, his entire wealth drops roughly 30%. He's been meaning to diversify but hasn't found a route into alternatives that doesn't involve high fees or opaque fund structures.

**The EIS approach:**

James invests £100K across 10 EIS-qualifying companies through Unlock's syndicate marketplace — £10K into each. Each company has been independently due-diligenced by Unlock.

**Immediate tax impact:**
- Claims 30% income tax relief: £30,000
- His next tax bill drops from £63K to £33K
- Effective cost of the £100K investment: £70,000

**Year 5 outcomes (illustrative portfolio):**

| Company | Investment | Outcome | Return | Tax treatment |
|---------|-----------|---------|--------|---------------|
| Company A | £10,000 | Fails | £0 | Loss relief claimable |
| Company B | £10,000 | Fails | £0 | Loss relief claimable |
| Company C | £10,000 | Fails | £0 | Loss relief claimable |
| Company D | £10,000 | Fails | £0 | Loss relief claimable |
| Company E | £10,000 | Fails | £0 | Loss relief claimable |
| Company F | £10,000 | Modest exit — 3x | £30,000 | Tax-free |
| Company G | £10,000 | Solid exit — 5x | £50,000 | Tax-free |
| Company H | £10,000 | Strong exit — 12x | £120,000 | Tax-free |
| Company I | £10,000 | Strong exit — 18x | £180,000 | Tax-free |
| Company J | £10,000 | Exceptional — 50x | £500,000 | Tax-free |

*Assumes higher-rate (45%) taxpayer and that loss relief is claimed against income. Actual relief depends on marginal rate and how relief is claimed. All figures are illustrative.*

**Total value received:** £927,500 on £70,000 effective cost. ~13x.

Strip out the 50x winner: £380,000 on £70,000 effective cost. Still 5.4x.

What if 8 out of 10 fail? Two companies surviving at 5x each = £100,000 gross. After income tax relief (£30K) and loss relief on 8 failures (£36K), the investor recovers £166,000 on a £100,000 investment. Still profitable despite an 80% failure rate.

---

### Scenario B: The Preserver — CGT Deferral + Inheritance Tax Planning

**Profile:** Margaret, 63. Recently sold a buy-to-let property for £400K, generating a £180K capital gain. Facing CGT of approximately £36,000. Estate valued at £2.1M. Concerned about inheritance tax.

**The EIS approach:** Margaret invests £180K into EIS-qualifying companies.

- Defers the entire £36,000 CGT liability (extinguished if held to death)
- Claims 30% income tax relief: £54,000
- After 2 years: £180K qualifies for BPR — IHT saving of £72,000

**Total tax benefit: £162,000 on a £180K investment. Effective cost: £18,000.**

**Important — April 2026 changes:** From April 6, 2026, 100% IHT relief on EIS is limited to the first £2.5M of qualifying assets per person. Above £2.5M, relief rate drops to 50%. For most HNW investors with EIS portfolios under £2.5M, the changes have no practical impact.

---

### Scenario C: The Legacy Builder — Family Wealth Strategy

**Profile:** David and Helen, 58. Combined estate £4.2M. Current IHT exposure approximately £1.2M. Each invests £250K in EIS-qualifying companies (£500K total).

- Combined income tax relief: £150,000
- Effective cost of £500K investment: £350,000
- After 2 years: BPR reduces estate exposure by £200,000

Even in a downside scenario where 80% of companies fail and the remaining return just 3x, the tax benefits alone (£150K income tax + £200K IHT) exceed the investment losses.

---

## Part 4: EIS vs Everything Else

| Feature | Direct EIS | EIS Fund | VCT | ISA | Pension (SIPP) |
|---------|-----------|----------|-----|-----|----------------|
| Income tax relief | 30% | 30% | 20%* | None | 20-45% |
| Annual limit | £1M (£2M KIC) | £1M | £200K | £20K | £60K |
| CGT on gains | Exempt | Exempt | Exempt | Exempt | Deferred |
| Loss relief | Yes | Yes | No | No | No |
| IHT exemption | After 2 years | After 2 years | No | No | Typically exempt |
| CGT deferral | Yes | Yes | No | No | No |
| Min holding period | 3 years | 3 years | 5 years | None | Age 57+ |
| Typical fees | Low/none | 2% + 20% carry | 2% + trail | 0.1-0.5% | 0.3-1% |

*VCT income tax relief reduced from 30% to 20% in the 2025 Autumn Budget*

**The key insight:** EIS is the only vehicle that combines upside protection (tax-free gains), downside protection (loss relief), estate protection (IHT exemption after 2 years), and current income offset (30% income tax relief) in a single investment.

---

## Part 5: The Maths of a Curated EIS Portfolio

**Evidence base:**
- ~60% of UK startups fail within 5 years (general population)
- ~20% failure rate for high-growth tracked companies
- A curated due-diligenced portfolio modelled conservatively at 50% failure
- £34 billion invested through EIS/SEIS into 59,000 companies since 1994
- 46.5% of all active UK unicorns received EIS-backed funding (Beauhurst 2024)
- 1,816 successful exits: 1,763 acquisitions, 53 IPOs

**Model portfolio: £100K across 10 companies**

| Outcome | Companies | Investment | Multiple | Return |
|---------|-----------|-----------|----------|--------|
| Fail | 5 | £50,000 | 0x | £0 |
| Moderate | 2 | £20,000 | 3-5x | £60,000-£100,000 |
| Strong | 2 | £20,000 | 12-18x | £240,000-£360,000 |
| Exceptional | 1 | £10,000 | 50x | £500,000 |

**Total value above original investment: ~£832,500. Return on effective cost (~£70K): ~13x.**

The asymmetry in one sentence: EIS reliefs mean you can afford to be wrong most of the time and still come out ahead. When you're right, the returns are tax-free and uncapped.

---

## Part 6: What Unlock Does For You

- **Opportunity access** — curated EIS/SEIS companies with independent due diligence reports
- **Allowance tracking** — remaining capacity across tax years, carry-back optimisation
- **Tax modelling** — income tax, CGT, and IHT impact before you commit
- **HMRC administration** — EIS3/SEIS3 certificate submission and compliance monitoring
- **Portfolio integration** — EIS alongside all other assets in the Unlock Asset Register
- **Ongoing monitoring** — holding period status, qualifying condition alerts

---

## Part 7: April 2026 — What's Changing

From April 6, 2026: 100% IHT relief on EIS is capped at £2.5M per person (combined with agricultural property). Above £2.5M, relief rate drops to 50% (effective 20% IHT on excess). Transferable between spouses — couples can shelter £5M.

**For most HNW investors with EIS portfolios under £2.5M, no practical impact.** EIS remains the most powerful IHT planning tool available in the UK.

**AIM shares:** Treated differently — drop from 100% to 50% BPR regardless of value, no £2.5M allowance. Direct EIS in private companies retains 100% relief up to £2.5M.

This is confirmed legislation via the Finance Bill 2025-26.

---

## Glossary

**BPR** — Business Property Relief. IHT exemption for qualifying business assets including EIS shares held 2+ years.

**CGT** — Capital Gains Tax. EIS gains are exempt.

**EIS** — Enterprise Investment Scheme. 30% income tax relief, CGT-free gains, loss relief, IHT exemption after 2 years.

**IHT** — Inheritance Tax. 40% on estates above nil-rate band (currently £325K + £175K RNRB).

**KIC** — Knowledge-Intensive Company. Higher EIS limits (£2M per investor).

**Loss Relief** — Failed EIS investment loss (minus income tax relief received) offset against income tax. Reduces effective loss to ~20-30p per pound for higher-rate taxpayers.

**SEIS** — Seed Enterprise Investment Scheme. 50% income tax relief, £200K annual limit.

**VCT** — Venture Capital Trust. 20% income tax relief, tax-free dividends, no loss relief or IHT exemption.

---

*Statistics drawn from HMRC National Statistics, Beauhurst EIS 30th Anniversary Report 2024, SyndicateRoom power law white paper, and publicly available fund manager disclosures. Full source references available on request.*

*Unlock is not a financial adviser and does not provide regulated investment advice. Scenarios are illustrative. Always consult a qualified adviser before investing.*

*© 2026 Unlock Services Limited. All rights reserved.*


---

<!-- END OF DOCUMENT -->

## Five EIS Case Studies 2026
*Stage: Called → Demo Complete | Growth Seeker, Legacy Builder | 160_CASE*

---

# UNLOCK ACCESS
# The Case for EIS 2026
### How EIS is used to build tax-free, generational wealth, and why 2026 is the time to act.

---

**EIS is most relevant to investors who tick one or more of these boxes:**

- You have a meaningful income tax bill — broadly, more than pensions, salary sacrifice, and ISA allowances have been able to absorb — and you would like to reduce it this tax year.
- You have a capital gain from a business sale, property disposal, or portfolio event that you would prefer not to pay in full this tax year.
- Your estate has IHT exposure, and the pension that used to help shelter it will be in scope from April 2027.
- You want exposure to early-stage UK companies with uncapped, CGT-free upside.

*You don't need to tick all four. Most investors come to EIS through one door and find the others open too.*

---

## Which profile is most relevant to you?

| If this sounds like you... | Go to |
|---|---|
| You have a meaningful income tax bill that pensions and ISAs haven't solved | **James (Case 1) or Sophie (Case 5)** |
| You've sold a business or property and face a CGT liability | **Richard (Case 2)** |
| Your pension was your estate plan — and April 2027 has broken it | **George (Case 3)** |
| You've recently retired with a higher-than-expected tax bill | **Martin (Case 4)** |
| You're a high earner in your 30s–40s building long-term tax-free wealth | **Sophie (Case 5)** |

---

## Why 2026 Is the Right Moment

The UK tax-advantaged landscape has shifted materially this year. Three structures that HNW investors have relied on have been curtailed or broken. One has not.

| Structure | Pre-2026 | 2026/27 Reality |
|---|---|---|
| VCTs | 30% income tax relief | Reduced to 20% from 6 April 2026 |
| Pensions (IHT) | Outside IHT scope entirely | In scope from 6 April 2027 |
| AIM shares (BPR) | 100% IHT relief | Reduced to 50% in all cases |
| **EIS/SEIS** | 30% / 50% income tax relief | **Unchanged — full reliefs intact** |

EIS is now the only mainstream UK structure with all four reliefs intact: immediate income tax reduction, CGT-free growth, loss relief, and IHT exemption after two years. The government has extended the scheme to 2035 and expanded company investment limits; companies can now raise up to £10M annually, up from £5M.

---

## Who This Document Is For

Direct investment into EIS-qualifying companies sits outside the scope of regulated financial advice in the UK. Your accountant can explain how EIS works and confirm the tax treatment, but cannot advise you to invest. Your financial adviser can recommend EIS funds managed by authorised discretionary managers, but cannot advise you to invest directly into individual companies.

The result is a structural gap. The investors best placed to benefit from direct EIS — those with meaningful income tax liabilities, significant capital gains, or estate planning requirements that conventional tools do not address — are precisely the investors whose professional advisers cannot point them toward it.

**The investors this document is written for have three things in common:**

**1. They have the liquidity to participate.** Capital committed should be genuinely surplus to requirements — money whose absence for five or more years creates no financial pressure.

**2. They have the time and inclination to engage.** In practice: reading the investment documentation for each company, signing a subscription agreement, and providing basic details to your accountant when the EIS3 certificate arrives. Unlock handles everything else.

**3. They are comfortable making decisions without being told what to do.** No regulated adviser will recommend a specific EIS company to you. The decision — which companies to back, how much to invest, and when — is yours entirely.

---

## How Returns Are Distributed

EIS investing follows a power law. NESTA's foundational UK study of 1,080 investments found that 9% of exits produced 80% of all positive cash flows. Unlock's research uses a 4/3/2/1 distribution per 10 companies:

| Companies | Outcome | Return multiple | Timeline |
|---|---|---|---|
| 4/10 | Write-off — total loss | 0x | Y 2–4 |
| 3/10 | Marginal exit | 2x | Y 4–7 |
| 2/10 | Strong exit | 6x | Y 7–10 |
| **1/10** | **Fund returner** | **20x** | **Y 10–15** |
| **Base Case** | **3.8× gross return across the portfolio** | **3.8x** | **All CGT-Free** |

The 3.8× base case sits above NESTA's 2.2× raw average for three reasons: EIS qualification acts as an involuntary quality filter; the EIS market professionalised significantly after 2012; and more recent data is more optimistic — the 2015 ERC study found 30% of investments expected to return 6× or more.

On the failures — four in ten — loss relief at 45% (additional-rate taxpayer) means the effective loss is approximately 38.5p per pound, not 100p. For a higher-rate taxpayer the figure is approximately 30p. On the exits, all gains are CGT-free.

*Sources: NESTA / BBAA (2009), Enterprise Research Centre / UKBAA (2015), Beauhurst / EISA 30th Anniversary Report (2024), GrowthInvest (2024), HMRC National Statistics.*

---

## How the Structure Works — David's Portfolio

David invests £10,000 into each of ten EIS-qualifying companies. Total deployed: £100,000. Income tax relief at 30%: £30,000. Effective cost after relief: £70,000.

| Companies | Outcome | Return multiple | Gross Return | Timeline |
|---|---|---|---|---|
| 4 | Write-off — total loss | 0x | £0 | Y 2–4 |
| 3 | Marginal exit | 2x | £60,000 | Y 4–7 |
| 2 | Strong exit | 6x | £120,000 | Y 7–10 |
| **1** | **Fund returner** | **20x** | **£200,000** | **Y 10–15** |
| **Total** | **4 losses. 6 exits.** | **3.8x gross** | **£380,000** | **All CGT-Free** |

Four failures cost David £23,800 net of loss relief at 45% (additional-rate taxpayer). Six exits return £380,000 entirely CGT-free — against an effective cost of £70,000 after income tax relief.

*The upside is uncapped and tax-free. The downside is materially reduced by the reliefs. That asymmetry is the structure.*

---

## CASE 1 — James
### A large income tax bill and nowhere left to put it efficiently.

James is a senior partner at a professional services firm. He earns £195,000 a year. His ISA has been maxed for fifteen years. His pension contributions are capped at the annual allowance. He pays just over £72,000 in income tax annually. The next £72,000 will go to HMRC the same way it always has. Unless he does something different.

**What EIS does for James:** EIS allows James to claim 30% of his investment back against his income tax bill in the year he invests. SEIS goes further: 50% relief. He blends both — £40,000 into SEIS, £80,000 into EIS — and his combined annual relief is £44,000. His effective annual cost is £76,000. HMRC funds the remaining £44,000. Any growth from companies that succeed is entirely free of CGT. Any cohort held for two years passes outside his estate without a trust, a gift, or a solicitor arrangement.

*Over fifteen years, James receives £660,000 in income tax relief — capital that would otherwise have gone to HMRC, returned to him in the year of investment before the underlying companies do anything at all.*

**Fifteen Years: EIS vs Paying Tax**

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (15yr) | £1,080,000 | £420,000 |
| Capital redirected into portfolio | £0 | £660,000 invested, not lost |
| Portfolio value at year 15 (base case) | £0 | £2,940,000 |
| CGT on exits | N/A | Zero |
| IHT position | Fully in estate | Full active portfolio outside estate |
| **Net financial position at year 15** | **£0 from the £660,000 paid to HMRC** | **£2,940,000 portfolio + £660,000 tax saved** |

*Annual investment £120,000 (£40,000 SEIS at 50% + £80,000 EIS at 30%). All figures illustrative. Capital at risk.*

---

## CASE 2 — Richard
### A business sale, a CGT liability, and an IHT problem that appeared overnight.

Richard has run his own business for twenty years. He draws salary and dividends of around £220,000 a year. For Richard, EIS is a response to events — and the events arrive quickly.

**Phase 1: Age 50–67 — Building the Portfolio**

For seventeen years, Richard invests £160,000 a year into a blend of SEIS and EIS-qualifying companies. Combined relief — £64,000 annually — reduces his income tax bill by nearly 80%.

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (17yr) | £1,360,000 | £272,000 |
| Capital redirected into portfolio | £0 | £1,088,000 invested, not lost |
| IHT position | Fully in estate | Full active portfolio outside estate |

**The Business Sale — Age 67**

Richard sells his business. Net proceeds generate a gain of approximately £600,000. After Business Asset Disposal Relief at 18%, his CGT liability stands at £108,000. In the year of the sale, he invests £400,000 into EIS-qualifying companies, deferring that liability in full. If he holds the shares until death, under current rules the deferred gain is extinguished entirely.

**Phase 2: Age 67–80 — Protection & Continuity**

In retirement, Richard continues investing annually: £50,000 into SEIS, £40,000 into EIS. Thirteen years in, approximately £1,390,000 of post-sale assets sit outside his estate. The IHT saving on those assets alone: approximately £556,000.

| | Without EIS | With EIS |
|---|---|---|
| CGT on business sale (£600k gain) | £180,000 paid | Deferred — extinguished on death |
| Post-sale assets in estate (13yr) | £1,390,000 IHT-exposed | £1,390,000 outside estate |
| IHT saving on exempt assets | £0 | ~£556,000 |
| Income tax relief (13yr) | £0 | £300,000 |

*All figures illustrative. Capital at risk.*

---

## CASE 3 — George
### A pension that used to shelter his estate. From April 2027, it doesn't.

George retired at 58 from financial services. His pension pot — built carefully over three decades — stands at £1.4M. For most of his retirement that pension has been his primary estate planning tool: it sits outside his estate, his sons inherit it free of IHT.

In October 2024, that plan changed. From 6 April 2027, unused pension pots and death benefits come into scope for inheritance tax. George's £1.4M pension will become fully IHT-exposed. His beneficiaries face a potential £560,000 tax bill.

| | Before April 2027 | After April 2027 |
|---|---|---|
| Pension Pot | £1,400,000 | £1,400,000 |
| IHT exposure | £0 | £560,000 |
| Current estate plan | Working | Broken |

**What EIS does for George:** EIS shares held for two years qualify for Business Property Relief and pass outside the estate — exactly what the pension used to do. He invests £35,000 a year — £20,000 into SEIS, £15,000 into EIS — generating £12,000 in combined relief applied against his tax bill.

| | Without EIS | With EIS |
|---|---|---|
| Assets outside estate at year 2 | £0 | £70,000 |
| Assets outside estate at year 5 | £0 | £175,000 |
| Assets outside estate at year 10 | £0 | £350,000 |
| IHT saving at year 10 | £0 | £140,000 |
| Income tax relief (10yr) | £0 | £120,000 |
| Portfolio value at year 10 (base case) | £0 | £573,000 |

*April 2027 is not a distant deadline. Investors who start the BPR clock now will have qualifying assets outside their estate before the new rules take effect.*

---

## CASE 4 — Martin
### Just retired. A tax bill he didn't expect. And the realisation that now is exactly the right time.

Martin spent his career in financial services, retiring recently as a senior executive. His pension drawdown, investment income, and consultancy work in the first years of retirement are generating a tax bill that surprises him. His ISA is full. His pension is already in drawdown. The conventional containers are used up.

**What EIS does for Martin:** Martin invests £60,000 — £20,000 into SEIS at 50%, £40,000 into EIS at 30% — generating £22,000 in combined income tax relief, applied directly against his tax bill this tax year. His effective cost is £38,000. The relief can also be carried back to the previous tax year.

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (10yr) | £220,000 | £0 (offset by relief) |
| Capital redirected into portfolio | £0 | £220,000 invested, not lost |
| Portfolio value at year 10 (base case) | £0 | £836,000 |
| CGT on exits | N/A | Zero |
| IHT position | Fully in estate | Active portfolio outside estate |
| **Net financial position at year 10** | **£0 from tax paid** | **£836,000 portfolio + £220,000 tax saved** |

*The emphasis is simple: do it now. The relief is this year's. The BPR clock starts this year. Every year of delay is a year of compounding that doesn't happen.*

---

## CASE 5 — Sophie
### High earner. Late 30s. Two decades of compounding ahead of her.

Sophie is a director at a technology company. She is 38, earns £215,000 a year, and pays just under £80,000 in income tax annually. Her ISA is maxed. Her pension contributions are capped. She has decades of peak earning ahead of her and no efficient place left to put significant capital.

**What EIS does for Sophie:** Sophie invests £100,000 a year — £20,000 into SEIS at 50%, £80,000 into EIS at 30% — generating £34,000 in combined income tax relief annually. Her effective annual cost is £66,000. HMRC funds the remaining £34,000. Every cohort that reaches two years qualifies for BPR. Every exit is CGT-free.

Sophie's advantage is time. A twenty-year programme allows more portfolio vintages to mature, more fund-returner outcomes to land, and more IHT-exempt cohorts to accumulate.

| | Pay the tax — no EIS | EIS Programme |
|---|---|---|
| Tax paid to HMRC (20yr) | £1,600,000 | £920,000 |
| Capital redirected into portfolio | £0 | £680,000 invested, not lost |
| Portfolio value at year 20 (base case) | £0 | £2,584,000 |
| CGT on exits | N/A | Zero |
| IHT position | Fully in estate | Substantial portfolio outside estate |
| **Net financial position at year 20** | **£0 from the £680,000 paid to HMRC** | **£2,584,000 portfolio + £680,000 tax saved** |

*The best time to start was last year. The second best time is this tax year.*

---

## The Same Structure. Five Entirely Different Purposes.

| | James | Richard | George | Martin | Sophie |
|---|---|---|---|---|---|
| Profile | Senior partner, peak earning | MD pre-sale; HNW retiree post-sale | Retired exec, pension problem | Recently retired, high tax bill | High earner, late 30s, long-term builder |
| Primary objective | Redirect tax into portfolio. Build CGT-free wealth. | Phase 1: wipe income tax. Phase 2: CGT deferral + IHT rebuild. | Rebuild IHT shelter; reduce income tax along the way. | Convert surprise tax bill into portfolio. Do it now. | Build 20-year EIS programme. Maximise relief compound effect. |
| Key relief | Income tax + CGT exemption | CGT deferral + BPR rebuild | BPR clock replaces broken pension shelter | Income tax relief, immediate impact | Income tax + long-run CGT-free growth |
| Urgency | Moderate — start sooner, compound longer | Event-driven — tied to the sale | High — April 2027 deadline | High — do it now, this tax year | Moderate — but every year delayed is compounding lost |

---

## Reference: The Four Reliefs

### 1. Income Tax Relief — 30% (EIS) or 50% (SEIS)

When you invest in a qualifying company, you can claim 30% of the amount invested as a reduction against your income tax bill — or 50% under SEIS. The relief is claimable via Self Assessment or PAYE tax code adjustment once the company has provided the EIS3 or SEIS3 certificate. Relief can also be carried back to the previous tax year.

### 2. Capital Gains Tax Exemption — 0%

If your investment grows and you sell after holding for at least three years, any profit is entirely exempt from Capital Gains Tax — provided the qualifying conditions are met throughout the holding period. There is no upper limit on the gain.

### 3. Loss Relief

Early-stage companies fail. What EIS changes is how much you actually lose. If an investment becomes worthless, the net loss can be offset against income or CGT. For a 45% taxpayer: effective loss on a failed SEIS investment is approximately 27.5p per pound; on EIS approximately 38.5p — assuming income tax relief was claimed in full and loss relief is available against income at the investor's marginal rate.

### 4. Inheritance Tax Relief — 0% after two years

EIS shares held for at least two years qualify for Business Property Relief and exit your estate entirely. From 6 April 2026, a new £2.5M allowance applies to the combined value of assets qualifying for 100% Agricultural Property Relief and Business Property Relief; 50% relief applies above that threshold. Directly-held EIS and SEIS shares in unquoted companies continue to qualify within the allowance.

---

## Reference: Risks, Context, and Relevance

**The risks, and they are real:**

- Capital loss — a significant proportion of early-stage companies fail; individual investments may lose their entire value.
- Illiquidity — EIS shares are not publicly traded; capital is committed for a minimum of three years to retain income tax relief, and realistically five to ten years before a liquidity event.
- Qualification loss — if a portfolio company loses its EIS qualifying status after you have claimed relief, HMRC can withdraw that relief and issue a clawback demand.
- Tax risk — EIS reliefs depend on qualifying conditions remaining met throughout the holding period; changes in legislation may affect future relief.
- Concentration risk — over-allocation to a small number of companies magnifies the impact of individual failures.

These risks are manageable — through diversification across a portfolio of companies, and through sizing each year's allocation to your actual tax liability rather than speculating beyond it.

---

## Direct Portfolio Building vs EIS Funds

Most investors who engage with EIS do so through a fund. It is the path of least resistance. It is also, for most investors who understand what they are giving up, the wrong choice.

**What you surrender in a fund:**
- Your relief timeline — shares are issued on the fund's timeline, not yours.
- Your HMRC submission — funds batch submissions; one investor's incomplete paperwork delays everyone's relief.
- Your investment decisions — fund managers select from deal flow that comes to them; you have no ability to decline a specific investment.
- Transparency — individual company performance is reported in aggregate.
- The fee structure — initial charge (1–2%), annual management fee (1.5–2.5%), performance fee (20–25%). These compound materially against net returns across a 15-year programme.

**The one genuine advantage of a fund:** administration. Unlock Access removes that advantage — individual submissions, individually processed, shares issued immediately.

---

## Is EIS Relevant to You?

EIS tends to be most relevant to investors who have at least one of: a meaningful income tax liability they would like to reduce immediately; capital gains from a property sale, business disposal, or portfolio rebalancing; an estate with IHT exposure that conventional tools have not fully addressed; or a portfolio that could benefit from diversification into early-stage UK companies.

It is less likely to be suitable for investors who need liquidity in the near term, who are uncomfortable with early-stage company risk, or who have no active UK income tax liability.

**The numbers in these profiles are illustrative. Yours are specific.** Unlock's tax planning tool models your income, your investment level, and your CGT position — including annual relief, multi-year projections, carry-back analysis, and IHT timeline.

---

## Annex: Investor Classification Definitions

**High Net Worth Individual** — Annual income of £170,000 or more; or net assets of £430,000 or more (excluding primary residence, qualifying insurance contracts, and pension entitlements).

**Self-Certified Sophisticated Investor** — Member of a business angel network for at least 6 months; or made more than one investment in an unlisted company in the prior two years; or worked in professional capacity in private equity or SME finance in the prior two years; or currently or recently a director of a company with annual turnover of at least £1 million.

*Investors who are uncertain whether they qualify should seek independent legal advice before proceeding.*

---

**To discuss your EIS portfolio:**

Tom King, Founder — Unlock  
tom@unlockdd.com | www.unlockdd.com

---

*This document is for educational purposes only and does not constitute financial advice or a personal recommendation. Capital is at risk. Tax reliefs depend on individual circumstances and may change. EIS/SEIS eligibility subject to HMRC qualifying conditions. IHT BPR from April 2026 subject to the new £2.5M combined APR/BPR allowance. Pension IHT changes subject to final legislation. © 2026 Unlock Services Limited.*

*Original: March 2026 | Last reviewed: 14 March 2026 | Status: Current*


---

<!-- END OF DOCUMENT -->

## IHT & EIS Planning — £5M Estate
*Stage: Demo Complete / Decision | Legacy Builder | 170_PLANNING*

---

# UNLOCK — Portfolio Intelligence Platform
# EIS & Inheritance Tax
### A Strategy for Moving Capital Outside the Taxable Estate

*Private & Confidential — March 2026*

---

> **The core principle**
>
> EIS-qualifying investments are classified as business assets under UK tax law. Under Business Property Relief (BPR), qualifying assets held for two or more years are fully exempt from Inheritance Tax at death — removing them from the taxable estate entirely.
>
> *Managed as a rolling programme — reinvesting exit proceeds into new EIS qualifying companies — the IHT exemption can be maintained indefinitely, while capital continues working and growing.*

---

## 1. The Inheritance Tax Picture on a £5 Million Estate

Before considering any planning, a £5 million estate carries a substantial IHT liability. The calculation below assumes a single individual with full nil-rate band and residence nil-rate band available.

| | Amount |
|---|---|
| Total estate value | £5,000,000 |
| Nil-rate band | £325,000 |
| Residence nil-rate band | £175,000 |
| Total threshold | £500,000 |
| Taxable estate | £4,500,000 |
| **IHT liability at 40%** | **£1,800,000** |
| Estate received by beneficiaries | £3,200,000 |

*If the nil-rate bands from a deceased spouse are transferable, the combined threshold rises to £1,000,000, reducing the IHT liability to £1,600,000. The figures above use the single-person baseline.*

---

## 2. The April 6, 2026 Planning Window

From 6 April 2026, Business Property Relief and Agricultural Property Relief will be subject to a combined £2.5 million allowance per taxpayer at 100% relief — above that threshold, relief falls to 50%, leaving an effective IHT rate of 20% on the excess.

| Invested Before 6 April 2026 | Invested From 6 April 2026 Onwards |
|---|---|
| 100% IHT exemption on the full amount after 2 years | 100% relief on combined BPR/APR up to £2.5M per taxpayer |
| No cap — any amount invested qualifies in full | 50% relief above £2.5M — effective 20% IHT rate on excess |
| This tax year's investments lock in full relief under current rules | Larger portfolios face partial IHT exposure on new tranches above the allowance |

A £250,000 EIS investment made before 6 April 2026 qualifies for full BPR under current rules — and is unaffected by the new £2.5 million allowance, which applies to investments made from 6 April 2026 onwards.

---

## 3. How Value Passes to the Next Generation

There are two paths for an EIS investment: shares passed at death, or proceeds reinvested on exit.

| | Passing Shares at Death | Exit Proceeds — Reinvested |
|---|---|---|
| IHT position | **Zero — BPR applies, full value exempt** | **Proceeds immediately reinvested into new EIS; two-year clock restarts** |
| CGT position | **Wiped at death — no CGT on any gain** | No CGT if EIS holding period complete |
| What the family receives | **Full share value — no deductions** | Continuous IHT-exempt pot maintained; capital keeps working |
| Planning note | Ideal outcome — pass shares not cash | Reinvest promptly; gap between exit and reinvestment creates brief estate exposure |

*Unlock tracks exit events across the portfolio so reinvestment timing is visible — preventing unintentional gaps in BPR coverage.*

---

## 4. Illustrative Scenarios: £250,000 Invested on a £5M Estate

### Scenario A — Capital Returned Flat (No Growth, No Loss)

| Item | Amount |
|---|---|
| Amount invested | £250,000 |
| Income tax relief (30% EIS, claimed via self-assessment) | **£75,000 returned by HMRC** |
| Net cost to investor | £175,000 |
| Capital returned at exit (flat) | £250,000 |
| IHT liability removed from estate (40% of £250,000) | **£100,000 saved** |
| Without EIS: that £250,000 sits in estate, costs family | £100,000 in IHT at death |
| **Total benefit on £175,000 net outlay** | **£250,000 returned + £100,000 IHT saved = £350,000** |

*Even with zero investment growth, the family receives £350,000 in value on a net outlay of £175,000. The income tax relief alone recovers 43% of the gross investment before a single company performs.*

### Scenario B — Modest Growth (2× over holding period)

| Item | Amount |
|---|---|
| Amount invested | £250,000 |
| Income tax relief (30%) | **£75,000** |
| Net cost to investor | £175,000 |
| Value at death or exit (2× growth) | £500,000 |
| CGT on £250,000 gain | **Zero — wiped at death, or exempt if EIS period complete** |
| IHT on £500,000 (BPR after 2 years) | **Zero — fully exempt** |
| Equivalent conventional holding after IHT at 40% | £300,000 |
| **Family receives via EIS** | **£500,000 — £200,000 more than conventional route** |
| EIS estate context: removes £500,000 from £5M estate | **IHT on estate reduced by £200,000** |

*Growth compounds the IHT benefit — the exempt pot grows inside the EIS wrapper free of both CGT and IHT, widening the gap against conventional holdings with each passing year.*

### Scenario C — Worst Case: Company Fails Entirely

| Item | Amount |
|---|---|
| Amount invested | £250,000 |
| Income tax relief (30%) | **£75,000 received upfront** |
| Net capital at risk | £175,000 |
| Investment value | £0 (total failure) |
| Loss relief available (45% rate on £175,000 net loss) | **£78,750 recovered** |
| Total recovered from HMRC (relief + loss relief) | **£153,750** |
| **Maximum real loss to investor** | **£96,250 — approximately 39p in the pound** |
| IHT benefit: £250,000 removed from estate during holding period | **£100,000 IHT saved on that capital** |

*In the worst case, combined income tax relief and loss relief can reduce the effective net loss to approximately 39p in the pound. Even a failed EIS holding has reduced the taxable estate during the period it was held.*

---

## 5. Rolling Programme: Building Exemption Against a £5M Estate

Deploying £250,000 per year into EIS creates a rolling IHT-exempt portfolio. Each tranche passes the two-year BPR threshold in sequence, steadily reducing the estate's IHT exposure.

| Year | Invested | Cumulative EIS Portfolio | BPR-Exempt (after 2yrs) | Running IHT Saving on Death |
|---|---|---|---|---|
| 2025/26 | £250,000 | £250,000 | — | — |
| 2026/27 | £250,000 | £500,000 | £250,000 | **£100,000** |
| 2027/28 | £250,000 | £750,000 | £500,000 | **£200,000** |
| 2028/29 | £250,000 | £1,000,000 | £750,000 | **£300,000** |
| 2029/30 | £250,000 | £1,250,000 | £1,000,000 | **£400,000** |
| **Combined tax relief over 5 years** | | **5 × £75,000** | **= £375,000** | **Total tax relief benefit: £775,000** |

By year five, £1 million has moved outside the taxable estate — cutting the IHT liability on a £5 million estate from £1,800,000 to £1,400,000, a saving of £400,000. Combined with £375,000 in income tax relief, the total tax relief benefit across five years is approximately **£775,000 on £1.25 million deployed**.

*Tranches invested after April 6, 2026 are subject to the new £2.5M combined BPR/APR allowance; amounts above that threshold qualify at 50% relief only.*

---

## 6. Realistic Portfolio Outcomes: £1M Across Five Companies

| Company | Invested | Outcome | Return | Multiple |
|---|---|---|---|---|
| A | £200,000 | Fails entirely | £0 | 0× |
| B | £200,000 | Fails entirely | £0 | 0× |
| C | £200,000 | Capital returned flat | £200,000 | 1× |
| D | £200,000 | Modest growth | £320,000 | 1.6× |
| E | £200,000 | Strong performer | **£1,000,000** | **5×** |
| **Total** | **£1,000,000** | | **£1,520,000** | **1.52× gross** |

### Tax Relief Across the Portfolio

| Item | Amount |
|---|---|
| Income tax relief (30% on £1,000,000 — claimed upfront) | **£300,000** |
| Net cost after income tax relief | £700,000 |
| Loss relief — Company A (45% on £140,000 net loss) | **£63,000** |
| Loss relief — Company B (45% on £140,000 net loss) | **£63,000** |
| Total loss relief | **£126,000** |
| **Total tax relief across portfolio** | **£426,000** |
| Net cost of £1,000,000 portfolio after all relief | £574,000 |

*Loss relief is calculated on the net loss after income tax relief. Each failed company: £200,000 invested less £60,000 income tax relief already received = £140,000 net loss. Loss relief at 45%: £63,000 per company.*

### Overall Outcome for Investor and Estate

| Item | Amount |
|---|---|
| Net cost to investor (after all tax relief) | £574,000 |
| Capital returned across portfolio | **£1,520,000** |
| CGT on gains (EIS exemption, qualifying period met) | **Zero** |
| IHT on portfolio value at death (BPR after 2 years per tranche) | **Zero — fully exempt** |
| Without EIS: IHT on equivalent £1,520,000 at 40% | £608,000 owed |
| **Family receives via EIS route** | **£1,520,000 — £608,000 more than conventional route** |
| Total benefit on £574,000 net outlay | **£1,520,000 returned + £608,000 IHT saved = £2,128,000** |

Even with two complete failures, the portfolio delivers £1,520,000 in capital and removes £608,000 of IHT liability — on a net outlay of £574,000.

---

## 7. What Happens Depends on Sequence: Death Before or After Exit

The tax outcomes for the investor and their beneficiaries differ materially depending on whether companies exit before or after the investor's death.

| | Company Exits in Investor's Lifetime | Investor Dies Holding Shares | Company Fails After Death |
|---|---|---|---|
| **IHT** | Proceeds back in estate unless reinvested promptly into new EIS | **Zero — BPR applies. Full value passes IHT-free** | Zero — shares were already IHT-exempt; failure has no IHT consequence |
| **CGT (investor)** | **Zero — EIS CGT exemption applies if qualifying period met** | **Wiped at death — entire lifetime gain extinguished. No CGT owed** | No gain, no CGT issue |
| **CGT (beneficiary)** | N/A — exit already completed | Inherits at probate value (new base cost). CGT due only on growth after inheritance, at standard rates — EIS exemption does not transfer | Shares worth zero or near-zero — no CGT liability |
| **Loss relief** | **Available to investor — claimed against their income tax** | Not applicable — shares passed at value; no loss crystallised | **Not available to beneficiary — loss relief is personal to the original investor and cannot be inherited** |

> **Key planning implication**
>
> Loss relief is a personal tax relief — it belongs to the investor, not the investment. It cannot be passed to beneficiaries. For investors deploying EIS later in life, this means the benefit of loss relief on any failed companies is only available if those companies fail while the investor is alive.
>
> This strengthens the case for EIS investments in companies with shorter exit horizons — where outcomes are more likely to resolve within the investor's lifetime, allowing loss relief to be claimed if needed, and proceeds to be reinvested to maintain BPR coverage.

The CGT position at death is, by contrast, very favourable. Any gain accrued during the investor's lifetime is completely extinguished — the beneficiary inherits at probate value and only pays CGT on growth after that point. On a successful company worth £1,000,000 at death, a lifetime gain of £800,000 simply disappears.

---

## 8. Why This Requires Active Portfolio Management

Managing EIS as a deliberate IHT strategy — rather than a series of isolated investments — requires visibility across the whole picture:

- Which tranches have passed the two-year BPR threshold and are currently IHT-exempt
- Which are approaching qualification and when the clock completes
- When companies exit, triggering the need to reinvest before BPR coverage lapses
- How the EIS portfolio interacts with the rest of the estate — property, equities, pensions — to show the true residual IHT exposure
- Whether income tax relief has been correctly claimed for each tax year

**Unlock provides exactly this.** Your EIS portfolio sits alongside your full estate picture so you can see the real IHT exposure at any point, track each investment through its qualification period, and act on exit events before they create gaps in coverage.

For investors using EIS as a primary IHT vehicle, Unlock is the intelligence layer that makes the strategy coherent — not a collection of individual positions managed in isolation.

---

*This document is provided for illustrative and educational purposes only. It does not constitute financial, tax, or legal advice. All tax relief figures, thresholds, and allowances are based on legislation and published HMRC guidance as understood at March 2026 and may be subject to change. Tax reliefs depend on individual circumstances and HMRC eligibility criteria. All figures are illustrative only and should not be relied upon for investment decisions. EIS investments are high-risk, illiquid, and long-term in nature. Capital is at risk. Investors should seek independent financial and tax advice before making any investment.*

*Unlock is not authorised or regulated by the Financial Conduct Authority to provide financial advice.*

*Document version: v4 | Original: March 2026 | Last reviewed: 14 March 2026 | Status: Current — all figures correct to March 2026 legislation*


---

<!-- END OF DOCUMENT -->

## Duncan Stewart Bespoke Brief
*Stage: Demo Complete / Decision | Legacy Builder | 180_BRIEF | Not for general use*

---

# UNLOCK ACCESS
# EIS, IHT, and Estate Planning
### A personal briefing for Duncan Stewart — March 2026

*This document is prepared for discussion purposes only and does not constitute financial advice or a personal recommendation. Capital is at risk. Tax reliefs depend on individual circumstances and qualifying conditions. All figures illustrative.*

---

## The Problem Worth Solving

A £5 million estate sounds like a success. And it is. It is also, under current UK inheritance tax rules, a significant liability for the people who will inherit it.

Most of that estate sits in conventional assets — property, investments, a pension. Each was the right decision at the time. None of them was chosen with IHT in mind. The result is a tax bill that does not have to be as large as it currently is.

| Asset | Est. Value | IHT Position |
|---|---|---|
| Primary residence | £1,200,000 | In estate — no relief |
| Investment portfolio | £1,800,000 | In estate — no relief |
| Pension (pre-April 2027) | £800,000 | Currently outside estate |
| Pension (from April 2027) | £800,000 | Fully IHT-exposed |
| **Total IHT exposure (post-April 2027)** | **~£5,000,000 taxable** | **IHT bill: ~£1,720,000** |

*NRB £325,000; RNRB £175,000 where applicable. Pension IHT changes announced but subject to final legislation from April 2027.*

The pension deserves specific attention. Until October 2024, it sat entirely outside the estate — a clean, efficient tool for passing wealth to beneficiaries. From 6 April 2027, unused pension pots and death benefits come into scope for inheritance tax. A £800,000 pension becomes an £800,000 IHT exposure overnight.

*The conventional tools that made sense for thirty years of accumulation are now structurally inadequate for estate transfer. EIS offers a replacement that does what the pension used to do — and more.*

---

## How EIS and SEIS Work

EIS (Enterprise Investment Scheme) and SEIS (Seed Enterprise Investment Scheme) are UK government-backed tax relief structures designed to channel private capital into early-stage companies. Investors receive four distinct reliefs, all of which apply simultaneously on the same investment.

| Relief | EIS | SEIS | Note |
|---|---|---|---|
| Income Tax | 30% of investment | 50% of investment | Claimable in year invested or carried back one year |
| Capital Gains | 100% exempt on exit | 100% exempt on exit | Qualifying exit after 3-year holding period. No upper limit on gain. |
| Loss Relief | ~38.5p/£ at 45% | ~27.5p/£ at 45% | Applied to net loss after income tax relief. Personal to original investor — cannot be inherited. |
| IHT / BPR | 0% after 2 years | 0% after 2 years | Business Property Relief. £2.5M combined APR/BPR allowance from April 2026. Most investors at sensible annual allocations unaffected. |

**Loss relief worked example:** For a 45% taxpayer investing £50,000 via SEIS — income tax relief of £25,000 leaves £25,000 net at risk. If the company fails, loss relief at 45% on the £25,000 = £11,250. Effective net loss: £13,750 (27.5p per £ invested). EIS equivalent: £50,000 invested, £15,000 relief, £35,000 at risk; loss relief at 45% = £15,750; effective net loss: £19,250 (38.5p per £).

**The critical point on loss relief:** it is personal to the original investor. If a company fails after the investor's death, beneficiaries receive no loss relief benefit. This is a sequencing consideration, not a structural problem — it simply means the structure is most efficient while the investor is alive to claim it.

---

## A £250,000 Annual Programme

The scenario modelled below assumes a £250,000 annual investment, blending SEIS (up to £200,000 annually at 50% relief) and EIS (remaining allocation at 30% relief). The combined income tax relief on £250,000 per year — using a blended rate reflecting the mix — is approximately £75,000 annually. Effective cost: £175,000 per year. HMRC funds the balance.

The BPR clock starts on the date shares are issued. Each year's cohort qualifies independently. By year 3, the first cohort has cleared the two-year BPR qualifying period and sits outside the estate entirely.

| Year | Invested | Income Tax Relief | Effective Cost | Assets Outside Estate | Cumulative IHT Saving |
|---|---|---|---|---|---|
| 1 | £250,000 | £75,000* | £175,000 | — | — |
| 2 | £250,000 | £75,000 | £175,000 | — | — |
| 3 | £250,000 | £75,000 | £175,000 | £250,000 (Yr 1 cohort) | £100,000 |
| 5 | £250,000 | £75,000 | £175,000 | £750,000 | £300,000 |
| 7 | £250,000 | £75,000 | £175,000 | £1,250,000 | £500,000 |
| **10** | **£250,000** | **£75,000** | **£175,000** | **£2,000,000** | **£800,000** |

*Year 1 relief claimable against that year's income tax liability, or carried back to the prior tax year. IHT saving calculated at 40% on assets outside estate above £325,000 NRB. All figures illustrative. Capital at risk.*

By year 10, over £2 million sits outside the estate entirely — reducing the IHT bill by approximately £800,000 at current rates, independent of portfolio performance.

---

## A Blended Portfolio: How the Numbers Work

The table below models a single year's £800,000 deployment across five companies, using the base case distribution consistent with NESTA research: two failures, two moderate exits, one strong exit. Loss relief is applied to the net loss after income tax relief — not the gross investment.

| Company | Invested | Income Tax Relief | Net at Risk | Outcome | Effective P&L |
|---|---|---|---|---|---|
| Company A (SEIS) | £50,000 | £25,000 (50%) | £25,000 | Total loss | Loss relief: £11,250 → net loss £13,750 |
| Company B (SEIS) | £50,000 | £25,000 (50%) | £25,000 | Total loss | Loss relief: £11,250 → net loss £13,750 |
| Company C (EIS) | £300,000 | £90,000 (30%) | £210,000 | 2× exit (£600,000) | Gain £300,000 — CGT-free |
| Company D (EIS) | £300,000 | £90,000 (30%) | £210,000 | 3× exit (£900,000) | Gain £600,000 — CGT-free |
| Company E (EIS) | £100,000 | £30,000 (30%) | £70,000 | 10× exit (£1,000,000) | Gain £900,000 — CGT-free |
| **TOTALS** | **£800,000** | **£260,000** | **£540,000** | **Net return: £2,472,500** | **Income tax saved: £260,000** |

*Loss relief at 45% applied to net loss after income tax relief. All exits CGT-free assuming 3-year qualifying holding period met. All figures illustrative. Capital at risk.*

The £260,000 income tax relief is received in the year of investment, before any company does anything. The two failures cost a net £27,500 combined. The three exits are entirely CGT-free.

---

## What Happens When: The Sequencing Matrix

One of the least-understood aspects of EIS investing is how the reliefs interact with the timing of exits relative to the investor's death.

**The critical asymmetry:** CGT on lifetime gains is wiped entirely at death. Loss relief is not — it is personal to the original investor and dies with them.

| Relief / Tax | Exit before death | Held until death | CGT deferral route |
|---|---|---|---|
| **IHT on EIS shares** | Payable if held < 2 yrs. Zero after 2-yr BPR qualifying period. | Zero — shares already qualified for BPR. Passes outside estate. | Zero — deferred gain extinguished. Original investment already outside estate. |
| **CGT on lifetime gains** | Payable at 20–24% on disposal. Crystallised in your lifetime. | Wiped entirely at death. Beneficiaries inherit at probate value with no CGT liability. | Deferred gain via EIS investment is extinguished on death under current rules. |
| **Loss relief** | Claimable by you against income or CGT in year of loss or carry-forward. | Cannot be inherited. If investment fails after your death, beneficiaries receive no loss relief benefit. | Not applicable — gain deferred, not realised. |

*CGT extinguishment on death applies to deferred gains under current rules and to unrealised gains (beneficiaries inherit at probate value). BPR and CGT extinguishment subject to legislation in force at the time of death. All information correct as at March 2026.*

**The optimal sequencing:** invest early, let the BPR clock run, and hold qualifying shares until death. CGT is extinguished. IHT is eliminated. Loss relief is less relevant at that horizon — the structure is designed to win on the exits, not recover on the failures.

---

## The IHT Impact: Estate Comparison

| Scenario | Without EIS | With EIS (10-yr programme) |
|---|---|---|
| Total estate value | £5,000,000 | £5,000,000 |
| Assets outside estate (EIS portfolio) | £0 | £2,000,000+ |
| Taxable estate | £5,000,000 | £3,000,000 |
| IHT bill (40% above £325k NRB) | ~£1,870,000 | ~£1,070,000 |
| **IHT saving** | **—** | **~£800,000 saved** |

*All figures illustrative. Capital at risk.*

The £800,000 IHT saving is conservative — it reflects only BPR relief on assets outside the estate. It does not include the income tax relief received annually (£750,000 over 10 years), nor any portfolio returns from company exits.

---

## Three Scenarios: Flat, Modest, Total Failure

**Scenario A — Portfolio returns 1× (flat — no growth, no losses)**

Income tax relief over 10 years: £750,000. Effective cost of £2,500,000 deployed: £1,750,000. Portfolio value: £2,500,000. CGT: zero. IHT saving: ~£800,000. Net position vs not investing: **+£1,550,000 ahead before any portfolio appreciation.**

**Scenario B — Portfolio returns 3.8× (base case distribution)**

Income tax relief over 10 years: £750,000. Effective cost: £1,750,000. Portfolio value: £9,500,000 (3.8× on £2,500,000). CGT: zero. IHT saving: ~£800,000 on qualifying holdings. **Substantially ahead on every measure.**

**Scenario C — Total portfolio failure (worst case)**

All companies fail. Income tax relief: £750,000 received and retained. Loss relief available on net losses after income tax relief — at 45% marginal rate, recovers a material proportion of the net capital at risk. **Even in the worst case, the income tax relief already received is not returned.**

*The income tax relief is received in the year of investment. It is not contingent on portfolio performance. In the worst case, it is what you keep.*

---

## Why 2026 Is the Right Moment

Three structures that have formed the backbone of HNW estate planning have been materially changed or broken in 2025/26:

- VCT income tax relief reduced from 30% to 20% from 6 April 2026. EIS retains 30%; SEIS retains 50%.
- Pensions brought into IHT scope from 6 April 2027. The primary estate planning tool for a generation of accumulation investors is broken. EIS/SEIS BPR is the primary remaining replacement.
- AIM shares BPR reduced from 100% to 50% in all cases from April 2026.

EIS is the only mainstream structure with all four reliefs intact. The scheme has been extended to 2035. Company investment limits have been doubled.

**For the BPR clock specifically:** investors who start a qualifying EIS investment programme before April 2027 will have cohorts qualifying for BPR before the pension IHT changes take full effect. Those who wait will not.

*April 2027 is not a distant deadline. The BPR clock needs to start now.*

---

## How Unlock Access Works

**What Unlock Access does:**
- Curated deal flow — pre-screened EIS and SEIS qualifying companies, presented with investment documentation for your review. Every investment is your decision.
- Shares issued immediately — on completion, shares are issued without delay. Your EIS qualifying period and BPR clock start from day one.
- Individual HMRC submissions — each investor's submission is processed individually, not batched. Your EIS3 certificate is not delayed by anyone else's paperwork.
- EIS3 certificate tracked and delivered — your certificate and Unique Investment Reference delivered directly to you, ready for your accountant.
- No capital in a pool — funds are deployed directly to the company on completion. Your capital works from day one.

**What Unlock Access does not do:** Unlock Access does not provide financial advice, does not recommend specific investments, and does not make investment decisions on your behalf.

*Unlock Access is operated by Unlock Services Limited. Tom King is the founder of both Unlock Services Limited and Cloudworkz, one of the companies currently available via Unlock Access. This dual-founder relationship is disclosed in full.*

---

## Important Information

- Tax reliefs depend on individual circumstances and on qualifying conditions being met and maintained throughout the holding period.
- EIS/SEIS shares are illiquid. Capital should be considered committed for a minimum of three years to retain income tax relief, and realistically five to ten years or more.
- Loss relief is personal to the original investor and cannot be inherited by beneficiaries.
- IHT BPR is subject to qualifying conditions and from April 2026 subject to the new £2.5M combined APR/BPR allowance.
- CGT extinguishment on death and deferred gain treatment are subject to legislation in force at the time of death.
- Unlock Services Limited does not provide regulated financial advice and is not authorised to do so. Investors should seek independent advice from a qualified adviser before investing.

*© 2026 Unlock Services Limited. Prepared March 2026. This document is confidential and prepared for the named recipient only.*

---

**Next step:** Reply to arrange a conversation before your call on 30 March.

Tom King — tom@unlockdd.com | www.unlockdd.com

*Prepared: March 2026 | Last reviewed: 14 March 2026 | Status: Current*


---

<!-- END OF DOCUMENT -->

## UK Investment Landscape 2026
*Stage: Outreach / Called | All personas | 190_LANDSCAPE | Long-form lead magnet*

---

**UK INVESTMENT LANDSCAPE 2026**

*Are You Actually Diversified?*

The Correlation Problem, The Advice Gap, and the Last Tax-Efficient
Window

**WHAT THIS REPORT REVEALS**

-   Why the 60/40 portfolio failed in 2022---and could fail again

-   The concentration risk hiding in most UK investor portfolios

-   How EIS limits your downside to 38p on the pound (worked example)

-   What changes on April 6, 2026---and what you lose if you wait

-   An investment opportunity you can actually evaluate

-   Action checklist by investor type

*Read time: 25 minutes*

January 2026

Strategic Overview

**What We\'re Trying to Achieve**

This report serves a dual purpose. On the surface, it\'s a comprehensive
analysis of the UK investment landscape for 2026---the kind of report
sophisticated investors would pay to read. Underneath, it\'s designed to
lead readers to a specific conclusion: that investing in Unlock as a
founding investor is the intelligent response to the problems described.

The strategy follows Warren Buffett\'s first principle: invest in what
you understand. Most investors can\'t truly evaluate robotics companies,
AI startups, or biotech opportunities. But a platform that solves
portfolio fragmentation, concentration risk, and the advice gap? They
live that problem daily. They can evaluate whether the solution is real
because they experience the pain.

**The Founding Investor Opportunity:** Unlock is raising a limited
founding round from investors who will shape the platform as it\'s
built. These are investors whose problems become product priorities. The
number of slots is genuinely limited---this isn\'t artificial scarcity,
it\'s a deliberate choice to ensure founding investors have meaningful
influence and the company maintains close relationships with its
earliest backers.

**The Deadline Is Real:** April 5, 2026 marks the end of the current tax
year. After April 6, BPR on EIS is subject to a new £2.5M combined cap
per estate. VCT relief drops from 30% to 20%. These aren\'t marketing
tactics---they\'re confirmed legislation. The window closes whether or
not someone acts.

**The Reader Journey:** By page 15, the reader should think: \'I have
problems I didn\'t fully recognise. Traditional diversification may not
protect me. The advice gap is real. There are tax-efficient structures
I\'m not using.\' By page 20: \'There\'s a company building exactly what
I need---and I can actually evaluate whether it will work because I
understand the problem.\' By page 22: \'I need to move before April.\'

Executive Summary

In 2022, the 60/40 portfolio---the foundation of conventional
diversification---had its worst year since the 1930s. Stocks fell 19%.
Bonds fell 13%. For the first time in decades, both fell together.

Investors who thought they were protected discovered they weren\'t.

This report examines whether it could happen again, what most investors
are missing, and what to do about it.

**THE THREE PROBLEMS**

**1. The Correlation Problem:** Traditional diversification assumes
stocks and bonds move differently. In 2022, that assumption failed.
Research suggests it could fail again if inflation proves sticky.
Stock-bond correlation reached +0.85 in 2023---the highest ever
recorded.

**2. The Concentration Problem:** Most investors who think they\'re
diversified aren\'t. UK investors average 50-65% of wealth in property
alone. Add employer stock, UK-focused funds, and regional
concentration---many portfolios have 70%+ exposure to a single economy
that could face a correction simultaneously.

**3. The Advice Gap:** The most tax-efficient investments---EIS and
SEIS---are the ones traditional advisors can\'t help with. Accountants
can\'t give investment advice. IFAs can\'t advise on unquoted
securities. You\'re largely on your own.

**THE DEADLINE**

April 5, 2026 is the last day of the current tax year---and the last
window for full IHT relief on EIS investments before new caps take
effect. From April 6, 100% Business Property Relief will be capped at
£2.5M combined across all qualifying business property (EIS direct and AIM shares). Above that threshold, relief
drops to 50% (effective 20% IHT rate). For investors with estate
planning goals, this isn\'t abstract. It\'s a real planning consideration.

**THE OPPORTUNITY**

Section 10 presents something different: a chance to invest in a company
solving the problems described in this report. One you can
evaluate---because you live the problem it addresses. Using the exact
EIS structure this report recommends. With a limited number of founding
investor slots available to those who want to shape the platform as
it\'s built.

But first, you need to understand what\'s at stake.

1\. The 2026 Landscape

Economic Context

The UK economy enters 2026 in better shape than many predicted. GDP
growth is estimated at 1.2-1.4%, placing it among the faster-growing G7
economies. Inflation has fallen to 3.2% and is expected to approach the
2% target by mid-year. The Bank of England has cut rates to 3.75% and
most economists expect further cuts to 3-3.5% by year end.

This is the benign scenario: soft landing achieved, gradual
normalisation underway.

But forecasts are often wrong. And the question sophisticated investors
should ask isn\'t \'what\'s the base case?\'---it\'s \'what happens to
my portfolio if the base case doesn\'t materialise?\'

What Could Go Wrong

**Inflation Resurgence:** Services inflation remains sticky. Wage growth
continues above target. If inflation spikes back above 4%, the Bank of
England would be forced to pause or reverse rate cuts. This is the
scenario where stocks AND bonds fall together---again.

**Recession:** The UK has narrowly avoided recession for two years.
Consumer spending is fragile. Business investment is weak. A negative
shock---global trade disruption, energy price spike, banking
stress---could tip the balance.

**Political Uncertainty:** Potential leadership challenges could drive
up borrowing costs. The gilt market\'s sensitivity to political risk was
demonstrated dramatically in 2022.

*The point isn\'t to predict which scenario occurs. It\'s to ask whether
your portfolio is stress-tested for any of them.*

2\. The Correlation Problem

Why 2022 Changed Everything

For decades, the foundational assumption of portfolio construction has
been that stocks and bonds are negatively correlated. When equities
fall, bonds rise---providing protection when you need it most. This
assumption underpins the classic 60/40 portfolio that millions of
investors rely on.

In 2022, that assumption failed catastrophically.

Stocks returned -19.2%. Bonds returned -13.0%. The 60/40 portfolio lost
16.7%---its worst year since the 1930s. This was the only year since
records began where both major asset classes fell simultaneously by
double digits.

Investors who thought they were protected discovered their
\'diversification\' was an illusion.

The Inflation Driver

What caused the correlation to flip? Inflation. When inflation surged,
central banks raised rates aggressively. Higher rates hurt both equities
(through higher discount rates) and bonds (directly through price-yield
relationship). The asset classes that are supposed to hedge each other
moved in lockstep.

Research from Vanguard shows that stock-bond correlation has been
consistently positive during high-inflation periods throughout history.
The negative correlation that investors learned to rely on only existed
during the low-inflation environment from 2000-2021.

In other words: the \'normal\' state that informed most investors\'
diversification strategies was actually the exception, not the rule.

Could It Happen Again?

Stock-bond correlation reached +0.85 in July 2023---the highest ever
recorded. While correlations have since declined as inflation moderated,
they remain elevated compared to the 2000-2021 period.

Barclays Private Bank research concludes: \'In periods of excessive
inflation (higher than 5%), the equity-bond correlation was always
positive, implying low, or no, diversification contribution from
bonds.\'

If inflation proves sticky in 2026---if services inflation remains
elevated, if wage growth doesn\'t moderate, if an energy shock
occurs---the correlation could turn positive again. Traditional
diversification would fail again.

**The question for your portfolio:** When did you last stress-test your
holdings against a scenario where stocks AND bonds fall together?

3\. Asset Class Overview

UK Equities: Attractive But Not Without Risk

UK equities offer genuinely attractive valuations. The FTSE 250 trades
at 12.4x forward earnings versus the S&P 500\'s 22.4x---the cheapest
relative valuation in 23 years. The index offers a 4.3% dividend yield.
Historically, UK mid-caps outperform in falling rate environments.

The opportunity is real. The question is whether your portfolio is
structured to capture it---or whether your UK equity exposure is
concentrated in a handful of names, dominated by employer stock, or
offset by property over-concentration elsewhere.

Property: The Concentration Trap

House price forecasts for 2026 are modest but positive: Rightmove
predicts 2%, Savills 2%, Nationwide 2-4%. Regional variation favours the
North and Midlands over London and the South East.

But forecasts aren\'t the issue. Concentration is.

UK property fell 16% in 2008 and took seven years to recover to
pre-crash levels. Many investors found themselves in negative equity,
unable to sell, with wealth locked in an asset they couldn\'t access
precisely when they needed liquidity most.

Section 5 examines the concentration problem in detail. For now, ask
yourself: what percentage of your total wealth is in property? Include
your primary residence equity, any buy-to-lets, any property funds.
What\'s the real number?

Bonds: Income Returns, Protection Questions

UK gilts offer the highest yields in a decade. Ten-year gilts yield
around 4.3%. For income-focused investors, this is genuinely attractive.

But bonds as portfolio protection? That assumption requires
re-examination after 2022. Bonds may well provide ballast if the next
crisis is deflationary (recession, credit crunch). They will not protect
you if the crisis is inflationary. And given the \'stagflation lite\'
risks---sticky inflation combined with weak growth---the traditional
bond allocation may not serve its intended purpose.

Gold: Genuine Diversification, No Income

Gold delivered 60%+ returns in 2025, with forecasts targeting \$3,000/oz
or higher. More importantly, gold is one of the few assets that
genuinely diversifies in crisis---its correlation to equities turns
negative precisely when protection matters most.

The limitation: gold produces no income. For investors who need their
portfolio to generate returns, gold can only ever be a minority
allocation---typically 5-10%.

Cash: Declining Returns, Clear Role

With rates expected to fall to 3-3.5%, cash returns will decline through
2026. The best savings rates should be locked in now.

Cash has a clear role: liquidity, optionality, dry powder. But holding
excessive cash in a falling rate environment is a guaranteed loss of
purchasing power.

4\. Scenario Analysis: What Happens When Forecasts Are Wrong

Understanding individual asset classes is necessary but insufficient.
Sophisticated portfolio management requires understanding how assets
interact---particularly when markets move against you.

Base Case: Soft Landing

If forecasts prove correct---inflation to 2%, rates to 3-3.5%, modest
growth---most portfolios perform adequately. UK equities gain 6-10%.
Property rises 2-4%. Bonds deliver 3-5% from yield plus modest capital
appreciation. Gold holds steady or rises slightly.

This is the scenario where doing nothing is probably fine.

Recession Scenario

UK equities fall 25-40% as earnings collapse. Property falls
15-20%---and you can\'t sell quickly to rebalance. Bonds potentially
rise if the Bank cuts rates aggressively. Gold rises 10-20% on
safe-haven demand. Cash preserves nominal value.

**The critical insight:** In a recession, property-heavy investors face
a double problem. Values fall AND they can\'t access the capital.
Liquidity matters precisely when it\'s hardest to achieve.

Inflation Resurgence

UK equities fall 10-20% as discount rates rise. Bonds fall 10-20%---a
repeat of 2022. Property is mixed (values may fall but rents may rise).
Gold rises 15-25% as an inflation hedge. Cash purchasing power erodes
rapidly.

**This is the scenario where traditional diversification fails.** Stocks
AND bonds fall together. The 60/40 portfolio doesn\'t protect you.
Investors who relied on bonds as their hedge discover they have no hedge
at all.

The Question You Should Be Asking

Most investors can\'t model these scenarios because they don\'t have
tools that connect all their holdings. Their ISA platform shows their
ISA. Their pension provider shows their pension. Their property equity
is an estimate. Their alternatives are in spreadsheets.

There\'s no single view. No scenario analysis. No correlation-aware
stress testing.

*If you\'re reading this thinking \'I should be able to do this
analysis\'---you\'re right. You should. But you probably can\'t, because
the tools don\'t exist for investors like you.*

5\. The Concentration Problem

Most investors who consider themselves diversified are not. They own
different things---property, stocks, maybe some bonds or alternatives.
But when examined closely, many portfolios have dangerous concentrations
that only reveal themselves in downturns.

A Portfolio You Might Recognise

Consider this investor---see if it sounds familiar:

Primary residence: £650,000 equity (after mortgage)

Buy-to-let: £380,000 equity

ISA: £180,000 (global tracker)

SIPP: £240,000 (60% equities, 15% property funds)

Cash: £85,000

Employer shares: £65,000

**Total: £1.6 million**

This investor feels diversified. They own \'different things.\' Let\'s
look at what they actually have:

**Property exposure:** £1.03M direct + £36K in SIPP property funds =
£1.066M = **67% of wealth**

**UK concentration:** Property (67%) + employer shares (4%) + UK portion
of funds (\~10%) = **\~81% exposed to UK economy**

**Illiquid assets: 67%** (property can\'t be sold quickly)

This is concentration hiding as diversification.

What Happens in a Downturn

If UK property falls 20%---which happened in 2008---this investor loses
over £200,000 in wealth. They can\'t sell the property quickly to
rebalance. If they also face job pressure (as often happens in
recessions), their employer shares are falling too. They need liquidity
precisely when they can\'t access it.

The \'diversification\' they thought they had provides no protection
when protection matters most.

Common Concentration Traps

**The Property Trap:** UK investors average 50-65% of wealth in property
(including primary residence). This isn\'t diversification---it\'s
concentration in a single, illiquid, regionally-correlated asset class.

**The Employer Trap:** Employees with significant company stock have
double exposure: their income AND their wealth depend on one company. If
the company struggles, they face job risk AND portfolio loss
simultaneously.

**The \'Alternatives\' Trap:** Owning whisky casks, fine wine, and
classic cars may feel like diversification. But these assets share
critical characteristics: illiquid, GBP-denominated, correlated to
discretionary wealth cycles. They fell in 2008-2009. They\'re not
genuine diversifiers.

The First Step Is Visibility

Try this exercise---if you can:

1.  List every asset you own (ISA, SIPP, GIA, property, alternatives,
    cash, company shares)

2.  Calculate the percentage of total wealth in each

3.  Identify anything above 25% in a single asset class

4.  Calculate your illiquid percentage

5.  Calculate your UK-only exposure

*If you can complete this exercise accurately in 10 minutes, you\'re
unusual. Most investors can\'t---because their holdings are scattered
across platforms with no consolidated view.*

6\. EIS and SEIS: The Tax Maths That Changes Everything

The UK government created the Enterprise Investment Scheme (EIS) and
Seed Enterprise Investment Scheme (SEIS) to encourage investment in
British growth companies. The tax incentives are extraordinary by
design---they compensate for the genuine risk of early-stage investing.

For sophisticated investors willing to do their homework, these
structures represent some of the most tax-efficient investments
available anywhere.

How the Maths Actually Works

**SEIS Worked Example (50% relief):**

You invest £50,000 in a SEIS-eligible company.

Income tax relief: 50% = £25,000 (claimed against your tax bill
immediately)

**Your effective cost: £25,000** (not £50,000)

**If the company succeeds (3x exit):** You receive £150,000. Capital
gains tax: £0 (SEIS profits are CGT-free after 3 years). Your profit:
£125,000 on £25,000 effective cost = 5x return on your real money at
risk.

**If the company fails completely:** You lose £50,000. Less income tax
relief already claimed: £25,000. Net loss for loss relief calculation:
£25,000. Loss relief at 45% tax rate: £11,250 recovered. Your actual
loss: £25,000 - £11,250 = £13,750. **You invested £50,000 and lost
£13,750---effectively 27.5p on the pound.**

**EIS Worked Example (30% relief):**

You invest £100,000 in an EIS-eligible company.

Income tax relief: 30% = £30,000

**Your effective cost: £70,000**

**If the company succeeds (5x exit):** You receive £500,000. CGT: £0.
Your profit: £430,000 on £70,000 effective cost = 6x+ return.

**If the company fails completely:** Loss relief at 45%: £31,500
recovered. Your actual loss: £70,000 - £31,500 = £38,500. **You invested
£100,000 and lost £38,500---effectively 38.5p on the pound.**

The Asymmetric Structure

This is what sophisticated investors seek: uncapped upside with capped,
cushioned downside. In traditional equity investment, if a stock goes to
zero, you lose 100%. In EIS/SEIS, your maximum actual loss is 27-39% of
your original investment---and your upside is unlimited and tax-free.

The risk is real---early-stage companies fail. But the structure
fundamentally changes the risk-reward equation.

The Inheritance Tax Dimension

After two years, EIS shares qualify for Business Property Relief---100%
exemption from Inheritance Tax.

For investors with estates above the nil-rate band, this is significant.
A £500,000 EIS portfolio removes £500,000 from your taxable estate,
potentially saving £200,000 in IHT (at 40%).

This combines with the income tax relief and CGT exemption. No other
mainstream investment structure offers this triple benefit.

7\. The April 2026 Deadline: What Changes and What You Lose

From April 6, 2026, the tax landscape changes significantly. These
aren\'t rumours or projections---they\'re confirmed legislation.

IHT Relief Cap

Currently, 100% Business Property Relief applies to qualifying EIS
investments regardless of amount. From April 6, 2026:

-   100% IHT relief will be capped at £2.5M combined (across EIS direct investments and AIM shares per estate)

-   Above £2.5M, relief drops to 50% (effective 20% IHT rate)

-   This applies to assets held at death, not date of investment

**What this means:** An investor with £3M in qualifying EIS investments
currently pays £0 IHT on those assets. From April 2026, they\'ll pay
IHT on the £500,000 above the cap at the effective 20% rate = £100,000
additional IHT. For most investors investing at sensible annual
allocations — £50,000–£250,000 per year — the cap is unlikely to bind
for several years.

VCT Relief Reduction

Income tax relief on Venture Capital Trusts drops from 30% to 20%. A
£50,000 VCT investment made before April 6 generates £15,000 tax relief.
After April 6: only £10,000. That\'s £5,000 lost for waiting.

The Decision Window

April 5, 2026 is the last day of the 2025/26 tax year. Investments made
by this date:

-   Qualify for current year income tax relief (claim back against
    2025/26 tax)

-   Start the 2-year clock for IHT relief under current rules

-   Lock in 30% VCT relief before it drops to 20%

For Legacy Builders with estate planning goals, this tax year is the
last window to lock in full IHT relief under current uncapped rules.
The decision isn\'t whether to invest in EIS eventually---it\'s whether
to invest before April 5, 2026.

8\. The Advice Gap: Why No One Can Help

Here\'s something most investors don\'t fully realise: when it comes to
tax-efficient investments in private companies, there\'s a structural
advice gap. The people you might naturally turn to for guidance often
cannot help---not won\'t, cannot.

Your Accountant

Accountants can explain the tax mechanics of EIS and SEIS---how the
reliefs work, what you can claim, how to submit paperwork. What they
cannot do is advise you on whether a specific investment is suitable for
your circumstances. That would be investment advice, which accountants
are not authorised to provide. The FCA does not regulate accountants.

Your IFA or Wealth Manager

Independent Financial Advisers are regulated by the FCA, but that
regulation only covers FCA-regulated products---ISAs, pensions, unit
trusts, investment bonds. Investment in private, unquoted companies
(which is what EIS and SEIS investments involve) falls outside the
FCA\'s regulatory scope. Most IFAs either cannot or will not advise on
these investments.

The Structural Result

The most tax-efficient investment structures available to UK investors
are precisely the ones where professional advice is hardest to obtain.
The people who could explain the tax benefits can\'t advise on
investment quality. The people who could advise on investment quality
often can\'t touch unquoted securities.

**The result: if you want to access EIS/SEIS benefits, you largely need
to do your own homework.**

What \'Doing Your Homework\' Actually Requires

**Understanding your own tax position:** What\'s your marginal income
tax rate? Do you have CGT gains that could be deferred? What\'s your
estate\'s IHT exposure?

**Understanding the investment:** Management team track record. Business
model viability. Market size and competition. Use of funds.

**Understanding the structure:** Has HMRC advance assurance been
obtained? What are the fees? What\'s the realistic hold period?

**Understanding portfolio fit:** What percentage of your portfolio is
appropriate for EIS? How does this correlate with your existing
holdings? What\'s your genuine risk capacity?

Even with investment knowledge, there\'s an analytical problem: How do
you model an EIS investment within your complete portfolio? How do you
understand the tax implications across your whole position? How do you
stress-test how this new holding affects your concentration risk?

*Most investors can\'t---because the tools don\'t exist.*

9\. Portfolio Construction for 2026

Given everything in this report---the correlation problem, the
concentration risk, the tax opportunities, the advice gap---what should
a sophisticated investor actually do?

Principles, Not Prescriptions

This report can\'t give you personalised advice---that\'s the advice gap
we\'ve just described. But we can outline principles that apply broadly:

**1. Know your actual allocation.** Not what you think it is---what it
actually is. Across all platforms, all wrappers, all asset types. Most
investors can\'t answer this question accurately.

**2. Understand your concentration.** If any single asset class exceeds
40% of your portfolio, you\'re concentrated. If any single holding
exceeds 15%, you\'re concentrated. If your illiquid assets exceed 50%,
you have a liquidity problem waiting to happen.

**3. Question your \'diversification.\'** Owning different things isn\'t
diversification if they move together. Property, UK equities, and
UK-focused alternatives may all fall together in a UK-specific crisis.

**4. Use your tax allowances.** ISA: £20,000/year. Pension: up to
£60,000/year. EIS: up to £1M/year (£2M for knowledge-intensive
companies). Every pound not sheltered is paying unnecessary tax.

**5. Consider asymmetric structures.** EIS/SEIS offers capped downside
with uncapped upside. For investors with capacity for some early-stage
risk, this asymmetry is valuable.

Sample Allocations by Investor Type

**The Preserver (Conservative, wealth protection focus):**

Core equities (global diversified): 40% \| Bonds/Gilts: 25% \| Gold: 5%
\| Cash: 15% \| Tax-efficient growth (EIS): 10% \| Property (REITs, not
BTL): 5%

**The Growth Seeker (Balanced, long-term growth focus):**

Core equities (global): 45% \| Bonds: 15% \| Alternative investments: 5%
\| Cash: 10% \| Tax-efficient growth (EIS/SEIS): 20% \| Property: 5%

**The Legacy Builder (IHT-focused, intergenerational planning):**

Core equities: 35% \| Bonds: 10% \| Tax-efficient + IHT-qualifying
(EIS): 35% \| Cash: 10% \| Property (diversified): 10%

*Note: These are illustrative frameworks, not recommendations. Your
allocation should reflect your specific circumstances, time horizon, and
risk tolerance.*

10\. An Investment You Can Actually Understand

The Buffett Principle

Warren Buffett\'s first rule: invest in what you understand.

Most investment opportunities ask you to evaluate technology you don\'t
build, markets you don\'t trade, or business models that require faith
in management you\'ve never met. You\'re betting that experts know what
they\'re doing.

This section presents something different.

The Problem You\'ve Just Experienced

If you\'ve read this far, you\'ve encountered problems you probably
recognise:

-   **Fragmented visibility:** Your holdings scattered across platforms
    with no complete picture

-   **Hidden concentration:** Portfolio risks you can\'t easily
    calculate

-   **Correlation blindness:** No tools to model how assets interact in
    stress

-   **Tax inefficiency:** Optimisation opportunities you can\'t see
    across your whole position

-   **The advice gap:** No independent guidance on alternatives and EIS

**You understand these problems because you live them.**

That understanding is valuable.

The Solution Being Built

**Unlock** is an investment intelligence platform for private investors
managing £250K-£5M across multiple asset classes. It provides:

-   **Consolidated portfolio view** across all platforms, wrappers, and
    asset types

-   **Scenario analysis** modelling how your holdings perform under
    different conditions

-   **Concentration alerts** identifying hidden risks in your allocation

-   **Tax optimisation** across your complete position

-   **EIS/SEIS integration** to evaluate tax-efficient opportunities
    within portfolio context

This is the tool you\'d pay for. This is the capability that should
exist.

Why This Investment Is Different

Unlike most startup investments---where you\'re betting on founders\'
ability to build something for customers you don\'t know---this
opportunity has a unique characteristic:

**You are the customer.**

The platform is built for investors exactly like you. The problems it
solves are your problems. You can evaluate the product because you
understand the need.

This is Buffett-compatible investing: a business model you can genuinely
assess because you live the problem it addresses.

The Founding Investor Programme

Unlock is raising a founding round from a limited number of investors
who will shape the platform as it\'s built.

**What founding investors receive:**

-   **Equity stake** at pre-launch valuation (£6.5M pre-money)

-   **Lifetime platform access** (no subscription fees, ever)

-   **Direct product influence** (your needs become roadmap priorities)

-   **Priority syndicate access** (first access to vetted EIS
    opportunities)

-   **Quarterly reporting** with direct founder access

**Why this structure matters:**

The founding investors ARE the initial users. Their portfolio problems
become product requirements. Their feedback shapes development
priorities. The company succeeds by solving problems for people who have
direct input into what those problems are.

This isn\'t typical startup investing where you hope the team builds the
right thing. You\'re ensuring they build what you need.

The EIS Alignment

Unlock qualifies for EIS.

This report has explained why EIS is attractive for sophisticated
investors. Now apply that analysis:

-   **30% income tax relief** on your investment

-   **Tax-free gains** if Unlock succeeds

-   **Loss relief** protecting \~60% of downside if it fails

-   **IHT exemption** after two years

You\'re investing using the exact structure this report recommends, in a
company whose success you can evaluate because you understand the
problem it solves.

A £50,000 investment costs £35,000 after tax relief. Maximum downside
with loss relief: approximately £14,000. Upside if the company achieves
its targets: 5-10x returns, tax-free.

This is EIS as it should be used: informed investment with structural
downside protection.

The Timing

Two deadlines matter:

**April 5, 2026:** End of 2025/26 tax year. Last date to claim EIS
relief against current year income. Last tax year to lock in full IHT
relief under current uncapped BPR rules.

**March 2026:** Founding round closes. After this, investment will be at
higher valuation (Growth Capital round) without founding investor
benefits.

If this opportunity makes sense for your portfolio, the window is now.

11\. Next Steps

Is This Right for You?

This opportunity fits investors who:

-   Recognise the problems described in this report from personal
    experience

-   Have capacity for early-stage investment (EIS should typically be
    10-20% of portfolio)

-   Understand that startups can fail, even with strong fundamentals

-   Value the ability to influence a product built for their needs

-   Want to apply EIS benefits to an investment they can genuinely
    evaluate

If that\'s not you, this report still provides a useful framework for
thinking about your portfolio.

If You Want to Learn More

The process is straightforward:

**Step 1: Discovery call (20 minutes)** --- Confirm fit, discuss your
portfolio situation, answer questions about Unlock.

**Step 2: Platform demo (30 minutes)** --- See the product. Understand
what it does and what\'s on the roadmap.

**Step 3: Your decision** --- Review terms, assess fit for your
portfolio, decide allocation.

**Step 4: If you proceed** --- Instant Investment via SeedLegals, EIS
paperwork handled by Unlock, onboarding to platform.

No obligation at any stage. The first call is simply to see if this
makes sense for your situation.

Contact

To schedule a discovery call:

**Tom King, Founder**

tom@unlockdd.com

www.unlockdd.com

12\. Action Checklist

**For All Investors:**

-   Calculate your actual asset allocation (not what you think it is)

-   Identify concentration risks above 30% in any single asset class

-   Review tax allowance usage (ISA, pension, EIS/SEIS)

-   Understand the April 2026 deadlines and how they affect you

**For Preservers (Wealth Protection Focus):**

-   Stress-test your portfolio: what happens if UK property falls 20%?

-   Check your liquidity: can you access 12 months\' expenses without
    selling assets?

-   Review your bond allocation given correlation breakdown risk

**For Growth Seekers (Long-Term Growth Focus):**

-   Calculate your effective returns after tax

-   Assess whether EIS tax relief would improve your risk-adjusted
    returns

-   Review opportunity cost of cash holdings in a falling rate
    environment

**For Legacy Builders (IHT Planning Focus):**

-   Calculate current IHT exposure (estate value minus £325K nil-rate
    band)

-   Understand April 2026 IHT relief cap and its impact on your planning

-   Model EIS allocation required for meaningful IHT reduction

-   Begin planning BEFORE April 5, 2026 tax year deadline

Conclusion

This report has covered substantial ground: the 2026 market outlook, the
correlation risks in traditional portfolios, the concentration problems
most investors don\'t see, and the tax-efficient structures that
sophisticated investors use.

But the most important insight isn\'t about markets. It\'s about a
structural gap in how private investors manage wealth.

**The tools don\'t exist.** Consolidated visibility, scenario analysis,
tax optimisation across complete portfolios, independent evaluation of
EIS opportunities---these capabilities should be available to anyone
managing serious money. They\'re not.

**Unlock is building them.** And because you understand the
problem---because you\'ve lived the fragmentation, the hidden
concentration, the advice gap---you can evaluate this investment in a
way that\'s impossible for most startup opportunities.

That\'s the Buffett advantage: invest in what you understand.

Whether or not you choose to invest in Unlock, this report provides a
framework for evaluating your portfolio differently:

-   Calculate your real concentration

-   Model your correlation exposure

-   Maximise your tax efficiency

-   Do your homework on alternatives

And if you recognise yourself in these pages---if the problems feel
personal---consider whether owning the solution might be the smartest
investment of all.

--- --- ---

**Important Notice**

This report is for informational purposes only and does not constitute
financial, tax, or investment advice. Investment values can fall as well
as rise, and you may get back less than you invest. Past performance is
not a reliable indicator of future results. Tax treatment depends on
individual circumstances and may change. EIS and SEIS investments carry
significant risks including the potential for total loss of capital.
Consult with qualified financial and tax professionals before making
investment decisions. Unlock is an early-stage company and investment
carries substantial risk.

---

## March 2026 Update: The Iran Conflict

*Added 14 March 2026*

Since this report was written in January 2026, the case for diversification has become materially stronger.

On 28 February 2026, US-Israeli airstrikes on Iran triggered a significant global energy shock. Brent crude rose from approximately £70 to over £100 per barrel within days. The Strait of Hormuz — through which approximately 20% of global oil supply transits — faces disruption risk. The OBR has specifically flagged the conflict as a risk to UK inflation and growth in its March 2026 Spring Forecast.

The consequences for UK investors are direct:

- **Bank of England rate cuts delayed.** Markets had priced near-certain cuts in March. These are now pushed to June at the earliest, with further cuts uncertain. Mortgage rates that had been falling are under upward pressure.
- **UK economy flatlined in January** — before the energy shock — growing 0% against a 0.2% forecast. The conflict adds to headwinds already in place.
- **Energy costs rising** across all asset classes — property running costs, business operating costs, and consumer spending power all under pressure.
- **Equity markets volatile.** FTSE 100 down. Global markets pricing in inflation risk and slower growth.

This is precisely the scenario this report warned about: a correlated shock to UK property, equities, pensions, and employment income simultaneously. Investors concentrated in UK assets have no uncorrelated component to cushion the impact.

The EIS argument is unchanged — and, if anything, strengthened. Early-stage UK companies with genuine technology or service moats are less correlated to global energy prices than residential property or public equities. The IHT argument remains unaffected; the April 6 deadline is a legislative fact independent of market conditions.

*Chatham House and Oxford Economics both project the conflict as likely to resolve within two months, with markets recovering as disruption fades. The structural concentration risk identified in this report, however, persists regardless of the conflict's duration.*

---

*Original: January 2026 | Last updated: 14 March 2026 (Iran conflict update added; BPR cap corrected to £2.5M; ASA → Instant Investment; founding round timeline updated) | Status: Current*


---

<!-- END OF DOCUMENT -->

# INVESTOR-FACING DOCUMENTS — DRAFT (GENERATED)

## FAQ & Objection Handler
*Stage: All | All personas | 062_FAQ | DRAFT — Pending QC | Generated 2 April 2026*

---

# Unlock — Frequently Asked Questions & Objection Handler
## For investors, agents, and advisers | Draft V1 | 2 April 2026

*This document is for information purposes only and does not constitute financial advice or an invitation to invest. Capital is at risk. Investors should seek independent professional advice before making any investment decision.*

---

## About Unlock

**What is Unlock?**

Unlock is a portfolio intelligence platform for UK private investors managing £250,000 to £5 million. It consolidates assets across all accounts, wrappers, platforms, and structures into a single view — and layers on tax intelligence, scenario modelling, and EIS deal-flow access.

The mission is simple: give private investors the same clarity, tools, and protections that institutions take for granted.

**Who is Unlock built for?**

Unlock is built for self-directed and adviser-informed investors who manage complex, multi-asset portfolios — property, equities, alternatives, ISAs, pensions, and EIS positions — across multiple platforms and wrappers. If you're working from spreadsheets, relying on partial views from individual platforms, or finding that your IFA cannot help with EIS directly, Unlock is built for you.

**Is Unlock financial advice?**

No. Unlock is a portfolio intelligence platform. It does not provide regulated financial advice, make investment recommendations, or tell you what to buy or sell. It gives you the data, modelling, and scenario analysis to arrive at better-informed decisions — and to arrive at meetings with your IFA or accountant already knowing your position.

**How does Unlock make money?**

Unlock earns from subscriptions — a monthly fee for platform access. There are no AUM-based charges, no trail fees, and no commission on any investment surfaced through the platform. Our incentive is your continued use of the platform, not the sale of any particular product.

---

## The Platform

**What does Unlock actually do?**

Five core capabilities:

*Asset Register* — A permanent, accurate record of everything you own across all accounts, platforms, wrappers, and family members. Lot-level cost basis tracking. Date-freeze for IHT and probate valuations. Currently operational for founding investor onboarding.

*Portfolio Simulator* — Scenario testing and stress modelling grounded in your actual positions. Models what happens to your specific portfolio under 30+ downside scenarios — markets down 30%, interest rates spike, property falls, stagflation. You see how your holdings hold up before a crisis, not after. In active development.

*Tax Intelligence Engine* — Real-time, forward-looking modelling of all UK tax interactions across EIS, SEIS, CGT, IHT, pension drawdown, and AIM BPR. Continuous HMRC rule-tracking. This is the core of what Unlock does. In active development; 18–24 months minimum for any competitor to replicate correctly.

*Syndicate Access* — Curated access to vetted collective investment opportunities at 8–10% fees, versus the 9–14% charged by Crowdcube, Seedrs, and comparable platforms. Founding investors receive priority allocation. Operational now.

*Unlock Access* — A curated EIS deal-flow and portfolio service. See the Unlock Access section below.

**What is the Decumulation Planner?**

The Decumulation Planner answers the question every investor approaching retirement needs to ask: given my assets, how long will my money last if I spend £X per year — and what is the optimal sequence to draw from those assets to minimise tax and maximise what I pass to my heirs?

It covers all major asset classes — cash, ISA, pension (DC/SIPP/workplace), investment property, VCT, EIS, and AIM shares — and models four drawdown strategies: tax-optimised, IHT-optimised, income-first, and growth-first.

*Status: Specification complete. Prototype build commencing.*

**How is Unlock different from my existing platforms?**

Most platforms are built for one thing: showing you what's on their platform. They have no visibility of what you hold elsewhere, no tax intelligence, and no scenario modelling. Unlock consolidates across all of them — and adds the intelligence layer on top.

Your IFA provides advice. Your accountant handles compliance. Unlock gives you the consolidated data and forward-looking modelling that makes both of those conversations more productive. It is not a replacement for professional advice — it is what you bring to those meetings.

**How is Unlock different from Moneyhub or other aggregators?**

Portfolio aggregators connect accounts and show you a consolidated balance. Unlock does that — and then models tax interactions, runs scenarios, tracks EIS qualifying periods, flags IHT exposure, and gives you actionable intelligence. It is a different capability level, built specifically for the complexity of HNW portfolios.

---

## EIS & SEIS

**What is EIS?**

EIS — the Enterprise Investment Scheme — is a UK government programme providing substantial tax reliefs on investments in qualifying early-stage companies. The four reliefs are:

*Income tax relief* — 30% of the amount invested, claimable via Self Assessment or PAYE. Claimable in the year of investment or carried back to the previous tax year.

*Capital Gains Tax exemption* — If your investment grows and you sell after holding for at least three years, any profit is entirely exempt from CGT. There is no upper limit on the qualifying gain.

*Loss relief* — If a company fails, the net loss can be set against income tax or CGT. For an additional-rate taxpayer, the effective downside on a failed EIS investment is approximately 38.5p per pound invested — not 100p — after income tax relief and loss relief are applied.

*Inheritance Tax relief* — EIS shares held for at least two years qualify for Business Property Relief (BPR) and exit your estate entirely, subject to the April 2026 cap described below.

**What is SEIS?**

SEIS — the Seed Enterprise Investment Scheme — applies to earlier-stage companies and provides higher relief rates: 50% income tax relief (versus 30% for EIS), plus CGT exemption and loss relief on the same basis. The annual investment limit under SEIS is £200,000.

For an additional-rate taxpayer investing £50,000 under SEIS: income tax relief of £25,000 is received in the year of investment. If the company fails, loss relief reduces the net loss to approximately £13,750. Effective downside: approximately 27.5p per pound.

**What has changed about BPR from April 2026?**

From April 6, 2026, IHT relief on EIS and SEIS investments is subject to a cap. 100% relief continues to apply up to £2,500,000 per estate. For amounts above that threshold, relief reduces to 50%. This is a significant structural change for investors who have been using EIS and SEIS for IHT mitigation.

This change is subject to final enactment. Investors planning to use EIS or SEIS for IHT mitigation should seek professional advice on the implications for their specific position.

**Can I carry back EIS income tax relief to last year?**

Yes. EIS and SEIS income tax relief can be carried back to the previous tax year, subject to the annual limits applying in that year. The claim is made via Self Assessment. The carry-back deadline for 2024/25 tax year claims is April 5, 2026 — the final day of the current tax year.

**What happens to EIS CGT relief at death?**

Any capital gain accrued on an EIS investment during your lifetime is completely extinguished at death. Your beneficiaries inherit at probate value and pay CGT only on growth after that point. The EIS exemption does not transfer to beneficiaries — but the gain wiping at death means the combination of EIS and estate planning is particularly powerful.

**What about loss relief at death?**

Loss relief is personal — it belongs to the investor, not the investment. If a company fails after your death, your beneficiaries cannot claim loss relief. This strengthens the case for EIS investments with shorter exit horizons for investors later in life.

**My IFA says they can't advise on EIS. Is that right?**

Yes. UK IFAs cannot provide regulated advice on individual EIS company investments. They can advise on EIS funds managed by authorised discretionary managers, and they can advise on VCTs. Direct EIS investment sits outside the scope of regulated advice entirely. This is not a gap in your IFA's capability — it is a structural feature of how the advice regime works.

It means the decision about which EIS companies to back is yours. Unlock gives you the data, tools, and structured information to make that decision well.

---

## IHT & Pension Planning

**What is happening with pension IHT from April 2027?**

Under current proposals, pension assets will be included within an individual's estate for IHT purposes from April 2027. Currently, pensions sit outside the estate and pass to beneficiaries without IHT. If this change is enacted, it would significantly affect the estate planning position of investors with large pension balances.

This change is subject to final enactment. It has been announced but has not yet received Royal Assent. Investors with substantial pension assets should model both scenarios — with and without pension IHT inclusion — when planning their estate strategy.

**How does Unlock help with IHT planning?**

Unlock's Tax Intelligence Engine models IHT exposure across the full portfolio — including EIS/SEIS BPR eligibility, AIM BPR tracking, pension exposure under both current and proposed rules, and the interaction between different asset classes and wrappers. It gives you the forward-looking picture before you act, not the reconstructed picture after.

---

## Unlock Access

**What is Unlock Access?**

Unlock Access is a curated EIS deal-flow and portfolio service. It connects qualified investors with early-stage EIS-qualifying companies that have passed a structured evaluation process.

Four pillars: Guidance — Tools — Access — Administration.

It is not a fund. You build your own EIS portfolio from Unlock's curated pipeline, with full visibility at every stage.

**How does Unlock Access evaluate companies?**

Every company is assessed against a 24-criterion framework across four dimensions before any investor sees it. The scoring summary for each company is shared with investors in full — the same evaluation the Unlock Access team used to make its own decision. This is structured disclosure, not a recommendation.

Absence from the platform is the filter. Companies that do not pass the evaluation do not appear. Investors see only companies that have met the threshold. That is the entire screening function.

**Does Unlock Access advise investors?**

No. Unlock Access does not hold FCA authorisation and operates as a deal-flow and information service. It provides structured disclosure — investors receive the evaluation framework, the scoring summary, and the company documentation, and make their own investment decisions. The decision about whether to invest, and how much, remains entirely with the investor.

**Is Unlock Access independent of the companies it features?**

Unlock Access raises capital for its own pipeline companies — Unlock and Cloudworkz — and states this openly. All fees and relationships are disclosed in full before any investment is made. The positioning is transparency and full disclosure, not claims of independence.

---

## The Founding Round

**What is the founding round?**

Unlock is raising £1.2 million at a £6.5 million pre-money valuation from approximately 25 founding investors. The investment instrument is an Instant Investment via SeedLegals. Shares issue on April 6, 2026.

Unlock holds SEIS advance assurance. The raise is EIS and SEIS qualifying, subject to individual circumstances.

**What is an Instant Investment?**

An Instant Investment is the investment instrument used in this round, processed via SeedLegals. It provides immediate EIS compliance processing and anti-dilution protection until Series A. It is not an ASA (Advanced Subscription Agreement), SAFE, or convertible note — it is a direct equity investment.

**What do founding investors receive?**

Founding investors receive equity in Unlock, EIS or SEIS tax reliefs subject to individual circumstances, priority allocation on all Unlock Access deal-flow, and white-glove onboarding — the founding team sets up your portfolio with your actual holdings, runs initial scenario analysis, and delivers a customised portfolio report. White-glove onboarding is a permanent benefit, not a time-limited offer.

**What is the minimum investment?**

£40,000. Maximum £500,000. Ticket sizes are discussed individually with the Unlock team.

**Who backs Unlock?**

Founding investor backers include a former Chairman of Barclays and the former Director General of TISA (The Investing and Savings Alliance).

---

## Common Objections

**"I already have an IFA who handles this."**

Your IFA is likely excellent at regulated advice. Unlock is not advice — it is your data layer. It consolidates your full portfolio so you arrive at IFA meetings knowing your position, not reconstructing it. Most IFAs find clients who use Unlock are better informed and faster to act. Unlock complements your IFA — it does not replace them.

**"I'm not interested in investing in early-stage companies."**

The platform intelligence — portfolio consolidation, tax modelling, scenario simulation — is available to all investors regardless of whether they use EIS or Unlock Access. The investment risk in early-stage companies is real and is not appropriate for everyone. The platform's value does not depend on your appetite for that risk.

**"I already invest in EIS through a fund."**

EIS funds provide access but limited visibility. You typically cannot see the underlying companies, the evaluation logic, or how each position interacts with your wider tax picture. Unlock Access gives you direct portfolio building with full visibility, and Unlock's platform shows you how each EIS position sits within your broader estate and tax position. Direct EIS and EIS funds are not mutually exclusive.

**"My accountant handles tax."**

Tax software is backward-looking. It tells you what happened last year. Unlock is forward-looking — you model scenarios before decisions, not after. Your accountant and Unlock are not alternatives. Unlock gives you the data that makes your accountant's work more precise and your year-end conversations more productive.

**"How is Unlock different from a spreadsheet?"**

A spreadsheet holds what you put in it. Unlock tracks cost basis at lot level, models 30+ stress scenarios, flags BPR qualifying periods, and applies HMRC rules to your actual positions in real time. A spreadsheet reflects where you are. Unlock tells you where you're heading.

**"What if the regulations change?"**

Unlock's Tax Intelligence Engine is built for continuous HMRC rule-tracking — regulatory change is not a risk to the platform, it is part of the value proposition. When rules change, Unlock models the impact across your portfolio before you act.

**"I'm happy with my current setup."**

Most investors who say this are managing fragmented portfolios across multiple providers, missing tax optimisation opportunities, and working without forward-looking scenario analysis. The question is not whether your current setup works — it is whether it is optimal. Unlock answers that question. A 20-minute demo makes it visible.

---

## Contact

**tom@unlockdd.com | www.unlockdd.com**

*This document does not constitute financial advice or an invitation to invest. Unlock Access does not hold FCA authorisation and operates as a deal-flow and information service. EIS and SEIS investments are high-risk and illiquid. Capital is at risk. Tax treatment depends on individual circumstances and may change. Investors should seek independent professional advice before making any investment decision.*

*April 2026 | Draft V1 | Status: Pending QC evaluation*


---

<!-- END OF DOCUMENT -->

# CAMPAIGN OPERATIONS — INTERNAL

## 30K Database Execution Plan
*Internal — Master outreach plan, pipeline stages, DB tiers, cadence*

---

# Unlock Investor Outreach Execution Plan
## 30,000 Database + Aircall + Pipedrive

**Last Updated:** March 14, 2026
> **V4 NOTE:** This document is aligned with Unlock Content Bank V4 (March 2026). All references to investment instrument use "Instant Investment" (not ASA, SAFE, or Advanced Subscription Agreement). Campaign start date updated to March 16, 2026.  
**Objective:** Convert 25 founding investors into committed capital (£1.2M+) via systematic 1-on-1 outreach — campaign start March 16, 2026  
**Primary Channel:** Cold/warm calls using 16-step Aircall playbook + Pipedrive tracking

---

## Part 1: Database Segmentation & Tier Strategy

### Why Segmentation Matters
Your 30,000 database is not homogeneous. You need to:
1. **Tier by likelihood** (Tier 1/2/3 investor profiles)
2. **Segment by persona** (Preserver/Growth Seeker/Legacy Builder)
3. **Identify warm intros** (existing relationships, recent activity)
4. **Assign dial sequence** (highest-probability calls first)

### Tier 1: Highest Probability (Warm + HNW + Active)
**Target:** ~300–500 investors  
**Profile:**
- Recent activity in your other platform (last 30 days)
- Portfolio size £500K–£5M+ (estimable from transaction history)
- Prior EIS/SEIS interest (documented in notes/tags)
- Existing relationship or warm intro available
- Age 35–65 (likely to have capital available)

**Conversion Expectation:** 25–35% demo booking rate, 30–40% Instant Investment close rate  
**Effort:** 1-2 outreach per investor (call + light follow-up)

### Tier 2: Medium Probability (HNW + Some Activity)
**Target:** ~1,500–2,000 investors  
**Profile:**
- Portfolio size £250K–£1M
- Some but not recent activity
- No documented EIS/SEIS interest (yet)
- Estimated fit based on asset class preferences
- Age 35–65

**Conversion Expectation:** 12–18% demo booking rate, 15–25% Instant Investment close rate  
**Effort:** 2-3 outreach attempts per investor

### Tier 3: Lower Probability (Exploratory)
**Target:** Remaining database  
**Profile:**
- Portfolio size <£250K or unknown
- Inactive or historical only
- May not be EIS/SEIS eligible
- Useful for brand awareness + list building

**Conversion Expectation:** 3–8% demo booking rate, 5–10% Instant Investment close rate  
**Effort:** Limited outreach; focus on high-volume list building

---

## Part 2: Pipedrive Configuration for Aircall Integration

### Pipeline Structure (Recommended)
Create a **five-stage pipeline** that mirrors your investor journey:

**Stage 1: Outreach Queued**
- Investor added to calling list
- Phone number verified
- Tier assigned (Tier 1/2/3)
- Persona estimated (Preserver/Growth Seeker/Legacy Builder)
- Call script selected (16-step playbook)

**Stage 2: Called (Demo Booked)**
- Aircall call logged automatically to Pipedrive
- Call duration, outcome, and agent notes captured
- Next action: Send demo confirmation email
- Booking date/time in Pipedrive custom field

**Stage 3: Demo Scheduled**
- Video demo link generated
- One-pager sent to investor
- Investor to join video call within 7 days
- Reminder: 24 hours before demo

**Stage 4: Demo Completed â†’ Pack 1 Sent**
- Demo outcome logged (enthusiastic/interested/skeptical/pass)
- Investor persona refined based on demo
- Pack 1 (Founding Investor Pack) emailed with personalized cover letter
- Follow-up call scheduled for 3–5 days post-demo

**Stage 5: Pack 1 â†’ Pack 2 (Decision Stage)**
- Pack 1 feedback received
- Investor interest level updated
- Pack 2 (Investor Information Memorandum) sent to qualified prospects
- Advisor/accountant loop initiated
- Instant Investment close target set

---

### Pipedrive Custom Fields (to add)

| Field Name | Type | Values | Purpose |
|---|---|---|---|
| Investor Tier | Dropdown | Tier 1 / Tier 2 / Tier 3 | Prioritize outreach |
| Investor Persona | Dropdown | Preserver / Growth Seeker / Legacy Builder | Personalize messaging |
| EIS/SEIS Eligible | Checkbox | Yes/No/Unknown | Compliance + tax positioning |
| Portfolio Size | Dropdown | <£250K / £250K-£1M / £1M-£5M / £5M+ | Ticket size expectation |
| Call Outcome | Dropdown | Demo Booked / Not Interested / Call Back Later / Wrong Number / Voicemail | Dial sequence logic |
| Demo Status | Dropdown | Scheduled / Completed / No-Show / Rescheduled | Pipeline tracking |
| Demo Feedback | Text | [Free-form notes] | Refinement + persona validation |
| Pack 1 Sent | Date | [Auto-populate] | Sales cycle tracking |
| Pack 2 Sent | Date | [Auto-populate] | Escalation tracking |
| Expected Ticket Size | Currency | £___ | Sales forecasting |
| Instant Investment Close Date | Date | [Investor-facing target] | Win planning |
| Advisor/Accountant Involved | Checkbox | Yes/No | Due diligence readiness |

---

### Aircall Integration Checklist
- [ ] Aircall â†’ Pipedrive webhook configured (calls auto-log to Pipedrive)
- [ ] Call recordings uploaded to Pipedrive deal records
- [ ] Agent screen pop enabled (Pipedrive investor record displays during call)
- [ ] Call disposition codes mapped to Pipedrive outcomes
- [ ] Call script available in Aircall interface (embed 16-step playbook as agent notes)

---

## Part 3: Dial Sequence & Weekly Targets

### 8-Week Campaign Overview

**Week 1–2: Tier 1 Blitz**
- **Target:** 300 Tier 1 investors called
- **Booking target:** 75–105 demos (25–35% conversion)
- **Dial pace:** 150 calls/week (roughly 30 calls/day across team)
- **Key focus:** Build momentum with highest-probability investors

**Week 3–4: Tier 1 Follow-Up + Tier 2 Ramp**
- **Target:** 50 Tier 1 follow-ups + 400 Tier 2 new calls
- **Booking target:** 20 Tier 1 follow-ups + 50–70 Tier 2 demos
- **Dial pace:** 225 calls/week
- **Key focus:** Close Tier 1 follow-ups; seed Tier 2 pipeline

**Week 5–6: Tier 2 Ramp + Demo Execution**
- **Target:** 600 Tier 2 calls + 40–50 demos conducted
- **Booking target:** 70–100 new Tier 2 demos + 12–15 Pack 1 sends
- **Dial pace:** 300 calls/week
- **Key focus:** Demo cadence (2–4 per day); Pack 1 deployment

**Week 7–8: Tier 2 Follow-Up + Close Focus**
- **Target:** 200 Tier 2 follow-ups + 50 demos conducted
- **Booking target:** 20–30 Pack 2 sends + 5–10 Instant Investment closes
- **Dial pace:** 150 calls/week (shift to closing)
- **Key focus:** Close Tier 1/2 investors; Instant Investment execution

**Total campaign reach:** ~1,500–2,000 investors contacted over 8 weeks

---

## Part 4: Call Script Integration with Aircall

### How to Use the 16-Step Playbook in Aircall

**Setup:**
1. Create an Aircall "call script" or embed in agent notes
2. Display as a **sidebar** during live calls (steps 1–16 visible)
3. Agent marks steps complete as they progress
4. Failed steps â†’ agent branches to objection handling

**Call Flow (Aircall Screen):**

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ UNLOCK INVESTOR OUTREACH - AIRCALL SCRIPT â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Investor: John Smith | Portfolio: £1.2M    â”‚
â”‚ Tier: 1 | Persona: Growth Seeker          â”‚
â”‚ EIS/SEIS Eligible: Yes                     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ â˜ Step 1: Greeting & Context              â”‚
â”‚ â˜ Step 2: Introduce EIS/SEIS              â”‚
â”‚ â˜ Step 3: Confirm Awareness & Risk        â”‚
â”‚ â˜ Step 4: Common Starting Point           â”‚
â”‚ â˜ Step 5: Correlation & Inflation         â”‚
â”‚ â˜ Step 6: Over-Concentration Reality      â”‚
â”‚ â˜ Step 7: Early-Stage Parallel & Unlock   â”‚
â”‚ â˜ Step 8: Identify Main Frustration       â”‚
â”‚ â˜ Step 9: Unlock's Solution               â”‚
â”‚ â˜ Step 10: Market Uncertainty             â”‚
â”‚ â˜ Step 11: Independent Investor Type      â”‚
â”‚ â˜ Step 12: Unlock Differentiation         â”‚
â”‚ â˜ Step 13: Suitability & Eligibility      â”‚
â”‚ â˜ Step 14: Segment & Decision Process     â”‚
â”‚ â˜ Step 15: Book Demo (Setup & Time)       â”‚
â”‚ â˜ Step 16: Commitment & Compliance        â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Call Outcome: [ ] Demo Booked              â”‚
â”‚              [ ] Not Interested            â”‚
â”‚              [ ] Call Back Later           â”‚
â”‚              [ ] Wrong Number              â”‚
â”‚              [ ] Voicemail                 â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

## Part 5: Agent Preparation & Objection Handling

### Pre-Launch Training (Day 1–2)

**Mandatory for all agents:**

1. **Watch:** 5-minute video overview of Unlock (problem/solution/why now)
2. **Read:** One-pager on three personas (Preserver/Growth Seeker/Legacy Builder)
3. **Role-play:** Mock call using 16-step script with senior agent
4. **Certification:** Complete 3 successful mock calls; pass objection quiz
5. **Live listen:** Shadow 5 calls with experienced agent before going live

**Success criteria:**
- Agent completes all 16 steps in natural conversation flow
- Agent adapts language to investor personality
- Agent correctly identifies investor persona during call
- Agent books 25%+ of calls into demos (minimum benchmark)

---

### Objection Handling Framework

**Key objections you'll hear:**

| Objection | Root Cause | Reframe | Next Action |
|---|---|---|---|
| "I'm not interested in early-stage investments" | Misunderstands Unlock's role | Unlock = platform to understand all your investments, not forced entry into new ones | Pivot to portfolio view + tax efficiency |
| "I don't have time for a demo" | Real or stalling | "It's 20 minutes, and most say it saves them 5+ hours on portfolio management per year" | Offer specific time window or recorded demo |
| "My IFA handles this" | Advisor gatekeeping | "Unlock isn't advice—it's your own intelligence layer. Your IFA will love the data you bring them." | Offer to include advisor in demo |
| "How do I know this isn't a scam?" | Legitimate concern | Name-drop credible early investors + Barclays board member reference | Send one-pager first, then demo |
| "What's the catch? Why is it cheap?" | Trust issue | "We make money on syndicate fees + subscriptions, not on product margins. Aligned incentives." | Explain revenue model clearly |
| "I'm happy with my current setup" | Status quo bias | "Most investors say that until they see they're missing 10–20% in returns due to fragmentation." | Use concrete example from Step 6 |
| "I'll think about it and call you back" | Fear of commitment | "Happy to—but let's grab 20 minutes first to see if it's even worth your time." | Pin down specific callback date |

**Agent notes:** When objection raised, mark in Pipedrive + log agent's reframe attempt. This data trains future calls.

---

## Part 6: Demo Execution (Week 1–8)

### Demo Cadence & Logistics

**Target:** 2–4 demos per day (Tom or senior team member)

**Setup:**
1. Investor receives email 24 hours before demo with:
   - Zoom/Teams link
   - One-pager ("What to Expect")
   - Unlock elevator pitch (30 seconds)
   - Note: "Capital at risk; this is an introduction, not advice"

2. Demo takes 20–25 minutes:
   - 3 min: Context + Unlock mission
   - 12 min: Live walkthrough (portfolio simulator, personas, syndicates, due diligence tools)
   - 5 min: Q&A + objection handling
   - 2 min: Outcome + next steps (Pack 1 if interested)

3. Post-demo email within 1 hour:
   - Thank you note
   - Pack 1 attached (personalized cover letter by persona)
   - Follow-up call scheduled 3–5 days later
   - Subject line: "Your Unlock Demo – [Investor Persona] Strategy Overview"

---

### Demo Persona-Specific Positioning

**If Preserver identified:**
- Lead with portfolio stress-test capability
- Show downside modeling + capital protection
- Emphasize "sleep at night" outcome
- Highlight risk controls built in

**If Growth Seeker identified:**
- Lead with syndicate access + deal flow
- Show portfolio upside potential
- Emphasize 8–10% fee advantage vs. competitors
- Highlight 10–20% performance uplift narrative

**If Legacy Builder identified:**
- Lead with tax efficiency tools
- Show EIS/SEIS integration + inheritance planning
- Emphasize family wealth modeling
- Highlight multi-generational outcomes

**One-pager sent after demo (tailored by persona):**

```
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        YOUR UNLOCK INVESTOR PROFILE
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

Based on our demo call, here's what we learned about you:

INVESTOR ARCHETYPE: Growth Seeker
â”œâ”€ Motivation: Long-term wealth growth with calculated risk
â”œâ”€ Strength: You understand diversification + upside potential
â””â”€ Unlock fit: Syndicates + portfolio simulation

YOUR CURRENT SITUATION:
â”œâ”€ Portfolio: Likely ~£1–2M across stocks, property, ISA
â”œâ”€ Challenge: Limited visibility into upside opportunities
â””â”€ Opportunity: Unlock syndicates at 8–10% (vs 9–14% market)

NEXT STEPS:
1. Review Pack 1 (Founding Investor overview) — 5 pages, 8 min read
2. Schedule 20-min follow-up call on [DATE/TIME]
3. If interested: Explore Pack 2 (full details) + Instant Investment structure

QUESTIONS? Email tom@unlockdd.com or call [PHONE]

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        Capital at risk. This is an introduction.
                  No advice given.
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
```

---

## Part 7: Pack 1 â†’ Pack 2 Conversion Sequence

### Post-Demo Email Sequence (Automated via Pipedrive)

**Email 1: Send immediately after demo**
- Subject: "Your Unlock Demo – [Persona] Strategy Overview"
- Body: Thank you + Pack 1 attached
- Tone: Warm, personalized, outcome-focused
- CTA: "Review Pack 1, then let's talk on [SCHEDULED DATE]"

**Email 2: Day 2 (if no response)**
- Subject: "Quick question: Was the demo useful?"
- Body: Light touch-base; offer to clarify any confusion
- Tone: Helpful, not pushy
- CTA: "Reply or call me"

**Email 3: Day 3 (24 hours before follow-up call)**
- Subject: "Tomorrow's call – Pack 1 questions?"
- Body: Remind of scheduled call; offer to address any Pack 1 questions
- Tone: Confirmatory
- CTA: Confirm time; send Zoom link

**Email 4: Day 5 (if Pack 1 well-received)**
- Subject: "Next level: Full transparency"
- Body: Introduce Pack 2; explain difference
- Tone: Exclusive, scarcity-driven
- CTA: "Ready to dive deep? Let's discuss Pack 2 details"

**Email 5: Day 7 (if interest confirmed)**
- Subject: "Pack 2 attached – Full investment details"
- Body: Pack 2 + custom cover letter addressing their specific situation
- Tone: Professional, detail-rich
- CTA: "Review with your accountant; let's schedule Stage 3 call"

---

### Follow-Up Call Script (Day 3–5 Post-Demo)

**Call objective:** Gauge interest, address Pack 1 questions, move to Pack 2

```
STAGE 2 FOLLOW-UP CALL (15 minutes)

Opening:
"Hi [Name], thanks for reviewing the demo. Quick check-in on 
what you thought—any questions about how Unlock works?"

Listen for:
- Enthusiasm (â†’ move to Pack 1 â†’ Pack 2 immediately)
- Skepticism (â†’ address specific objection)
- Hesitation (â†’ uncover real concern)

If enthusiasm:
"Fantastic—so the [PERSONA]-focused approach makes sense for 
your situation. Next step is Pack 1, which gives you the full 
investment overview, founding investor benefits, and how you'd 
participate. Have you had a chance to review it?"

If they've read Pack 1:
"What stood out to you? What would you like to know more about?"

Listen for objections and address with reframes above.

If they're ready to move forward:
"Perfect—so the next step is Pack 2, which is the full legal 
and financial details, valuation framework, and Instant Investment structure. 
This is typically something you'd review with your accountant 
or IFA. Fair to send that over?"

Closing:
"Great—I'll send Pack 2 over today. Would it make sense to 
schedule a call in 5–7 days once you and your advisor have 
reviewed? That way we can walk through any questions and get 
you comfortable with the terms."

[Confirm date/time for Stage 3 call]
```

---

## Part 8: Sales Metrics & Weekly Dashboard

### KPIs to Track (Update Daily)

**Daily Metrics (Aircall â†’ Pipedrive auto-log):**
- Calls completed: __ (Target: 30–40/day)
- Calls booked to demos: __ (Target: 25–35% conversion)
- Demo confirmations: __ (Target: 80% of booked show up)

**Weekly Metrics (Pipedrive report):**
| Metric | Target | Week 1 | Week 2 | Week 3 | Week 4 | Week 5 | Week 6 | Week 7 | Week 8 |
|---|---|---|---|---|---|---|---|---|---|
| Calls dialed | 150 | | | | | | | | |
| Demos booked | 38–50 | | | | | | | | |
| Pack 1 sent | 8–12 | | | | | | | | |
| Pack 2 sent | 2–4 | | | | | | | | |
| Instant Investment closes | 1–2 | | | | | | | | |
| Cumulative capital raised | | | | | | | | | £___ |

**Sample Pipedrive Dashboard View:**

```
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
                    UNLOCK FOUNDING ROUND TRACKER
                         Week of March 16, 2026
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

FUNNEL OVERVIEW:
â”œâ”€ Tier 1 Outreach: 300 investors contacted (75 booked demos)
â”œâ”€ Tier 2 Outreach: 0 (starting Week 3)
â”œâ”€ Demo Completed: 25 (12 Pack 1 sent, 2 Pack 2 sent)
â””â”€ Instant Investment Signed: 0 (target: 1 by end of week)

CONVERSION RATES:
â”œâ”€ Outreach â†’ Demo Booking: 25% (TARGET: 25–35%)
â”œâ”€ Demo â†’ Pack 1 Send: 48% (TARGET: 60%+)
â”œâ”€ Pack 1 â†’ Pack 2 Send: 17% (TARGET: 50%+)
â””â”€ Pack 2 â†’ Instant Investment: 0% (TARGET: 30%+, ramping Week 5+)

PIPELINE BY STAGE:
â”œâ”€ Scheduled Demos (Next 7 days): 18
â”œâ”€ Pack 1 Pending Response: 10
â”œâ”€ Pack 2 Pending Response: 2
â””â”€ Instant Investment Pending: 0

TEAM PERFORMANCE:
â”œâ”€ Tom (team lead): 8 calls/day | 6 demos booked | 3 Pack 1 sent
â”œâ”€ Agent 2: 12 calls/day | 8 demos booked | 4 Pack 1 sent
â”œâ”€ Agent 3: 10 calls/day | 7 demos booked | 5 Pack 1 sent
â””â”€ Total: 30 calls/day | 21 demos booked | 12 Pack 1 sent

RED FLAGS:
âš  Pack 1 â†’ Pack 2 conversion only 17% (should be 50%+)
  â†’ Action: Review Pack 1 positioning; add FAQ to email
âš  Demo completion rate 80% (normal; improve reminder emails)
  â†’ Action: Add SMS reminder 2 hours before demo

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
```

---

## Part 9: Aircall + Pipedrive Technical Setup

### Pre-Campaign Checklist

**Aircall Configuration:**
- [ ] Three agent accounts created (Tom + 2 agents)
- [ ] Phone number(s) configured (local UK number or vanity number)
- [ ] Dialer list uploaded (30,000 investors with phone numbers)
- [ ] Call script template created with 16-step playbook
- [ ] Recording enabled (for quality assurance + training)
- [ ] Voicemail drop script created: "Hi [Name], it's [Agent] from Unlock UK — I'm calling about a new platform for private investors. Quick 20-minute call might be valuable. Please call me back at [PHONE]."

**Pipedrive Configuration:**
- [ ] Custom fields added (see Part 2)
- [ ] Five-stage pipeline configured (see Part 2)
- [ ] Aircall integration enabled (calls auto-log)
- [ ] Email templates created (see Part 7)
- [ ] Automated workflows set up:
  - [ ] When demo booked â†’ send confirmation email + calendar invite
  - [ ] When demo completed â†’ send Pack 1 + follow-up reminder
  - [ ] When Pack 1 sent â†’ set 3-day reminder for follow-up call
  - [ ] When Pack 2 sent â†’ set 7-day reminder for Stage 3 call
- [ ] Reports created:
  - [ ] Daily call volume + booking rate
  - [ ] Weekly conversion metrics
  - [ ] Agent performance leaderboard
  - [ ] Revenue forecast (capital raised vs. target)

**Database Preparation:**
- [ ] 30,000 investor records imported to Pipedrive
- [ ] Phone numbers validated (remove duplicates, bad numbers)
- [ ] Tier 1/2/3 assignments made (via scoring or manual review)
- [ ] Persona estimates added (based on portfolio history)
- [ ] Do-not-call list filtered out (compliance)
- [ ] Calling list sequenced by tier + estimated conversion probability

**Compliance & Legal:**
- [ ] GDPR consent confirmed (phone number usage)
- [ ] TCPA compliance (US investors, if applicable)
- [ ] Call recording disclosure script in place
- [ ] "Capital at risk" disclaimer in all emails
- [ ] "No advice given" statement in all materials

---

## Part 10: Sample Outreach Calendar (8 Weeks)

### Week 1–2: Tier 1 Blitz (March 16 – April 5)

**Monday, March 16:**
- Agent training + mock calls (all day)
- Tom: 2–3 calibration calls before going live

**Tuesday, March 17 – Friday, March 21:**
- 30 calls/day (150 total)
- Target: 38–50 demos booked
- Daily standup: 5 PM (review call outcomes, adjust messaging)

**Monday, March 24:**
- Follow-up outreach on Tier 1 voicemails
- Begin scheduling demos for Week 1–2 completion
- 2–3 demo calls

**Tuesday, March 25 – Friday, March 28:**
- Continue Tier 1 calls + demo execution
- 30 calls/day + 2–3 demos/day
- Cumulative: ~50 demos scheduled by end of week

**Monday, Dec 1:**
- Tier 1 follow-up push (call-backs, reschedules)
- Demo execution ramps (4 demos/day)
- Pack 1 sending begins (12–15 targeted)

**Cumulative outcome Week 1–2:**
- ~300 Tier 1 calls
- ~75 demos booked
- ~25 demos completed
- ~12 Pack 1 sent

---

### Week 3–4: Tier 1 Follow-Up + Tier 2 Ramp (Dec 2 – Dec 15)

**Monday, Dec 2:**
- 20 Tier 1 follow-ups (voicemail call-backs, reschedules)
- 200 Tier 2 new calls begin
- Demo execution continues (3–4/day)

**Tuesday, Dec 3 – Friday, Dec 6:**
- 200 Tier 2 calls
- 2–3 Tier 1 follow-ups per day
- Demo execution: 2–3/day
- Pack 1 follow-ups: 2–3/day (investors who received Pack 1 last week)

**Monday, Dec 9 – Friday, Dec 13:**
- 200 Tier 2 calls (second wave)
- Demo execution: 3–4/day (ramping)
- Pack 2 sending begins (2–4 targeted)
- Stage 3 calls begin (demo follow-up + Pack 1 review discussions)

**Cumulative outcome Week 3–4:**
- ~50 Tier 1 follow-ups
- ~400 Tier 2 calls
- ~50–70 Tier 2 demos booked
- ~40 demos completed
- ~20 Pack 1 sent
- ~4 Pack 2 sent

---

### Week 5–6: Tier 2 Ramp + Demo Execution Surge (Dec 16 – Dec 29)

**Monday, Dec 16:**
- Holiday week prep: reduce to 20 calls/day (many investors traveling)
- Focus: Demo execution + Pack 2 depth discussions
- Demo execution: 3–4/day
- Pack 2 follow-ups: 2–3/day

**Tuesday, Dec 17 – Thursday, Dec 19:**
- Light calling (holiday season beginning)
- Maximum demo execution: 4/day
- Follow-up call blitz (Pack 1 reviewers)

**Friday, Dec 20 – Dec 26:**
- Holiday break (minimal calling, focus on admin + reporting)
- Demo execution: 2/day (investors available)

**Monday, Dec 27 – Wednesday, Dec 29:**
- Resume full calling (20–30 calls/day)
- Demo execution: 3–4/day
- Instant Investment close attempts begin (first targeted closes)

**Cumulative outcome Week 5–6:**
- ~250 Tier 2 calls
- ~40–50 demos completed
- ~15 Pack 1 sent
- ~8 Pack 2 sent
- ~1–2 Instant Investment closes (early momentum)

---

### Week 7–8: Close Focus (Dec 30 – Jan 13)

**Monday, Dec 30 – Friday, Jan 3:**
- Light calling (New Year holidays)
- 15–20 calls/day
- Heavy demo + follow-up focus
- Instant Investment close push: 5–10 targeted

**Monday, Jan 6 – Friday, Jan 10:**
- Full calling resume (30 calls/day)
- Demo execution: 3–4/day
- Instant Investment close push: 5–10 targeted
- Pack 2 depth calls: 3–4/day

**Monday, Jan 13 onwards:**
- Final push on pipeline
- Close remaining Stage 3 investors
- Begin Tier 2 follow-up wave (if cap not yet hit)

**Cumulative outcome Week 7–8:**
- ~200 calls (lighter week due to holidays)
- ~20 demos completed
- ~5–10 Pack 2 sent
- ~5–10 Instant Investment closes

---

### 8-Week Campaign Cumulative Targets

| Metric | Target | Realistic Range |
|---|---|---|
| **Calls dialed** | 1,500–2,000 | 1,600–1,800 |
| **Demos booked** | 300–400 | 280–350 |
| **Demos completed** | 200–250 | 150–200 |
| **Pack 1 sent** | 80–120 | 70–100 |
| **Pack 2 sent** | 30–50 | 20–35 |
| **Instant Investment signed** | 20–25 | 18–22 |
| **Capital raised** | £1.2M–£1.5M | £900K–£1.3M |

---

## Part 11: Agent Training Playbook

### Pre-Launch Training (2 Days)

**Day 1: Unlock Deep Dive**
- 30 min: Company overview (problem/solution/why now)
- 20 min: Three personas + their motivations
- 20 min: Key differentiators vs. competitors
- 20 min: EIS/SEIS tax relief explanation (must-know)
- 20 min: Traction narrative (Barclays reference, early investors, alpha users)
- 30 min: Q&A

**Day 2: Script & Mock Calls**
- 30 min: 16-step playbook walkthrough (steps 1–16 reviewed line by line)
- 30 min: Demo booking success factors (timing, positioning, commitment)
- 60 min: Agent 1 mock call (live with feedback)
- 60 min: Agent 2 mock call (live with feedback)
- 30 min: Objection handling deep dive
- 30 min: Success metrics + KPI expectations
- 30 min: Aircall + Pipedrive tool overview

**Certification:**
- Agent must complete 3 successful mock calls (25%+ demo booking rate)
- Agent must explain three personas in their own words
- Agent must answer 5 objection scenarios correctly
- Agent must shadow 3 live calls before going independent

---

### Ongoing Training (Weekly)

**Monday 9 AM: Weekly Standup**
- Review previous week's metrics
- Celebrate wins (highest booker, best conversion story)
- Identify challenges (common objections, missed closes)
- Refine script based on learnings

**Wednesday 2 PM: Agent Coaching (15 min per agent)**
- Listen to 2 live calls
- Provide real-time feedback
- Coach on persona identification or objection handling

**Friday 4 PM: Team Huddle**
- Cumulative week review
- Preview upcoming week targets
- Share success stories + replicable tactics

---

### Script Customization by Agent

**Tom's angle (founder):**
- "Hi [Name], it's Tom from Unlock. I'm calling a few investors who I think would really value what we've builtâ€¦"
- Position: Co-founder perspective, personal credibility
- Ideal for: Tier 1 warm intros, skeptical investors, large tickets

**Agent 2's angle (consultant):**
- "Hi [Name], I'm calling on behalf of Unlock, an investment intelligence platformâ€¦"
- Position: Product expert, thorough walkthrough
- Ideal for: Tier 2, systematic investors, detail-oriented

**Agent 3's angle (coach):**
- "Hi [Name], I'm helping investors optimize their portfolios using a new toolâ€¦"
- Position: Helpful advisor, outcomes-focused
- Ideal for: Tier 2, relationship-focused, growth seekers

---

## Part 12: Risk Mitigation & Contingency Plans

### What if demo booking rate is below 25%?

**Diagnosis:**
1. Are agents completing all 16 steps? (Check Aircall recordings)
2. Is the EIS/SEIS explanation landing? (Ask investors in post-call surveys)
3. Is the Unlock value prop clear? (Refine Step 7 messaging)
4. Are agents hitting the right persona? (Review Tier assignment)

**Response:**
- [ ] Extend Tier 1 outreach by 2 weeks
- [ ] Add FAQ one-pager to improve clarity
- [ ] Replace struggling agent with stronger performer
- [ ] Refine positioning based on objection patterns
- [ ] Increase call volume (if conversion flat, dial more to hit targets)

---

### What if demo-to-Pack-1 conversion is below 50%?

**Diagnosis:**
1. Is the demo experience strong? (Investor feedback)
2. Is Pack 1 positioning clear? (Refine email + cover letter)
3. Are there objections not being addressed in demo? (Listen to recordings)
4. Are investors expecting free access? (Clarify founding investor benefits)

**Response:**
- [ ] Add "What's Included" section to Pack 1 cover letter
- [ ] Create demo variant for Preservers (more downside focus)
- [ ] Send demo recording link for investors who want to review
- [ ] Increase follow-up touch points (24-hour email + phone call)
- [ ] Reduce Pack 1 length (aim for 6–8 pages instead of 10)

---

### What if Pack-2-to-Instant Investment conversion is below 25%?

**Diagnosis:**
1. Are investors involving advisors? (Check if advisor participation accelerates close)
2. Is Pack 2 too complex? (Investor feedback)
3. Are there pricing/valuation objections? (Revisit Instant Investment mechanics explanation)
4. Is scarcity message strong enough? (Update urgency language)

**Response:**
- [ ] Create simplified "Instant Investment at a Glance" one-pager
- [ ] Add worked examples (£50K, £100K, £250K investment scenarios)
- [ ] Offer "advisor deep dive call" to explain Pack 2 to accountants/IFAs
- [ ] Increase scarcity pressure (send "2 slots remaining" update)
- [ ] Extend Stage 3 call from 20 min to 30 min (more time to close)

---

### What if capital raise target is missed by 25% (£900K instead of £1.2M)?

**Fallback plan:**
1. **Tier 2 extension (Week 9–10):** Dial 500+ more Tier 2 investors (lower conversion but reach new segment)
2. **Growth Capital Round acceleration:** Move Growth Capital positioning forward (offer £250K additional raise at 20% discount, target growth investors)
3. **Referral bonus:** Offer existing founders 5% bonus for each new founder referral
4. **Strategic investors:** Reach out to family offices + syndicators for larger tickets (£250K–£500K)

---

## Part 13: Success Stories & Social Proof Collection

### Post-Instant Investment Close: Investor Testimonial Request

**Email (sent 24 hours after Instant Investment signed):**

```
Subject: Quick testimonial? (Helps us close others like you)

Hi [Investor Name],

Thanks for committing to Unlock. We're grateful for your belief in 
the platform.

Quick ask: Would you be open to a 2-minute video testimonial 
about what convinced you to invest? Investors later in the funnel 
often ask to hear from real founders/investors who've already 
committed. It would mean a lot.

No pressure—just reply if you're up for it.

Best,
Tom
```

**Video testimonial script (2 minutes):**
```
"Hi, I'm [Name]. I invested in Unlock because [KEY REASON]. 
What convinced me was [SPECIFIC FEATURE OR FOUNDER INSIGHT]. 
I think [TARGET INVESTOR TYPE] would really benefit from 
[USE CASE]. Tom and the team are [CREDIBILITY MARKER]."
```

**Use testimonial clips in:**
- Week 5+ outreach emails ("Recent founder [Name] saidâ€¦")
- Stage 2 demo followup (share video of similar investor)
- Pack 1 cover letters (personalized per persona)

---

## Part 14: End-of-Campaign Reporting

### Post-Campaign Summary (Week 9)

**Email to stakeholders:**

```
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
           UNLOCK FOUNDING ROUND FINAL RESULTS
                      8-Week Campaign Review
                      March 16 – May 10, 2026
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

CAMPAIGN OVERVIEW:
â”œâ”€ Investors contacted: 1,647
â”œâ”€ Database utilization: 5.5% of 30,000
â”œâ”€ Total demos completed: 185
â”œâ”€ Total Pack 1 sent: 87
â”œâ”€ Total Pack 2 sent: 28
â””â”€ Instant Investment agreements signed: 22

CAPITAL RESULTS:
â”œâ”€ Capital raised: £1.18M
â”œâ”€ Average ticket size: £53.6K
â”œâ”€ Discount utilization: 35–59% (tiered)
â”œâ”€ Target achievement: 98% of £1.2M goal
â””â”€ Founding investor slots filled: 22/25

CONVERSION FUNNEL:
â”œâ”€ Outreach â†’ Demo booking: 24.8% (target 25–35%)
â”œâ”€ Demo â†’ Pack 1 send: 55.4% (target 60%+)
â”œâ”€ Pack 1 â†’ Pack 2 send: 38.6% (target 50%+)
â””â”€ Pack 2 â†’ Instant Investment: 42.8% (target 30%+)

TEAM PERFORMANCE:
â”œâ”€ Tom: 12 Instant Investments closed (highest closer + founder credibility)
â”œâ”€ Agent 2: 6 Instant Investments closed (highest volume + consistency)
â”œâ”€ Agent 3: 4 Instant Investments closed (strong engagement quality)

LESSONS LEARNED:
1. Tier 1 investors converted at 45% demo â†’ Pack 1 (vs 60% target)
   â†’ Insight: Need warmer intro + personal referral to hit targets
   
2. Advisor involvement = 70% close rate (vs 35% without advisor)
   â†’ Action: Proactively offer advisor deep-dive calls in Stage 3
   
3. Growth Seekers booked demos at 35% (vs 22% overall)
   â†’ Action: Target Growth Seekers more aggressively in future rounds
   
4. Pack 1 â†’ Pack 2 conversion highest for £100K+ investors
   â†’ Action: Segment Pack 1 by ticket size in Growth Capital round

NEXT STEPS:
â”œâ”€ Growth Capital Round (Q2 2026): 50+ investors targeted
â”œâ”€ Founding Investor onboarding: White-glove setup + Q4 2025 reporting
â”œâ”€ Platform development: Syndicate mechanics live by Q1 2026
â””â”€ Series A preparation: Begin institutional investor cultivation

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
```

---

## Part 15: Founding Investor Onboarding (Post-Instant Investment)

### Week 1 Post-Instant Investment: Welcome Flow

**Day 1 (Instant Investment signed):**
- Automated confirmation email + PDF receipt
- Invoice for EIS submission (if applicable)
- Founder welcome call scheduled for Day 2

**Day 2:**
- Tom hosts 30-min "Founding Investor Welcome" call
- Topics: What's next (EIS process, platform access, syndicate roadmap)
- Investor receives: Onboarding kit, platform login, syndicate calendar

**Days 3–7:**
- White-glove onboarding (1-on-1 platform setup)
- Founding investor Slack/WhatsApp group added
- syndicate priority access shared
- Monthly reporting cadence confirmed (last Friday of each month)

---

### Quarterly Reporting (Post-Launch)

**Q1 2026, Q2 2026, Q3 2026, Q4 2026:**
- User growth metrics (free â†’ paid conversion)
- Syndicate deployment updates (capital raised, deal flow)
- Product roadmap progress (features launched)
- Financial runway + Series A prep status
- Founder updates (wins, challenges, asks)

**Founding Investor perks locked in:**
- Lifetime premium access (no subscription fees ever)
- Priority syndicate allocation (first 48 hours to commit)
- Quarterly investor dinners (network building)
- Roadmap influence (quarterly voting on features)
- Exit preference (pro-rata rights on Series A, favorable liquidation preferences)

---

## Part 16: Quick Reference Checklists

### Pre-Campaign Launch Checklist
- [ ] Aircall phone lines configured + agents onboarded
- [ ] Pipedrive CRM setup complete (custom fields, workflows, integrations)
- [ ] 30,000 investor records imported + tiered + segmented
- [ ] 16-step call script embedded in Aircall interface
- [ ] Agent training completed (3 mock calls + certification per agent)
- [ ] Pack 1 + Pack 2 finalized + ready to send
- [ ] Email templates created (5 sequence emails)
- [ ] Legal/compliance reviewed (GDPR, TCPA, disclaimers)
- [ ] Dashboard + reporting configured (daily/weekly metrics)

### Daily Agent Checklist (Before First Call)
- [ ] Aircall phone tested (can make/receive calls)
- [ ] Pipedrive open + investor record loaded on screen
- [ ] 16-step script visible as sidebar or notes
- [ ] Call recorder enabled
- [ ] Email templates loaded and ready
- [ ] Objection handling sheet printed nearby
- [ ] Demo booking calendar visible
- [ ] "Capital at risk" disclosure ready to deliver

### Weekly Team Checklist
- [ ] Monday 9 AM: Team standup (review metrics, celebrate wins)
- [ ] Wednesday 2 PM: Agent coaching (listen to 2 calls, provide feedback)
- [ ] Friday 4 PM: Weekly huddle (cumulative review, weekend prep)
- [ ] Pipedrive dashboard updated (conversions, revenue forecast, red flags)
- [ ] Aircall recordings reviewed (quality + compliance spot-check)
- [ ] Email sequences sent on schedule

### Post-Instant Investment Checklist (For Each Investor)
- [ ] Confirmation email + PDF receipt sent
- [ ] EIS submission process initiated
- [ ] Founder welcome call scheduled (Day 2)
- [ ] Platform access provisioned (login + password sent)
- [ ] Slack/WhatsApp group added
- [ ] Monthly reporting cadence added to calendar
- [ ] Founding investor benefits summary sent
- [ ] Next syndicate opportunity preview shared

---

## Appendix: Template Assets (Ready to Customize)

### Email Template 1: Initial Outreach

```
Subject: [Name], quick idea for your portfolio

Hi [Name],

Hope you're well. I'm Tom from Unlock — a new investment 
intelligence platform for private investors like yourself.

The reason I'm reaching out: We help investors understand 
their full portfolio exposure (taxes, risk, opportunities) 
— especially around EIS/SEIS opportunities most people miss.

20-minute call to see if it's relevant? If not, no worries.

Tom
Unlock
tom@unlockdd.com
+44 [PHONE]
```

---

### Email Template 2: Pack 1 Follow-Up

```
Subject: Your [Persona] investment profile – Unlock overview

Hi [Name],

Following our demo yesterday, attached is an overview of 
how Unlock works specifically for [PERSONA] investors like you.

It covers:
- How the platform simulates different scenarios
- Founding investor benefits (lifetime access, priority syndicates)
- Why now: scarcity + timing

Quick read (5 pages, 8 min).

Let's hop on a quick call [DATE] to discuss any questions?

Best,
Tom
```

---

### Email Template 3: Pack 2 Invitation

```
Subject: Ready to dive deep? Full investment details

Hi [Name],

You've reviewed our overview. Now, here's the full transparency.

Pack 2 includes:
- Complete investment terms & Instant Investment mechanics
- Valuation framework + sensitivity analysis
- 2026–2029 financial projections
- Exit strategy (M&A, IPO, PE pathways)
- Full EIS/SEIS process + tax relief calculations

This is typically something you'd review with your accountant.
Happy to facilitate a call with your advisor if helpful.

Next step: Schedule a 30-min call once you've reviewed with 
your team.

Best,
Tom
```

---

### Email Template 4: Instant Investment Close Push

```
Subject: Last call: Founding investor benefits expire Dec 31

Hi [Name],

Appreciating your interest in Unlock. Want to flag: the 
founding investor offer (lifetime access + priority syndicates) 
expires end of year.

After Q1 2026, Growth Capital investors won't receive these 
permanent benefits.

Also: EIS submission window closes [DATE]. After that, HMRC 
processing adds 4+ weeks to your relief claim.

If you'd like to move forward, let's get Instant Investment signed by [DATE].

Happy to discuss any final questions.

Best,
Tom
```

---

### Pipedrive Email Sequence (Automated)

**Trigger:** Pack 1 sent

Delay 3 days â†’ Email 2 (light touch-base)
Delay 1 day (total 4) â†’ Email 3 (24-hour reminder before call)
If no response after call â†’ Delay 2 days â†’ Email 4 (Pack 2 offer)
If Pack 1 not opened after 7 days â†’ Phone call reminder (agent dials)

---

## Final Summary: 8-Week Execution Roadmap

```
WEEK 1–2: Tier 1 Blitz
â”œâ”€ 300 calls
â”œâ”€ 75 demos booked
â”œâ”€ 25 demos completed
â””â”€ 12 Pack 1 sent

WEEK 3–4: Tier 1 Follow-Up + Tier 2 Ramp
â”œâ”€ 450 calls (Tier 1 follow-ups + Tier 2 new)
â”œâ”€ 50–70 new Tier 2 demos booked
â”œâ”€ 40 demos completed
â””â”€ 20 Pack 1 sent, 4 Pack 2 sent

WEEK 5–6: Tier 2 Ramp + Demo Surge (Holiday Season)
â”œâ”€ 250 calls (lighter due to holidays)
â”œâ”€ 40–50 demos completed
â”œâ”€ 15 Pack 1 sent
â””â”€ 8 Pack 2 sent, 1–2 Instant Investment signed

WEEK 7–8: Close Focus (New Year)
â”œâ”€ 200 calls (lighter due to holidays)
â”œâ”€ 20 demos completed
â”œâ”€ 5–10 Pack 2 sent
â””â”€ 5–10 Instant Investment signed

CUMULATIVE TARGETS:
â”œâ”€ 1,200–1,500 calls dialed
â”œâ”€ 200–250 demos completed
â”œâ”€ 80–120 Pack 1 sent
â”œâ”€ 30–50 Pack 2 sent
â”œâ”€ 20–25 Instant Investment signed
â””â”€ £1.2M capital raised (22 founding investors)

FOUNDING INVESTOR ONBOARDING:
â”œâ”€ Week 1–2: White-glove setup
â”œâ”€ Week 3+: Monthly reporting + syndicate access
â””â”€ Lifetime benefits locked in (access, priority, roadmap influence)
```

---

**This plan is ready to execute immediately.**

**Next action:** Tom to run first 5 calibration calls Tuesday, March 17  9 AM.

---

**End of Execution Plan**


---

<!-- END OF DOCUMENT -->

## Pipedrive & Aircall Setup
*Internal — CRM and calling platform configuration*

---

> **V4 NOTE:** Updated March 2026. All pipeline stage names and email templates use "Instant Investment" not SAFE/ASA. Campaign dates updated to March 16, 2026 start.

# Pipedrive + Aircall Setup Guide for Unlock
## Complete Technical Configuration

**Objective:** Connect Aircall phone system to Pipedrive CRM so all calls auto-log, custom fields track investor stage, and workflows automate email sequences.

---

## Part A: Pipedrive Initial Setup

### Step 1: Create Your Five-Stage Pipeline

**Go to:** Settings â†’ Pipelines â†’ Add New Pipeline

**Pipeline Name:** "Unlock Founding Round"

**Stages (create in order):**

1. **Stage 1: Outreach Queued** (Pre-call)
   - Description: "Investor added to calling list, phone verified, tier assigned"
   - Color: Blue
   - Probability: 0% (not yet contacted)

2. **Stage 2: Called (Demo Booked)** (After call)
   - Description: "Call completed, demo booked or voicemail left"
   - Color: Yellow
   - Probability: 20% (early interest)

3. **Stage 3: Demo Scheduled** (Demo scheduled but not completed)
   - Description: "Video demo link sent, investor to join within 7 days"
   - Color: Orange
   - Probability: 40% (interested enough to attend)

4. **Stage 4: Demo Completed â†’ Pack 1 Sent** (Post-demo)
   - Description: "Demo delivered, Pack 1 sent, follow-up call scheduled"
   - Color: Purple
   - Probability: 60% (strong interest)

5. **Stage 5: Pack 1 â†’ Pack 2 (Decision Stage)** (Advanced stage)
   - Description: "Pack 2 sent, advisor loop initiated, Instant Investment targeting stage"
   - Color: Green
   - Probability: 75% (high-intent stage)

---

### Step 2: Add Custom Fields to Track Investor Journey

**Go to:** Settings â†’ Customize Fields â†’ Deals

**Add these fields (in order):**

| Field Name | Type | Values/Options | Required? | Notes |
|---|---|---|---|---|
| **Investor Tier** | Dropdown | Tier 1 / Tier 2 / Tier 3 | Yes | Determines dial priority |
| **Investor Persona** | Dropdown | Preserver / Growth Seeker / Legacy Builder | No (set after demo) | Drives personalized messaging |
| **EIS/SEIS Eligible** | Dropdown | Yes / No / Unknown | No | Compliance + tax positioning |
| **Portfolio Size (Estimate)** | Dropdown | <Â£250K / Â£250K-Â£1M / Â£1M-Â£5M / Â£5M+ | No | Ticket size prediction |
| **Phone Number** | Text | [auto-populated] | Yes | Aircall integration |
| **Email Address** | Email | [auto-populated] | Yes | For email sequences |
| **Call Outcome** | Dropdown | Demo Booked / Not Interested / Call Back Later / Wrong Number / Voicemail | Yes (after call) | Next action logic |
| **Aircall Call Recording** | URL | [auto-linked] | No (auto-populate) | Store recording link |
| **Aircall Call Duration (sec)** | Number | [auto-populate] | No | Track call length |
| **Demo Scheduled Date** | Date | [investor-provided] | No | Trigger reminders |
| **Demo Completed** | Checkbox | Yes/No | No | Workflow trigger |
| **Demo Feedback Score** | Dropdown | Very Interested (90-100) / Interested (70-89) / Neutral (50-69) / Lukewarm (30-49) / Not Interested (<30) | Yes (after demo) | Qualification gate |
| **Demo Feedback Notes** | Text | [Free-form] | No | Persona + objection details |
| **Pack 1 Sent Date** | Date | [auto-populate via workflow] | No | Track email deployment |
| **Pack 1 Opened** | Checkbox | Yes/No | No | Email tracking (if enabled) |
| **Pack 1 Response** | Dropdown | Enthusiastic / Interested / Lukewarm / Not Interested | No | Trigger Pack 2 logic |
| **Pack 2 Sent Date** | Date | [auto-populate] | No | Track escalation |
| **Pack 2 Opened** | Checkbox | Yes/No | No | Email tracking |
| **Advisor/Accountant Involved** | Checkbox | Yes/No | No | Due diligence readiness |
| **Expected Ticket Size** | Currency | Â£___ | No (estimate after Pack 2) | Sales forecasting |
| **Instant Investment Close Date (Target)** | Date | [assigned in Stage 4+] | No | Win planning |
| **Instant Investment Signed Date** | Date | [auto-populate on close] | No | Celebration + onboarding trigger |
| **Discount Negotiated** | Percentage | [Enter % agreed] | No (post-investment) | Internal tracking only — never shared with investors |
| **EIS/SEIS Submission Status** | Dropdown | Not Started / Pending / Submitted / Approved | No (post-investment) | Compliance tracking |
| **Founding Investor Status** | Dropdown | Committed / Pending / Not Pursuing | Yes | Final classification |

---

### Step 3: Configure Pipeline Automation (Workflows)

**Go to:** Settings â†’ Automation â†’ Workflows

**Workflow 1: Auto-Log Aircall Calls to Pipedrive**

- **Trigger:** New call in Aircall
- **Action:** Create deal in Pipedrive (Stage 1: Outreach Queued)
- **Details mapped:**
  - Caller: Tom/Agent Name
  - Phone: [From Aircall]
  - Call duration: [Auto-captured]
  - Recording link: [Auto-attached]
  - Timestamp: [Auto-set]

---

**Workflow 2: When Demo Booked â†’ Auto-Move to Stage 2 + Send Email**

- **Trigger:** Call Outcome = "Demo Booked"
- **Actions:**
  1. Move deal to Stage 2 (Called - Demo Booked)
  2. Send email: "Demo Confirmation â€“ Next Steps"
  3. Add task: "Send calendar invite + one-pager"
  4. Notify: Tom (internal note)

**Email template:**
```
Subject: Your Unlock Demo â€“ Confirmed

Hi [Investor Name],

Great news! Your demo is confirmed for [DATE/TIME] via Zoom.

Here's what to expect:
- 20-minute walkthrough of the Unlock platform
- Personalized portfolio simulation
- Q&A on investment strategy
- No advice givenâ€”just an introduction

ðŸ“Ž One-pager (attached) explains what we'll cover.

Link: [ZOOM_LINK]

See you then!
Tom
```

---

**Workflow 3: When Demo Completed + Feedback >70 â†’ Send Pack 1**

- **Trigger:** 
  - Demo Completed = Yes
  - Demo Feedback Score â‰¥ 70
- **Actions:**
  1. Move deal to Stage 4 (Demo Completed â†’ Pack 1 Sent)
  2. Send email: Pack 1 (Founding Investor Pack)
  3. Create task: "Follow-up call in 3 days"
  4. Send internal Slack notification

**Email template:**
```
Subject: Your Unlock Investor Overview â€“ [Persona Strategy]

Hi [Investor Name],

Following your demo, here's the complete Founding Investor overview 
tailored to your [PERSONA] profile.

ðŸ“Ž Pack 1 includes:
âœ“ Deal basics (Â£6.5M pre-money, up to 50% discount)
âœ“ EIS/SEIS benefits (30â€“50% relief, 4-week HMRC payout)
âœ“ Early investor perks (lifetime access, priority syndicates)
âœ“ 3 investor personas + your fit
âœ“ Go-to-market roadmap
âœ“ Exit strategy (5â€“10x in 3â€“5 years)

Quick read: 5 pages, 8 minutes.

Let's chat [DATE/TIME] to discuss questions?

Best,
Tom
```

---

**Workflow 4: When Pack 1 Response = Interested â†’ Auto-Send Pack 2**

- **Trigger:** Pack 1 Response = "Interested" or "Enthusiastic"
- **Actions:**
  1. Move deal to Stage 5 (Pack 1 â†’ Pack 2)
  2. Send email: Pack 2 (Investor Information Memorandum) with custom cover letter
  3. Create task: "Schedule Stage 3 deep-dive call (30 min)"
  4. Log in Slack: "New Pack 2 recipient: [Name] - [Persona]"

**Email template:**
```
Subject: Full Investment Details â€“ Pack 2 (Deep Dive)

Hi [Investor Name],

Ready to go deeper? Here's the full transparency.

ðŸ“Ž Pack 2 includes:
âœ“ Complete Instant Investment mechanics + worked examples
âœ“ Valuation framework + sensitivity analysis
âœ“ 2026â€“2029 financial projections
âœ“ Exit strategy (named acquirers, IPO milestones)
âœ“ EIS/SEIS tax relief walkthrough
âœ“ Risk factors + mitigation
âœ“ Full appendices (business plan, market analysis)

This is typically something you'd review with your accountant. 
Happy to facilitate a call if you'd like me to walk them through it.

Next step: Review with your team, then let's schedule a deep-dive 
call with you (and your advisor, if relevant).

Target: Instant Investment signature by [DATE] to lock in founding investor 
benefits.

Best,
Tom
```

---

**Workflow 5: When Instant Investment Signed â†’ Onboarding Flow**

- **Trigger:** Founding Investor Status = "Committed" (manually set upon Instant Investment signature)
- **Actions:**
  1. Move deal to Won (Close it)
  2. Update cumulative capital raised field
  3. Send email: Onboarding kit + founding investor perks summary
  4. Create task: "Schedule welcome call (Tom) for Day 2"
  5. Add investor to Slack group: #founding-investors
  6. Log in spreadsheet: Capital tracking + cap table
  7. Notify: Tom + CFO (revenue recognition)

**Email template:**
```
Subject: Welcome to Unlock â€“ Founding Investor Onboarding

Hi [Investor Name],

ðŸŽ‰ Instant Investment agreement signed! You're now an official Unlock Founding Investor.

Here's what's next:

âœ“ Onboarding kit (attached) â€” covers EIS process, platform setup, and current roadmap
âœ“ Platform access â€” login + password sent separately
âœ“ Founding investor Slack â€” join #founding-investors (private community)
âœ“ Welcome call â€” Tom calling tomorrow at [TIME]
âœ“ Q1 2026 syndicate preview â€” priority access to first deal flow

Your lifetime benefits are locked in:
â†’ Lifetime premium access (no subscription fees)
â†’ Priority syndicate allocation (first 48 hours)
â†’ Quarterly investor dinners
â†’ Roadmap influence (voting on features)

Questions? Reply to this email or call Tom directly: [PHONE]

Welcome to the founding investor family!

Best,
Tom
```

---

### Step 4: Set Up Email Templates (In Pipedrive)

**Go to:** Manage â†’ Email Templates

**Create 5 templates:**

1. **"Stage 1: Initial Demo Confirmation"**
   - Used when: Call Outcome = Demo Booked
   - Variables: [Name], [DateTime], [ZoomLink]

2. **"Stage 2: Pack 1 Follow-Up"**
   - Used when: Demo Completed + High Feedback
   - Variables: [Name], [Persona], [ScheduledCallDate]

3. **"Stage 3: Pack 2 Invitation"**
   - Used when: Pack 1 Response = Interested
   - Variables: [Name], [AdvisorOption], [SoftDeadline]

4. **"Stage 4: Instant Investment Close Push"**
   - Used when: Pack 2 viewed but no response after 5 days
   - Variables: [Name], [UrgencyDate], [ScarcityMessage]

5. **"Stage 5: Onboarding Kit"**
   - Used when: Instant Investment Signed
   - Variables: [Name], [EISProcess], [SlackLink], [WelcomeCallTime]

---

## Part B: Aircall Integration

### Step 1: Enable Aircall â†’ Pipedrive Webhook

**In Aircall:**
1. Go to Admin â†’ Integrations â†’ Pipedrive
2. Click "Connect"
3. Authorize Aircall to access your Pipedrive account
4. Select which phone line(s) to sync with Pipedrive
5. **Mapping settings:**
   - Incoming call â†’ Create deal in Pipedrive (if not exists)
   - Call data captured:
     - Caller phone number
     - Call duration
     - Call timestamp
     - Call recording link
     - Agent name
   - Auto-move to Stage 2 (Called) when call completes

---

### Step 2: Configure Agent Screen Pop

**In Aircall:**
1. Admin â†’ Phone Settings â†’ Screen Pop
2. Enable: "Display Pipedrive deal when call incoming"
3. Match on: Phone number
4. Display: Deal card (investor name, tier, persona, last note)

**What agent sees during call:**
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ INCOMING CALL: +44 20 XXXX XXXX            â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Investor Name: John Smith                  â”‚
â”‚ Tier: 1 | Persona: Growth Seeker           â”‚
â”‚ Portfolio: Â£1.2M | EIS Eligible: Yes       â”‚
â”‚ Last Note: "Interested in syndicates"      â”‚
â”‚ Call Duration: 6 min (ongoing)             â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ [MUTE] [HOLD] [TRANSFER] [RECORD]          â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

### Step 3: Aircall Call Disposition Codes

**In Aircall:** Admin â†’ Call Handling â†’ Disposition Codes

**Set up codes (agent selects at end of call):**

- **101** = Demo Booked (Move to Stage 2)
- **102** = Not Interested (Move to Lost, log as "No")
- **103** = Call Back Later (Move back to Stage 1, schedule callback)
- **104** = Wrong Number (Delete deal)
- **105** = Voicemail Left (Move to Stage 2, flag for follow-up)
- **106** = Interested, Send Info (Move to Stage 2, queue Pack 1)

**When agent selects code 101:**
```
Aircall asks: "What date/time for demo?"
Agent enters: [DATE/TIME]
Aircall auto-logs to Pipedrive â†’ Trigger Workflow 2 (confirmation email + calendar)
```

---

### Step 4: Call Recording Storage

**In Aircall:**
1. Admin â†’ Recording Settings â†’ Enable Recording
2. Storage: Cloud (Aircall servers)
3. Retention: 2 years
4. Disclosure: "This call may be recorded" â€” auto-played at call start

**In Pipedrive (Workflow):**
- Call recording automatically attached to deal record
- Accessible via custom field: [Aircall Call Recording] (URL link)
- Used for: Quality assurance, agent training, compliance

---

## Part C: Pipedrive Dashboard Setup

### Create Investor Campaign Dashboard

**Go to:** Reports â†’ Custom Dashboards â†’ New Dashboard

**Dashboard Title:** "Unlock Founding Round â€“ Live Campaign Tracker"

**Add 6 cards:**

---

**Card 1: Funnel Summary (Stacked Bar Chart)**

| Stage | Count | Conversion % |
|---|---|---|
| Outreach Queued | 1,500 | â€” |
| Called (Demo Booked) | 375 | 25% |
| Demo Completed â†’ Pack 1 | 200 | 53% |
| Pack 1 â†’ Pack 2 | 85 | 43% |
| Instant Investment Signed (Won) | 25 | 29% |

**Metric:** "Average conversion by stage"

---

**Card 2: Daily Call Volume (Line Chart)**

- X-axis: Date (Nov 18 â€“ Jan 13)
- Y-axis: Calls dialed per day
- Target line: 30 calls/day
- Actual: [Real-time from Aircall sync]

**Shows:** Are we meeting dial targets? Identify off days.

---

**Card 3: Capital Raised Progress (Gauge Chart)**

- Target: Â£1.2M
- Current: Â£[LIVE from SEIS/SEIS Signed deals]
- % to goal: [Auto-calculated]
- Color: Red (0â€“40%), Yellow (40â€“70%), Green (70â€“100%)

---

**Card 4: Demo Booking Rate (Metric Card)**

- Title: "Call â†’ Demo Booking Rate"
- Number: [% from (Called/Outreach Queued)]
- Benchmark: 25â€“35% target
- Color: Green if â‰¥25%, Yellow if 15â€“25%, Red if <15%

---

**Card 5: Investor Tier Breakdown (Pie Chart)**

- Tier 1: 300 (started Week 1)
- Tier 2: 600 (ramping Week 3+)
- Tier 3: 600 (exploratory)
- **Shows:** Which tier generating closes?

---

**Card 6: Avg Deal Size by Tier (Bar Chart)**

- Tier 1: Â£85,000 (higher tickets)
- Tier 2: Â£52,000 (mid-range)
- Tier 3: Â£32,000 (exploratory)

**Shows:** Which tier most valuable per close?

---

### Create Agent Performance Dashboard

**Go to:** Reports â†’ Custom Dashboards â†’ New Dashboard (Agent View)

**Dashboard Title:** "Agent Leaderboard â€“ [Date Range]"

**Add 4 cards:**

---

**Card 1: Calls Completed (Top Agent)**

| Agent | Calls | Demos Booked | Booking % | Pack 1 Sent | Instant Investment Closed |
|---|---|---|---|---|---|
| Tom | 180 | 45 | 25% | 20 | 12 |
| Agent 2 | 220 | 52 | 24% | 28 | 6 |
| Agent 3 | 185 | 42 | 23% | 16 | 4 |

**Sort by:** Calls completed (high to low)

---

**Card 2: Demo Booking Rate (Efficiency)**

| Agent | Booking % | Benchmark | Status |
|---|---|---|---|
| Agent 2 | 24% | 25% | âš  Slightly below target |
| Tom | 25% | 25% | âœ“ On target |
| Agent 3 | 23% | 25% | âš  Slightly below target |

**Insight:** Identify agent who needs coaching.

---

**Card 3: Instant Investment Close Rate (Effectiveness)**

| Agent | Pack 2s Sent | Instant Investments Closed | Close % |
|---|---|---|---|
| Tom | 12 | 12 | 100% â­ |
| Agent 2 | 28 | 6 | 21% |
| Agent 3 | 16 | 4 | 25% |

**Insight:** Tom closes best â†’ assign him to Stage 3 deep-dives.

---

**Card 4: Average Call Duration (Quality)**

| Agent | Avg Duration | Benchmark | Note |
|---|---|---|---|
| Tom | 8 min 42 sec | 8â€“10 min | Hitting 16-step script âœ“ |
| Agent 2 | 7 min 15 sec | 8â€“10 min | âš  Too short; rushing |
| Agent 3 | 9 min 30 sec | 8â€“10 min | âœ“ Good depth |

**Insight:** Agent 2 needs to slow down; more info-gathering.

---

## Part D: Contact Import & Database Setup

### Step 1: Prepare Your 30,000 Investor List

**CSV format (6 required columns):**

```
first_name,last_name,email,phone,tier,persona_estimate
John,Smith,john.smith@email.com,+44 20 XXXX XXXX,1,Growth Seeker
Jane,Doe,jane.doe@email.com,+44 121 XXXX XXXX,1,Preserver
David,Brown,david.brown@email.com,+44 161 XXXX XXXX,2,Legacy Builder
...
```

**Validation checks before import:**
- [ ] No duplicate phone numbers (flag duplicates)
- [ ] All phone numbers E.164 format (+44 + 10 digits)
- [ ] All emails valid (basic regex check)
- [ ] No missing first/last names
- [ ] Tier 1/2/3 assignments complete
- [ ] Persona estimates logical (based on portfolio history from your other platform)

---

### Step 2: Import to Pipedrive

**Go to:** Contacts â†’ Import Contacts

1. Upload CSV file
2. Map columns:
   - First Name â†’ [first_name]
   - Last Name â†’ [last_name]
   - Email â†’ [email]
   - Phone â†’ [phone]
   - Custom: Investor Tier â†’ [tier]
   - Custom: Investor Persona â†’ [persona_estimate]

3. On import completion:
   - Automatically create deals for each contact
   - Set all deals to Stage 1 (Outreach Queued)
   - Assign to agents (round-robin by tier)

---

### Step 3: Tier-Based Assignment

**In Pipedrive â†’ Manage â†’ Assign Deals:**

- **Tier 1 (300 contacts) â†’ Tom** (founder credibility + warmth)
- **Tier 2 (900 contacts) â†’ Agent 2 + Agent 3** (split evenly: Agent 2 = 450, Agent 3 = 450)
- **Tier 3 (800+ contacts) â†’ Agent 2 + Agent 3** (secondary list, dial after Tier 1/2 progressing)

**Why this assignment:**
- Tom on Tier 1 = warm + strategic (builds early momentum)
- Agents scale Tier 2 (volume dial + conversion)
- Tier 3 used to backfill if Tier 1/2 conversion slows

---

### Step 4: Set Up Calling Lists in Aircall

**In Aircall â†’ Campaign Manager:**

1. **Create Campaign 1: "Tier 1 Blitz"**
   - Contacts: 300 (from Pipedrive Tier 1)
   - Assigned to: Tom
   - Dial mode: Power dialer (auto-dial next contact when current call ends)
   - Agent: Tom
   - Hours: 9 AM â€“ 5 PM, Mondayâ€“Friday
   - Target: 30 calls/day

2. **Create Campaign 2: "Tier 2 Ramp"**
   - Contacts: 900 (Tier 2, from Pipedrive)
   - Assigned to: Agent 2 + Agent 3
   - Dial mode: Power dialer
   - Start date: Week 3 (Dec 2)
   - Target: 30 calls/day per agent

3. **Create Campaign 3: "Tier 3 Exploratory"**
   - Contacts: 800+ (Tier 3, from Pipedrive)
   - Assigned to: Agent 2 + Agent 3 (when Tier 1/2 progress slows)
   - Start date: Week 5 (Jan 1, post-holiday)
   - Target: 20 calls/day per agent

---

## Part E: Compliance & Legal Setup

### Step 1: GDPR Compliance

**In Pipedrive:**
- [ ] Add custom field: "Consent Type" (Existing customer / Warm intro / Cold outreach)
- [ ] Investors with "Cold outreach" = phone calls only (no SMS)
- [ ] Investors with "Existing customer" = phone + email + SMS allowed

**In Aircall:**
- [ ] Enable: "Consent recording disclosure"
- [ ] Auto-play at call start: "This call may be recorded for quality purposes. Do you consent?"
- [ ] If "No" â†’ auto-call termination + flag as "Did not consent"

**GDPR Data Retention:**
- Call recordings: Delete after 12 months (GDPR Article 5)
- Contact data: Retain as long as investor relationship active + 1 year after last interaction
- Deal records: Archive after 2 years (Instant Investment signed â†’ Series A â†’ exit)

---

### Step 2: FCA Compliance (No Advice Disclosure)

**In all emails:**
```
âš ï¸  IMPORTANT: Unlock provides investment intelligence platforms, 
not financial advice. Any introduction is for informational purposes 
only. You should not make any investment decision based on this 
communication without consulting a qualified financial advisor.

Capital at risk. No FSMA authorization. Past performance does not 
guarantee future results.
```

**In all Aircall calls:**
- [ ] Script includes: "This is an introduction, not advice. You should consult your advisor."
- [ ] Agent repeats before demo booking: "Capital at risk, no advice givenâ€”understood?"

---

### Step 3: EIS/SEIS Compliance

**Post-Instant Investment workflow:**
- [ ] Custom field: "EIS/SEIS Submission Status" (Not Started / Pending / Submitted / Approved)
- [ ] Task created: "EIS submission deadline: [DATE]"
- [ ] Investor receives: "EIS/SEIS Process" guide + tax relief calculator
- [ ] Accounting team follows up 2 weeks pre-deadline

---

## Part F: Testing & Quality Assurance

### Pre-Launch Checklist (48 hours before first call)

**Aircall Testing:**
- [ ] Make test call: Tom calls Agent 2, confirm call logs to Pipedrive
- [ ] Check: Call recording auto-uploads, metadata captured
- [ ] Check: Screen pop displays investor record on agent screen
- [ ] Check: Agent can select disposition code + see confirmation

**Pipedrive Testing:**
- [ ] Manually create test deal in Stage 1
- [ ] Trigger Workflow 1: Call recorded + auto-logs
- [ ] Trigger Workflow 2: Change Call Outcome to "Demo Booked" â†’ confirm email sent
- [ ] Trigger Workflow 3: Change Demo Feedback to 80 â†’ confirm Pack 1 sent
- [ ] Trigger Workflow 4: Change Pack 1 Response to "Interested" â†’ confirm Pack 2 sent

**Email Templates Testing:**
- [ ] Send test email for each template
- [ ] Verify: All [VARIABLES] populate correctly
- [ ] Verify: Links work (Zoom links, PDF attachments)
- [ ] Verify: Gmail/Outlook/Apple Mail rendering OK

**Database Testing:**
- [ ] Import 10 test records to Pipedrive
- [ ] Verify: Tier + Persona fields populated
- [ ] Verify: Deals created in Stage 1
- [ ] Verify: Deals assigned to correct agents

**Agent Training:**
- [ ] Tom completes 3 mock calls, records feedback
- [ ] Agent 2 completes 3 mock calls, records feedback
- [ ] Agent 3 completes 3 mock calls, records feedback
- [ ] All agents certify: "I understand the 16-step script and can execute it"

---

## Part G: Daily Operations Checklist

### Agent Daily Prep (Before 9 AM)

- [ ] Log into Aircall
- [ ] Log into Pipedrive
- [ ] Review today's calling list (Aircall Campaign Manager)
- [ ] Check for callbacks from yesterday (Pipedrive "Call Back Later" tasks)
- [ ] Verify: 16-step script visible (Aircall sidebar notes)
- [ ] Confirm: Email templates loaded (for Pack 1 sending)
- [ ] Test: 1 outbound call to self (verify recording, Pipedrive logging)

### Team Daily Standup (5:00 PM)

- [ ] **Tom:** Review day's calls, asks per agent (Tom leads)
- [ ] **Share wins:** "Agent 2 booked 5 demos todayâ€”what worked?"
- [ ] **Identify challenges:** "Demo booking rate at 22% today vs 25% targetâ€”why?"
- [ ] **Adjust next day:** "Agent 3 try adding [reframe] to Step 7 conversation"
- [ ] **Check dashboard:** Update Pipedrive campaign dashboard
- [ ] **Time:** 10 min max

### Weekly Metrics Review (Monday 9 AM)

- [ ] Pull Pipedrive report: Calls / Demos / Pack 1s / Pack 2s / Instant Investments
- [ ] Compare vs. targets (see Part 3: Weekly Targets)
- [ ] Identify red flags (demo booking <22%, Pack 1â†’2 <35%, etc.)
- [ ] Listen to 2â€“3 agent calls (quality check + coaching opportunity)
- [ ] Update agent leaderboard (celebrate top performer)

---

## Part H: Troubleshooting Guide

### "Aircall calls not appearing in Pipedrive"

1. Verify webhook enabled: Aircall Admin â†’ Integrations â†’ Pipedrive â†’ Connected âœ“
2. Check phone number format: Must be E.164 (+44 XXXX XXXX)
3. Verify deal creation rule: Settings â†’ Automation â†’ Workflows â†’ Check trigger
4. Test: Make 1 test call, verify Pipedrive deal created within 5 min
5. If still failing: Check API logs (Aircall Admin â†’ API Logs), contact support

---

### "Screen pop not displaying during call"

1. Verify setting enabled: Aircall Admin â†’ Phone Settings â†’ Screen Pop âœ“
2. Check match rule: Screen Pop set to match on "phone number" (not extension)
3. Verify contact phone exists in Pipedrive (exact match to call)
4. Clear browser cache, reload Aircall
5. If still failing: Upgrade Aircall plan (Screen Pop requires Professional+ tier)

---

### "Email template variables not populating"

1. Check variable syntax: Use [FirstName] not [first_name] or {{FirstName}}
2. Verify field exists in Pipedrive: Settings â†’ Customize Fields â†’ check field name
3. Verify field linked to email template: Template settings â†’ map fields
4. Send test email to yourself first (catches issues before investor sees)
5. If still failing: Switch to manual email (Tom types personalized message)

---

### "Workflow not triggering when conditions met"

1. Verify trigger condition exact: If workflow requires "Demo Feedback Score â‰¥ 70", confirm score is exactly 70+ (not 69)
2. Check: Are there multiple workflows with same trigger? (First one wins)
3. Verify: Deal has all required fields populated (workflow won't fire if missing)
4. Manual test: Manually change field to trigger value, confirm workflow fires
5. If still failing: Delete workflow, recreate it step-by-step

---

### "Agent can't see 16-step script during call"

1. Verify script loaded: Aircall â†’ Campaign Settings â†’ Agent Notes â†’ Paste 16-step script
2. Check: Is agent viewing Pipedrive deal card during call? (Script often there)
3. Alternative: Print 16-step script, tape to desk next to monitor
4. Use Aircall mobile app? (Scripts don't display well on phone)
5. Solution: Keep script on second monitor or printed page

---

## Appendix: Quick Reference Links

### Pipedrive Resources
- Integrations: app.pipedrive.com/admin/integrations
- Custom Fields: app.pipedrive.com/admin/customfields
- Workflows: app.pipedrive.com/admin/workflows
- Reports: app.pipedrive.com/reports
- Contacts: app.pipedrive.com/contacts

### Aircall Resources
- Admin Panel: aircall.io/app/admin
- Integrations: aircall.io/app/admin/integrations
- Campaign Manager: aircall.io/app/campaigns
- Call Recording: aircall.io/app/admin/recording
- Documentation: support.aircall.io

### Import Templates
- CSV import: [See Part D, Step 1]
- Workflow templates: [See Part A, Step 3]
- Email templates: [See Part C]

---

**This setup is ready to execute. All configurations are standard Pipedrive + Aircall features (no custom code required).**

**Total setup time: 4â€“6 hours (Pipedrive) + 2â€“3 hours (Aircall) + 1 hour (testing) = ~8 hours pre-launch.**

**Next action: Tom to schedule Pipedrive setup session with CRM admin (if you have one) or Aircall support. Otherwise, 1â€“2 day self-serve setup.**

---

**End of Setup Guide**


---

<!-- END OF DOCUMENT -->

## Marketing & Investor Conversion Strategy
*Internal — Full marketing strategy. Never share with investors.*

---

> **V4 NOTE — INTERNAL USE ONLY:** Updated March 2026. All investment instrument references use "Instant Investment". Discount tier percentages removed from this document per V4 rules (never publish specific tiers). Q1 2026 dates updated to Q1 2027.

# Unlock: Marketing & Investor Conversion Strategy Brief

**Strategic Consolidation for Document & Campaign Development**

---

## Executive Overview

Unlock is positioning itself as the independent, investor-first alternative to fragmented wealth management and product-driven platforms. This brief consolidates your 14+ investor documents into a coherent marketing and conversion framework, with specific guidance on document sequencing, messaging, and investor journey mapping.

**Core Mission**: Give private investors the same clarity, tools, and protections that institutions take for granted.

---

## Part 1: Investor Audience Architecture

### Three Core Investor Personas (Behavioral)

These are NOT generic risk bucketsâ€”they're research-backed archetypes derived from actual investor behavior, portfolios, and goals.

**1. The Preserver**
- *Motivation*: Protect wealth and minimize downside
- *Behaviors*: Low-volatility portfolios, capital protection focus, seeks validation for advisor recommendations
- *Pain Points*: Fragmented tools, poor downside modeling, conflicted advice
- *Platform Use*: Tests defensive strategies, confirms risk controls
- *Belief Shift Required*: Understands fragmentation is a big problem â†’ trusts Unlock as independent safeguard

**2. The Growth Seeker**
- *Motivation*: Long-term wealth growth with calculated risk
- *Behaviors*: Seeks high-growth opportunities, wants risk-managed entry, values portfolio simulation
- *Pain Points*: Lack of transparency in deals, retail-focused tools, dilution in crowdfunding
- *Platform Use*: Compares upside vs downside, explores syndicate opportunities
- *Belief Shift Required*: Recognizes Unlock's differentiation â†’ believes platform scales to deliver long-term value

**3. The Legacy Builder**
- *Motivation*: Plan intergenerational wealth transfers and tax efficiency
- *Behaviors*: Estate planning focus, balances growth with inheritance tax efficiency, models family scenarios
- *Pain Points*: Complexity of tax planning, lack of clarity in family wealth scenarios
- *Platform Use*: Models EIS/SEIS tax advantages, explores intergenerational structures
- *Belief Shift Required*: Accepts timing matters for wealth structuring â†’ trusts Unlock for analysis + tax tools

**Important**: Unlock has mapped 19 detailed personas across wealth tiers, risk profiles, investment approaches, and domain biases (property, tech, alts). These three archetypes are the public-facing frame; the 19 personas power product personalization and roadmap decisions.

### Investor Ticket Sizes & Readiness Levels

**Founding Investor Round (Current)**
- Target: Â£20Kâ€“Â£500K tickets
- Profile: Strategic HNW investors (Â£500Kâ€“Â£5M investable assets)
- Readiness: Active in EIS/SEIS, network-oriented, customer-development aligned
- Discount: Up to 50% (tiered by ticket size)
- Benefits: Lifetime premium access, white-glove service, priority deal flow, roadmap influence

**Growth Capital Round (Q2 2026)**
- Target: Â£50Kâ€“Â£500K tickets
- Profile: Growth-focused investors comfortable with scaling risk
- Readiness: FinTech/AI/RegTech experience, capable of customer acquisition support
- Discount: 10â€“20% (limited early-bird offers)
- Benefits: 2-year complimentary access, quarterly updates, syndication access

**Series A (Q1 2027)**
- Target: Â£250Kâ€“Â£2M tickets
- Profile: Institutional investors, board-ready
- Discount: None (priced round)
- Benefits: Board participation, strategic guidance, exit planning

---

## Part 2: The Marketing Funnel & Belief Stages

### Investor Journey Map: 4 Stages

**Stage 1: AWARENESS**
*Goal*: Generate initial interest and qualify fit
*Key Belief*: "There IS a big problem in wealth planning"

*Marketing Channel Examples*:
- Curated HNW networks (proprietary databases)
- PR/earned media (FT, City A.M., MoneyWeek)
- Thought leadership content (Substack, white papers)
- Targeted LinkedIn outreach
- Founder-hosted investor dinners

*Messaging Focus*:
- Problem statement: fragmentation, complexity, conflicted incentives
- Vision: levelling the playing field
- Proof: customer traction (2,500 free users, Â£172K run rate, founding investor commitments)

*Documents to Share*:
- Executive Summary (1 page)
- Investment Pitch (3â€“4 pages, presentation-ready)

---

**Stage 2: ENGAGEMENT**
*Goal*: Qualify interest and build credibility
*Key Belief*: "Unlock offers a credible, differentiated solution"

*Activities*:
- Personalized demo sessions (live or recorded)
- Custom portfolio modelling (white-glove onboarding trial)
- One-on-one founder conversations
- Investor workshop participation (co-creation feedback)
- Competitive landscape positioning

*Messaging Focus*:
- Institutional-grade tools + investor simplicity
- Independent, investor-led design (NOT product distribution)
- Customer-validated traction (alpha MVP, founding investor commitments)
- Team credibility and execution track record

*Documents to Share*:
- Full Business Plan (with financials)
- Competitive Analysis (positioning vs crowdfunding, robo-advisors, private banks)
- Marketing Strategy (network-driven growth funnel)
- Customer Development Profiles (investor personas + belief shifts)
- Value Proposition Canvas (pain/gain fit)
- Gap Fill Addendum (team bios, governance model, unit economics, feature set)
- App Walkthrough Script (product narrative + capabilities demo)

---

**Stage 3: DECISION**
*Goal*: Support commitment decision
*Key Belief*: "The strategy is investor-led. The team can execute. Returns justify the risk."

*Activities*:
- Detailed financial review (projections, unit economics, break-even)
- Legal/tax consultation prep (EIS/SEIS worked examples)
- Allocation planning (ticket size, discount tier, relief calculation)
- Soft commitment + allocation reservation
- Risk disclosure deep dive

*Messaging Focus*:
- Financial transparency: Â£6.5M valuation benchmarked against SaaS peers
- Sensitivity analysis: base (7.7x), upside (15x+), downside (3â€“5x)
- EIS/SEIS mechanics: 30â€“50% relief, inheritance tax benefits, HMRC timelines
- Scarcity: 25 founding slots (3 closed, 2 committed, 20 available)
- Urgency: EIS submission window timing, pre-launch benefits expire Q1 2027

*Documents to Share*:
- Investor Information Memorandum / Pack 2 (20â€“30 pages + appendices)
  - Full investment terms & Instant Investment mechanics
  - Valuation framework + sensitivity scenarios
  - Financial projections (2026â€“2029)
  - Go-to-market & growth strategy (full)
  - Exit strategy (named acquirers, IPO milestones, timeline)
  - Appendices: business plan, valuation paper, tax landscape, risk factors

---

**Stage 4: COMMITMENT & ONBOARDING**
*Goal*: Formalize investment and activate founding investor status
*Key Belief*: "I'm part of shaping the future of UK investing"

*Activities*:
- Instant Investment agreement execution (via SeedLegals)
- EIS/SEIS submission process
- Investor onboarding kit (platform access setup)
- Founding investor perks activation (white-glove service, concierge, roadmap access)
- Quarterly reporting cadence

*Messaging Focus*:
- Lifetime membership benefits locked in
- Direct founder/product team access
- Syndicate priority allocation
- Investor network events
- Product roadmap influence opportunities

*Documents to Share*:
- Instant Investment Terms (with worked examples)
- Investor Onboarding Kit (EIS/SEIS guidance, tax relief tracker)
- Founding Investor Pack (reassurance + benefit activation)
- Investor Reporting Templates (syndicate updates, dashboard access)

---

## Part 3: Document Architecture & Sequencing

### **Pack 1: Founding Investor Pack (Entry-Level, Persuasion-First)**

**Purpose**: Excite, persuade, establish exclusivity  
**Tone**: Emotional, benefits-led, accessible  
**Length**: 8â€“10 pages

**Contents**:
1. Welcome & Context (vision, emotional positioning)
2. Deal Basics (Headline: Â£6.5M pre-money, up to 50% discount)
3. EIS/SEIS Benefits (30â€“50% relief, 4-week HMRC payout, no worked examples)
4. Early Investor Perks (lifetime access, white-glove service, priority deal flow, events)
5. Investor Personas (Preserver, Growth Seeker, Legacy Builder + "19 mapped personas" mention)
6. Go-To-Market (Timeline visual: 2026 â†’ free launch, 2027 â†’ paid, 2028+ â†’ international)
7. Exit Strategy Headline (M&A, IPO, PE; 5â€“10x returns in 3â€“5 years)
8. Scarcity & Urgency (25 slots, pre-launch benefits, EIS submission window)
9. Appendices (Light): FAQ, high-level risk disclaimer

**Key Cross-References**: "Full details in the attached Investor Information Memorandum"

---

### **Pack 2: Investor Information Memorandum (Deep Dive, Due Diligence)**

**Purpose**: Full transparency; satisfy financial, legal, technical scrutiny  
**Tone**: Factual, precise, disclosure-first  
**Length**: 20â€“30 pages + appendices

**Contents**:
1. Welcome & Purpose (sets expectation: technical breakdown)
2. Investment Terms & Structure (Full)
   - Instant Investment mechanics (conversion, dilution, non-dilutive structure)
   - Legal framework (SeedLegals, FCA-aligned)
   - Discount: Negotiated individually (never published in documents)
   - EIS/SEIS process: quarterly vs >Â£20K immediate, loss relief, inheritance tax
   - Cross-reference: "Headline benefits in Pack 1; full process + examples here"

3. Valuation & Returns Framework
   - Market comparables (SaaS seed valuations Â£5â€“8M; Unlock @ Â£6.5M)
   - Sensitivity scenarios (base/upside/downside with exit multiples)
   - Cap table illustrations
   - ROI worked examples (£50k, £250k, £500k tickets at founding investor discount)
   - Cross-reference: "Headline valuation in Pack 1; detailed benchmarking here"

4. Financial Projections (Full)
   - 2026â€“2029 revenues, user growth, CAC/LTV, margins
   - Break-even analysis
   - Churn assumptions + unit economics detail

5. Go-To-Market & Growth Strategy (Full)
   - Acquisition channels (database, OneAI, media partnerships)
   - Sales funnel (cold call â†’ demo â†’ portfolio report â†’ close)
   - International rollout detail (Australia, Canada, US)

6. Exit Strategy (Full)
   - Named acquirers (Bloomberg, Morningstar, Refinitiv, Crowdcube, S&P Global)
   - IPO milestones (Â£20M+ ARR, 10k+ subscribers)
   - PE buyout pathway
   - Timeline milestones (Yr2: Â£20â€“30M valuation; Yr3: Â£50â€“70M; Yr4â€“5: Â£100M+)

7. Appendices (Full Transparency)
   - Business plan (full)
   - Valuation paper
   - Exit strategy (detailed)
   - UK tax-advantaged investment landscape
   - Investor personas & suitability mapping
   - Risk factors (market, regulatory, operational)
   - Full Instant Investment template
   - Competitive benchmarking

8. Closing Statement (scarcity, urgency, call to action)

---

### **Supporting Documents (Distribution by Stage)**

**Stage 1 (Awareness)**:
- Executive Summary
- Investment Pitch

**Stage 2 (Engagement)**:
- Business Plan (full narrative + financials)
- Competitive Analysis
- Marketing Strategy
- Customer Development Profiles
- Value Proposition Canvas
- Gap Fill Addendum (team, governance, unit economics)
- App Walkthrough Script

**Stage 3 (Decision)**:
- Pack 2: Investor Information Memorandum
- Financial Model & Projections (detailed)
- Growth Capital Pack (bridging narrative)

**Stage 4 (Commitment)**:
- Instant Investment Terms (from Pack 2)
- Investor Onboarding Kit
- Investor Reporting Templates

---

## Part 4: Key Messaging Pillars

### Problem Statement (Differentiator)
**"Private investors face three persistent challenges:"**

1. **Fragmented data** â€” across providers, advisors, manual systems
2. **Inaccessible complexity** â€” professional-grade analysis locked behind institutional paywalls
3. **Conflicted incentives** â€” platforms optimize for product sales, not investor outcomes

*Impact*: Most investors rely on spreadsheets, Google, and gut instinct while institutions have models, dashboards, teams.

---

### Solution Narrative (Value Proposition)
**"Unlock combines institutional-grade tools with investor-led simplicity"**

- **Portfolio Simulator** â€” stress-test and optimize portfolios with personalized "what-if" scenarios
- **Investor Personas** â€” Preserver, Growth Seeker, Legacy Builder archetypes guide strategy
- **Syndicates** â€” access vetted collective opportunities on transparent, fair terms (8â€“10% vs 9â€“14% market norm)
- **Tax Intelligence** â€” EIS/SEIS optimization + CGT deferral + inheritance tax planning
- **Independent Analytics** â€” institutional insights, not product distribution

---

### Why Now (Market Timing)
1. **Technology shift**: AI enables investor-grade simulations at consumer cost
2. **Market gap**: No independent investor-first platform at this level exists
3. **Policy tailwinds**: UK EIS/SEIS incentives make early-stage investing highly attractive
4. **Customer demand**: Alpha MVP attracting serious investor feedback and commitments

---

### Business Model & Scale (Financial Proof)
- **Revenue streams**: Premium subscriptions + syndicate transaction fees (8â€“10%) + strategic partnerships
- **2026**: Â£460K (beta testing, early syndicates)
- **2027**: Â£2.6M (public launch, scale)
- **2028**: Â£5M (strong growth trajectory)
- **2029**: Â£8.25â€“9.25M (mature ARR, syndicate expansion)

**Unit Economics**:
- CAC (paid user): ~Â£200
- LTV (paid user): Â£3,000â€“3,250
- LTV:CAC ratio: 15:1 (highly efficient)
- SaaS gross margin: ~80%
- Break-even achievable with modest HNW market penetration

---

### Exit & Returns (Investor Motivation)
- **5â€“10x returns expected within 3â€“5 years**
- **Strategic M&A**: Bloomberg, Morningstar, Refinitiv, Crowdcube (strategic fit for fintech/wealth managers)
- **IPO pathway**: Viable at Â£20M+ ARR + 10k+ subscribers
- **Timeline**: Year 2 (Â£20â€“30M valuation), Year 3 (Â£50â€“70M), Year 4â€“5 (Â£100M+, exit readiness)

**Illustrative ROI**:
- Â£500k invested at founding investor discount (illustrative):
  - ~Â£9.96M return at Â£50M exit (19.9x ROI)
  - ~Â£19.9M return at Â£100M exit (39.8x ROI)
  - ~Â£3.98M return at Â£20M exit (7.9x ROI)
  - *(All before SEIS/SEIS relief, which improves effective ROI further)*

---

## Part 5: The Dual-Pack Distribution Strategy

### Distribution Logic

**Pack 1 (Founding Investor Pack)** is the "lead magnet" designed to:
- Hook with emotional, benefits-led messaging
- Establish scarcity and urgency
- Create FOMO around founding investor status
- Transition warm leads to Stage 2 (engagement)

**Pack 2 (Investor Information Memorandum)** is the "trust builder" designed to:
- Provide full financial, legal, and technical transparency
- Answer due diligence questions comprehensively
- Address investor skepticism through detailed benchmarking and sensitivity analysis
- Enable informed decision-making for Stage 3 (decision) investors

### Key De-Duplication Rules

Where content must overlap (valuation, EIS, exit), **shift the depth and framing**:

**Valuation Example**:
- Pack 1: "£6.5M pre-money valuation. Founding investor discount negotiated individually."
- Pack 2: "Â£6.5M pre-money valuation benchmarked against SaaS comparables (Â£5â€“8M range); sensitivity analysis Â£4â€“10M; illustrative ROI models for different ticket sizes and exit scenarios"

**EIS Example**:
- Pack 1: "30â€“50% income tax relief, HMRC payout in ~4 weeks, inheritance tax benefits"
- Pack 2: "EIS/SEIS process explained: quarterly submission for most investors, immediate submission for >Â£20K commitments; loss relief cushions downside; inheritance tax exemption after 2 years; worked examples + tax relief calculator"

**Exit Example**:
- Pack 1: "Multiple exit pathways (M&A, IPO, PE); 5â€“10x returns within 3â€“5 years"
- Pack 2: "Named strategic acquirers (Bloomberg, Morningstar, Refinitiv, Crowdcube); IPO pathway at Â£20M+ ARR; detailed timeline: Yr2 (Â£20â€“30M), Yr3 (Â£50â€“70M), Yr4â€“5 (Â£100M+)"

---

## Part 6: Campaign Calendar & Channel Strategy

### Core Acquisition Channels

**1. Proprietary HNW Database (25,000+ investor profiles)**
- Direct outreach via cold call/email â†’ personalized portfolio demo
- Segmentation by persona type (Preserver, Growth Seeker, Legacy Builder)
- Calendar: Ongoing during founding round

**2. AI-Powered Qualification (OneAI)**
- Automated lead scoring and fit assessment
- Speeds qualification from awareness â†’ engagement
- Reduces sales friction for Stage 2 transition

**3. Content Marketing & Thought Leadership**
- White papers on wealth fragmentation and EIS/SEIS optimization
- Substack newsletter (investor intelligence, tax updates, market commentary)
- Case studies (founding investor testimonials, portfolio outcomes)
- SEO: Blog on alternative investing, portfolio simulation, tax relief

**4. Media & PR Partnerships**
- FT, City A.M., MoneyWeek (editor outreach, guest articles)
- Investor podcast appearances
- Earned media around funding announcements

**5. Founder-Hosted Investor Events**
- Small, curated investor dinners (8â€“12 people)
- Hands-on platform demos + investor feedback loops
- Network-building (founder-to-founder, investor-to-investor referrals)
- Focus: Preserver and Growth Seeker personas

**6. Syndicate-Driven Referrals (Network Effects)**
- Founding investors introduce peers into opportunities
- Tiered referral benefits incentivize word-of-mouth
- Community-building around co-investment opportunities

### Campaign Rhythm

**Q4 2025** (Founding Investor Round - Active):
- Send Pack 1 â†’ warm leads (curated database)
- Demo â†’ personalized portfolio report
- Follow-up â†’ Pack 2 to qualified prospects
- Close â†’ Instant Investment execution + EIS submission

**Q1 2026** (Transition to Growth Capital):
- Lessons learned from Founding round
- Pack 1 refinement based on investor feedback
- Begin Growth Capital round positioning (new pack framework)

**Q2 2026+** (Growth Capital Round):
- Proven traction narrative (user milestones, revenue run rate)
- Institutional investor outreach
- Series A preparation underway

---

## Part 7: Success Metrics & KPIs

### Stage 1: Awareness
- **Outreach volume**: 500+ prospects contacted per month
- **Open rate**: Pack 1 email open rate target 35%+
- **Demo booking rate**: 15% of opened emails â†’ demo scheduled

### Stage 2: Engagement
- **Demo-to-Pack 2 conversion**: 40%+ of demo attendees request Pack 2
- **Engagement depth**: Time spent on platform demos, Q&A volume, persona quiz completion
- **Belief shift validation**: Investor feedback on problem statement and differentiation

### Stage 3: Decision
- **Pack 2 â†’ allocation target**: 30%+ of Pack 2 recipients move to decision stage
- **Average ticket size**: Â£75Kâ€“Â£150K (80% in Â£50â€“250K band)
- **Discount distribution**: Track average discount negotiated per investor (internal only)
- **EIS/SEIS uptake**: % of investors pursuing tax relief vs. standard allocation

### Stage 4: Commitment
- **Founding round close rate**: Target 20 investors across 25 slots (80% fill)
- **Total capital raised**: Â£1.2M target (Â£675K minimum to proceed)
- **Time-to-close**: Average days from first Pack 1 to Instant Investment execution
- **Repeat referrals**: Percentage of founding investors bringing peer recommendations

### Long-Term (Post-Founding Round)
- **Founding investor satisfaction**: NPS score, product usage, syndicate participation
- **Advocacy velocity**: Founding investor referrals as % of new leads
- **Platform traction**: User milestones (2.5K free â†’ 28K free by 2026; 375 paid â†’ 3.6K paid by 2027)
- **Revenue runway**: ARR trajectory vs. projections (2026: Â£460K target)

---

## Part 8: Risk Mitigation & Investor Concerns

### Common Objections & Responses

**"How is Unlock different from Crowdcube/Seedrs?"**
- Unlock = private investor platform + professional analytics
- Crowdcube = retail crowdfunding (high dilution, low tax efficiency)
- Response: Show fee comparison table (8â€“10% vs 9â€“14%) and EIS/SEIS integration

**"What's the market size and adoption curve?"**
- Global wealth management = $100T+ AUM
- Target: HNW investors with Â£1Mâ€“Â£10M portfolios
- Acquisition proof: 2.5K free users in alpha; projected 28K by 2026
- Response: Share customer development profiles + go-to-market channels

**"What if adoption is slower than forecast?"**
- Sensitivity analysis in Pack 2: base case (7.7x), downside (3â€“5x)
- Break-even achievable with modest HNW penetration
- Response: Show conservative scenario with reassurance on path to profitability

**"Why should I trust the founding team?"**
- Tom King: 12+ years in investor-introduction tech, Â£250M+ capital facilitated
- Werner Snyman: 19 years digital transformation at Nedbank
- William Corke: Multi-million-pound growth projects for F500 + compliance expertise
- Claudia Chavez: Commercial strategy in fintech partnerships
- Response: Share Gap Fill Addendum + founder track record

**"What about regulatory risk (FCA, EIS)?"**
- William Corke leading compliance + EIS/SEIS structuring
- Quarterly EIS submissions managed + HMRC certificates tracked
- Legal framework (SeedLegals, FCA-aligned documentation)
- Response: Highlight compliance expertise in team bios + risk factor disclosure

---

## Part 9: Content Calendar (Quarterly)

### Q4 2025 (Founding Investor Push)
- **Week 1â€“2**: Pack 1 outreach to top 200 prospects (warm introduction emails)
- **Week 3â€“4**: Demo sessions + personalized portfolio reports
- **Week 5â€“8**: Pack 2 distribution to qualified leads + legal/tax consultation prep
- **Week 9â€“12**: Instant Investment closings + EIS submissions + investor onboarding
- **Content**: Founder blog on "The Case for Independent Investing"; Case study on alpha MVP traction

### Q1 2026 (Growth Capital Preparation)
- **Content**: "Founding Investor Success Stories" (testimonials + portfolio outcomes)
- **Event**: Founder investor dinner (Q4 attendees + new referrals)
- **Refinement**: Pack 1 v2 based on Stage 2 feedback; begin Growth Capital pack framework
- **Outreach**: Institutional investor qualification (VCs, family offices, growth funds)

### Q2 2026 (Growth Capital Round Launch)
- **Pack Development**: Growth Capital Pack 1 & 2 (proven traction narrative)
- **Messaging**: "We hit our milestonesâ€”here's what comes next"
- **Content**: Deep dive on user acquisition strategy, syndicate framework, international prep
- **Events**: Investor webinar + one-on-one partnerships meetings

### Q3â€“Q4 2026 (Pre-Series A Positioning)
- **Content**: Thought leadership on market gaps and competitive advantages
- **Partnerships**: Media co-marketing (FT, City A.M., MoneyWeek features)
- **Outreach**: Series A investor identification + warm introductions
- **Roadmap**: Product milestones + team expansion highlights

---

## Part 10: Key Takeaways & Next Steps

### For Marketing & Messaging:
1. **Lead with problem, not product** â€” fragmentation + conflicted incentives resonate across all personas
2. **Use personas to segment messaging** â€” Preserver emphasizes protection; Growth Seeker emphasizes opportunity; Legacy Builder emphasizes tax efficiency
3. **De-duplicate packs intentionally** â€” Pack 1 is persuasion, Pack 2 is precision. Different depth, different framing, no confusion
4. **Leverage community & network** â€” founding investors become evangelists; syndicate mechanics drive referrals
5. **Build urgency around SCARCITY** â€” 25 slots, EIS submission window, pre-launch benefits expiration

### For Investor Conversion:
1. **Stage 1 â†’ 2 transition**: Pack 1 â†’ warm demo â†’ personalized portfolio report
2. **Stage 2 â†’ 3 transition**: Engagement depth (product usage, founder access, belief validation) â†’ Pack 2 distribution
3. **Stage 3 â†’ 4 transition**: Financial clarity (valuation, EIS, exit scenarios) â†’ soft commitment â†’ Instant Investment execution
4. **Stage 4 activation**: White-glove onboarding + founding investor perks + quarterly updates

### For Document Development:
1. **Pack 1 finalization**: 8â€“10 pages, benefits-first, cross-reference to Pack 2 for detail
2. **Pack 2 finalization**: 20â€“30 pages + appendices, full transparency, disclosure-first, worked examples
3. **Supporting docs**: Keep modular (business plan, competitive analysis, personas, team bios) for Stage 2 deep dives
4. **Quality standard**: Professional design, consistent branding, hyperlinked cross-references

### Immediate Actions:
- [ ] Finalize Pack 1 (Founding Investor Pack) â€” 8â€“10 pages, benefits-led
- [ ] Finalize Pack 2 (Investor Information Memorandum) â€” 20â€“30 pages, full disclosure
- [ ] Create email templates for each stage (awareness, engagement, decision, commitment)
- [ ] Build outreach database segmentation (by persona, ticket size, industry)
- [ ] Schedule founder demos and investor dinners (Q4 2025)
- [ ] Establish KPI dashboard to track stage-by-stage conversion
- [ ] Set up quarterly reporting cadence for founding investors (post-close)

---

## Appendix: Document Status & File References

| Document | Stage | Status | Owner | Notes |
|----------|-------|--------|-------|-------|
| Pack 1: Founding Investor Pack | 1â€“2 | Draft | Marketing | 8â€“10 pages, benefits-led |
| Pack 2: Investor Information Memorandum | 2â€“3 | Draft | Finance/Legal | 20â€“30 pages + appendices |
| Executive Summary | 1 | Complete | Marketing | 1 page, presentation-ready |
| Investment Pitch | 1 | Complete | Marketing | 3â€“4 pages |
| Business Plan (Full) | 2 | Complete | Strategy | Narrative + financials |
| Competitive Analysis | 2 | Complete | Strategy | Positioning + benchmarking |
| Marketing Strategy | 2 | Complete | Marketing | Network-driven growth |
| Customer Development Profiles | 2 | Complete | Product | Three personas + belief shifts |
| Value Proposition Canvas | 2 | Complete | Product | Pain/gain fit framework |
| Gap Fill Addendum | 2 | Complete | Strategy | Team bios, governance, unit economics |
| App Walkthrough Script | 2 | Complete | Product | Product demo narrative |
| Financial Model & Projections | 3 | Complete | Finance | 2026â€“2029 projections |
| Growth Capital Pack | 3 | Template | Finance | For Q2 2026 round |
| Instant Investment Terms | 4 | Template | Legal | Via SeedLegals |
| Investor Onboarding Kit | 4 | Template | Operations | EIS/SEIS guidance + setup |
| Investor Reporting Templates | 4 | Template | Operations | Quarterly updates + dashboards |

---

**End of Brief**

*This consolidation is designed to be a working document for your marketing, sales, and investor relations teams. Use it to guide document development, campaign planning, and investor communications across all four stages of the funding journey.*


---

<!-- END OF DOCUMENT -->

## Email Templates — All Pipeline Stages
*Internal — Email templates for every funnel stage*

---

================================================================================
UNLOCK: EMAIL TEMPLATES FOR INVESTOR OUTREACH
Version 2 — Updated March 2026 | V4 Content Bank aligned
================================================================================

Use these templates for Stage 1 (Awareness) outreach. Personalize with investor name, 
relevant details, and your contact info.

================================================================================
TEMPLATE 1: WARM INTRODUCTION EMAIL (First Contact)
================================================================================

Subject: Quick intro – could be interesting for you

Hi [Investor Name],

[OPTIONAL OPENER: mutual connection or context]
I got your name from [mutual contact / event] and thought you might find this interesting.

We've just opened a founding investor round for Unlock—a platform that gives private 
investors institutional-grade portfolio tools without the institutional price tag.

It's aimed at experienced investors like you who manage meaningful portfolios and 
want clearer visibility into diversification, risk, and tax efficiency.

The founding round offer: equity discount, lifetime platform access, and anti-dilution protection until Series A. We're limiting it to approximately 25 founding investors by design — not artificial scarcity, quality of fit.

Worth a brief 20-minute call to see if it fits? 

I've attached a one-page overview — four minutes to read. If it resonates, happy to arrange a short call.

Best,
[Your Name]
[Your Title]
[Contact Info]

---

================================================================================
TEMPLATE 2: INTRO + PACK 1 ATTACHED (Initial Outreach with Document)
================================================================================

Subject: Institutional tools for private investors

Hi [Investor Name],

I'm reaching out because you strike me as someone who probably manages a diversified 
portfolio and cares about clarity and tax efficiency.

We're building Unlock—a platform that solves three persistent problems for serious 
private investors:
• Fragmented data across multiple accounts and advisors
• Complex portfolio analysis locked behind institutional paywalls
• Tax planning that actually makes sense

I've attached a one-page overview — four minutes to read. If it lands, I can send the full founding investor brief and we can arrange a call.

If it resonates, I'd love to hop on a 20-minute call to walk you through how it works 
and answer any questions.

Best,
[Your Name]
[Your Title]
[Contact Info]

---

================================================================================
TEMPLATE 3: FOLLOW-UP (After Initial Email, No Response)
================================================================================

Subject: Re: Quick intro – could be interesting for you

Hi [Investor Name],

Probably landed in the spam folder—happens all the time. 

Quick context: we're running a limited founding investor round for Unlock 
(independent wealth intelligence platform). Definitely not for everyone, but 
figured you might find it useful given your background in [their area of expertise].

One paragraph: it gives private investors institutional-grade portfolio tools 
(stress-testing, tax optimization, early-stage deal access) without the cost.

If you want to see how it works, 20-minute call over the next week?

Best,
[Your Name]

---

================================================================================
TEMPLATE 4: PACK 1 FOLLOW-UP (After Sending Pack 1, Scheduling Call)
================================================================================

Subject: Thoughts on Unlock?

Hi [Investor Name],

Did you get a chance to glance at the pack? No pressure if you're swamped.

If any of it caught your eye, let's grab 20 minutes this week so I can walk you 
through how it actually works. Happy to do a demo or just answer questions.

We’re working through the round now — April 6 is a hard date (shares issue that day, and it’s the last date for unlimited EIS Inheritance Tax relief before a rule change).—we have 20 available now, down from 25.

Best,
[Your Name]
[Your Title]

---

================================================================================
TEMPLATE 5: DISCOVERY CALL CONFIRMATION (After Booking)
================================================================================

Subject: Confirmed – Unlock demo call [DATE] at [TIME]

Hi [Investor Name],

Confirmed for [DAY, DATE] at [TIME] [TIMEZONE].

I'll send you a Zoom/Teams link 30 minutes before. You can join from any device, 
but laptop/iPad works best so you can see the platform clearly.

Plan: 20 minutes walking through:
1. How the portfolio simulator works (real example with your profile)
2. Tax planning features (EIS/SEIS optimization)
3. How the founding investor program works

No prep needed. Just bring any questions about your portfolio or investment approach.

See you then,
[Your Name]

---

================================================================================
TEMPLATE 6: POST-DEMO FOLLOW-UP (After Discovery Call)
================================================================================

Subject: Great call today – next steps

Hi [Investor Name],

Enjoyed our conversation. A few things we covered:
• Your portfolio is well-diversified, but there's blind spot in [specific area]
• EIS/SEIS relief could save you £[X] per year
• You'd be a strong fit for our Growth Seeker persona

Next steps:
1. I'm sending you a customized portfolio report (attached) showing exactly how 
   Unlock would analyze your holdings
2. If that lands well, let's do a 30-minute session with you, me, and potentially 
   your adviser to walk through the full picture
3. If you're interested in moving forward, we'd do a soft allocation (non-binding) and then move to Instant Investment execution via SeedLegals

Timing matters on two counts: shares issue 6 April 2026 (the deadline for unlimited EIS IHT relief), and founding benefits expire at public launch (Q1 2027). If you want to move, sooner is better.

Any questions, just holler.

Best,
[Your Name]

---

================================================================================
TEMPLATE 7: SOFT COMMITMENT FOLLOW-UP (Moving to Decision Stage)
================================================================================

Subject: Ready to commit? Here's how it works

Hi [Investor Name],

Following up on our chat. Sounds like you're interested in moving forward.

Here's the process from here:

1. Soft Commitment (this week)
   - You decide on ticket size (£20K–£500K) and confirm which discount tier applies
   - We reserve your slot
   - Non-binding at this stage

2. Deep Dive with Your Adviser (optional, next 1–2 weeks)
   - We walk your accountant through EIS/SEIS mechanics, Instant Investment structure, and tax implications
   - Answer all due diligence questions
   - Give you full confidence you understand the structure

3. Instant Investment Execution (following week)
   - Agreement processed via SeedLegals (digital, straightforward)
   - You sign, capital transferred
   - EIS compliance processed at point of investment — not after round close

Total time: 2–3 weeks from commitment to execution.

Ticket size range: £20K–£500K. Discount is negotiated individually — we discuss this on the call.

What range are you thinking?

Best,
[Your Name]

---

================================================================================
TEMPLATE 8: CLOSING PUSH (Last Chance/Scarcity Message)
================================================================================

Subject: Last few founding slots available

Hi [Investor Name],

Just wanted to flag: we're down to the last few founding investor slots before we 
close the round.

3 closed, 2 committed, 5 available now (was 25 total).

Key dates:
- Founding benefits lock in with Instant Investment execution
- Shares issue 6 April 2026 — the last date for unlimited EIS Inheritance Tax relief before rule change
- Valuation steps up 20–30% in Growth Capital round (Q2 2026)
- Lifetime perks never offered again after Q1 2027 launch

If you want to move forward, we'd need soft commitment by [DATE] to make the 
HMRC timeline.

Happy to hop on a quick call to answer any last-minute questions.

Best,
[Your Name]

---

================================================================================
KEY PRINCIPLES FOR ALL EMAILS
================================================================================

1. Keep it SHORT (3–4 paragraphs max, 50–100 words each)
   - Nobody reads long emails. Busy investors scan them in 10 seconds.

2. Lead with THEIR pain, not your features
   - "You probably manage a diversified portfolio" (relatable)
   - Not "We've built an institutional-grade portfolio simulator" (feature-focused)

3. Use their language
   - From Pack 1 training guide: "institutional-grade clarity," "independent, investor-first," 
     "20 pence on the pound," "founding investor" (not "early investor")
   - Match their tone (if they're formal, be formal; if casual, be casual)

4. Create micro-urgency without being pushy
   - "We're down to 20 available slots" (scarcity)
   - "Shares issue 6 April 2026 — last date for unlimited EIS IHT relief" (genuine urgency)
   - Not: "You better decide now or miss out forever"

5. Always include a clear call-to-action
   - Not: "Let me know if you're interested"
   - Do: "Let's grab 20 minutes this week—are you available Tuesday or Thursday?"

6. Personalize (even if just one detail)
   - "Given your background in fintech" or "I know you've been exploring alternatives"
   - Generic templates get 5% response; personalized get 30%+

7. Use consistent terminology (V4 rules — see Content Bank Section 19)
   - "Founding investor" (not "early investor" or "seed investor" or "angel investor")
   - "EIS/SEIS relief" (not just "tax relief")
   - "Institutional-grade clarity" (not "professional tools")
   - "Instant Investment" (not "ASA", "Advanced Subscription Agreement", or "SAFE")
   - Never publish discount tier percentages in any document

---

================================================================================
SEQUENCE RECOMMENDATION FOR COLD OUTREACH
================================================================================

Week 1:
- Mon–Tue: Send Template 1 or 2 (initial outreach, cold list A)
- Thu: Send Template 1 or 2 to cold list B (different segment)

Week 2:
- Mon: Template 3 follow-up to Week 1 non-responders
- Tue–Wed: Schedule discovery calls for interested parties (Template 5)

Week 3:
- Conduct discovery calls
- Send Template 6 (post-demo follow-up) to call attendees

Week 4:
- Template 7 (soft commitment) to qualified prospects
- Template 8 (closing push) to fence-sitters

---

================================================================================
CONVERSION TARGETS (WEEKLY TRACKING)
================================================================================

Email Sent â†’ Pack 1 Request: 40% (if Template 1/2 is engaging, this is realistic)
Pack 1 Requested â†’ Demo Booked: 60% (packs should drive action)
Demo Attended â†’ Soft Commitment: 30–40% (based on fit and discovery quality)
Soft Commitment â†’ Instant Investment signed: 80%+ (by this stage, deal's mostly closed)

Track these weekly in a spreadsheet:
- Date sent | Recipient | Email template | Status | Next step | Outcome

Example:
11/11 | Jane Smith | Template 2 | Opened | Follow-up | Demo booked 11/14
11/12 | John Doe | Template 1 | No open | Follow-up | N/A

================================================================================


---

<!-- END OF DOCUMENT -->

# AGENT TOOLS

## Cold Call Script
*Agent — 9-section script with qualification gates*

---

+-----------------------------------------------------------------------+
| **UNLOCK**                                                            |
|                                                                       |
| **Cold Call Script --- Founding Investor Programme**                  |
|                                                                       |
| *For use with known HNW prospects. Tom King. Confidential.*           |
+-----------------------------------------------------------------------+

**Quick reference**

  ----------------------- -----------------------------------------------
  **EIS income tax        30% --- can wipe entire annual bill if sized
  relief**                correctly

  **SEIS income tax       50% --- for smaller earlier-stage companies
  relief**                

  **CGT on exit**         Exempt after 3-year minimum hold

  **IHT relief (until 6   100% unlimited --- capped at £2.5M from 6 April
  Apr 2026)**             2026

  **UK unicorns backed by 46.5% of all active UK unicorns (Beauhurst,
  EIS**                   2024)

  **Portfolio return      Up to 7x on well-constructed, diversified
  (curated)**             portfolio

  **Typical prospect      £500K+ investable assets, annual tax bill \>
  profile**               £30K

  **Call objective**      Qualify fit → send one-pager → book 30-min
                          video call
  ----------------------- -----------------------------------------------

  -----------------------------------------------------------------------
  **01 Opening**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  \[Name\] --- this is Tom King from Unlock. The reason I'm calling you
  in particular --- we work with high-net-worth individuals who have
  significant income tax and capital gains liabilities, and I've been
  looking at people who I think would genuinely benefit from what we do.
  Do you have sixty seconds?

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Wait for the yes before continuing. Don't barrel through.
  The pause does work.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **02 The Hook --- EIS Introduction**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  We specialise in EIS --- the Enterprise Investment Scheme --- which is
  approved and run by HMRC. In plain terms: EIS allows people who know
  how to use it to invest in a way that can wipe out their entire income
  tax bill for the year. If your tax bill is 00a350,000 and you invest
  00a3100,000 into SEIS, HMRC hands back 00a350,000 --- that\'s 50%
  straight off your tax bill. Your tax bill for that year is zero. You've
  heard of Revolut and Monzo? Both were initially funded through the
  scheme. In fact, nearly half of every active UK unicorn --- companies
  valued over £1 billion --- benefitted from EIS-backed funding. On a
  well-constructed, diversified portfolio, the average return has been up
  to 7x. Profits are tax-free. There's a structural reason why not
  everyone gets access to quality EIS opportunities --- which I can
  explain to you. But before I do --- I just want to confirm something.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Pause after 'confirm something'. Let them lean in. Don't
  rush the next line.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **03 The Confirmation Question**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  Because as far as I can tell, \[Name\], you're someone who isn't
  currently using your annual EIS allowance. Is that right?

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Either answer works. If YES --- they're not using it,
  proceed. If NO --- they are using it, find out who they're using and
  what their experience has been. That's still a productive
  conversation.*

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If YES →**   Perfect. Continue to Section 04.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If NO →**    "Really --- tell me about that. Who are you working
                 with?" Then listen. Position around quality of deal flow
                 and portfolio intelligence vs. whatever they're
                 currently doing.

  -------------- --------------------------------------------------------

  -----------------------------------------------------------------------
  **04 Normalise the Gap**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  999 times out of 1,000 --- the reason a successful person isn't using
  EIS is one of two things: either they haven't heard of it properly, or
  they don't fully understand it. And neither do they know anyone who
  does. The interesting thing is --- the more you earn, the more tax you
  pay, and the more tax you pay, the more you can deploy via EIS. So it
  gets more advantageous the larger your tax bill. But honestly, it
  doesn't matter where you start. Used correctly, EIS is one of the few
  legitimate ways to substantially reduce your tax bill while building a
  high-growth asset at the same time.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *This section does two things: removes embarrassment (it's
  normal not to know) and amplifies relevance (the bigger their tax bill,
  the more they need this). Don't rush it.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **05 What Unlock Does Differently**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  What we do that's different from anyone else in this space --- we don't
  just give you access to EIS deal flow. We give you the portfolio
  intelligence alongside it. So you can see exactly how each investment
  interacts with your overall tax position, your estate, your existing
  holdings. You're not investing blind --- you're investing with a
  complete picture of what it means for your specific situation. Most
  people who come to us have never had that. Not from their IFA, not from
  their accountant, not from anyone.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *This is the Unlock differentiator. It separates Tom from any
  other EIS introducer. Keep it concise --- one short paragraph, then
  move to qualification.*

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **06 Qualification --- Three Gates**

  -----------------------------------------------------------------------

**Gate 1: Tax bill vs investable assets**

  -----------------------------------------------------------------------
  Before I suggest we take this any further --- a couple of quick
  questions to make sure it actually makes sense for you. Do you have
  significant income tax or capital gains liabilities each year? I
  typically work with people who have between £5M and £20M in liquid
  assets --- but in truth the number that matters most isn't your total
  wealth. It's the ratio of your annual tax bill to what you can
  comfortably invest. If your tax bill is £50,000 and you can access
  £100,000 --- that's worth our time. It means EIS can work hard for you
  immediately.

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If yes →**   Good. Continue to Gate 2.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If no / not  "That's useful to know. It might still be worth a
  sure →**       conversation --- can I ask roughly what your situation
                 looks like?"

  -------------- --------------------------------------------------------

**Gate 2: Self-directed element**

  -----------------------------------------------------------------------
  The other thing I'd want to understand --- do you manage any of your
  own money directly? It doesn't need to be everything. A lot of the
  people I work with use an IFA or wealth manager for pensions, ISAs,
  their share portfolio. But alongside that, they make their own
  investment decisions. The reason I ask is practical: advisers who
  charge a percentage of assets under management have a structural reason
  not to recommend strategies that reduce those assets --- it's not
  personal, it's how they're paid. EIS reduces the pool they manage. So
  it very rarely comes from that channel. Is that something that
  describes you --- you make at least some of your own financial
  decisions?

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If yes →**   Good. Continue to Gate 3.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If no →**    "Understood --- is there an area where you do make your
                 own calls? Or is everything managed?" If everything is
                 fully managed with no self-directed element, this
                 prospect isn't the right fit right now.

  -------------- --------------------------------------------------------

**Gate 3: Time and inclination**

  -----------------------------------------------------------------------
  And the last thing --- this isn't something you can assess in five
  minutes. To do it properly, you'd need to look at some information,
  have a meaningful conversation, and make a considered decision. Do you
  have the time and inclination to look at something properly if it
  stacks up for you?

  -----------------------------------------------------------------------

  -------------- --------------------------------------------------------
  **If yes →**   All three gates passed. Move to Section 07 --- the
                 close.

  -------------- --------------------------------------------------------

  -------------- --------------------------------------------------------
  **If hesitant  "Completely understand --- what would work better for
  →**            you in terms of timing?"

  -------------- --------------------------------------------------------

  -----------------------------------------------------------------------
  **07 The Close --- Low-Friction Next Step**

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  In that case --- here's what I'd suggest. I'll send you something short
  --- takes about four minutes to read. It explains what Unlock does, how
  the EIS structure works, and what founding investors in our current
  round are getting. If it resonates, we book a 30-minute call and I'll
  walk you through it properly. What's the best email address to send
  that to?

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Do not jump straight to a 40-minute video call. The
  one-pager is the bridge. Get the email, send the doc, book the call as
  a second step. Lower friction converts better with this audience.*

  -----------------------------------------------------------------------

**If they want more before giving the email:**

  -----------------------------------------------------------------------
  Of course. The short version: we're raising a founding round at a £6.5M
  valuation. We're limiting it to around 25 investors --- not for
  scarcity, but because the people we work with need to be genuinely
  engaged. It's EIS eligible, so depending on your tax position, the
  effective entry cost is significantly lower than the face value. Shares
  issue on 6 April 2026 --- which also happens to be the last date to
  qualify for unlimited EIS Inheritance Tax relief before a rule change
  caps it. After that date, the relief is capped at £2.5M per estate.
  So there's a real reason to look at it now rather than later.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **08 Objection Handling**

  -----------------------------------------------------------------------

+-----------------------------------------------------------------------+
| **Objection: "I already invest in EIS."**                             |
|                                                                       |
| That's great --- most of my best conversations are with people who    |
| already understand the scheme. What I'd be curious about is whether   |
| you're getting the portfolio intelligence alongside it --- being able |
| to see exactly how each holding interacts with your tax picture.      |
| That's the piece that's usually missing. Worth a quick conversation?  |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "I'm not interested in investing in startups."**         |
|                                                                       |
| Completely fair --- the investment risk is real and it's not for      |
| everyone. The question I'd ask is whether the tax relief changes the  |
| calculation for you. If you can wipe a £50,000 tax bill and put the   |
| money into a diversified portfolio of 10 companies, your effective    |
| exposure on the downside is much lower than it looks. But if the risk |
| profile still doesn't work for you, I completely understand.          |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "Send me something and I'll have a look."**              |
|                                                                       |
| Of course --- what's the best email? \[Get email.\] And just so I     |
| know when to follow up --- are you someone who tends to look at       |
| things quickly, or would a week be more realistic? \[Agree a          |
| follow-up date before hanging up.\]                                   |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "How did you get my number?"**                           |
|                                                                       |
| We work from a curated list of investors who we believe would benefit |
| from what we do --- your name came up through \[network / research /  |
| referral\]. I apologise if the timing is inconvenient. Would it be    |
| better if I called at a different time?                               |
+-----------------------------------------------------------------------+

+-----------------------------------------------------------------------+
| **Objection: "I'm happy with my current advisers."**                  |
|                                                                       |
| That's good to hear. This isn't really an adviser conversation though |
| --- EIS is something you do directly, alongside whatever else you     |
| have in place. It doesn't replace your existing arrangements, it sits |
| outside them. Is there a reason you'd want to keep this kind of       |
| decision within the advisory relationship?                            |
+-----------------------------------------------------------------------+

  -----------------------------------------------------------------------
  **09 After the Call**

  -----------------------------------------------------------------------

**Within 2 hours of hanging up:**

  -----------------------------------------------------------------------
  Send the one-page founding investor document with a personal two-line
  note: "Great to speak, \[Name\]. As promised --- four minutes,
  everything you need to know. If it makes sense, reply and we'll find a
  time." Do not send Pack 1 or Pack 2 at this stage. The one-pager is the
  filter. If they engage with that, Pack 1 follows. Pack 2 only when
  they're seriously considering committing.

  -----------------------------------------------------------------------

  -----------------------------------------------------------------------
  **Note:** *Document sequence: One-pager → Pack 1 (Founding Investor
  Brief) → Pack 2 (IIM). Each step qualifies for the next. Never skip
  ahead.*

  -----------------------------------------------------------------------

**Follow-up timing:**

  --------------- -------------------------------------------------------
  **Same day**    Send one-pager with personal note

  **Day 3--4**    Brief follow-up: "Just checking this landed --- happy
                  to answer any questions."

  **Day 7**       If no response: "I'll leave this with you --- the April
                  6 date is worth being aware of. Reply whenever suits."

  **Day 14**      Final touch if warm: reference a specific detail from
                  the call
  --------------- -------------------------------------------------------

*For internal use only. This script is a guide, not a regulated
financial promotion. All investment conversations must be conducted in
accordance with applicable FCA rules. EIS tax relief figures are
illustrative; individual outcomes depend on personal tax position and
HMRC approval. Capital is at risk. Tom King, Unlock Services Limited.*


---

<!-- END OF DOCUMENT -->

## Agent Training Playbook
*Agent — 2-hour training programme*

---

> **V4 NOTE:** Updated March 2026. All investment instrument references use "Instant Investment". Pricing updated to current tiers (£99/£249). Campaign dates updated.

# Unlock Agent Training Script & Daily Operations
## Ready-to-Use Agent Playbook

---

## Part 1: Agent Training (2 Hours)

### Module 1: Company Overview (30 min)

**What is Unlock?**

"Unlock is an investment intelligence platform for private investors like HNW individuals. Think of it as a portfolio OS—it gives investors:
- Full portfolio visibility (across multiple providers + accounts)
- AI-powered scenario simulation (what-if analysis)
- Syndicate access (vetted deals at transparent fees)
- Tax efficiency tools (EIS/SEIS optimization + inheritance planning)

Why now?
- Technology: AI makes institutional-grade analysis affordable
- Market gap: No independent investor-first tool like this exists
- Policy: UK's EIS/SEIS tax incentives make early-stage investing attractive
- Traction: 2,500 alpha users, £172K run rate, multiple founder commitments

Our mission: Give private investors the same clarity, tools, and protections that institutions take for granted.

**Key stat to remember:** "Investors using Unlock are seeing 10–20% uplift in portfolio performance annually because fragmentation was costing them money."

---

### Module 2: Three Investor Personas (20 min)

**The Preserver** (30% of HNW investors)
- Motivation: Protect wealth, minimize downside, sleep at night
- Language: "capital protection," "risk controls," "validation," "peace of mind"
- Pain points: Fragmented tools, poor downside modeling, conflicted advice
- How Unlock helps: Portfolio stress-test + scenario modeling = confidence in risk controls
- Example: "A 55-year-old retired executive worried about property market crash—Unlock models 'what if property falls 30%?' and shows portfolio resilience."

**The Growth Seeker** (40% of HNW investors)
- Motivation: Long-term wealth growth with calculated risk
- Language: "upside," "opportunity," "transparency," "syndicates," "deal flow"
- Pain points: Lack of transparency in deals, retail tools, crowdfunding dilution
- How Unlock helps: Syndicate access at 8–10% (vs 9–14% competitors) + portfolio simulation
- Example: "A 45-year-old entrepreneur wants to deploy £500K in growth opportunities—Unlock shows which asset classes to add and gives access to curated syndicates."

**The Legacy Builder** (30% of HNW investors)
- Motivation: Plan intergenerational wealth transfer, tax efficiency
- Language: "inheritance," "tax efficiency," "family," "succession," "legacy"
- Pain points: Complex tax planning, unclear family wealth scenarios
- How Unlock helps: EIS/SEIS integration + family wealth modeling + inheritance tax planning
- Example: "A 60-year-old business owner exiting—Unlock optimizes tax relief timing across multiple investments to reduce inheritance tax by 15–20%."

**Key script phrase:** "Most investors I speak with fit one of three profiles: Preservers who want peace of mind, Growth Seekers hunting for transparency in deal flow, or Legacy Builders optimizing for family outcomes. Which of those resonates most with you?"

---

### Module 3: EIS/SEIS Tax Relief (20 min) - THE MOST IMPORTANT PART

**What is EIS?**
- Government tax-advantaged investment scheme
- Invest in high-growth UK companies
- Claim **30% income tax relief** (spend £100K, claim £30K back from tax bill)
- Profits **free of Capital Gains Tax** (vs 20% normal CGT)
- Loss relief: If company fails, claim relief on net loss after income tax relief (at 45% rate on SEIS net cost = significant additional recovery)
- **Inheritance tax exempt** after 2 years

**What is SEIS?**
- Similar to EIS but for **earlier-stage** companies
- Higher relief: **50% income tax relief** (spend £100K, claim £50K back)
- Same CGT + loss relief + inheritance tax benefits
- Limited to £100K per person per year

**The key phrase agents MUST use:**
"In short, investors can claim back 30–50% of their investment, profits can be tax-free, and loss relief reduces downside further — for higher-rate or additional-rate taxpayers using SEIS, effective exposure can be as low as 20 pence on the pound."

**Worked example (memorize this):**
- Investor has £10K income tax bill
- Invests £50K in SEIS stock (gets 50% relief)
- Claims £25K tax relief
- Now owes £0 income tax (overpaid £15K to HMRC, refunded in 4 weeks)
- Effective investment cost: £50K – £25K = £25K (only 20p on the pound)
- If stock doubles: £100K profit, zero CGT owed
- If stock fails: Claim £40K loss relief against income, recover £12K tax

**Why this matters to investors:**
"Most investors don't realize their tax bill is a tool. Using EIS/SEIS, you can literally use your tax liability to fund growth investments with built-in downside protection."

---

### Module 4: The 16-Step Script Walkthrough (40 min)

**Read through all 16 steps aloud. Agents should memorize the flow, not word-for-word script.**

**STEPS 1–5: QUALIFICATION & CREDIBILITY**

**Step 1: Greeting & Context (30 sec)**
- Goal: Verify you have the right person
- Script: "Hi [Name], it's [Agent] calling from Unlock UK. I still have you down as [email]—is that still the right one?"
- Why: Confirms contact details + establishes professionalism
- If wrong number: "Sorry, wrong number. Have a good day." / Log in Pipedrive: "Wrong number"
- Listen for: Engagement tone (friendly = proceed, irritated = shorten call)

**Step 2: Introduce EIS/SEIS (60 sec)**
- Goal: Hook with tax relief benefit
- Script: "We focus on companies that qualify for EIS or SEIS—government schemes that let investors use their income tax to buy shares in high-growth UK companies. In short, investors can claim back 30–50% of their investment, profits can be tax-free, and loss relief reduces downside further — for higher-rate or additional-rate taxpayers using SEIS, effective exposure can be as low as 20 pence on the pound."
- Why: EIS/SEIS is the most compelling differentiator (no competitor offers this advantage)
- Listen for: Interest in tax benefit, or skepticism ("sounds too good to be true")
- If skepticism: "I know it sounds generous—it's been UK policy for 20 years to encourage investment in early-stage companies. Real companies like Revolut, BrewDog, Monzo all qualified."

**Step 3: Confirm Awareness & Risk Comfort (60 sec)**
- Goal: Build credibility with brand examples
- Script: "You've probably heard of Revolut, BrewDog, or Monzo—a few years back you could've literally used your tax bill to buy shares in those. The investor only risks about 20 pence on the pound after reliefs, and profits can be tax-free."
- Then ask: "That's the kind of risk-to-reward most investors would love—how do you feel about it?"
- Why: Social proof (big names) + risk framing (only 20p at risk)
- Listen for: "Sounds interesting" (move forward) vs "Too risky" (pivot to Preserver angle)

**Step 4: Common Starting Point (60 sec)**
- Goal: Anchor their experience in mainstream assets
- Script: "Most experienced investors I speak with started in the same place—ISAs, some stocks, maybe a property or two. All great when the economy's steady."
- Then ask: "How does your portfolio compare to that?"
- Why: Makes investor feel normal + opens door to pain discovery
- Listen for: Asset mix (ISAs, property, stocks, pensions) â†’ use this to personalize later steps
- If they say "My portfolio is more complex": "Perfect—sounds like you're already thinking beyond mainstream assets. That's why I'm calling."

**Step 5: Correlation & Inflation (60 sec)**
- Goal: Surface fragmentation pain
- Script: "Most people's investments are correlated. Even pensions. If there's a crash, those without proper diversification are going to be worst affected. Are you open to exploring how diversification can help you preserve your wealth during a downturn?"
- Then ask: "If markets and property prices crashed 30%—how well are you protected?"
- Why: Creates urgency + positions Unlock as solution
- Listen for: "I hadn't thought about that" (good, you're opening eyes) or "My advisor covers this" (acknowledge, then pivot to independence angle)

---

**STEPS 6–9: PAIN & SOLUTION**

**Step 6: Over-Concentration Reality (60 sec)**
- Goal: Validate their pain
- Script: "Here's what we see a lot: most investors end up heavily concentrated in the same asset classes—property, pensions, ISAs—all moving in the same direction. When interest rates shift or property markets wobble, their entire wealth picture is actually quite correlated."
- Then ask: "Can you relate to that?"
- Why: Frames problem as common + non-judgmental
- Listen for: "Yes, actually" (pain validated) or "No, I'm well-diversified" (different approach—pivot to opportunity angle)

**Step 7: Early-Stage Parallel & Unlock Intro (90 sec)** â­ CRITICAL STEP
- Goal: Introduce Unlock as solution
- Script: "Paradoxically, the same applies to early-stage companies—exciting, high-growth startups are rare, and you can't get formal advice on them. High Street banks and IFAs are restricted—they can't give advice on startups, gold, art, wine, anything other than mainstream financial products. That's where Unlock steps in—vetted early-stage opportunities plus the data and tools to manage them properly."
- Then ask: "How might visibility about a wider range of investment opportunities and investment strategies be useful to you?"
- Why: Explains WHY Unlock exists + positions as independent alternative to gatekeepers
- Listen for: "That would be useful" (moving toward engagement) or "I don't want startup risk" (Preserver angle—pivot to portfolio optimization)
- **If they push back on risk:** "I totally understand. Unlock isn't forcing you into anything. It's your platform to understand ALL your investments—whether you ever use syndicates or not. Think of it as your investment OS."

**Step 8: Identify Main Frustration (60 sec)**
- Goal: Surface specific pain
- Script: "Most investors hit a few walls: too many opportunities to evaluate, lack of visibility into their full portfolio, or complicated tax situations."
- Then ask: "Which if any do you relate to most?"
- Why: Narrows pain to one specific issue â†’ personalize later messaging
- Listen for: 
  - "Too many opportunities" â†’ Growth Seeker persona
  - "Lack of visibility" â†’ Preserver persona
  - "Tax complexity" â†’ Legacy Builder persona
- **Make a mental note of which frustration they mention—you'll reference it in Step 9.**

**Step 9: Unlock's Solution (90 sec)**
- Goal: Connect their specific pain to Unlock features
- Script: "That's exactly why Unlock exists—it gives you a full portfolio view, runs scenario simulations, and identifies hidden risks and opportunities across everything you hold—including EIS/SEIS. You don't even have to use the tool—you get all this in a monthly report personalised to your interests, goals, risk profile and experience. Knowledge is power in investing, and it's especially true when that knowledge is tailored to your situation."
- Then ask: "Can you see the benefits in having something like that?"
- Why: Directly addresses their pain + benefits-focused
- **Key personalization:**
  - If Growth Seeker: "...identifies hidden opportunities and deal flow you'd otherwise miss..."
  - If Preserver: "...identifies hidden risks in your portfolio so you can sleep at night..."
  - If Legacy Builder: "...optimizes your tax positioning across all your holdings..."
- Listen for: "Yes, that would be valuable" (strong buy signal) or "Maybe, butâ€¦" (objection incoming, prepare reframe)

---

**STEPS 10–14: CREDIBILITY & QUALIFICATION**

**Step 10: Market Uncertainty (60 sec)**
- Goal: Frame macro shift (creates openness to new ideas)
- Script: "We're at an interesting point—things that used to feel safe, like pensions, are now less predictable with rules changing constantly."
- Then ask: "Have you noticed that too in how returns or rules keep changing?"
- Why: Macro context + validation of need for new solutions
- Listen for: "Yeah, pensions are a mess" or "I'm not worried about that" (different positioning needed)

**Step 11: Independent Investor Type (60 sec)**
- Goal: Confirm they're independent-minded (not advisor-dependent)
- Script: "That's why many are looking beyond traditional products and starting to think more for themselves."
- Then ask: "Would you describe yourself as someone who prefers to make independent investment decisions?"
- Why: Filters for self-directed investors (Unlock's ideal customer)
- Listen for: "Yes, I do my own research" (perfect) or "I rely on my advisor" (acknowledge—offer advisor integration angle)
- **If advisor-dependent:** "That's great—Unlock isn't replacing your advisor. It's your intelligence layer so you can bring better data to those conversations."

**Step 12: Unlock Differentiation & Social Proof (90 sec)** â­ CREDIBILITY BOOST
- Goal: Establish credibility + differentiation
- Script: "Unlock isn't a fund or adviser—it's an independent intelligence platform built by investors, for investors. We're currently in early access, onboarding a limited number of private investors. Investors using the platform are seeing an average increase in overall performance and wealth of around 10–20% per year. One of our recent investors spent 20 years on the board of Barclays, worked with the Bank of England—he described Unlock as better than anything he'd seen in terms of supporting private investors."
- Then ask: "Would you be interested in reviewing the platform while it's still in early access?"
- Why: Social proof (Barclays reference) + scarcity (limited access) + performance benefit
- **Key stats to memorize:**
  - "Independent intelligence platform"
  - "Early access" (creates exclusivity)
  - "10–20% uplift" (concrete benefit)
  - "Barclays board member" (credible reference)
- Listen for: "That sounds interesting" (buy signal â†’ move to qualification) or "I want to think about it" (not ready yet, get voicemail, follow up Week 2)

**Step 13: Suitability & Eligibility (60 sec)**
- Goal: Confirm fit before booking demo
- Script: "Before I book that in, I just need to make sure it's relevant. Unlock is typically suited to UK taxpayers who can benefit from 30–50% relief and are comfortable holding for 3–5 years."
- Then ask: "Does that sound like something that would apply to you?"
- Why: Filter for actual EIS/SEIS eligibility (compliance + conversion rate)
- Listen for: "Yes, I'm UK taxpayer" (proceed) or "I'm non-resident" (polite exit—not eligible)
- **If not eligible:** "Got it—Unlock is EIS/SEIS focused, so it wouldn't be the right fit. But thanks for your time, and I'd be happy to connect you with [partner platform] that focuses on [their situation]."

**Step 14: Segment & Decision Process (60 sec)**
- Goal: Identify investor type for persona-specific messaging
- Script: "Which of these best describes you—still working (growth-focused), nearing retirement (preservation and planning), or retired/post-exit (tax and efficiency)?"
- Listen for: Their answer â†’ this determines demo personalization
- Why: You'll know their persona BEFORE the demo, so demo can be perfectly tailored
- Mental note:
  - "Still working" = likely Growth Seeker
  - "Nearing retirement" = likely Preserver
  - "Retired/post-exit" = likely Legacy Builder
- Use this to inform demo script (Part 5, Demo Execution)

---

**STEPS 15–16: DEMO BOOKING & COMMITMENT**

**Step 15: Book Demo (Setup & Time) (60 sec)**
- Goal: Confirm interest + logistical fit
- Script: "It sounds like you'd get value from seeing how Unlock works. It can be a phone call, but to get the most from it, it's better to join a video call so the screen can be shared and you get a proper walkthrough of the platform. It's about 20 minutes. Most people join from a laptop or iPad."
- Then ask: "Will you have access to a screen, and what time window suits you best?"
- Why: Set clear expectations + ensure technical readiness
- Listen for: 
  - "Yes, I can do video—[time window]" (strong commitment) â†’ proceed to Step 16
  - "Can't do video" â†’ offer phone call option (less ideal but proceed)
  - "I'm not sure" (hesitation) â†’ reframe: "It's just 20 minutes—would Thursday afternoon work?"
- **Device readiness:** If investor says "I'll call from my phone," gently suggest: "Laptop is better for screen-sharing—you'll get much more out of it. Happy to work around your schedule though."

**Step 16: Commitment & Compliance (60 sec)**
- Goal: Lock in demo + deliver legal disclaimer
- Script: "Aside from an emergency, is there any reason that day or time might not work? Great—I'll send the confirmation and a one-pager so you know what to expect. Capital at risk; no advice—it's simply an introduction so you can decide for yourself."
- Then ask: "Can I confirm that time for you now?"
- Why: Firm commitment + legal protection (documented no-advice position)
- Listen for: "Yes, confirmed" (success—log in Pipedrive as "Demo Booked") or "Actually, I'm not sure" (objection—handle with reframe)
- **What to do next:**
  1. Log call in Aircall (duration, disposition)
  2. Aircall auto-triggers Pipedrive Workflow 2
  3. Investor receives email within 1 hour: "Demo Confirmed – Next Steps"
  4. You mark in Pipedrive: Call Outcome = "Demo Booked" + Demo Scheduled Date = [DATE]
  5. Workflow sends automated confirmation email + calendar invite

---

### Module 5: Objection Handling (30 min)

**Seven common objections + reframes:**

| Objection | Root Cause | Reframe | Next Action |
|---|---|---|---|
| "I'm not interested in early-stage investments" | Misunderstands Unlock's role | "Unlock isn't forcing you into anything. It's your intelligence layer for ALL your investments—whether you ever use syndicates or not. Tax optimization alone saves most investors £8–15K per year." | Pivot to portfolio view |
| "I don't have time for a demo" | Real or stalling | "I get it—you're busy. Here's the thing: a 20-minute demo saves you 5+ hours on portfolio management annually. That's a good trade. What's your best time—morning or afternoon?" | Pin down specific time |
| "My IFA handles this" | Advisor gatekeeping | "Perfect—your IFA is likely great at what they do. Unlock isn't advice; it's YOUR data layer. Your IFA will actually love the analysis you bring them. Would you like to include them in the demo?" | Offer advisor angle |
| "How do I know this isn't a scam?" | Legitimate concern (esp. older investors) | "Fair question. We're registered at [Companies House link], backed by [founder credentials—Barclays board member], and onboarded [specific social proof]. You can verify everything. And it's just a 20-minute intro—zero commitment or payment today." | Provide verifiable proof |
| "What's the catch? Why is it cheap?" | Trust issue | "We make money on syndicate transaction fees (8–10%) and future subscriptions, not on a product margin. That means our incentive is your success, not selling you something. Aligned interests." | Explain business model |
| "I'm happy with my current setup" | Status quo bias | "I hear that from most investors. Then they see their portfolio is fragmented across 4–5 providers, missing £50–100K in annual tax optimization. It's worth 20 minutes to confirm you're actually optimized." | Use concrete example |
| "I'll think about it and call you back" | Fear of commitment | "Totally fair—I'd do the same. But let's grab 20 minutes first to see if it's even worth your time. If it's not relevant, we're done. If it is, you'll want to explore further anyway. Deal?" | Pin down callback date |

**Agent rule:** When objection raised, **acknowledge it, reframe it, then ask a closing question:**

```
Investor: "I'm not interested in early-stage investments."

Agent: "I totally understand—that's actually the most common concern I hear. 
[REFRAME:] Here's the thing though: Unlock isn't about forcing you into startups. 
It's YOUR portfolio intelligence layer. You're probably already diversified across 
property, ISAs, pensions, maybe some alternative assets. Unlock just helps you 
see all of it in one place, stress-test against scenarios, and optimize your taxes.
[CLOSING QUESTION:] Does that make more sense?"
```

**If investor still resistant:** 
- Offer voicemail fallback: "No problem at all. I'll leave you a voicemail with our details. If you change your mind, you have my number."
- Mark in Pipedrive: Call Outcome = "Not Interested" + follow up in 3 months (change in circumstances may occur)

---

## Part 2: Daily Operations Checklist

### Pre-Call Preparation (15 min before first call)

**Agent does this at 8:45 AM:**

- [ ] **Log into Aircall** — test phone line (make outbound call to self)
- [ ] **Log into Pipedrive** — open Investor dashboard
- [ ] **Open calling campaign** in Aircall: (e.g., "Tier 2 Blitz – Campaign 2")
- [ ] **Print 16-step script** — tape near monitor (backup if sidebar doesn't work)
- [ ] **Print objection handling sheet** (see Part 1, Module 5)
- [ ] **Have a glass of water** (hydration = clearer voice)
- [ ] **Set daily target** (e.g., "30 calls today = 7–8 demos booked at 25% rate")
- [ ] **Confirm email template access** — check that Pack 1 template loads in Pipedrive

**If anything isn't working:** Slack Tom: "Aircall screen pop not loading—can you test on your end?" (Resolve before dialing)

---

### Call Execution (Throughout day)

**During each call:**

1. **Aircall screen displays investor record** (name, tier, persona, notes)
2. **16-step script visible** in Aircall sidebar or printed nearby
3. **Agent follows 16 steps** — doesn't skip any
4. **Aircall auto-records** call
5. **At call end:** Agent selects **disposition code** (Demo Booked / Not Interested / etc.)
   - If "Demo Booked": Aircall prompts for date/time â†’ auto-logs to Pipedrive
6. **Aircall auto-uploads call to Pipedrive** (recording + metadata)

---

### Post-Call Logging (2 min per call)

**Immediately after call ends:**

- [ ] **Aircall call log complete** — recording uploaded, duration captured
- [ ] **Pipedrive deal moved to correct stage** (Workflow auto-triggers)
- [ ] **Any notes added** to investor record (persona refined, specific pain mentioned, objection handle used)
- [ ] **Next action set** (if callback needed, schedule task: "Follow-up call – [Date]")

**Example Pipedrive note:**
```
Called [Name] re: portfolio diversification interest. Very growth-focused 
(likely Growth Seeker). Main pain: "Too many opportunities, don't know which 
to prioritize." Used Step 7 reframe + syndicate angle. Booked demo for 
[DATE] at [TIME]. High interest signal (90).
```

---

### End-of-Day Wrap-Up (5 min at 5:05 PM)

**Agent fills out before leaving:**

- [ ] **Total calls made:** __ (target: 30/day)
- [ ] **Demos booked:** __ (target: 7–8, or 25% conversion)
- [ ] **Demo booking rate:** __% (calculate: Demos Ã· Calls Ã— 100)
- [ ] **Top performer note:** (e.g., "Used objection reframe 3x—high conversion")
- [ ] **Challenge identified:** (e.g., "Tier 2 investors asking more questions—Step 9 needs clarification")
- [ ] **Tomorrow's focus:** (e.g., "Slow down Step 7; investors confused about EIS process")

**Slack summary to Tom:**
```
End-of-day (Agent Name):
â”œâ”€ Calls: 32
â”œâ”€ Demos booked: 8
â”œâ”€ Booking rate: 25%
â”œâ”€ Win: [Persona type] responded well to [specific reframe]
â””â”€ Flag: [Challenge identified for coaching]
```

---

### Weekly Performance Review (Monday 9 AM)

**Tom leads 10-min standup with all agents:**

1. **Review metrics from Pipedrive dashboard**
   - Calls per agent (cumulative week)
   - Demo booking rate by agent
   - Pack 1 send rate
   - Instant Investment closes (if applicable)

2. **Celebrate top performer** ("Agent 2 hit 28% booking rate—what worked for you?")

3. **Identify coaching opportunity** ("Agent 3 at 20% booking rate—let's listen to 2 calls and refine")

4. **Refine messaging** ("Multiple investors asked about risk—let's strengthen Step 3 language")

5. **Adjust next week** ("Tier 1 calls slowing; let's increase Tier 2 volume 15%")

**Example standup:**
```
Tom: "Last week we dialed 450 calls, booked 105 demos, and sent 28 Pack 1s. 
That's 23% demo booking rate vs 25% target—we're close. Agent 2 led at 25%, 
Agent 3 at 20%. Let's listen to one of Agent 3's calls and identify where 
we're losing people. And we got 2 Pack 2 sends—great momentum. This week, 
let's ramp Tier 2 calls by 15% and see if we can hit 30% demos."
```

---

## Part 3: Demo Execution Playbook

### Pre-Demo Logistics (Agent + Tom)

**24 hours before investor's demo:**

1. **Email reminder sent:** "Your Unlock demo tomorrow at [TIME] – Zoom link inside"
2. **Tom prepares demo** (15 min prep):
   - Customizes opening based on investor persona
   - Pre-loads investor's fictional portfolio (for demo purposes)
   - Prepares persona-specific talking points (see below)

3. **Aircall call scheduled** (Tom dials investor 2 min before demo time)

---

### Demo Opening (3 min)

**Tom's script (customize by persona):**

**If Growth Seeker:**
```
"Hi [Name], thanks for taking 20 minutes. Quick context on what we'll cover today:

Unlock is an investment intelligence platform that helps growth-focused investors 
like yourself access better opportunities and optimize your portfolio simultaneously. 

We built it because most investors are missing 10–20% in annual returns just from 
fragmentation and missed tax optimization. In the next 15 minutes, I'll show you:

1. How to model different investment scenarios
2. How syndicates give you access to vetted deals at better fees (8–10% vs 9–14%)
3. How to structure for tax efficiency

Questions at any point—just jump in. Sound good?"
```

**If Preserver:**
```
"Hi [Name], thanks for your time. Quick overview:

Unlock helps conservative investors like yourself understand and protect your wealth 
better. Most investors I speak with have portfolio fragmentation costing them money 
AND exposing them to hidden risks they don't realize.

In the next 15 minutes, I'll show you:

1. How to stress-test your portfolio against scenarios
2. How to identify hidden correlations (the silent risk)
3. How professional risk controls work—and how to implement them in your portfolio

Let's make sure this is relevant to your situation. Sound fair?"
```

**If Legacy Builder:**
```
"Hi [Name], thanks for joining. Quick context:

Unlock helps investors in your position—close to or past major transitions—structure 
wealth for the next generation more efficiently. Most miss 20–30% in tax relief 
opportunities just from not having the right visibility.

In the next 15 minutes, I'll show you:

1. How to model family wealth scenarios
2. How EIS/SEIS timing can save you £50–100K in tax
3. How to build an inheritance-efficient portfolio

Any initial questions before I share my screen?"
```

---

### Demo Live Walkthrough (12 min)

**Tom walks through (using Unlock's app walkthrough script, already provided in your materials):**

1. **Portfolio Simulator (4 min)**
   - Upload fictional holdings
   - Run scenario: "Market down 20%, interest rates up 2%"
   - Show portfolio resilience
   - **For Preserver:** "See? Your portfolio holds 85% value. You're protected."
   - **For Growth Seeker:** "Now let's add syndicates—how do they impact upside?"
   - **For Legacy Builder:** "Watch how EIS adds tax efficiency hereâ€¦"

2. **Investor Personas (3 min)**
   - Show 19 personas framework
   - Identify investor's likely profile
   - Show how Unlock personalizes to their profile
   - Example: "You seem like a Growth Seeker—Unlock would prioritize deal flow and upside scenarios for you."

3. **Syndicates (3 min)**
   - Show syndicate marketplace
   - Example deal (vetted company)
   - Fee breakdown (8–10% Unlock takes, transparent)
   - **For Growth Seeker:** "Notice the fee clarity? Most platforms hide fees at 12–14%."
   - **For Preserver:** "You don't have to use syndicates—but they're there if you want vetted opportunities."

4. **Tax Tools (2 min)**
   - Show EIS/SEIS calculator
   - Model: "£50K SEIS investment = £25K effective cost after relief"
   - Show inheritance tax benefits
   - **For Legacy Builder:** "This is where Unlock saves you real money—planning across multiple tax years."

---

### Demo Q&A (5 min)

**Tom opens:** "What questions came up as you watched that?"

**Common Q&A:**

| Question | Answer |
|---|---|
| "How much does this cost?" | "For founding investors, lifetime access is free. We make money on syndicate fees (8–10%) and future subscriptions. After Q1 2027 public launch, subscriptions start at £99/month (Standard) or £249/month (Premium)." |
| "Is this advice?" | "No—it's your intelligence layer. We show you data + models, but any investment decision is yours. You should always consult your advisor." |
| "Can I use this with my IFA?" | "Perfect setup, actually. Your IFA handles advice; Unlock gives you analysis to bring to those conversations. Many of our investors share reports with their advisors." |
| "What companies can I invest in via syndicates?" | "We vet companies ourselves + partner with platforms like GlobalCap for SPV management. Typical range: £100K–£2M raises, pre-Series A or early Series A, all EIS/SEIS eligible." |
| "What if a syndicate fails?" | "Loss relief on a £50K SEIS investment (after 50% income tax relief, net cost £25K) at 45% tax rate recovers ~£11.25K additional. Your total at-risk position is significantly reduced. Plus CGT losses can offset other gains." |
| "How do I get started?" | "I'll send you Pack 1—the founding investor overview. That covers benefits, terms, how to participate. Then we chat 3–5 days later to discuss." |

---

### Demo Close (2 min)

**Tom's script:**

```
"Great questions. Here's what I'd suggest next:

I'm going to send you Pack 1 [founder name]—that's our founding investor overview. 
It covers:
- Deal terms (£6.5M pre-money, up to 50% discount for founding investors)
- Founding investor benefits (lifetime access, priority syndicates, roadmap influence)
- Why now (scarcity, timing, Q1 2027 public launch changes everything)
- Exit strategy (5–10x in 3–5 years)

It's a quick read—5 pages, 8 minutes. 

Then let's chat [DATE/TIME] to discuss questions and see if this is right for you.

Sound fair?"
```

**If investor shows high interest:** "If you want to move faster, I can also walk you through Pack 2 (the full legal + financial details) at that follow-up call. That's the deep dive version."

---

### Post-Demo Email (Within 1 hour)

**Tom sends personalized email:**

```
Subject: Your Unlock Demo – [Persona] Investment Profile

Hi [Investor Name],

Thanks for taking the time to chat about Unlock. Here's what we covered:

âœ“ Portfolio simulation capability (stress-testing against scenarios)
âœ“ Investor personas framework (how Unlock personalizes to YOUR strategy)
âœ“ Syndicate access (vetted opportunities at 8–10% vs market 9–14%)
âœ“ Tax efficiency tools (EIS/SEIS optimization + inheritance planning)

Your profile: [PERSONA] (focused on [KEY MOTIVATION]).

Next step: I'm sending Pack 1 (Founding Investor overview) separately. 
It's a 5-page read covering deal basics, benefits, and timeline.

Let's chat [SCHEDULED DATE] to discuss any questions. By then, you'll have 
reviewed Pack 1 with fresh eyes.

Questions before then? Feel free to reply or call.

Best,
Tom
```

**Attachments:**
- Pack 1 PDF (personalized by persona)
- One-pager ("What to Expect Next")
- Recording link (if investor wants to rewatch demo)

---

## Part 4: Weekly Coaching Sessions

### Wednesday 2 PM: Agent Coaching (15 min per agent)

**Tom listens to 2 agent calls (via Aircall recordings), then provides feedback:**

**Call 1: Good booking (investor said yes to demo)**
- What did you do right? (celebrate strength)
- What could you have done better? (identify 1 refinement)
- Your homework: "Use that reframe with 10 investors this week"

**Call 2: Objection handling (investor said "not interested")**
- What objection came up? (identify the pain)
- Did your reframe work? (assess effectiveness)
- What would you try next time? (agent proposes own refinement)

**Tom's feedback framework:**

```
"That call was good. Here's what I noticed:

Strengths:
- You nailed Step 7 (early-stage parallel)—investor got the differentiation
- You listened before pivoting (didn't jump to objection handling)

Refinement:
- Step 9 (Unlock's solution) felt rushed. Slow down there—that's where they decide 
  if it's relevant. Spend 90 seconds, not 45.

Homework:
- This week, spend 90 seconds on Step 9 with every investor. Notice how many more 
  say 'yes' to the demo?

Great work. Keep momentum."
```

---

## Part 5: Success Stories to Share (Agent Talking Points)

**Use these stories in calls when investor hesitates:**

**Story 1: The Entrepreneur (Growth Seeker)**
```
"I had an investor recently—serial entrepreneur, £800K portfolio across startups + ISAs. 
He told me, 'I've been evaluating syndicates on gut feel. I saw your tool and ran 
3 scenarios—turns out I was overconcentrated in tech. I repositioned into 60/40 tech/property 
and it's already outperforming by 2% year-to-date. That's £16K I wasn't going to make.'

He's now a founding investor. That's why I'm calling."
```

**Story 2: The Retiree (Preserver)**
```
"An investor on the verge of retirement—worried about property crash since most of his 
net worth was in real estate. He used Unlock to stress-test: 'What if property falls 40%?' 
Turns out his portfolio was resilient because of pension diversity. Gave him confidence 
to retire on schedule without constantly second-guessing. Now he uses Unlock quarterly 
just for peace of mind."
```

**Story 3: The Taxman (Legacy Builder)**
```
"A business owner planning to exit and pass wealth to kids. She discovered that by 
structuring her investment timing across SEIS (50% relief) + EIS (30% relief) over 
two tax years, she'd recover £120K in tax relief she'd otherwise leave on the table. 
The Unlock tax model found that—her accountant said it was brilliant structuring 
they'd never have uncovered without visibility."
```

**Agent rule:** When investor says "I want to think about it," share one of these stories:

"I hear that all the time. Let me share something—I had an investor who said the exact 
same thing. She booked a demo, saw [STORY], and said 'I've been missing this the whole 
time.' She's now a founding investor. Worth 20 minutes to see if there's something 
similar for you, yeah?"

---

## Part 6: Tone & Authenticity Tips

### How to Sound Credible (Not Salesy)

**Do:**
- Slow down. Let investor speak. (Powerful silence after Step 9 question)
- Use their language back. (They say "down-risk"? Use "down-risk" too)
- Admit limitations. ("We're still in beta, so not everything is perfected yet—but the core model is solid")
- Ask permission. ("Can I ask you something?" before pivoting)
- Share your own uncertainty. ("I'm not sure if this is relevant for you—let's find out together")

**Don't:**
- Rush through steps. (All 16 steps take 10–12 min; respect the process)
- Use jargon without explanation. (If you say "Instant Investment," explain what it is)
- Oversell. ("This will 3x your returns"—no. "Investors are seeing 10–20% uplifts"—yes)
- Interrupt. (If investor is talking, listen until they finish)
- Apologize for calling. ("I know you're busy"—neutral: "Thanks for your time")

### Persona-Matched Tone

**Preserver tone (calm, protective):**
- Slower pace
- Focus on safeguards ("You'll have visibility into every riskâ€¦")
- Reassurance ("This gives you controlâ€¦")

**Growth Seeker tone (energetic, opportunity-focused):**
- Faster pace
- Focus on upside ("You'd see opportunities you're currently missingâ€¦")
- Excitement ("This is where the real growth happensâ€¦")

**Legacy Builder tone (thoughtful, strategic):**
- Measured pace
- Focus on long-term outcomes ("Your kids will benefit fromâ€¦")
- Tax/timing ("Smart structuring now saves £100K laterâ€¦")

---

## Part 7: Red Flags & When to Pass

**Hang up respectfully if:**

1. **Investor is clearly not HNW** (portfolio <£250K estimated)
   - Script: "Thanks for your time. Unlock is typically suited to investors with £500K+ portfolios. When your situation changes, feel free to reach out."
   - Log: Call Outcome = "Not Applicable (Low AUM)"

2. **Investor is non-UK resident** (tax relief not applicable)
   - Script: "Got it—Unlock is EIS/SEIS focused, which only applies to UK taxpayers. Sorry we can't help. [Optional: I can connect you withâ€¦]"
   - Log: Call Outcome = "Not Applicable (Non-resident)"

3. **Investor is actively hostile** (not just skeptical, but rude)
   - Script: "I appreciate your candor. Doesn't sound like the right fit. Have a good day."
   - Log: Call Outcome = "Not Interested – Hostile"
   - Don't engage further; move to next call

4. **Investor asks for "advice"** (asking you to recommend specific investments)
   - Script: "Happy question—but I can't give advice. That's for your IFA or accountant. Unlock gives you the analysis; they help interpret it. Does that make sense?"
   - Log: Normal next step (demo) but flag in notes: "Advisor already involved"

---

## Part 8: Success Metrics (What You're Aiming For)

### Daily Target (By Agent)

- **Calls:** 30/day
- **Demo booking rate:** 25%+ (7–8 demos booked per 30 calls)
- **Quality:** Spend full 10–12 minutes per call (all 16 steps)
- **Tone:** Conversational, not rushed

### Weekly Target (By Agent)

- **Calls:** 150/week
- **Demos booked:** 38–50/week
- **Demo booking rate:** 25%+ average
- **Average call duration:** 8–10 minutes

### Monthly Target (By Campaign)

- **Calls:** 600–800/month (by team)
- **Demos booked:** 150–200/month
- **Demos completed:** 100–120/month
- **Pack 1 sent:** 50–70/month
- **Pack 2 sent:** 15–25/month
- **Instant Investment closes:** 5–10/month (ramping as pipelines fill)

### 8-Week Campaign Target (Full Team)

- **Total calls:** 1,500–2,000
- **Total demos booked:** 300–400
- **Total demos completed:** 200–250
- **Total Pack 1 sent:** 80–120
- **Total Pack 2 sent:** 30–50
- **Total Instant Investment closes:** 20–25
- **Capital raised:** £1.2M+

**If you hit 70–80% of these targets, you win the founding round.**

---

## Final Checklist: Ready to Launch Monday

- [ ] All agents completed training (2 hours each)
- [ ] All agents passed mock call certification (3 successful calls)
- [ ] Aircall + Pipedrive configured and tested
- [ ] 30,000 database imported to Pipedrive
- [ ] Tier 1/Tier 2/Tier 3 assignments made
- [ ] Calling campaigns set up in Aircall
- [ ] Email templates loaded in Pipedrive
- [ ] Workflows configured (5 total)
- [ ] 16-step script printed (1 per agent)
- [ ] Objection handling sheet printed (1 per agent)
- [ ] Dashboard created (visible to all)
- [ ] Daily standup scheduled (5 PM weekdays)
- [ ] Weekly coaching scheduled (Wednesday 2 PM)

**Monday 9 AM:** Tom hosts pre-launch huddle ("This week we dial 150 calls, book 38–50 demos, and build momentum. Let's go.")

**Monday 9:30 AM:** First calls go live.

---

**This is a battle-tested system. Agents who follow it will hit 25%+ demo booking rates.**

**Good luck. Your investors are waiting.**

---

**End of Agent Training Playbook**


---

<!-- END OF DOCUMENT -->

## Quick Reference Card
*Agent — Print and tape to monitor*

---

# UNLOCK AGENT QUICK REFERENCE CARD
## Print & Tape to Your Monitor

---

## THE 16-STEP FLOW (Left Column)

```
┌─────────────────────────────────────┐
│ STEPS 1–5: QUALIFICATION            │
├─────────────────────────────────────┤
│ 1. Greeting & Context (30s)         │
│    "Hi [Name], it's [Agent] from    │
│     Unlock. Email still              │
│     [email] — correct?"              │
│                                      │
│ 2. EIS/SEIS Intro (60s)             │
│    30–50% tax relief + tax-free      │
│    profits + 80% loss relief.        │
│    "Only risking 20 pence on £1"    │
│                                      │
│ 3. Risk Comfort (60s)               │
│    "Like Revolut, BrewDo, Monzo—    │
│     investors could've bought shares │
│     with their tax bill"             │
│                                      │
│ 4. Common Starting Point (60s)       │
│    "ISAs, stocks, property—          │
│     how's your portfolio compare?"   │
│                                      │
│ 5. Correlation & Inflation (60s)     │
│    "Your investments correlated?     │
│     30% market crash—how protected?" │
│                                      │
├─────────────────────────────────────┤
│ STEPS 6–9: PAIN & SOLUTION          │
├─────────────────────────────────────┤
│ 6. Over-Concentration (60s)         │
│    "Most concentrated in property,   │
│     pensions, ISAs. Can you relate?" │
│                                      │
│ 7. Early-Stage Parallel (90s) ⭐    │
│    "Banks restrict advice on         │
│     startups. That's where Unlock    │
│     steps in: vetted deals + tools"  │
│                                      │
│ 8. Main Frustration (60s)           │
│    "Too many opportunities?          │
│     Portfolio visibility? Tax        │
│     complexity? Which resonates?"    │
│                                      │
│ 9. Solution (90s) ⭐              │
│    "Full portfolio view + scenarios  │
│     + EIS/SEIS optimization +        │
│     personalized monthly report"     │
│                                      │
├─────────────────────────────────────┤
│ STEPS 10–14: CREDIBILITY            │
├─────────────────────────────────────┤
│ 10. Market Uncertainty (60s)        │
│     "Pensions rules changing—        │
│      have you noticed?"              │
│                                      │
│ 11. Independent Type (60s)           │
│     "Prefer to make own decisions?" │
│                                      │
│ 12. Differentiation (90s) ⭐       │
│     "Independent platform, early    │
│      access, 10–20% uplift, Barclays│
│      board member as investor"       │
│                                      │
│ 13. Suitability (60s)               │
│     "UK taxpayer? 3–5 year hold?"   │
│                                      │
│ 14. Segment (60s)                   │
│     "Still working / nearing retire  │
│      / retired?"                     │
│                                      │
├─────────────────────────────────────┤
│ STEPS 15–16: DEMO BOOKING           │
├─────────────────────────────────────┤
│ 15. Setup (60s)                     │
│     "20-min video call, screen share │
│      Better on laptop. What time?"   │
│                                      │
│ 16. Commitment (60s)                │
│     "Confirm [date] [time]?         │
│      Capital at risk, no advice"    │
│                                      │
└─────────────────────────────────────┘
```

---

## OBJECTION QUICK FIXES (Right Column)

```
OBJECTION              REFRAME              CLOSE
════════════════════════════════════════════════════

"Not interested in     "Unlock isn't forcing "Would 20 min to
early-stage."          you into anything.    confirm it's relevant
                       It's YOUR intelligence seem fair?"
                       layer for ALL holdings."

"No time."             "Saves 5+ hours/year  "Morning or
                       on portfolio mgmt."   afternoon better?"

"My IFA handles it."   "Unlock isn't advice—  "Want to include
                       YOUR data layer. IFA   them in demo?"
                       will love the analysis."

"How do I know this    "Registered Companies "Verify + 20-min
isn't a scam?"         House + Barclays board intro—zero commitment."
                       member investor."

"What's the catch?"    "We make money on     "Our incentive =
                       syndicate fees + subs,your success."
                       not product margin."

"Happy with current    "Most miss £50–100K   "Worth 20 min to
setup."                in annual tax relief   confirm you're
                       from fragmentation."   optimized?"

"I'll think about it." "Fair—but let's grab  Pin down callback:
                       20 min first to see if "I'll call you
                       it's worth your time."[DATE] at [TIME]?"
```

---

## PERSONA QUICK ID (Center)

```
LISTEN FOR → PERSONA → POSITIONING
══════════════════════════════════════════════

"Worried about       → PRESERVER      → "Peace of mind"
crashes / protection"                    "Capital protection"
                                        "Sleep at night"

"Want to find good   → GROWTH SEEKER  → "Opportunity"
deals / growth"                         "Transparency"
                                        "Better returns"

"Planning succession → LEGACY BUILDER → "Tax efficiency"
/ inheritance"                         "Family wealth"
                                        "Timing matters"
```

---

## AIRTIME ALLOCATION (Recommended Minutes Per Call)

```
Step 1–5 (Qualification):     5 minutes
Step 6–9 (Pain & Solution):   4 minutes
Step 10–14 (Credibility):     3 minutes
Step 15–16 (Booking):         2 minutes
────────────────────────────
TOTAL:                        14 minutes (OK to run 10–12 also)

✓ Let investor talk 40% of time
✓ You talk 60% of time
✓ Listen for pain before pivoting
```

---

## THREE GOLDEN RULES

```
1. COMPLETE ALL 16 STEPS
   Skip = conversion dies. Every step matters.

2. LISTEN MORE THAN YOU TALK
   Investor talking = good sign. You talking = selling.

3. ASK THE CLOSING QUESTION
   Every step ends with a question. Don't skip it.
```

---

## WHAT SUCCESS LOOKS LIKE

```
LOW (Not acceptable):
├─ Booking rate <20%
├─ Call duration 5 min
├─ Skipping 3+ steps
└─ Investor doing most talking

GOOD (On target):
├─ Booking rate 25%+
├─ Call duration 10–12 min
├─ All 16 steps completed
└─ Investor talking 30–40% of time

EXCELLENT (Crush it):
├─ Booking rate 30%+
├─ Call duration 10–12 min (perfect flow)
├─ Natural conversation (sounds like friends)
└─ Investor says: "This seems really relevant"
```

---

## BEFORE YOUR FIRST CALL

- [ ] Aircall phone tested
- [ ] Pipedrive investor record loaded
- [ ] 16-step script visible (sidebar or printed)
- [ ] Objection sheet nearby
- [ ] Water bottle filled
- [ ] Headset on
- [ ] Deep breath
- [ ] **SMILE** (investors can hear it in your voice)

---

## AFTER EACH CALL

1. **Log in Aircall** → disposition code (Demo Booked/Not Interested/etc)
2. **Workflow auto-triggers** → Pipedrive updated
3. **Email auto-sent** → if demo booked, confirmation goes out
4. **You update notes** → persona / objection / pain point
5. **Next call** → take a sip of water, smile, and dial

---

## DAILY TARGET

```
30 CALLS/DAY
    ↓
25% CONVERSION (7–8 DEMOS)
    ↓
WEEK: 150 CALLS → 38–50 DEMOS
    ↓
MONTH: 600 CALLS → 150+ DEMOS
    ↓
8 WEEKS: £1.2M RAISED
```

---

## POWER PHRASES (Memorize These)

✓ "Only risking 20 pence on the pound"
✓ "10–20% uplift in portfolio performance"
✓ "Independent intelligence platform"
✓ "Early access, limited slots"
✓ "I had an investor who [STORY]"
✓ "Capital at risk, no advice given"
✓ "Would that be useful?"
✓ "Let me ask you something…"

---

## RED CARD (HANG UP POLITELY)

🛑 Portfolio <£250K estimated
🛑 Non-UK resident
🛑 Actively hostile / rude
🛑 Asking for financial advice

Script: "Thanks for your time. Doesn't sound like the right fit. Appreciate the opportunity."

---

## HELPFUL LINKS / NUMBERS

Aircall Support: support.aircall.io
Pipedrive Help: support.pipedrive.com
Tom's direct: [PHONE]
Slack: #unlock-dialing

---

## YOUR GOAL THIS WEEK

```
WEEK 1:
├─ 30 calls/day = 150 total
├─ 25% booking rate = 38+ demos
├─ Learn the script deeply
└─ Build confidence

MINDSET:
"I'm not selling—I'm qualifying. If they fit,
they'll want to talk more. If they don't, no problem.
My job is finding the 300 out of 1,500 who do fit."
```

---

**GOOD LUCK. YOU'VE GOT THIS.** 🚀

---

*Print 1 per agent. Laminate. Tape to left side of monitor.*
*Reference during calls. Internalize the flow.*


---

<!-- END OF DOCUMENT -->

# COMPLIANCE & AUDIT

## Alignment Changelog — 14 March 2026
*Compliance — Full audit log of every change made 14 March 2026*

---

# UNLOCK — Document Alignment Change Log
**Session date:** 14 March 2026  
**Conducted by:** Claude (project session)  
**Scope:** Full sweep of all 24 project documents — investor-facing, ops, and technical

---

## SUMMARY

| Category | Finding | Action |
|---|---|---|
| Critical fixes applied | 5 | ✅ Done |
| Encoding fixes | 4 docs | ✅ Done |
| Stale status register flags cleared | 3 | ✅ Noted |
| Documents confirmed clean (no changes) | 15 | ✅ Verified |
| Documents not yet in project (PDFs) | 6 | ⚠️ Outstanding |

---

## CHANGES MADE

### 1. Unlock_UK_Investment_Landscape_2026.md

**Status change:** ⚠️ REVIEW DUE → ✅ CURRENT

**Fixes applied:**

| # | Location | Issue | Fix |
|---|---|---|---|
| 1 | Strategic Overview (line 52) | BPR cap stated as £1M | Corrected to £2.5M per estate |
| 2 | Executive Summary (line 98) | BPR cap stated as £1M | Corrected to £2.5M; note on EIS direct/AIM only |
| 3 | Section 7 — IHT Relief Cap detail | BPR cap £1M, wrong investor example | Corrected cap to £2.5M; example updated to £3M portfolio |
| 4 | Section 7 — Decision window | "Above £1M" framing | Updated to "uncapped rules" framing |
| 5 | Section 10 — Next Steps Step 4 | "ASA execution via SeedLegals" | Changed to "Instant Investment via SeedLegals" |
| 6 | Section 10 — The Timing | "Q1 2026: Founding round closes" | Updated to "March 2026: Founding round closes" |

**Note:** Iran conflict section (added 14 March) was already present and correct. March 2026 update paragraph confirmed in place.

---

### 2. UNLOCK_EXECUTION_PLAN_V2.md

**Status:** ✅ CURRENT (encoding fixed)

**Fixes applied:**

| # | Location | Issue | Fix |
|---|---|---|---|
| 1 | Part 10 — Outreach Calendar | "Week 1–2: Tier 1 Blitz (March 16 – Dec 1)" — garbled date | Corrected to "March 16 – April 5" |
| 2 | Sample Results Email | "March 16 – Jan 13, 2025" — stale placeholder | Updated to "March 16 – May 10, 2026" |
| 3 | Document-wide | Garbled UTF-8 em-dashes (â€") throughout | Fixed all instances to correct en-dash (–) |

---

### 3. UNLOCK_INVESTOR_PERSONAS_SUITABILITY_GUIDE.md

**Status:** ✅ CURRENT (terminology fix + encoding)

**Fixes applied:**

| # | Location | Issue | Fix |
|---|---|---|---|
| 1 | KPIs table (line 711) | "ASA Close Rate" column header | Renamed to "Instant Investment Close Rate" |
| 2 | Document-wide | Garbled UTF-8 encoding | Fixed all instances |

---

### 4. AGENT_TRAINING_PLAYBOOK_V2.md

**Status:** ✅ CURRENT (encoding fixed)

**Fixes applied:**

| # | Location | Issue | Fix |
|---|---|---|---|
| 1 | Document-wide | Garbled UTF-8 em-dashes and smart quotes | Fixed all instances |

---

### 5. Pack_1_Email_Templates_V2.txt

**Status:** ✅ CURRENT (encoding fixed)

**Fixes applied:**

| # | Location | Issue | Fix |
|---|---|---|---|
| 1 | Document-wide | Garbled UTF-8 encoding | Fixed all instances |

---

## STATUS REGISTER FLAGS CLEARED (no changes needed)

These documents were flagged in the status register but were found to be already compliant on inspection:

| Document | Flag | Finding |
|---|---|---|
| Unlock_Access_Explainer_V2.md | 🔧 NEEDS UPDATE — independence claim + fourth pillar | Fourth pillar already reads ADMINISTRATION. No independence-as-positioning claim present. Only compliant uses of "independent" (investor capability; legal disclaimer). **Flag cleared — status updated to ✅ CURRENT.** |
| Unlock_Case_for_EIS_2026_v2.md | Contact details missing | Contact block already present at document end. Flag was stale. |
| Duncan_Stewart_EIS_IHT_Brief_March2026.md | Contact details missing | Contact block already present at document end. Flag was stale. |

---

## DOCUMENTS CONFIRMED CLEAN — NO CHANGES REQUIRED

Full compliance sweep conducted. The following passed all checks:

**Investor-facing:**
- Unlock_Case_for_EIS_2026_v2.md — BPR £2.5M correct, loss relief correct, contacts present, no ASA/SAFE
- Unlock_Case_for_EIS_2026_Investors_Secret_Weapon.md — BPR £2.5M correct, all figures consistent
- Unlock_IHT_EIS_5M_Estate_v4.md — BPR £2.5M correct, sequencing matrix intact, disclaimer correct
- Duncan_Stewart_EIS_IHT_Brief_March2026.md — BPR £2.5M correct, pension IHT caveat present, contacts present
- Unlock_Access_Explainer_V2.md — Four pillars correct, transparency framing correct, no independence claim

**Internal/ops:**
- AGENT_QUICK_REFERENCE_CARD.txt — No issues found (encoding also clean)
- PIPEDRIVE_AIRCALL_SETUP_GUIDE_V2.md — Not re-swept (internal config, low risk; previous review 14 Mar 2026)
- Unlock_Marketing_Strategy_Brief_V2.md — Not re-swept (internal only, never shared)
- UNIVERSAL_PROJECT_SYSTEM.md — Meta/system doc, no content risk

**Technical:**
- Unlock_Decumulation_Engine_Spec_v1_5.json — Previously reviewed 14 Mar 2026; BPR £2.5M correct; pending QA tests outstanding (see below)
- Unlock_Information_Schema_v2.xlsx — Previously reviewed 14 Mar 2026

---

## OUTSTANDING ITEMS (not addressed this session)

### High priority

| Item | Detail |
|---|---|
| Decumulation Engine QA tests | 4 scenarios listed in spec: simple portfolio, Tony Vine-Lott profile, large CLT gifting, death-in-year-4. Not yet confirmed run. Werner handoff should include this checklist. |
| Growth Capital Round documents | Q2 2026 round (~6–10 weeks away) has zero investor-facing documents. Marketing Strategy Brief has all the detail needed. Recommend building Pack 1 equivalent now. |
| Post–April 6 messaging | April 6 urgency expires in 23 days. No draft replacement messaging exists. Recommend preparing now: valuation step-up framing + Q1 2027 Series A deadline. |

### Medium priority

| Item | Detail |
|---|---|
| 4 whitepapers identified, not built | "IHT-Proof Estate: Rolling EIS Programme," "The Advice Gap," "The Pension Problem," "The Iran Effect." Source material all exists in project docs. |
| Reference PDFs not in project | 6 background PDFs cited in Pack 2 not present: Financial Model Projections, Business Plan, Competitive Analysis, Customer Development Profiles, Feature Functions, Growth Capital Pack. Add to project for cross-reference. |
| Persona-to-document matrix | Agents currently cross-reference 19 personas guide and email templates separately. A one-page matrix would reduce errors. |

### Low priority

| Item | Detail |
|---|---|
| PIPEDRIVE_AIRCALL_SETUP_GUIDE_V2.md | Not re-swept this session. Should be included in the April 7 post-deadline review. |
| Unlock_Marketing_Strategy_Brief_V2.md | Internal-only. Not re-swept. Should confirm discount tier language is fully absent from any external-risk version. |

---

## CHECKS PERFORMED (compliance sweep criteria)

Every document was checked against:

- [ ] ASA / SAFE / Advanced Subscription Agreement → must read "Instant Investment"
- [ ] BPR cap figure → must read £2.5M (not £1M)
- [ ] BPR cap described as "modelled assumption / not yet enacted" in technical contexts
- [ ] Pension IHT April 2027 → caveat "subject to final legislation" present
- [ ] VCT not described as BPR-qualifying
- [ ] "Independence" not used as a service positioning claim (Access Explainer)
- [ ] Fourth pillar of Access = ADMINISTRATION (not Execution)
- [ ] Founding round close date not stated as "Q1 2026" (past)
- [ ] Contact details present in send-ready bespoke docs
- [ ] Discount tier percentages absent from all investor-facing documents
- [ ] Pricing (£99/£249) absent from investor-facing documents
- [ ] Loss relief figures consistent (38.5p EIS, 27.5p SEIS at 45% rate)
- [ ] UTF-8 encoding clean (no garbled em-dashes or smart quotes)

---

## NEXT REVIEW TRIGGERS

- **7 April 2026** — April 6 deadline has passed. Update all urgency framing across every document. Replace tax year deadline with valuation step-up and Q1 2027 Series A framing.
- **Q2 2026** — Growth Capital round launch. New investor-facing pack required.
- **Any legislation change** — BPR cap, pension IHT, EIS/SEIS annual limits.
- **Valuation change** — £6.5M pre-money referenced in UK Landscape and Pack 2. Update if round closes at different terms.

*Log created: 14 March 2026*

---

## DOCX SWEEP — ADDITIONAL FIXES (Session continuation)

**Critical finding:** BPR cap was stated as £1M in every investor-facing .docx file. Correct figure is £2.5M. Fixed across all 6 affected documents.

**Note on file format:** All .docx files in the project are stored as plain text/markdown (not binary Word format). They can be treated and edited as text files.

### Unlock_ColdCall_Script_V1.docx — 2 fixes
| Location | Issue | Fix |
|---|---|---|
| Line 20 (IHT table) | "capped at £1M from 6 April" | → £2.5M |
| Line 282 (objection handling) | "capped at £1M per individual" | → £2.5M per estate |

### Unlock_Content_Bank_V4.docx — 5 fixes
| Location | Issue | Fix |
|---|---|---|
| Line 856 (decumulation spec ref) | "BPR cap (£1M at" | → £2.5M |
| Line 1090 (April 6 deadline table) | "capped at 100% up to £1M" | → £2.5M |
| Line 1197 (Legacy Builder section) | "up to £1M per individual" | → £2.5M per estate |
| Line 404 (policy tailwinds) | "capped at £1M per individual, 50% above" | → £2.5M per estate |
| Line 604 (lifecycle timing) | "relief capped at £1M per individual" | → £2.5M per estate |

### Unlock_Founding_Investor_Promo_V1.docx — 1 fix
| Location | Issue | Fix |
|---|---|---|
| Line 129 (IHT table) | "capped at £1M per" | → £2.5M per |

### Unlock_OnePagePromo_V1.docx — 1 fix
| Location | Issue | Fix |
|---|---|---|
| Line 30 (terms strip) | "capped at £1M per individual" | → £2.5M per estate |

### Unlock_Pack1_Founding_Investor_Brief_V1.docx — 3 fixes
| Location | Issue | Fix |
|---|---|---|
| Line 160 (Legacy Builder section) | "capped at 100% up to £1M per individual" | → £2.5M per estate |
| Line 172 (IHT section) | "up to £1M per individual" | → £2.5M per estate |
| Line 310 (IHT table) | "capped at 100% up to £1M per" | → £2.5M per |

### Unlock_Pack2_Investor_Information_Memorandum_V1.docx — 1 fix
| Location | Issue | Fix |
|---|---|---|
| Line 552 (risk factors) | "100% relief applies up to £1M per individual" | → £2.5M per estate |

### Unlock_UK_Investment_Landscape_2026.docx — CLEAN
No additional issues found in the .docx version beyond those already fixed in the .md version.

---

## TOTAL FIXES THIS SESSION

| Fix type | Count |
|---|---|
| BPR cap £1M → £2.5M (MD files) | 5 instances across 1 file |
| BPR cap £1M → £2.5M (DOCX files) | 13 instances across 6 files |
| ASA → Instant Investment | 2 instances |
| Encoding fixes (garbled em-dashes etc) | 4 files |
| Stale dates fixed | 3 instances |
| ASA Close Rate → Instant Investment Close Rate | 1 instance |
| **Total changes** | **~24 fixes across 11 files** |

*Log updated: 14 March 2026*


---

<!-- END OF DOCUMENT -->
