# UNLOCK — AGENT BRIEF & CLAUDE SESSION CONTEXT
## How to Use This Project | V1 | Current
**Last updated:** 14 March 2026

---

## WHAT THIS PROJECT IS

Unlock is raising a Founding Investor round from a 30,000-contact database. This Claude project contains every document, script, template, and spec needed to run that campaign — from first call to Instant Investment close.

**You are Tom King, founder.** Claude is your campaign intelligence layer.

---

## APPROVED TERMINOLOGY — USE THESE EXACT WORDS

| ✅ Say this | ❌ Never say this |
|---|---|
| Instant Investment | ASA / Advanced Subscription Agreement / SAFE |
| £2.5M BPR cap per estate | £1M BPR cap |
| Negotiated individually | Specific discount percentages |
| Transparency / full disclosure | Independent (as a positioning claim) |
| ADMINISTRATION (fourth pillar) | Execution (old fourth pillar name) |
| Growth Capital Round (Q2 2026) | Second round / Series A (at this stage) |

---

## DOCUMENT HIERARCHY

**When in doubt about what to say or send, check in this order:**

1. `700_CONTENT_Bank_V4` — master source of truth for all messaging
2. The specific document being used
3. `020_GLOSSARY_Terms` — for precise wording
4. This file — for context and rules

**Never derive investor-facing copy from memory. Always anchor to 700_.**

---

## THE INVESTOR JOURNEY (5 pipeline stages)

| Stage | Pipedrive stage | Document sent | Follow-up |
|---|---|---|---|
| 1 | Outreach Queued | — | Call from `500_SCRIPT` |
| 2 | Called → Demo Booked | — | Demo confirmation email (`230_EMAILS`) |
| 3 | Demo Scheduled | `100_` or `110_` One-pager / Promo | 24hr reminder |
| 4 | Demo Complete | `120_BRIEF` Pack 1 | Call in 3–5 days |
| 5 | Pack 1 → Decision | `130_IIM` Pack 2 | Advisor loop → close |

---

## THREE INVESTOR PERSONAS

| Persona | % of HNW | Key language | Lead document |
|---|---|---|---|
| Preserver | 30% | "capital protection," "peace of mind," "risk controls" | `190_LANDSCAPE` |
| Growth Seeker | 40% | "upside," "transparency," "deal flow," "syndicates" | `150_CASE` Secret Weapon |
| Legacy Builder | 30% | "inheritance," "IHT," "family," "succession" | `170_PLANNING` IHT Estate |

19 detailed sub-personas in `520_GUIDE_Investor_Personas`.

---

## KEY FIGURES — MEMORISE THESE

| Figure | Value | Note |
|---|---|---|
| Pre-money valuation | £6.5M | Founding round |
| Raise target | £1.2M+ | 25 founding investors |
| Ticket range | £20K–£500K | |
| Database size | 30,000 | Segmented Tier 1/2/3 |
| EIS income tax relief | 30% | Up to £1M/year (£2M KIC) |
| SEIS income tax relief | 50% | Up to £200K/year |
| BPR cap (from Apr 6) | £2.5M per estate | EIS direct + AIM only. VCT excluded. Announced, not enacted. |
| VCT relief drop | 30% → 20% | From April 6, 2026 |
| Pension IHT exposure | From April 2027 | Subject to final legislation |
| EIS loss relief (45% taxpayer) | ~38.5p/£ | On net loss after income tax relief |
| SEIS loss relief (45% taxpayer) | ~27.5p/£ | On net loss after income tax relief |
| Platform pricing | £99/£249 | INTERNAL ONLY — never in investor docs |
| Campaign start | 16 March 2026 | |
| April 6 deadline | 23 days away | Tax year + BPR rule change |

---

## COMPLIANCE RULES — CHECK EVERY INVESTOR DOC

Before any investor-facing document is sent or updated:

- [ ] BPR cap = £2.5M (not £1M)
- [ ] Investment instrument = "Instant Investment"
- [ ] No discount percentages published
- [ ] No platform pricing (£99/£249) visible
- [ ] Pension IHT caveat present where referenced
- [ ] BPR cap caveat present in technical contexts ("announced, modelled — not yet enacted law")
- [ ] Contact details present: tom@unlockdd.com | www.unlockdd.com
- [ ] Legal disclaimer present on all investor docs

---

## UPCOMING BUILD ITEMS

| Priority | Item | Target |
|---|---|---|
| 🔴 Urgent | Post–April 6 messaging (`196_`) | Ready by April 7 |
| 🔴 High | Growth Capital Round pack (`195_`) | Ready by end of April |
| 🟡 Medium | Decumulation Engine QA — send to Werner | This week |
| 🟡 Medium | 4 whitepapers (`320_`–`350_`) | May 2026 |

---

## WHAT CHANGED ON 14 MARCH 2026

Full change log in `600_CHANGELOG_Alignment_14Mar2026`. Summary:

- **BPR cap corrected from £1M → £2.5M** across every document (13 fixes in docx files alone — this was the most widespread error)
- ASA/SAFE → Instant Investment (2 remaining instances fixed)
- Encoding corruption fixed across 4 ops docs
- Stale dates corrected in execution plan
- 3 status register flags cleared (documents were already compliant)

---

*Brief created: 14 March 2026*
