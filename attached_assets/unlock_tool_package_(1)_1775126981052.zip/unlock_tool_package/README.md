# Unlock — Tool Package
## Complete build package | 2 April 2026

---

## Start Here

| File | What it is |
|---|---|
| `MISSING_CONTENT_BRIEF.md` | What doesn't exist yet, why it matters, and what to build first |
| `specs/SBDS_Unlock_Content_Intelligence_V2.md` | Full platform spec — 28 FRs, 20 sections, build-ready |
| `schema/registry.json` | Complete document registry — seed file for the platform |
| `schema/leads.json` | Sample leads — Duncan Stewart, Sarah Mitchell, James Whitfield |
| `schema/compliance_constants.json` | All compliance constants with notes |

---

## Package Structure

```
/specs
  SBDS_Unlock_Content_Intelligence_V2.md   ← Platform spec (current)

/schema
  SCHEMA_SUMMARY.json                      ← Master schema reference
  registry.json                            ← Full document registry (seed)
  leads.json                               ← Sample lead records (seed)
  compliance_constants.json                ← Compliance constants (seed)
  400_SPEC_Decumulation_Engine_V1_5.json   ← Decumulation Engine algorithm
  000_INDEX_Unlock_Project_Map.md          ← Project index

/content                                   ← Tier 1 source of truth
  700_CONTENT_Bank_V4_CURRENT.md           ← Master messaging (all copy anchors here)
  520_GUIDE_Investor_Personas_19.md        ← 19 personas — signals, pain points, objections
  190_LANDSCAPE_UK_Investment_2026.md      ← UK market report / lead magnet

/investor_docs                             ← All current investor-facing send documents
  100_PROMO_One_Page                       ← Cold outreach
  110_PROMO_Founding_Investor_Three_Page   ← Cold outreach, forwardable
  120_BRIEF_Pack1_Founding_Investor        ← Post-demo (Pack 1)
  130_IIM_Pack2_Information_Memorandum     ← Decision stage (Pack 2 / IIM)
  140_EXPLAINER_Access_Service             ← Unlock Access supplementary
  150_CASE_EIS_Investors_Secret_Weapon     ← EIS education, cold HNW
  160_CASE_EIS_2026_Five_Case_Studies      ← EIS worked examples
  170_PLANNING_IHT_EIS_5M_Estate          ← IHT/EIS planning, Legacy Builder
  180_BRIEF_Duncan_Stewart_Bespoke         ← Bespoke — not for general use
  190_LANDSCAPE_UK_Investment_2026         ← Long-form lead magnet (also in /content)

/campaign                                  ← Internal ops — never share with investors
  200_PLAN_Execution_30K_Database          ← Master outreach plan
  210_PIPELINE_Pipedrive_Aircall_Setup     ← CRM configuration
  220_STRATEGY_Marketing_Investor_Conversion ← Full strategy (internal only)
  230_EMAILS_Pack1_Templates               ← Email templates, all pipeline stages

/agent_tools
  500_SCRIPT_Cold_Call                     ← 9-section call script
  510_PLAYBOOK_Agent_Training              ← 2-hour training programme
  530_CARD_Agent_Quick_Reference           ← Print and tape to monitor

/compliance
  600_CHANGELOG_Alignment_14Mar2026        ← Full audit log
  010_INSTRUCTIONS_Agent_Brief             ← Session instructions
```

---

## Platform Architecture (4 Layers)

**Layer 1 — Recommendation Engine**
Transcript → persona detection (Pass 1) → deterministic eligibility filter → AI ranking (Pass 2) → email draft → send log

**Layer 2 — Lead History & Engagement Tracker**
Lead records, send logs (immutable), deduplication, stage progression, next best action

**Layer 3 — Content Management Infrastructure**
Document registry, propagation alerts, compliance panel, Content Bank browser

**Layer 4 — Content Generation & QC Engine**
Generate missing docs → QC evaluation (separate API call) → source trace → DRAFT registration → user confirms → CURRENT promotion

---

## Critical Rules (non-negotiable)

| Rule | Detail |
|---|---|
| Deduplication before AI | Already-sent doc IDs excluded before Pass 2 call |
| Deterministic eligibility | AI ranks only what system has pre-approved |
| Pass 1 ≠ Pass 2 | Analysis and ranking are separate API calls with separate outputs |
| QC ≠ Generator | Separate system prompt, no shared context, ever |
| Always DRAFT first | Generated docs never auto-promote to CURRENT |
| Max 2 regen attempts | After 2 failures: MANUAL_REVIEW_REQUIRED, no auto-promotion |
| Immutable send logs | Corrections appended only — never edit in place |
| Seed validation on startup | Blocks UI if any validation fails |

---

## Compliance Constants (always visible in platform)

| Constant | Value |
|---|---|
| BPR cap | £2,500,000 — "subject to final enactment" |
| VCT income tax relief | 20% (NOT 30%) |
| Pension IHT change | April 2027 — "subject to final enactment" |
| Decumulation Planner | "Specification complete. Prototype build commencing." |
| Access framing | Structured disclosure — not scoring or advice |
| Instrument | Instant Investment (NOT ASA) |
| Tagline | "Clarity, without complexity" |

---

## Build Sequence (do not deviate)

```
Stage 1:  lead resolution → transcript analysis → deterministic filter
          → ranking → send confirmation → history write

Stage 2:  email draft → blocked-doc enforcement → registry/changelog
          → propagation → pipeline stage suggestion → visual polish

Stage 3:  generation brief → generation API call → QC API call
          → regeneration loop → promotion flow → test protocol
```

First Stage 3 test case: `196_MESSAGING_Post_April6` — generates real content needed within 4 days.

---

## Performance SLAs

| Operation | Limit |
|---|---|
| Pass 1 + Pass 2 combined | ≤ 15 seconds (transcripts < 3,000 tokens) |
| QC evaluation | ≤ 10 seconds (documents < 2,000 words) |
| Seed validation | ≤ 2 seconds |
| Registry load | ≤ 1 second (up to 100 documents) |
| Pass 2 candidate cap | Maximum 8 documents |

